export const Header = (): JSX.Element => {
  return (
    <header className="flex flex-col w-full items-start">
      {/* Top row: badge with title + vector connector */}
      <div className="items-end justify-center inline-flex flex-[0_0_auto]">
        {/* Blue rounded badge containing the title */}
        <div className="items-start gap-2.5 px-[120px] py-20 bg-[#0070d2] rounded-[180px_180px_0px_0px] inline-flex flex-[0_0_auto]">
          <h1 className="flex items-center w-fit mt-[-1.00px] [font-family:'Poppins',Helvetica] font-semibold text-neutral-00 text-[150px] tracking-[0] leading-[225px] whitespace-nowrap">
            Light Theme
          </h1>
        </div>

        {/* SVG vector that creates the curved transition to the right */}
        <img
          className="w-[295px] h-[292px]"
          alt="Vector"
          src="/figmaAssets/vector-1.svg"
        />
      </div>

      {/* Thin blue bar extending to the right with rounded right corners */}
      <div className="self-stretch w-full h-[46px] bg-[#0070d2] rounded-[0px_50px_50px_0px]" />
    </header>
  );
};
