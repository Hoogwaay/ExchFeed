# Employee Panel (Панель сотрудника)

## Overview
A work dashboard for employees to manage review tasks assigned to clients. Built with React + TypeScript frontend and Express + PostgreSQL backend.

## Architecture
- **Frontend**: React 18, Vite, TanStack Query, Wouter, Tailwind CSS, Shadcn UI
- **Backend**: Node.js, Express 5, Drizzle ORM, PostgreSQL
- **Shared**: Zod schemas and Drizzle table definitions used by both sides

## Pages
- **Главная** (`/`) — Incoming review tasks with counters (pending today, done today, clients in work). Each task card shows: client name, language (RU/EN), review text/amount/reviewer name, confirm link input, Login/Password copy buttons, Mail.ru quick open
- **Инфо** (`/info`) — Client information: brief technical spec (TZ) and clickable wallet addresses that copy to clipboard

## Database Schema
- `users` — user accounts
- `clients` — client profiles with `tz` (brief spec) and `wallets` (JSON array of `{name, address}`)
- `reviews` — review records
- `transactions` — financial transactions
- `tasks` — employee work orders (заявки) with review language, text, amount, reviewer name, login/password credentials, confirm link, status (pending/done/rejected)

## API Endpoints
- `GET/POST /api/clients` — client list and creation
- `PATCH/DELETE /api/clients/:id` — client updates and deletion
- `GET /api/tasks` — all tasks
- `GET /api/tasks/stats` — counters: `{ pending, doneToday, clientsInWork }`
- `POST /api/tasks` — create task (admin)
- `PATCH /api/tasks/:id` — update task (employee sets status/confirmLink)
- `DELETE /api/tasks/:id` — delete task
- `GET/POST/PATCH/DELETE /api/reviews` — review CRUD
- `GET /api/reviews/stats` — review statistics
- `GET/POST/PATCH/DELETE /api/transactions` — transaction CRUD

## Development
```bash
npm run dev       # Start dev server (port 5000)
npm run db:push   # Push schema changes to database
npm run build     # Production build
```

## Wallets JSON Format
Client wallets stored as JSON string in `clients.wallets`:
```json
[
  {"name": "USDT TRC20", "address": "TXzQ..."},
  {"name": "Bitcoin", "address": "1BvB..."}
]
```
