import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { ThemeProvider } from "@/lib/theme";
import { Layout } from "@/components/Layout";
import NotFound from "@/pages/not-found";
import Overview from "@/pages/Overview";
import Customers from "@/pages/Customers";
import Reviews from "@/pages/Reviews";
import Balance from "@/pages/Balance";
import Analytics from "@/pages/Analytics";
import Campaign from "@/pages/Campaign";
import ActivityLog from "@/pages/ActivityLog";
import Employees from "@/pages/Employees";

function Router() {
  return (
    <Layout>
      <Switch>
        <Route path="/" component={Overview} />
        <Route path="/analytics" component={Analytics} />
        <Route path="/campaign" component={Campaign} />
        <Route path="/activity" component={ActivityLog} />
        <Route path="/customers" component={Customers} />
        <Route path="/employees" component={Employees} />
        <Route path="/reviews" component={Reviews} />
        <Route path="/balance" component={Balance} />
        <Route component={NotFound} />
      </Switch>
    </Layout>
  );
}

function App() {
  return (
    <ThemeProvider>
      <QueryClientProvider client={queryClient}>
        <TooltipProvider>
          <Toaster />
          <Router />
        </TooltipProvider>
      </QueryClientProvider>
    </ThemeProvider>
  );
}

export default App;
