import { Router } from "express";
import { db } from "@workspace/db";
import {
  clients, reviews, transactions, schedules, resources,
  insertScheduleSchema, insertResourceSchema,
} from "@workspace/db";
import { eq, desc, gte } from "drizzle-orm";

const router = Router();

const ADMIN_LOGIN = process.env.ADMIN_LOGIN || "Admin";
const ADMIN_PASSWORD = process.env.ADMIN_PASSWORD || "Admin";

const WORKER_LOGIN = process.env.WORKER_LOGIN || "Work";
const WORKER_PASSWORD = process.env.WORKER_PASSWORD || "Work";

const USER_LOGIN = process.env.USER_LOGIN || "User";
const USER_PASSWORD = process.env.USER_PASSWORD || "User";

// ─── Auth ─────────────────────────────────────────────────────────────────────

router.post("/admin/login", (req, res) => {
  const { login, password } = req.body as { login?: string; password?: string };
  if (login === ADMIN_LOGIN && password === ADMIN_PASSWORD) {
    res.json({ ok: true, token: "admin-session-valid", role: "admin" });
    return;
  }
  res.status(401).json({ ok: false, error: "Неверный логин или пароль" });
});

router.post("/crm/login", (req, res) => {
  const { login, password } = req.body as { login?: string; password?: string };
  if (login === WORKER_LOGIN && password === WORKER_PASSWORD) {
    res.json({ ok: true, token: "worker-session-valid", role: "worker" });
    return;
  }
  res.status(401).json({ ok: false, error: "Неверный логин или пароль" });
});

router.post("/admin/auth/login", (req, res) => {
  const { login, password } = req.body as { login?: string; password?: string };
  if (login === USER_LOGIN && password === USER_PASSWORD) {
    res.json({ ok: true, token: "user-session-valid", role: "user" });
    return;
  }
  res.status(401).json({ ok: false, error: "Неверный логин или пароль" });
});

// ─── Admin Clients ─────────────────────────────────────────────────────────────

function mapClientToAdmin(c: typeof clients.$inferSelect) {
  let sites: unknown[] = [];
  try { if (c.wallets) sites = JSON.parse(c.wallets); } catch { /* ignore */ }
  return {
    id: c.id,
    name: c.name,
    status: c.status,
    login: c.email ?? null,
    passwordHash: c.phone ?? null,
    googleSheetUrl: c.notes ?? null,
    sites,
  };
}

router.get("/admin/clients", async (_req, res) => {
  try {
    const all = await db.select().from(clients).orderBy(desc(clients.createdAt));
    res.json({ ok: true, clients: all.map(mapClientToAdmin) });
  } catch (e) {
    res.status(500).json({ ok: false, error: String(e) });
  }
});

router.post("/admin/clients", async (req, res) => {
  try {
    const { name, status, googleSheetUrl, sites } = req.body as {
      name?: string; status?: string; googleSheetUrl?: string; sites?: unknown[];
    };
    if (!name) return res.status(400).json({ ok: false, error: "name required" });
    const [created] = await db.insert(clients).values({
      name,
      status: (status as "in_work" | "potential" | "refused" | "paused") ?? "potential",
      notes: googleSheetUrl ?? null,
      wallets: sites ? JSON.stringify(sites) : null,
    }).returning();
    res.status(201).json({ ok: true, client: mapClientToAdmin(created) });
  } catch (e) {
    res.status(500).json({ ok: false, error: String(e) });
  }
});

router.put("/admin/clients/:id", async (req, res) => {
  try {
    const { name, status, googleSheetUrl, sites } = req.body as {
      name?: string; status?: string; googleSheetUrl?: string; sites?: unknown[];
    };
    const updates: Partial<typeof clients.$inferInsert> = {};
    if (name !== undefined) updates.name = name;
    if (status !== undefined) updates.status = status as "in_work" | "potential" | "refused" | "paused";
    if (googleSheetUrl !== undefined) updates.notes = googleSheetUrl;
    if (sites !== undefined) updates.wallets = JSON.stringify(sites);
    const [updated] = await db.update(clients).set(updates).where(eq(clients.id, req.params.id)).returning();
    if (!updated) return res.status(404).json({ ok: false, error: "Not found" });
    res.json({ ok: true, client: mapClientToAdmin(updated) });
  } catch (e) {
    res.status(500).json({ ok: false, error: String(e) });
  }
});

router.delete("/admin/clients/:id", async (req, res) => {
  try {
    const [deleted] = await db.delete(clients).where(eq(clients.id, req.params.id)).returning();
    if (!deleted) return res.status(404).json({ ok: false, error: "Not found" });
    res.json({ ok: true });
  } catch (e) {
    res.status(500).json({ ok: false, error: String(e) });
  }
});

router.post("/admin/clients/:id/generate-credentials", async (req, res) => {
  try {
    const { id } = req.params;
    const [client] = await db.select().from(clients).where(eq(clients.id, id));
    if (!client) return res.status(404).json({ ok: false, error: "Client not found" });
    const login = `client_${id.slice(0, 6)}`;
    const password = Math.random().toString(36).slice(2, 10).toUpperCase();
    await db.update(clients).set({ email: login, phone: password }).where(eq(clients.id, id));
    res.json({ ok: true, login, password });
  } catch (e) {
    res.status(500).json({ ok: false, error: String(e) });
  }
});

// ─── Admin Reviews ─────────────────────────────────────────────────────────────

router.post("/admin/reviews", async (req, res) => {
  try {
    const { clientId, count, earnedAmount, date, notes } = req.body as {
      clientId?: string; count?: number; earnedAmount?: string; date?: string; notes?: string;
    };
    const [created] = await db.insert(reviews).values({
      clientId: clientId ?? null,
      count: count ?? 1,
      earnedAmount: earnedAmount ?? "0",
      date: date ? new Date(date) : new Date(),
      notes: notes ?? null,
    }).returning();
    res.status(201).json({ ok: true, review: created });
  } catch (e) {
    res.status(500).json({ ok: false, error: String(e) });
  }
});

router.get("/admin/reviews/stats", async (_req, res) => {
  try {
    const now = new Date();
    const startOfToday = new Date(now.getFullYear(), now.getMonth(), now.getDate());
    const startOfMonth = new Date(now.getFullYear(), now.getMonth(), 1);

    const allReviews = await db.select().from(reviews);
    const allClients = await db.select().from(clients);

    const totalAllTime = allReviews.reduce((s, r) => s + r.count, 0);
    const earningsAllTime = allReviews.reduce((s, r) => s + Number(r.earnedAmount), 0);

    const monthReviews = allReviews.filter(r => new Date(r.date) >= startOfMonth);
    const reviewsDoneThisMonth = monthReviews.reduce((s, r) => s + r.count, 0);
    const earningsPerMonth = monthReviews.reduce((s, r) => s + Number(r.earnedAmount), 0);

    const todayReviews = allReviews.filter(r => new Date(r.date) >= startOfToday);
    const reviewsToday = todayReviews.reduce((s, r) => s + r.count, 0);

    const clientsActive = allClients.filter(c => c.status === "in_work").length;
    const clientsPaused = allClients.filter(c => c.status === "paused").length;

    const byDayMap: Record<string, number> = {};
    for (const r of allReviews) {
      const key = new Date(r.date).toISOString().split("T")[0];
      byDayMap[key] = (byDayMap[key] ?? 0) + r.count;
    }
    const chartData = Object.entries(byDayMap)
      .sort((a, b) => a[0].localeCompare(b[0]))
      .map(([date, count]) => ({ date, count }));

    res.json({
      clientsActive,
      clientsPaused,
      reviewsToday,
      reviewsDoneThisMonth,
      reviewsRemainingThisMonth: 0,
      reviewsTotalThisMonth: reviewsDoneThisMonth,
      chartData,
      earningsPerMonth: earningsPerMonth.toFixed(2),
      reviewsAllTime: totalAllTime,
      earningsAllTime: earningsAllTime.toFixed(2),
    });
  } catch (e) {
    res.status(500).json({ ok: false, error: String(e) });
  }
});

router.get("/admin/reviews/chart", async (req, res) => {
  try {
    const period = (req.query.period as string) || "day";
    const range = (req.query.range as string) || "month";
    const now = new Date();
    let fromDate: Date;
    if (range === "month") {
      fromDate = new Date(now.getFullYear(), now.getMonth(), 1);
    } else if (range === "3months") {
      fromDate = new Date(now.getFullYear(), now.getMonth() - 2, 1);
    } else if (range === "year") {
      fromDate = new Date(now.getFullYear(), 0, 1);
    } else {
      fromDate = new Date(0);
    }

    const filtered = await db.select().from(reviews).where(gte(reviews.date, fromDate));

    function keyFor(d: Date): string {
      if (period === "month") {
        return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}`;
      }
      if (period === "week") {
        const monday = new Date(d);
        monday.setDate(d.getDate() - ((d.getDay() + 6) % 7));
        return monday.toISOString().split("T")[0];
      }
      return d.toISOString().split("T")[0];
    }

    const map: Record<string, number> = {};
    for (const r of filtered) {
      const key = keyFor(new Date(r.date));
      map[key] = (map[key] ?? 0) + r.count;
    }
    const data = Object.entries(map)
      .sort((a, b) => a[0].localeCompare(b[0]))
      .map(([date, count]) => ({ date, count }));

    res.json({ ok: true, data });
  } catch (e) {
    res.status(500).json({ ok: false, error: String(e) });
  }
});

// ─── Admin Accounting (maps to transactions) ───────────────────────────────────

function mapTxToAccounting(tx: typeof transactions.$inferSelect) {
  const d = tx.date instanceof Date ? tx.date : new Date(tx.date);
  return {
    id: tx.id,
    type: tx.type,
    amount: tx.amount,
    description: tx.description ?? "",
    category: tx.category ?? null,
    recordDate: d.toISOString().split("T")[0],
  };
}

router.get("/admin/accounting", async (_req, res) => {
  try {
    const all = await db.select().from(transactions).orderBy(desc(transactions.date));
    res.json({ ok: true, records: all.map(mapTxToAccounting) });
  } catch (e) {
    res.status(500).json({ ok: false, error: String(e) });
  }
});

router.post("/admin/accounting", async (req, res) => {
  try {
    const { type, amount, description, category, recordDate } = req.body as {
      type?: string; amount?: string; description?: string; category?: string; recordDate?: string;
    };
    if (!type || !amount) return res.status(400).json({ ok: false, error: "type and amount required" });
    const [created] = await db.insert(transactions).values({
      type: type as "income" | "expense",
      amount,
      description: description ?? null,
      category: category ?? null,
      date: recordDate ? new Date(recordDate) : new Date(),
    }).returning();
    res.status(201).json({ ok: true, record: mapTxToAccounting(created) });
  } catch (e) {
    res.status(500).json({ ok: false, error: String(e) });
  }
});

router.put("/admin/accounting/:id", async (req, res) => {
  try {
    const { type, amount, description, category, recordDate } = req.body as {
      type?: string; amount?: string; description?: string; category?: string; recordDate?: string;
    };
    const updates: Partial<typeof transactions.$inferInsert> = {};
    if (type !== undefined) updates.type = type as "income" | "expense";
    if (amount !== undefined) updates.amount = amount;
    if (description !== undefined) updates.description = description;
    if (category !== undefined) updates.category = category;
    if (recordDate !== undefined) updates.date = new Date(recordDate);
    const [updated] = await db.update(transactions).set(updates).where(eq(transactions.id, req.params.id)).returning();
    if (!updated) return res.status(404).json({ ok: false, error: "Not found" });
    res.json({ ok: true, record: mapTxToAccounting(updated) });
  } catch (e) {
    res.status(500).json({ ok: false, error: String(e) });
  }
});

router.delete("/admin/accounting/:id", async (req, res) => {
  try {
    const [deleted] = await db.delete(transactions).where(eq(transactions.id, req.params.id)).returning();
    if (!deleted) return res.status(404).json({ ok: false, error: "Not found" });
    res.json({ ok: true });
  } catch (e) {
    res.status(500).json({ ok: false, error: String(e) });
  }
});

// ─── Admin Schedules ───────────────────────────────────────────────────────────

router.get("/admin/schedules", async (_req, res) => {
  try {
    const all = await db.select().from(schedules).orderBy(desc(schedules.workDate));
    res.json({ ok: true, schedules: all });
  } catch (e) {
    res.status(500).json({ ok: false, error: String(e) });
  }
});

router.post("/admin/schedules", async (req, res) => {
  try {
    const parsed = insertScheduleSchema.safeParse(req.body);
    if (!parsed.success) return res.status(400).json({ ok: false, error: parsed.error });
    const [created] = await db.insert(schedules).values(parsed.data).returning();
    res.status(201).json({ ok: true, schedule: created });
  } catch (e) {
    res.status(500).json({ ok: false, error: String(e) });
  }
});

router.put("/admin/schedules/:id", async (req, res) => {
  try {
    const parsed = insertScheduleSchema.partial().safeParse(req.body);
    if (!parsed.success) return res.status(400).json({ ok: false, error: parsed.error });
    const [updated] = await db.update(schedules).set(parsed.data).where(eq(schedules.id, req.params.id)).returning();
    if (!updated) return res.status(404).json({ ok: false, error: "Not found" });
    res.json({ ok: true, schedule: updated });
  } catch (e) {
    res.status(500).json({ ok: false, error: String(e) });
  }
});

router.delete("/admin/schedules/:id", async (req, res) => {
  try {
    const [deleted] = await db.delete(schedules).where(eq(schedules.id, req.params.id)).returning();
    if (!deleted) return res.status(404).json({ ok: false, error: "Not found" });
    res.json({ ok: true });
  } catch (e) {
    res.status(500).json({ ok: false, error: String(e) });
  }
});

// ─── Admin Resources ───────────────────────────────────────────────────────────

router.get("/admin/resources", async (_req, res) => {
  try {
    const all = await db.select().from(resources).orderBy(desc(resources.createdAt));
    res.json({ ok: true, resources: all });
  } catch (e) {
    res.status(500).json({ ok: false, error: String(e) });
  }
});

router.post("/admin/resources", async (req, res) => {
  try {
    const parsed = insertResourceSchema.safeParse(req.body);
    if (!parsed.success) return res.status(400).json({ ok: false, error: parsed.error });
    const [created] = await db.insert(resources).values(parsed.data).returning();
    res.status(201).json({ ok: true, resource: created });
  } catch (e) {
    res.status(500).json({ ok: false, error: String(e) });
  }
});

router.delete("/admin/resources/:id", async (req, res) => {
  try {
    const [deleted] = await db.delete(resources).where(eq(resources.id, req.params.id)).returning();
    if (!deleted) return res.status(404).json({ ok: false, error: "Not found" });
    res.json({ ok: true });
  } catch (e) {
    res.status(500).json({ ok: false, error: String(e) });
  }
});

// ─── Google Sheets Sync (stub) ─────────────────────────────────────────────────

router.post("/admin/sheets/sync", (_req, res) => {
  res.json({ ok: true, message: "Sync completed", synced: 0 });
});

// ─── Client profile / reviews ─────────────────────────────────────────────────

router.get("/client/profile", async (req, res) => {
  try {
    const clientId = req.query.clientId as string;
    if (!clientId) return res.status(400).json({ ok: false, error: "clientId required" });
    const [client] = await db.select().from(clients).where(eq(clients.id, clientId));
    if (!client) return res.status(404).json({ ok: false, error: "Not found" });

    let sites: unknown[] = [];
    try { if (client.wallets) sites = JSON.parse(client.wallets); } catch { /* ignore */ }

    const clientReviews = await db.select().from(reviews)
      .where(eq(reviews.clientId, clientId))
      .orderBy(desc(reviews.date));

    res.json({
      ok: true,
      client: { id: client.id, name: client.name, status: client.status, sites },
      reviews: clientReviews,
    });
  } catch (e) {
    res.status(500).json({ ok: false, error: String(e) });
  }
});

router.get("/client/reviews", async (req, res) => {
  try {
    const clientId = req.query.clientId as string;
    if (!clientId) return res.status(400).json({ ok: false, error: "clientId required" });
    const clientReviews = await db.select().from(reviews)
      .where(eq(reviews.clientId, clientId))
      .orderBy(desc(reviews.date));
    res.json({ ok: true, reviews: clientReviews });
  } catch (e) {
    res.status(500).json({ ok: false, error: String(e) });
  }
});

export default router;
