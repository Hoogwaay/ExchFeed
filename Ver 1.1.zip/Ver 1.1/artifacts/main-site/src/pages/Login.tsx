import { useState } from "react";
import { useLocation } from "wouter";
import { useCursor } from "@/lib/cursor-context";

export default function Login() {
  const [, navigate] = useLocation();
  const { hoverOn, hoverOff } = useCursor();
  const [login, setLogin] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState(false);
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError(false);
    try {
      const res = await fetch("/api/admin/auth/login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ login, password }),
      });
      const data = await res.json();
      if (data.ok) {
        localStorage.setItem("client_token", data.token);
        navigate("/cabinet");
      } else {
        setError(true);
      }
    } catch {
      setError(true);
    } finally {
      setLoading(false);
    }
  };

  return (
    <>
      <style>{`
        *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }
        html { scroll-behavior: smooth; }
        body { background: #050505; color: #fff; overflow-x: hidden; cursor: none; }
        ::selection { background: #00f5ff; color: #050505; }
        input::placeholder { color: rgba(255,255,255,0.2); }
        a, button { cursor: none; }
        .login-nav { max-width: 1400px; margin: 0 auto; padding: 0 48px; height: 72px; display: flex; align-items: center; justify-content: space-between; }
        .login-main { min-height: 100svh; background: #050505; display: flex; align-items: center; justify-content: center; padding: 120px 24px 80px; }
        .login-card { width: 100%; max-width: 460px; }
        .login-form { border: 1px solid rgba(255,255,255,0.1); border-radius: 2px; padding: 52px 44px; background: rgba(255,255,255,0.02); }
        @media (max-width: 768px) {
          body { cursor: auto; }
          .login-nav { padding: 0 20px; height: 60px; }
          .login-main { padding: 80px 20px 60px; align-items: flex-start; }
          .login-form { padding: 36px 24px; }
        }
      `}</style>

      <header style={{
        position: "fixed", top: 0, width: "100%", zIndex: 1000,
        borderBottom: "1px solid rgba(255,255,255,0.08)",
        background: "rgba(5,5,5,0.92)", backdropFilter: "blur(12px)",
      }}>
        <nav className="login-nav">
          <div
            onClick={() => navigate("/")}
            onMouseEnter={hoverOn} onMouseLeave={hoverOff}
            style={{ fontFamily: "monospace", fontSize: "1rem", fontWeight: 700, letterSpacing: 3, color: "#fff", cursor: "pointer", textTransform: "uppercase" }}
          >
            Exchange Feed
          </div>
          <button
            onClick={() => navigate("/")}
            onMouseEnter={hoverOn} onMouseLeave={hoverOff}
            style={{
              padding: "10px 24px", background: "transparent",
              border: "1px solid rgba(255,255,255,0.15)", borderRadius: 2,
              color: "rgba(255,255,255,0.5)", fontWeight: 600, fontFamily: "monospace",
              fontSize: "0.75rem", letterSpacing: 2, textTransform: "uppercase",
              transition: "border-color 0.3s, color 0.3s",
            }}
            onMouseOver={(e) => { e.currentTarget.style.borderColor = "rgba(255,255,255,0.4)"; e.currentTarget.style.color = "#fff"; }}
            onMouseOut={(e) => { e.currentTarget.style.borderColor = "rgba(255,255,255,0.15)"; e.currentTarget.style.color = "rgba(255,255,255,0.5)"; }}
          >
            ← Назад
          </button>
        </nav>
      </header>

      <main className="login-main">
        <div className="login-card">
          <div style={{
            fontFamily: "monospace", fontSize: "0.65rem", letterSpacing: 4,
            color: "#00f5ff", textTransform: "uppercase", marginBottom: 28, textAlign: "center",
          }}>
            Личный кабинет
          </div>
          <h1 style={{
            fontSize: "clamp(2rem,8vw,3rem)", fontWeight: 900,
            color: "#fff", letterSpacing: -2, lineHeight: 1,
            textAlign: "center", marginBottom: 48, fontFamily: "'Inter', sans-serif",
          }}>
            ВХОД
          </h1>
          <form className="login-form" onSubmit={handleSubmit}>
            <div style={{ marginBottom: 20 }}>
              <label style={{ fontFamily: "monospace", fontSize: "0.7rem", letterSpacing: 2, color: "rgba(255,255,255,0.4)", textTransform: "uppercase", display: "block", marginBottom: 10 }}>
                Логин
              </label>
              <input
                type="text"
                value={login}
                onChange={(e) => setLogin(e.target.value)}
                placeholder="Введите логин"
                required
                onMouseEnter={hoverOn} onMouseLeave={hoverOff}
                style={{
                  width: "100%", padding: "14px 18px",
                  background: "rgba(255,255,255,0.04)",
                  border: `1px solid ${error ? "rgba(255,68,68,0.4)" : "rgba(255,255,255,0.1)"}`,
                  borderRadius: 2, color: "#fff", fontSize: "0.95rem",
                  fontFamily: "'Inter',sans-serif", outline: "none", transition: "border-color 0.3s",
                }}
                onFocus={(e) => { if (!error) e.currentTarget.style.borderColor = "#00f5ff"; }}
                onBlur={(e) => { if (!error) e.currentTarget.style.borderColor = "rgba(255,255,255,0.1)"; }}
              />
            </div>
            <div style={{ marginBottom: 28 }}>
              <label style={{ fontFamily: "monospace", fontSize: "0.7rem", letterSpacing: 2, color: "rgba(255,255,255,0.4)", textTransform: "uppercase", display: "block", marginBottom: 10 }}>
                Пароль
              </label>
              <input
                type="password"
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="Введите пароль"
                required
                onMouseEnter={hoverOn} onMouseLeave={hoverOff}
                style={{
                  width: "100%", padding: "14px 18px",
                  background: "rgba(255,255,255,0.04)",
                  border: `1px solid ${error ? "rgba(255,68,68,0.4)" : "rgba(255,255,255,0.1)"}`,
                  borderRadius: 2, color: "#fff", fontSize: "0.95rem",
                  fontFamily: "'Inter',sans-serif", outline: "none", transition: "border-color 0.3s",
                }}
                onFocus={(e) => { if (!error) e.currentTarget.style.borderColor = "#00f5ff"; }}
                onBlur={(e) => { if (!error) e.currentTarget.style.borderColor = "rgba(255,255,255,0.1)"; }}
              />
            </div>
            {error && (
              <div style={{
                marginBottom: 20, padding: "12px 18px",
                border: "1px solid rgba(255,68,68,0.3)", borderRadius: 2,
                background: "rgba(255,68,68,0.06)", display: "flex", alignItems: "center", gap: 10,
              }}>
                <span style={{ color: "#ff4444", fontSize: "0.9rem", flexShrink: 0 }}>✕</span>
                <span style={{ fontFamily: "monospace", fontSize: "0.75rem", letterSpacing: 1, color: "#ff6666" }}>
                  Неверный логин или пароль
                </span>
              </div>
            )}
            <button
              type="submit" disabled={loading}
              onMouseEnter={hoverOn} onMouseLeave={hoverOff}
              style={{
                width: "100%", padding: "17px",
                background: "#00f5ff", border: "none", borderRadius: 2,
                color: "#050505", fontWeight: 800, fontSize: "0.8rem", letterSpacing: 2,
                textTransform: "uppercase", fontFamily: "monospace",
                opacity: loading ? 0.6 : 1,
                transition: "opacity 0.3s, transform 0.2s, box-shadow 0.2s",
              }}
              onMouseOver={(e) => { if (!loading) { e.currentTarget.style.transform = "translateY(-2px)"; e.currentTarget.style.boxShadow = "0 12px 32px rgba(0,245,255,0.25)"; } }}
              onMouseOut={(e) => { e.currentTarget.style.transform = ""; e.currentTarget.style.boxShadow = ""; }}
            >
              {loading ? "Проверка..." : "Войти →"}
            </button>
          </form>
        </div>
      </main>
    </>
  );
}
