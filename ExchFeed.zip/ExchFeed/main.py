"""
Exchange Feed — Flask entry point
Run: python main.py
"""

import os
import subprocess
import sys
import time
from pathlib import Path

import requests as req_lib
from flask import Flask, Response, request, send_from_directory

ROOT = Path(__file__).parent
DIST = ROOT / "artifacts" / "exchange-feed" / "dist" / "public"
API_PORT = 8081
API_BASE = f"http://127.0.0.1:{API_PORT}"
PORT = int(os.environ.get("PORT", 5000))

app = Flask(__name__, static_folder=None)


def build_frontend():
    print("[flask] Building frontend (Vite)...")
    result = subprocess.run(
        ["pnpm", "--filter", "@workspace/exchange-feed", "run", "build"],
        cwd=str(ROOT),
        env={**os.environ, "PORT": str(PORT), "BASE_PATH": "/"},
    )
    if result.returncode != 0:
        print("[flask] Frontend build failed — aborting.")
        sys.exit(1)
    print("[flask] Frontend built successfully.")


def build_api():
    print("[flask] Building API server (esbuild)...")
    result = subprocess.run(
        ["pnpm", "--filter", "@workspace/api-server", "run", "build"],
        cwd=str(ROOT),
        env={**os.environ, "PORT": str(API_PORT)},
    )
    if result.returncode != 0:
        print("[flask] API server build failed — aborting.")
        sys.exit(1)
    print("[flask] API server built successfully.")


def start_api() -> subprocess.Popen:
    print(f"[flask] Starting API server on port {API_PORT}...")
    proc = subprocess.Popen(
        ["node", "--enable-source-maps", "artifacts/api-server/dist/index.mjs"],
        cwd=str(ROOT),
        env={**os.environ, "PORT": str(API_PORT)},
    )
    for _ in range(30):
        try:
            req_lib.get(f"{API_BASE}/api/healthz", timeout=1)
            print("[flask] API server is ready.")
            return proc
        except Exception:
            time.sleep(0.5)
    print("[flask] Warning: API server did not respond in time, continuing anyway.")
    return proc


@app.route("/api", defaults={"path": ""}, methods=["GET", "POST", "PUT", "DELETE", "PATCH", "OPTIONS"])
@app.route("/api/<path:path>", methods=["GET", "POST", "PUT", "DELETE", "PATCH", "OPTIONS"])
def proxy_api(path=""):
    target = f"{API_BASE}/api/{path}"
    if request.query_string:
        target += "?" + request.query_string.decode()

    excluded_headers = {"host", "content-length", "transfer-encoding", "connection"}
    headers = {k: v for k, v in request.headers if k.lower() not in excluded_headers}

    resp = req_lib.request(
        method=request.method,
        url=target,
        headers=headers,
        data=request.get_data(),
        stream=True,
        timeout=30,
    )

    response_headers = {
        k: v for k, v in resp.raw.headers.items()
        if k.lower() not in {"transfer-encoding", "connection"}
    }

    return Response(
        resp.iter_content(chunk_size=4096),
        status=resp.status_code,
        headers=response_headers,
    )


@app.route("/", defaults={"path": ""})
@app.route("/<path:path>")
def serve_static(path=""):
    candidate = DIST / path
    if path and candidate.is_file():
        return send_from_directory(str(DIST), path)
    index = DIST / "index.html"
    if index.exists():
        return send_from_directory(str(DIST), "index.html")
    return "Not found — did you run the build?", 404


if __name__ == "__main__":
    build_frontend()
    build_api()
    api_proc = start_api()
    print(f"[flask] Starting Flask on 0.0.0.0:{PORT} …")
    try:
        app.run(host="0.0.0.0", port=PORT, debug=False, threaded=True)
    finally:
        print("[flask] Shutting down API server...")
        api_proc.terminate()
