import { useRef, useEffect, useState, useCallback } from "react";
import { useLocation } from "wouter";
import { useCursor } from "@/lib/cursor-context";

function scrollToContact() {
  const el = document.getElementById("contact");
  if (!el) return;
  window.scrollTo({ top: el.getBoundingClientRect().top + window.scrollY + 40, behavior: "smooth" });
}

function useReveal() {
  const ref = useRef<HTMLDivElement>(null);
  const [visible, setVisible] = useState(false);
  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    const obs = new IntersectionObserver(
      ([entry]) => { if (entry.isIntersecting) { setVisible(true); obs.disconnect(); } },
      { threshold: 0.1 }
    );
    obs.observe(el);
    return () => obs.disconnect();
  }, []);
  return { ref, visible };
}

function RevealBlock({ children, delay = 0, style = {} }: {
  children: React.ReactNode; delay?: number; style?: React.CSSProperties;
}) {
  const { ref, visible } = useReveal();
  return (
    <div ref={ref} style={{
      opacity: visible ? 1 : 0,
      transform: visible ? "translateY(0)" : "translateY(48px)",
      transition: `opacity 0.85s cubic-bezier(0.16,1,0.3,1) ${delay}ms, transform 0.85s cubic-bezier(0.16,1,0.3,1) ${delay}ms`,
      ...style,
    }}>
      {children}
    </div>
  );
}

const CONTACT_ITEMS = [
  { label: "Email", value: "support@exchange-feed.com" },
  { label: "Telegram", value: "@exchange_feed_bot" },
];

export default function Home() {
  const [, navigate] = useLocation();
  const { hoverOn, hoverOff } = useCursor();
  const [searchResult, setSearchResult] = useState(false);
  const [formSent, setFormSent] = useState(false);
  const [formError, setFormError] = useState(false);
  const [formLoading, setFormLoading] = useState(false);
  const [menuOpen, setMenuOpen] = useState(false);
  const [loginOpen, setLoginOpen] = useState(false);
  const [loginError, setLoginError] = useState(false);
  const [loginLoading, setLoginLoading] = useState(false);
  const [copiedItem, setCopiedItem] = useState<string | null>(null);
  const [platforms, setPlatforms] = useState<{ id: number; name: string; type: string; url: string | null }[]>([]);
  const rafRef = useRef<number>(0);
  const posRef = useRef(0);
  const [, setTick] = useState(0);

  useEffect(() => {
    function tick() {
      posRef.current -= 0.4;
      setTick((t) => t + 1);
      rafRef.current = requestAnimationFrame(tick);
    }
    rafRef.current = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(rafRef.current);
  }, []);

  useEffect(() => {
    fetch("/api/platforms")
      .then((r) => r.json())
      .then((data: { ok: boolean; platforms: { id: number; name: string; type: string; url: string | null }[] }) => {
        if (data.ok) setPlatforms(data.platforms);
      })
      .catch(() => {});
  }, []);

  // Close login modal on Escape
  useEffect(() => {
    if (!loginOpen) return;
    const onKey = (e: KeyboardEvent) => { if (e.key === "Escape") setLoginOpen(false); };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [loginOpen]);

  const copyToClipboard = useCallback(async (text: string) => {
    try {
      await navigator.clipboard.writeText(text);
      setCopiedItem(text);
      setTimeout(() => setCopiedItem(null), 2000);
    } catch {
      // fallback for older browsers
      const el = document.createElement("textarea");
      el.value = text;
      document.body.appendChild(el);
      el.select();
      document.execCommand("copy");
      document.body.removeChild(el);
      setCopiedItem(text);
      setTimeout(() => setCopiedItem(null), 2000);
    }
  }, []);

  const handleFormSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    const form = e.currentTarget as HTMLFormElement;
    const email = (form.elements.namedItem("email") as HTMLInputElement).value;
    const telegram = (form.elements.namedItem("telegram") as HTMLInputElement).value;
    const message = (form.elements.namedItem("message") as HTMLTextAreaElement).value;
    setFormLoading(true);
    setFormError(false);
    try {
      const res = await fetch("/api/contact", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email, telegram, message }),
      });
      const data = await res.json() as { ok: boolean };
      if (data.ok) {
        setFormSent(true);
        form.reset();
        setTimeout(() => setFormSent(false), 5000);
      } else {
        setFormError(true);
        setTimeout(() => setFormError(false), 4000);
      }
    } catch {
      setFormError(true);
      setTimeout(() => setFormError(false), 4000);
    } finally {
      setFormLoading(false);
    }
  };

  const handleLoginSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    setLoginLoading(true);
    setLoginError(false);
    try {
      const formData = new FormData(e.currentTarget);
      const login = formData.get("login") as string;
      const password = formData.get("password") as string;
      const res = await fetch("/api/admin/auth/login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ login, password }),
      });
      const data = await res.json();
      if (data.ok) {
        if (data.role === "client") {
          localStorage.setItem("client_token", data.token);
          localStorage.setItem("client_id", String(data.clientId));
          setLoginOpen(false);
          navigate("/cabinet");
        } else {
          localStorage.setItem("admin_token", data.token);
          setLoginOpen(false);
          navigate("/admin");
        }
      } else {
        setLoginError(true);
      }
    } catch {
      setLoginError(true);
    } finally {
      setLoginLoading(false);
    }
  };

  const marqueeText = "EXCHANGE FEED · РЕПУТАЦИЯ · ОТЗЫВЫ · АНОНИМНО · ";
  const repeated = marqueeText.repeat(8);
  const charWidth = 18;
  const totalWidth = repeated.length * charWidth;
  const offset = ((posRef.current % totalWidth) + totalWidth) % totalWidth;

  const navLinks = [
    { href: "#why", label: "Почему мы" },
    { href: "#terms", label: "Условия" },
    { href: "#search", label: "Поиск" },
    { href: "#platforms", label: "Мониторинги" },
    { href: "#contact", label: "Контакты", isContact: true },
  ];

  return (
    <>
      <style>{`
        *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }
        html { scroll-behavior: smooth; }
        body {
          font-family: 'Inter', -apple-system, sans-serif;
          background: #050505; color: #fff; overflow-x: hidden; cursor: none;
          user-select: none; -webkit-user-select: none; -moz-user-select: none;
        }
        input, textarea { user-select: text !important; -webkit-user-select: text !important; }
        ::selection { background: #c9ff47; color: #050505; }
        input::placeholder, textarea::placeholder { color: rgba(255,255,255,0.2); }
        a, button { cursor: none; }

        .nav-inner { max-width: 1400px; margin: 0 auto; padding: 0 48px; height: 72px; display: flex; align-items: center; justify-content: space-between; gap: 24px; }
        .nav-links { display: flex; gap: 40px; list-style: none; }
        .nav-link { color: rgba(255,255,255,0.5); text-decoration: none; font-size: 0.8rem; letter-spacing: 2px; text-transform: uppercase; font-family: monospace; font-weight: 500; transition: color 0.3s; }
        .nav-link:hover { color: #c9ff47; }
        .hamburger { display: none; flex-direction: column; gap: 5px; background: none; border: none; padding: 6px; }
        .hamburger span { display: block; width: 22px; height: 1.5px; background: #fff; transition: transform 0.3s, opacity 0.3s; }

        .mobile-menu { display: none; position: fixed; inset: 0; top: 60px; background: rgba(5,5,5,0.98); z-index: 900; flex-direction: column; align-items: center; justify-content: center; gap: 36px; backdrop-filter: blur(16px); }
        .mobile-menu.open { display: flex; }
        .mobile-menu a { color: rgba(255,255,255,0.7); text-decoration: none; font-size: 1.5rem; font-weight: 700; letter-spacing: 2px; text-transform: uppercase; font-family: monospace; transition: color 0.2s; }
        .mobile-menu a:hover { color: #c9ff47; }

        .hero-section { min-height: 100svh; background: #050505; display: flex; flex-direction: column; justify-content: center; padding: 120px 48px 80px; position: relative; overflow: hidden; }
        .hero-inner { max-width: 1400px; margin: 0 auto; width: 100%; display: flex; align-items: flex-start; justify-content: space-between; gap: 60px; }
        .hero-text { flex: 1; min-width: 0; }
        .hero-stats { display: flex; flex-direction: column; min-width: 280px; padding-top: 20px; }
        .hero-stat { border-top: 1px solid rgba(255,255,255,0.08); padding: 28px 0; }
        .hero-stat:last-child { border-bottom: 1px solid rgba(255,255,255,0.08); }
        .hero-buttons { display: flex; gap: 20px; flex-wrap: wrap; }

        .s-pad { padding: 140px 48px; }
        .s-inner { max-width: 1400px; margin: 0 auto; }

        .sec-head { display: flex; align-items: flex-end; justify-content: space-between; margin-bottom: 100px; border-bottom: 1px solid rgba(255,255,255,0.08); padding-bottom: 40px; }
        .sec-head-alt { display: flex; align-items: flex-end; justify-content: space-between; margin-bottom: 80px; border-bottom: 1px solid rgba(255,255,255,0.08); padding-bottom: 40px; }

        .feature-grid { display: grid; grid-template-columns: repeat(2,1fr); gap: 1px; background: rgba(255,255,255,0.06); }
        .terms-grid { display: grid; grid-template-columns: 1fr 380px; gap: 80px; align-items: start; }
        .search-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 40px; }
        .contact-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 80px; align-items: start; }
        .footer-inner { max-width: 1400px; margin: 0 auto; display: flex; justify-content: space-between; align-items: center; }

        .copy-item { transition: padding-left 0.3s, background 0.3s; border-radius: 2px; }
        .copy-item:hover { background: rgba(255,255,255,0.04); }

        .hide-sm { }
        .sticky-box { position: sticky; top: 100px; }

        @keyframes pulse { 0%,100% { opacity:1; transform:scale(1); } 50% { opacity:0.5; transform:scale(0.8); } }
        @keyframes scrollLine { 0%,100% { opacity:0; transform:translateY(-8px); } 50% { opacity:1; transform:translateY(0); } }
        @keyframes modalIn { from { opacity: 0; transform: scale(0.96) translateY(16px); } to { opacity: 1; transform: scale(1) translateY(0); } }

        @media (max-width: 1024px) {
          .nav-inner { padding: 0 32px; }
          .nav-links { gap: 24px; }
          .hero-section { padding: 100px 32px 60px; }
          .hero-inner { gap: 40px; }
          .hero-stats { min-width: 220px; }
          .s-pad { padding: 100px 32px; }
          .terms-grid { grid-template-columns: 1fr; gap: 48px; }
          .sec-head { margin-bottom: 64px; }
          .sec-head-alt { margin-bottom: 56px; }
          .contact-grid { gap: 48px; }
          .sticky-box { position: static; }
        }

        @media (max-width: 768px) {
          body { cursor: auto; }
          .nav-inner { padding: 0 20px; height: 60px; }
          .nav-links { display: none; }
          .hamburger { display: flex; }
          .hero-section { padding: 76px 20px 56px; }
          .hero-inner { flex-direction: column; gap: 40px; }
          .hero-stats { flex-direction: row; flex-wrap: wrap; min-width: unset; padding-top: 0; border-top: 1px solid rgba(255,255,255,0.08); }
          .hero-stat { flex: 1; min-width: 100px; border-top: none; border-left: 1px solid rgba(255,255,255,0.08); padding: 20px 16px; }
          .hero-stat:first-child { border-left: none; }
          .hero-stat:last-child { border-bottom: none; }
          .hero-buttons { flex-direction: column; }
          .hero-btn-fill, .hero-btn-outline { width: 100% !important; text-align: center !important; justify-content: center !important; }
          .s-pad { padding: 72px 20px; }
          .sec-head { flex-direction: column; align-items: flex-start; gap: 12px; margin-bottom: 48px; }
          .sec-head-alt { flex-direction: column; align-items: flex-start; gap: 12px; margin-bottom: 40px; }
          .hide-sm { display: none !important; }
          .feature-grid { grid-template-columns: 1fr; }
          .feature-card { min-height: 260px !important; padding: 32px 24px !important; }
          .terms-grid { grid-template-columns: 1fr; gap: 40px; }
          .search-grid { grid-template-columns: 1fr; }
          .contact-grid { grid-template-columns: 1fr; gap: 40px; }
          .footer-inner { flex-direction: column; gap: 8px; text-align: center; }
          .search-input-row { flex-direction: column !important; }
          .login-modal-card { padding: 36px 24px !important; max-width: 100% !important; }
        }

        @media (max-width: 420px) {
          .hero-stats { flex-direction: column; border-top: none; }
          .hero-stat { border-left: none !important; border-top: 1px solid rgba(255,255,255,0.08) !important; padding: 16px 0 !important; }
          .hero-stat:last-child { border-bottom: 1px solid rgba(255,255,255,0.08) !important; }
        }
      `}</style>

      {/* ── LOGIN MODAL ─────────────────────────────── */}
      {loginOpen && (
        <div
          onClick={() => { setLoginOpen(false); setLoginError(false); }}
          style={{
            position: "fixed", inset: 0, zIndex: 99000,
            background: "rgba(5,5,5,0.75)",
            backdropFilter: "blur(16px)",
            WebkitBackdropFilter: "blur(16px)",
            display: "flex", alignItems: "center", justifyContent: "center",
            padding: 24,
          }}
        >
          <div
            className="login-modal-card"
            onClick={(e) => e.stopPropagation()}
            style={{
              width: "100%", maxWidth: 440,
              background: "#0a0a0a",
              border: "1px solid rgba(255,255,255,0.12)",
              borderRadius: 4,
              padding: "52px 44px",
              animation: "modalIn 0.35s cubic-bezier(0.16,1,0.3,1)",
              position: "relative",
            }}
          >
            {/* Close */}
            <button
              onClick={() => { setLoginOpen(false); setLoginError(false); }}
              onMouseEnter={hoverOn} onMouseLeave={hoverOff}
              style={{
                position: "absolute", top: 20, right: 20,
                background: "none", border: "none",
                color: "rgba(255,255,255,0.3)", fontSize: "1.2rem",
                lineHeight: 1, padding: 4,
                transition: "color 0.2s",
              }}
              onMouseOver={(e) => (e.currentTarget.style.color = "#fff")}
              onMouseOut={(e) => (e.currentTarget.style.color = "rgba(255,255,255,0.3)")}
            >
              ✕
            </button>

            <div style={{ fontFamily: "monospace", fontSize: "0.65rem", letterSpacing: 4, color: "#c9ff47", textTransform: "uppercase", marginBottom: 20, textAlign: "center" }}>
              Личный кабинет
            </div>
            <h2 style={{ fontSize: "2rem", fontWeight: 900, color: "#fff", letterSpacing: -2, lineHeight: 1, textAlign: "center", marginBottom: 40, fontFamily: "'Inter', sans-serif" }}>
              ВХОД
            </h2>

            <form onSubmit={handleLoginSubmit}>
              <div style={{ marginBottom: 20 }}>
                <label style={{ display: "block", fontFamily: "monospace", fontSize: "0.62rem", letterSpacing: 2, color: "rgba(255,255,255,0.4)", textTransform: "uppercase", marginBottom: 8 }}>
                  Логин
                </label>
                <input
                  name="login" type="text" placeholder="Введите логин" required
                  onMouseEnter={hoverOn} onMouseLeave={hoverOff}
                  style={{
                    width: "100%", padding: "13px 16px",
                    background: "rgba(255,255,255,0.05)",
                    border: `1px solid ${loginError ? "rgba(255,68,68,0.4)" : "rgba(255,255,255,0.1)"}`,
                    borderRadius: 2, color: "#fff", fontSize: "0.95rem",
                    fontFamily: "'Inter',sans-serif", outline: "none", transition: "border-color 0.3s",
                  }}
                  onFocus={(e) => { if (!loginError) e.currentTarget.style.borderColor = "#c9ff47"; }}
                  onBlur={(e) => { if (!loginError) e.currentTarget.style.borderColor = "rgba(255,255,255,0.1)"; }}
                />
              </div>
              <div style={{ marginBottom: 32 }}>
                <label style={{ display: "block", fontFamily: "monospace", fontSize: "0.62rem", letterSpacing: 2, color: "rgba(255,255,255,0.4)", textTransform: "uppercase", marginBottom: 8 }}>
                  Пароль
                </label>
                <input
                  name="password" type="password" placeholder="Введите пароль" required
                  onMouseEnter={hoverOn} onMouseLeave={hoverOff}
                  style={{
                    width: "100%", padding: "13px 16px",
                    background: "rgba(255,255,255,0.05)",
                    border: `1px solid ${loginError ? "rgba(255,68,68,0.4)" : "rgba(255,255,255,0.1)"}`,
                    borderRadius: 2, color: "#fff", fontSize: "0.95rem",
                    fontFamily: "'Inter',sans-serif", outline: "none", transition: "border-color 0.3s",
                  }}
                  onFocus={(e) => { if (!loginError) e.currentTarget.style.borderColor = "#c9ff47"; }}
                  onBlur={(e) => { if (!loginError) e.currentTarget.style.borderColor = "rgba(255,255,255,0.1)"; }}
                />
              </div>

              {loginError && (
                <div style={{
                  marginBottom: 20, padding: "12px 16px",
                  border: "1px solid rgba(255,68,68,0.3)", borderRadius: 2,
                  background: "rgba(255,68,68,0.06)", display: "flex", alignItems: "center", gap: 10,
                }}>
                  <span style={{ color: "#ff4444", flexShrink: 0 }}>✕</span>
                  <span style={{ fontFamily: "monospace", fontSize: "0.75rem", letterSpacing: 1, color: "#ff6666" }}>
                    Неверный логин или пароль
                  </span>
                </div>
              )}

              <button
                type="submit" disabled={loginLoading}
                onMouseEnter={hoverOn} onMouseLeave={hoverOff}
                style={{
                  width: "100%", padding: "16px",
                  background: "#c9ff47", border: "none", borderRadius: 2,
                  color: "#050505", fontWeight: 800, fontSize: "0.8rem",
                  letterSpacing: 2, textTransform: "uppercase", fontFamily: "monospace",
                  opacity: loginLoading ? 0.6 : 1, transition: "opacity 0.3s, transform 0.2s, box-shadow 0.2s",
                }}
                onMouseOver={(e) => { if (!loginLoading) { e.currentTarget.style.transform = "translateY(-2px)"; e.currentTarget.style.boxShadow = "0 12px 32px rgba(201,255,71,0.25)"; } }}
                onMouseOut={(e) => { e.currentTarget.style.transform = ""; e.currentTarget.style.boxShadow = ""; }}
              >
                {loginLoading ? "Проверка..." : "Войти →"}
              </button>
            </form>
          </div>
        </div>
      )}

      {/* Mobile menu overlay */}
      <div className={`mobile-menu${menuOpen ? " open" : ""}`}>
        {navLinks.map((item) => (
          <a
            key={item.href}
            href={item.href}
            onClick={(e) => {
              e.preventDefault();
              setMenuOpen(false);
              setTimeout(() => {
                if (item.isContact) { scrollToContact(); return; }
                document.querySelector(item.href)?.scrollIntoView({ behavior: "smooth" });
              }, 50);
            }}
          >
            {item.label}
          </a>
        ))}
        <button
          onClick={() => { setMenuOpen(false); setLoginOpen(true); }}
          style={{
            padding: "14px 40px", background: "#c9ff47", border: "none",
            borderRadius: 2, color: "#050505", fontWeight: 800,
            fontSize: "0.85rem", letterSpacing: 2, textTransform: "uppercase",
            fontFamily: "monospace", marginTop: 8,
          }}
        >
          Вход
        </button>
      </div>

      {/* HEADER */}
      <header style={{
        position: "fixed", top: 0, width: "100%", zIndex: 1000,
        borderBottom: "1px solid rgba(255,255,255,0.08)",
        background: "rgba(5,5,5,0.92)", backdropFilter: "blur(12px)",
      }}>
        <nav className="nav-inner">
          <div
            onClick={() => window.scrollTo({ top: 0, behavior: "smooth" })}
            onMouseEnter={hoverOn} onMouseLeave={hoverOff}
            style={{ fontFamily: "monospace", fontSize: "1rem", fontWeight: 700, letterSpacing: 3, color: "#fff", cursor: "pointer", textTransform: "uppercase", flexShrink: 0 }}
          >
            Exchange Feed
          </div>

          <ul className="nav-links">
            {navLinks.map((item) => (
              <li key={item.href}>
                <a
                  href={item.href}
                  className="nav-link"
                  onMouseEnter={hoverOn} onMouseLeave={hoverOff}
                  onClick={(e) => {
                    e.preventDefault();
                    if (item.isContact) { scrollToContact(); return; }
                    document.querySelector(item.href)?.scrollIntoView({ behavior: "smooth" });
                  }}
                >
                  {item.label}
                </a>
              </li>
            ))}
          </ul>

          <div style={{ display: "flex", alignItems: "center", gap: 12 }}>
            <button
              onClick={() => { setLoginOpen(true); setLoginError(false); }}
              onMouseEnter={hoverOn} onMouseLeave={hoverOff}
              style={{
                padding: "10px 28px", background: "transparent",
                border: "1px solid rgba(255,255,255,0.2)", borderRadius: 2,
                color: "#fff", fontWeight: 600, fontFamily: "monospace",
                fontSize: "0.75rem", letterSpacing: 2, textTransform: "uppercase",
                transition: "border-color 0.3s, background 0.3s, color 0.3s",
              }}
              onMouseOver={(e) => { e.currentTarget.style.borderColor = "#c9ff47"; e.currentTarget.style.color = "#c9ff47"; e.currentTarget.style.background = "rgba(201,255,71,0.05)"; }}
              onMouseOut={(e) => { e.currentTarget.style.borderColor = "rgba(255,255,255,0.2)"; e.currentTarget.style.color = "#fff"; e.currentTarget.style.background = "transparent"; }}
            >
              Вход
            </button>

            <button
              className="hamburger"
              onClick={() => setMenuOpen((o) => !o)}
              aria-label="Меню"
            >
              <span style={{ transform: menuOpen ? "rotate(45deg) translate(4px, 4px)" : "" }} />
              <span style={{ opacity: menuOpen ? 0 : 1 }} />
              <span style={{ transform: menuOpen ? "rotate(-45deg) translate(4px, -4px)" : "" }} />
            </button>
          </div>
        </nav>
      </header>

      {/* HERO */}
      <section className="hero-section">
        <div style={{
          position: "absolute", right: -20, top: "50%", transform: "translateY(-50%)",
          fontSize: "clamp(120px,20vw,400px)", fontWeight: 900, lineHeight: 1,
          color: "rgba(255,255,255,0.025)", userSelect: "none", pointerEvents: "none", fontFamily: "monospace",
        }}>EF</div>

        <div className="hero-inner" style={{ position: "relative", zIndex: 2 }}>
          <div className="hero-text">
            <div style={{
              display: "inline-flex", alignItems: "center", gap: 10,
              border: "1px solid rgba(201,255,71,0.3)", borderRadius: 2,
              padding: "6px 14px", marginBottom: 40,
              fontFamily: "monospace", fontSize: "0.7rem", letterSpacing: 3,
              color: "#c9ff47", textTransform: "uppercase",
            }}>
              <span style={{ width: 6, height: 6, borderRadius: "50%", background: "#c9ff47", display: "inline-block", animation: "pulse 2s infinite" }} />
              Закрытый сервис отзывов
            </div>

            <h1 style={{
              fontSize: "clamp(3rem,9vw,8rem)", fontWeight: 900, lineHeight: 0.88,
              color: "#fff", margin: "0 0 40px", letterSpacing: -3, fontFamily: "'Inter', sans-serif",
            }}>
              EXCHANGE<br />
              <span style={{ color: "#c9ff47" }}>FEED</span>
            </h1>

            <p style={{
              fontSize: "clamp(0.95rem,2vw,1.15rem)", color: "rgba(255,255,255,0.45)",
              maxWidth: 500, lineHeight: 1.75, marginBottom: 48,
            }}>
              Анонимное управление репутацией обменников. Пишем, модерируем, масштабируем под любые площадки без предоплаты.
            </p>

            <div className="hero-buttons">
              <button
                className="hero-btn-fill"
                onClick={scrollToContact}
                onMouseEnter={hoverOn} onMouseLeave={hoverOff}
                style={{
                  padding: "18px 44px", background: "#c9ff47", border: "none", borderRadius: 2,
                  color: "#050505", fontWeight: 800, fontSize: "0.85rem", letterSpacing: 2,
                  textTransform: "uppercase", fontFamily: "monospace",
                  transition: "transform 0.3s, box-shadow 0.3s",
                }}
                onMouseOver={(e) => { e.currentTarget.style.transform = "translateY(-3px)"; e.currentTarget.style.boxShadow = "0 16px 40px rgba(201,255,71,0.3)"; }}
                onMouseOut={(e) => { e.currentTarget.style.transform = ""; e.currentTarget.style.boxShadow = ""; }}
              >
                Начать демо бесплатно
              </button>
              <a
                className="hero-btn-outline"
                href="#why"
                onMouseEnter={hoverOn} onMouseLeave={hoverOff}
                onClick={(e) => { e.preventDefault(); document.querySelector("#why")?.scrollIntoView({ behavior: "smooth" }); }}
                style={{
                  padding: "18px 44px", background: "transparent",
                  border: "1px solid rgba(255,255,255,0.15)", borderRadius: 2,
                  color: "#fff", fontWeight: 700, fontSize: "0.85rem", letterSpacing: 2,
                  textTransform: "uppercase", fontFamily: "monospace",
                  textDecoration: "none", display: "inline-flex", alignItems: "center",
                  transition: "border-color 0.3s, color 0.3s",
                }}
                onMouseOver={(e) => { e.currentTarget.style.borderColor = "#c9ff47"; e.currentTarget.style.color = "#c9ff47"; }}
                onMouseOut={(e) => { e.currentTarget.style.borderColor = "rgba(255,255,255,0.15)"; e.currentTarget.style.color = "#fff"; }}
              >
                Как это работает
              </a>
            </div>
          </div>

          {/* Stats */}
          <div className="hero-stats">
            {[
              { num: "60+", label: "Постоянных партнёров" },
              { num: "2+", label: "Года на рынке" },
              { num: "100%", label: "Анонимность" },
            ].map((s) => (
              <div key={s.num} className="hero-stat">
                <div style={{ fontSize: "clamp(1.8rem,4vw,3rem)", fontWeight: 900, color: "#c9ff47", lineHeight: 1, fontFamily: "'Inter',sans-serif", letterSpacing: -2 }}>{s.num}</div>
                <div style={{ fontSize: "0.75rem", color: "rgba(255,255,255,0.4)", letterSpacing: 2, textTransform: "uppercase", fontFamily: "monospace", marginTop: 6 }}>{s.label}</div>
              </div>
            ))}
          </div>
        </div>

        <div style={{
          position: "absolute", bottom: 48, left: "50%", transform: "translateX(-50%)",
          display: "flex", flexDirection: "column", alignItems: "center", gap: 8,
        }}>
          <div style={{ width: 1, height: 56, background: "linear-gradient(to bottom, transparent, rgba(255,255,255,0.3))", animation: "scrollLine 2s ease-in-out infinite" }} />
          <div style={{ fontSize: "0.65rem", letterSpacing: 3, color: "rgba(255,255,255,0.3)", fontFamily: "monospace", textTransform: "uppercase" }}>scroll</div>
        </div>
      </section>

      {/* MARQUEE */}
      <div style={{ background: "#c9ff47", overflow: "hidden", padding: "14px 0", borderTop: "1px solid #b8ee36", borderBottom: "1px solid #b8ee36" }}>
        <div style={{ whiteSpace: "nowrap", transform: `translateX(${-offset % (charWidth * marqueeText.length)}px)`, willChange: "transform" }}>
          <span style={{ fontFamily: "monospace", fontSize: "0.85rem", fontWeight: 700, letterSpacing: 3, textTransform: "uppercase", color: "#050505" }}>
            {repeated}
          </span>
        </div>
      </div>

      {/* WHY */}
      <section id="why" className="s-pad" style={{ background: "#080808" }}>
        <div className="s-inner">
          <RevealBlock>
            <div className="sec-head">
              <div>
                <div style={{ fontFamily: "monospace", fontSize: "0.7rem", letterSpacing: 3, color: "#c9ff47", textTransform: "uppercase", marginBottom: 20 }}>01 — Преимущества</div>
                <h2 style={{ fontSize: "clamp(2rem,5vw,4rem)", fontWeight: 900, color: "#fff", lineHeight: 1.05, letterSpacing: -2, margin: 0 }}>
                  Почему с нами<br />не болит голова
                </h2>
              </div>
              <div className="hide-sm" style={{ fontFamily: "monospace", fontSize: "0.7rem", letterSpacing: 2, color: "rgba(255,255,255,0.25)", textTransform: "uppercase", textAlign: "right" }}>
                60+ партнёров<br />2+ года опыта
              </div>
            </div>
          </RevealBlock>

          <div className="feature-grid">
            {[
              { num: "01", title: "Полная анонимность", text: "Никто не узнает о сотрудничестве. Без утечек, без светящихся аккаунтов, без лишних вопросов." },
              { num: "02", title: "Живое качество", text: "Естественный язык, реальные сценарии клиента. Пишем под ваши тематики без спама-шаблонов." },
              { num: "03", title: "Оплата по факту", text: "Видите результат — платите. Никаких предоплат, никаких рисков и обещаний." },
              { num: "04", title: "60+ партнеров", text: "Более 2 лет на рынке. Долгосрочное сотрудничество с крупными командами обменников." },
            ].map((card, i) => (
              <RevealBlock key={card.num} delay={i * 60}>
                <div
                  className="feature-card"
                  onMouseEnter={hoverOn} onMouseLeave={hoverOff}
                  style={{
                    position: "relative", overflow: "hidden",
                    background: "#080808", padding: "60px 50px", minHeight: 300,
                    transition: "transform 0.4s cubic-bezier(0.16,1,0.3,1)",
                  }}
                  onMouseOver={(e) => { e.currentTarget.style.transform = "scale(1.01)"; }}
                  onMouseOut={(e) => { e.currentTarget.style.transform = ""; }}
                >
                  {/* Green corner accent */}
                  <div style={{
                    position: "absolute", top: 0, right: 0, width: 120, height: 120,
                    background: "radial-gradient(circle at top right, rgba(201,255,71,0.07) 0%, transparent 70%)",
                    pointerEvents: "none",
                  }} />
                  <div style={{ position: "relative", zIndex: 2 }}>
                    <div style={{ fontFamily: "monospace", fontSize: "0.65rem", letterSpacing: 3, color: "rgba(255,255,255,0.2)", textTransform: "uppercase", marginBottom: 48 }}>
                      {card.num}
                    </div>
                    <div style={{ width: 32, height: 1, background: "#c9ff47", marginBottom: 28 }} />
                    <h3 style={{ fontSize: "clamp(1.1rem,2vw,1.5rem)", fontWeight: 800, color: "#fff", marginBottom: 16, letterSpacing: -0.5 }}>{card.title}</h3>
                    <p style={{ fontSize: "0.9rem", color: "rgba(255,255,255,0.45)", lineHeight: 1.75 }}>{card.text}</p>
                  </div>
                </div>
              </RevealBlock>
            ))}
          </div>
        </div>
      </section>

      {/* TERMS */}
      <section id="terms" className="s-pad" style={{ background: "#050505" }}>
        <div className="s-inner">
          <RevealBlock>
            <div className="sec-head">
              <div>
                <div style={{ fontFamily: "monospace", fontSize: "0.7rem", letterSpacing: 3, color: "#c9ff47", textTransform: "uppercase", marginBottom: 20 }}>02 — Условия</div>
                <h2 style={{ fontSize: "clamp(2rem,5vw,4rem)", fontWeight: 900, color: "#fff", lineHeight: 1.05, letterSpacing: -2, margin: 0 }}>
                  Подстраиваемся<br />под вас
                </h2>
              </div>
            </div>
          </RevealBlock>

          <div className="terms-grid">
            <div>
              {[
                "Создаем фейковые заявки с полным путем клиента для максимально правдоподобных отзывов.",
                "Пишем по вашим тезисам: даете структуру — приводим к живому формату.",
                "Любой язык, ГЕО, почта. Адаптируем под локальные площадки и аудитории.",
                "Работаем весь день для естественного поведения аккаунтов.",
              ].map((text, i) => (
                <RevealBlock key={i} delay={i * 80}>
                  <div
                    onMouseEnter={hoverOn} onMouseLeave={hoverOff}
                    style={{
                      display: "flex", gap: 28, alignItems: "flex-start",
                      padding: "32px 0", borderBottom: "1px solid rgba(255,255,255,0.07)",
                      transition: "padding-left 0.4s",
                    }}
                    onMouseOver={(e) => (e.currentTarget.style.paddingLeft = "16px")}
                    onMouseOut={(e) => (e.currentTarget.style.paddingLeft = "0")}
                  >
                    <div style={{
                      minWidth: 44, height: 44, border: "1px solid rgba(201,255,71,0.4)",
                      borderRadius: 2, display: "flex", alignItems: "center", justifyContent: "center",
                      fontFamily: "monospace", fontSize: "0.75rem", color: "#c9ff47", fontWeight: 700, flexShrink: 0,
                    }}>
                      {String(i + 1).padStart(2, "0")}
                    </div>
                    <p style={{ fontSize: "clamp(0.95rem,1.5vw,1.1rem)", color: "rgba(255,255,255,0.7)", lineHeight: 1.7, margin: 0 }}>{text}</p>
                  </div>
                </RevealBlock>
              ))}
            </div>

            <RevealBlock delay={150}>
              <div className="sticky-box" style={{ border: "1px solid rgba(255,255,255,0.1)", borderRadius: 2, padding: "clamp(28px,4vw,48px) clamp(24px,3vw,40px)" }}>
                <div style={{ fontFamily: "monospace", fontSize: "0.65rem", letterSpacing: 3, color: "#c9ff47", textTransform: "uppercase", marginBottom: 28 }}>Тарифы</div>
                <h3 style={{ fontSize: "clamp(1.4rem,3vw,1.8rem)", fontWeight: 900, color: "#fff", marginBottom: 16, letterSpacing: -1 }}>Без жестких тарифов</h3>
                <p style={{ color: "rgba(255,255,255,0.4)", lineHeight: 1.75, fontSize: "0.95rem", marginBottom: 36 }}>
                  Стоимость зависит от объема, площадок и языков. Подписываем NDA при необходимости.
                </p>
                <div style={{ borderTop: "1px solid rgba(255,255,255,0.08)", paddingTop: 28 }}>
                  <div style={{ fontSize: "2.5rem", fontWeight: 900, color: "#c9ff47", letterSpacing: -2, fontFamily: "'Inter',sans-serif" }}>60+</div>
                  <div style={{ fontFamily: "monospace", fontSize: "0.7rem", letterSpacing: 2, color: "rgba(255,255,255,0.35)", textTransform: "uppercase", marginTop: 6 }}>постоянных партнёров</div>
                </div>
              </div>
            </RevealBlock>
          </div>
        </div>
      </section>

      {/* SEARCH */}
      <section id="search" className="s-pad" style={{ background: "#080808" }}>
        <div className="s-inner">
          <RevealBlock>
            <div className="sec-head-alt">
              <div>
                <div style={{ fontFamily: "monospace", fontSize: "0.7rem", letterSpacing: 3, color: "#c9ff47", textTransform: "uppercase", marginBottom: 20 }}>03 — Поиск</div>
                <h2 style={{ fontSize: "clamp(2rem,5vw,4rem)", fontWeight: 900, color: "#fff", lineHeight: 1.05, letterSpacing: -2, margin: 0 }}>
                  Где ваш обменник<br />уже есть
                </h2>
              </div>
            </div>
          </RevealBlock>

          <div className="search-grid">
            <RevealBlock>
              <div style={{ border: "1px solid rgba(255,255,255,0.08)", borderRadius: 2, padding: "clamp(28px,4vw,50px)" }}>
                <div style={{ fontFamily: "monospace", fontSize: "0.65rem", letterSpacing: 3, color: "#c9ff47", textTransform: "uppercase", marginBottom: 28 }}>Проверка обменника</div>
                <div className="search-input-row" style={{ display: "flex", gap: 12, marginBottom: 20 }}>
                  <input
                    placeholder="https://мой-обменник.com"
                    style={{
                      flex: 1, padding: "14px 18px", background: "rgba(255,255,255,0.04)",
                      border: "1px solid rgba(255,255,255,0.1)", borderRadius: 2,
                      color: "#fff", fontSize: "0.9rem", fontFamily: "'Inter',sans-serif", outline: "none", minWidth: 0,
                    }}
                    onFocus={(e) => (e.currentTarget.style.borderColor = "#c9ff47")}
                    onBlur={(e) => (e.currentTarget.style.borderColor = "rgba(255,255,255,0.1)")}
                  />
                  <button
                    onClick={() => setSearchResult(true)}
                    onMouseEnter={hoverOn} onMouseLeave={hoverOff}
                    style={{
                      padding: "14px 20px", background: "#c9ff47", border: "none",
                      borderRadius: 2, color: "#050505", fontWeight: 800,
                      fontSize: "0.75rem", letterSpacing: 2, textTransform: "uppercase",
                      fontFamily: "monospace", flexShrink: 0, transition: "opacity 0.2s",
                    }}
                    onMouseOver={(e) => (e.currentTarget.style.opacity = "0.85")}
                    onMouseOut={(e) => (e.currentTarget.style.opacity = "1")}
                  >
                    Найти
                  </button>
                </div>
                <p style={{ color: "rgba(255,255,255,0.3)", fontSize: "0.85rem", lineHeight: 1.7 }}>
                  Получите список площадок где уже есть профиль + рекомендации по расширению.
                </p>
              </div>
            </RevealBlock>

            <RevealBlock delay={100}>
              <div style={{ border: `1px solid ${searchResult ? "rgba(201,255,71,0.3)" : "rgba(255,255,255,0.08)"}`, borderRadius: 2, padding: "clamp(28px,4vw,50px)", transition: "border-color 0.4s" }}>
                <div style={{ fontFamily: "monospace", fontSize: "0.65rem", letterSpacing: 3, color: "#c9ff47", textTransform: "uppercase", marginBottom: 28 }}>Результаты анализа</div>
                <div style={{ display: "flex", flexWrap: "wrap", gap: 10, marginBottom: 20 }}>
                  {[{ label: "BestChange", active: true }, { label: "TrustPilot", active: true }, { label: "ForumBits", active: false }].map((tag) => (
                    <span key={tag.label} style={{
                      padding: "8px 14px", borderRadius: 2, fontSize: "0.8rem", fontFamily: "monospace", letterSpacing: 1,
                      border: `1px solid ${tag.active ? "rgba(201,255,71,0.4)" : "rgba(255,255,255,0.1)"}`,
                      color: tag.active ? "#c9ff47" : "rgba(255,255,255,0.3)",
                      background: tag.active ? "rgba(201,255,71,0.07)" : "transparent",
                    }}>
                      {tag.active ? "✓ " : "➕ "}{tag.label}
                    </span>
                  ))}
                </div>
                <p style={{ color: "rgba(255,255,255,0.25)", fontSize: "0.8rem", fontFamily: "monospace", letterSpacing: 1 }}>
                  ➕ Рекомендуем добавить · ✓ Уже размещено
                </p>
              </div>
            </RevealBlock>
          </div>
        </div>
      </section>

      {/* PLATFORMS */}
      <section id="platforms" className="s-pad" style={{ background: "#080808" }}>
        <div className="s-inner">
          <RevealBlock>
            <div className="sec-head-alt">
              <div>
                <div style={{ fontFamily: "monospace", fontSize: "0.7rem", letterSpacing: 3, color: "#c9ff47", textTransform: "uppercase", marginBottom: 20 }}>04 — Площадки</div>
                <h2 style={{ fontSize: "clamp(2rem,5vw,4rem)", fontWeight: 900, color: "#fff", lineHeight: 1.05, letterSpacing: -2, margin: 0 }}>
                  Мониторинги и форумы
                </h2>
                <p style={{ marginTop: 20, color: "rgba(255,255,255,0.4)", fontSize: "clamp(0.95rem,1.5vw,1.1rem)", maxWidth: 540 }}>
                  Площадки, с которыми мы работаем. Размещаем и управляем отзывами напрямую.
                </p>
              </div>
            </div>
          </RevealBlock>

          {["monitoring", "forum"].map((type, ti) => (
            <RevealBlock key={type} delay={ti * 100}>
              <div style={{ marginBottom: ti === 0 ? 56 : 0 }}>
                <div style={{ fontFamily: "monospace", fontSize: "0.65rem", letterSpacing: 3, color: "rgba(255,255,255,0.3)", textTransform: "uppercase", marginBottom: 24 }}>
                  — {type === "monitoring" ? "Мониторинги" : "Форумы"}
                </div>
                <div style={{ display: "flex", flexWrap: "wrap", gap: 12 }}>
                  {platforms.filter((p) => p.type === type).map((p) => (
                    <a
                      key={p.id}
                      href={p.url ?? "#"} target="_blank" rel="noopener noreferrer"
                      onMouseEnter={hoverOn} onMouseLeave={hoverOff}
                      style={{
                        display: "inline-flex", alignItems: "center", gap: 8,
                        padding: "12px 20px",
                        border: `1px solid ${type === "monitoring" ? "rgba(255,255,255,0.1)" : "rgba(255,255,255,0.08)"}`,
                        borderRadius: 2, textDecoration: "none", color: "#fff",
                        fontFamily: "monospace", fontSize: "0.85rem", letterSpacing: 1,
                        transition: "border-color 0.3s, background 0.3s",
                      }}
                      onMouseOver={(e) => { e.currentTarget.style.borderColor = type === "monitoring" ? "#c9ff47" : "rgba(255,255,255,0.4)"; e.currentTarget.style.background = type === "monitoring" ? "rgba(201,255,71,0.05)" : "rgba(255,255,255,0.04)"; }}
                      onMouseOut={(e) => { e.currentTarget.style.borderColor = type === "monitoring" ? "rgba(255,255,255,0.1)" : "rgba(255,255,255,0.08)"; e.currentTarget.style.background = "transparent"; }}
                    >
                      <span style={{ width: 6, height: 6, borderRadius: type === "monitoring" ? "50%" : 1, background: type === "monitoring" ? "#c9ff47" : "rgba(255,255,255,0.4)", flexShrink: 0 }} />
                      {p.name}
                    </a>
                  ))}
                  {platforms.filter((p) => p.type === type).length === 0 && (
                    <span style={{ color: "rgba(255,255,255,0.2)", fontFamily: "monospace", fontSize: "0.8rem" }}>Загрузка...</span>
                  )}
                </div>
              </div>
            </RevealBlock>
          ))}
        </div>
      </section>

      {/* CONTACT */}
      <section id="contact" className="s-pad" style={{ background: "#050505" }}>
        <div className="s-inner">
          <RevealBlock>
            <div className="sec-head">
              <div>
                <div style={{ fontFamily: "monospace", fontSize: "0.7rem", letterSpacing: 3, color: "#c9ff47", textTransform: "uppercase", marginBottom: 20 }}>05 — Контакты</div>
                <h2 style={{ fontSize: "clamp(2rem,5vw,4rem)", fontWeight: 900, color: "#fff", lineHeight: 1.05, letterSpacing: -2, margin: 0 }}>
                  Начните демо-период
                </h2>
              </div>
            </div>
          </RevealBlock>

          <div className="contact-grid">
            <RevealBlock>
              <div>
                <p style={{ fontSize: "clamp(0.95rem,1.5vw,1.1rem)", color: "rgba(255,255,255,0.45)", lineHeight: 1.8, marginBottom: 48 }}>
                  Понимаем боль владельцев обменников: рейтинг проседает, появляется негатив. Exchange Feed решает это системно.
                </p>

                {/* Clickable contact items with copy feedback */}
                <div style={{ marginBottom: 40 }}>
                  {CONTACT_ITEMS.map((item, i) => {
                    const isCopied = copiedItem === item.value;
                    return (
                      <div
                        key={item.label}
                        className="copy-item"
                        onClick={() => copyToClipboard(item.value)}
                        onMouseEnter={hoverOn} onMouseLeave={hoverOff}
                        style={{
                          display: "flex", justifyContent: "space-between", alignItems: "center",
                          padding: "20px 12px",
                          borderBottom: i < CONTACT_ITEMS.length - 1 ? "1px solid rgba(255,255,255,0.07)" : "none",
                          gap: 16, cursor: "pointer",
                          transition: "background 0.2s",
                        }}
                      >
                        <span style={{ fontFamily: "monospace", fontSize: "0.7rem", letterSpacing: 2, color: "rgba(255,255,255,0.3)", textTransform: "uppercase", flexShrink: 0 }}>
                          {item.label}
                        </span>
                        <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
                          <span style={{ fontSize: "0.9rem", color: isCopied ? "#c9ff47" : "#fff", transition: "color 0.3s", textAlign: "right" }}>
                            {item.value}
                          </span>
                          <span style={{
                            fontFamily: "monospace", fontSize: "0.65rem", letterSpacing: 1,
                            color: isCopied ? "#c9ff47" : "rgba(255,255,255,0.2)",
                            textTransform: "uppercase",
                            transition: "color 0.3s, opacity 0.3s",
                            opacity: isCopied ? 1 : 0.6,
                            flexShrink: 0,
                          }}>
                            {isCopied ? "✓ скопировано" : "копировать"}
                          </span>
                        </div>
                      </div>
                    );
                  })}
                </div>

                <div style={{ border: "1px solid rgba(201,255,71,0.15)", borderRadius: 2, padding: "28px" }}>
                  <div style={{ fontFamily: "monospace", fontSize: "0.65rem", letterSpacing: 3, color: "#c9ff47", textTransform: "uppercase", marginBottom: 12 }}>Как начать</div>
                  <div style={{ fontSize: "0.9rem", color: "rgba(255,255,255,0.5)", lineHeight: 1.7 }}>
                    Тестовые отзывы → Согласование → Масштабирование → Результат
                  </div>
                </div>
              </div>
            </RevealBlock>

            <RevealBlock delay={120}>
              <form onSubmit={handleFormSubmit} style={{ border: "1px solid rgba(255,255,255,0.1)", borderRadius: 2, padding: "clamp(28px,4vw,60px) clamp(24px,4vw,50px)" }}>
                <div style={{ fontFamily: "monospace", fontSize: "0.65rem", letterSpacing: 3, color: "#c9ff47", textTransform: "uppercase", marginBottom: 40 }}>Получить демо</div>
                {[
                  { id: "email", label: "E-mail", type: "email", placeholder: "you@example.com" },
                  { id: "telegram", label: "Telegram", type: "text", placeholder: "@username" },
                ].map((f) => (
                  <div key={f.id} style={{ marginBottom: 24 }}>
                    <label htmlFor={f.id} style={{ display: "block", fontFamily: "monospace", fontSize: "0.65rem", letterSpacing: 2, color: "rgba(255,255,255,0.4)", textTransform: "uppercase", marginBottom: 8 }}>{f.label}</label>
                    <input
                      id={f.id} name={f.id} type={f.type} placeholder={f.placeholder} required
                      onMouseEnter={hoverOn} onMouseLeave={hoverOff}
                      style={{ width: "100%", padding: "14px 18px", background: "rgba(255,255,255,0.04)", border: "1px solid rgba(255,255,255,0.1)", borderRadius: 2, color: "#fff", fontSize: "0.95rem", fontFamily: "'Inter',sans-serif", outline: "none" }}
                      onFocus={(e) => { e.currentTarget.style.borderColor = "#c9ff47"; e.currentTarget.style.background = "rgba(201,255,71,0.04)"; }}
                      onBlur={(e) => { e.currentTarget.style.borderColor = "rgba(255,255,255,0.1)"; e.currentTarget.style.background = "rgba(255,255,255,0.04)"; }}
                    />
                  </div>
                ))}
                <div style={{ marginBottom: 28 }}>
                  <label htmlFor="message" style={{ display: "block", fontFamily: "monospace", fontSize: "0.65rem", letterSpacing: 2, color: "rgba(255,255,255,0.4)", textTransform: "uppercase", marginBottom: 8 }}>Задача</label>
                  <textarea
                    id="message" name="message" placeholder="Какие площадки и объемы интересуют?"
                    onMouseEnter={hoverOn} onMouseLeave={hoverOff}
                    style={{ width: "100%", padding: "14px 18px", background: "rgba(255,255,255,0.04)", border: "1px solid rgba(255,255,255,0.1)", borderRadius: 2, color: "#fff", fontSize: "0.95rem", fontFamily: "'Inter',sans-serif", outline: "none", minHeight: 110, resize: "vertical" }}
                    onFocus={(e) => { e.currentTarget.style.borderColor = "#c9ff47"; e.currentTarget.style.background = "rgba(201,255,71,0.04)"; }}
                    onBlur={(e) => { e.currentTarget.style.borderColor = "rgba(255,255,255,0.1)"; e.currentTarget.style.background = "rgba(255,255,255,0.04)"; }}
                  />
                </div>
                <button
                  type="submit" disabled={formLoading}
                  onMouseEnter={hoverOn} onMouseLeave={hoverOff}
                  style={{
                    width: "100%", padding: "17px",
                    background: formSent ? "#080808" : formError ? "#1a0505" : "#c9ff47",
                    border: formSent ? "1px solid #c9ff47" : formError ? "1px solid #ff4444" : "none",
                    borderRadius: 2, color: formSent ? "#c9ff47" : formError ? "#ff4444" : "#050505",
                    fontWeight: 800, fontSize: "0.8rem", letterSpacing: 2, textTransform: "uppercase",
                    fontFamily: "monospace", transition: "all 0.4s", opacity: formLoading ? 0.6 : 1,
                  }}
                >
                  {formLoading ? "Отправка..." : formSent ? "✓ Отправлено · Свяжемся в течение часа" : formError ? "✗ Ошибка · Попробуйте ещё раз" : "Получить демо →"}
                </button>
              </form>
            </RevealBlock>
          </div>
        </div>
      </section>

      {/* FOOTER */}
      <footer style={{ borderTop: "1px solid rgba(255,255,255,0.08)", padding: "28px 48px", background: "#050505" }}>
        <div className="footer-inner">
          <div style={{ fontFamily: "monospace", fontSize: "0.7rem", letterSpacing: 2, color: "rgba(255,255,255,0.2)", textTransform: "uppercase" }}>Exchange Feed © 2024</div>
          <div style={{ fontFamily: "monospace", fontSize: "0.7rem", letterSpacing: 2, color: "rgba(255,255,255,0.2)", textTransform: "uppercase" }}>Анонимно · Надёжно · Результат</div>
        </div>
      </footer>
    </>
  );
}
