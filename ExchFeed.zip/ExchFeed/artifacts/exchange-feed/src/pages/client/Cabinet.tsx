import { useEffect, useState } from "react";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from "recharts";
import ClientLayout from "./ClientLayout";

const C = "#c9ff47";
const CARD_BG = "rgba(255,255,255,0.03)";
const BORDER = "rgba(255,255,255,0.08)";
const CARD_BORDER = "rgba(255,255,255,0.1)";

interface SiteData {
  id: number;
  url: string;
  reviewsPerMonth: number;
  reviewsPeriod: string;
  pricePerReview: string;
  reviewsAllTime: number;
  reviewsThisMonth: number;
  reviewsToday: number;
  dailyTarget: number;
  chartData: { date: string; count: number }[];
}

interface ProfileData {
  client: { id: number; name: string; status: string };
  sites: SiteData[];
}

function StatBox({ label, value, accent }: { label: string; value: string | number; accent?: boolean }) {
  return (
    <div style={{
      background: CARD_BG,
      border: `1px solid ${accent ? "rgba(201,255,71,0.2)" : BORDER}`,
      borderRadius: 8, padding: "20px 24px",
    }}>
      <div style={{ fontSize: "0.7rem", color: "rgba(255,255,255,0.4)", textTransform: "uppercase", letterSpacing: 2, marginBottom: 10, fontFamily: "monospace" }}>
        {label}
      </div>
      <div style={{ fontSize: "1.8rem", fontWeight: 800, color: accent ? C : "#fff", lineHeight: 1 }}>
        {value}
      </div>
    </div>
  );
}

function periodLabel(period: string) {
  if (period === "day") return "в день";
  if (period === "week") return "в неделю";
  return "в месяц";
}

export default function Cabinet() {
  const [profile, setProfile] = useState<ProfileData | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(false);

  useEffect(() => {
    const token = localStorage.getItem("client_token");
    if (!token) return;
    fetch("/api/client/profile", {
      headers: { Authorization: `Bearer ${token}` },
    })
      .then((r) => r.json())
      .then((d) => {
        if (d.ok) setProfile(d);
        else setError(true);
      })
      .catch(() => setError(true))
      .finally(() => setLoading(false));
  }, []);

  const now = new Date();
  const monthName = now.toLocaleString("ru-RU", { month: "long", year: "numeric" });

  return (
    <ClientLayout>
      <div style={{ padding: "40px 48px", maxWidth: 1200 }}>
        <style>{`
          @media (max-width: 768px) {
            .cab-pad { padding: 24px 20px !important; }
            .cab-grid { grid-template-columns: 1fr !important; }
          }
        `}</style>

        <div style={{ marginBottom: 36 }}>
          <div style={{ fontFamily: "monospace", fontSize: "0.65rem", letterSpacing: 4, color: C, textTransform: "uppercase", marginBottom: 8 }}>
            Мониторинг
          </div>
          <h1 style={{ fontSize: "1.75rem", fontWeight: 900, color: "#fff", letterSpacing: -1, marginBottom: 4 }}>
            {profile?.client.name ?? "Личный кабинет"}
          </h1>
          <div style={{ fontSize: "0.85rem", color: "rgba(255,255,255,0.4)", fontFamily: "monospace" }}>
            Отчёт за {monthName}
          </div>
        </div>

        {loading ? (
          <div style={{ color: "rgba(255,255,255,0.4)", fontFamily: "monospace", fontSize: "0.85rem" }}>Загрузка...</div>
        ) : error ? (
          <div style={{ color: "#ff6666", fontFamily: "monospace", fontSize: "0.85rem" }}>Ошибка загрузки данных</div>
        ) : profile && profile.sites.length === 0 ? (
          <div style={{ background: CARD_BG, border: `1px solid ${BORDER}`, borderRadius: 10, padding: 48, textAlign: "center", color: "rgba(255,255,255,0.3)", fontFamily: "monospace" }}>
            Нет активных площадок
          </div>
        ) : (
          <div style={{ display: "flex", flexDirection: "column", gap: 40 }}>
            {profile?.sites.map((site) => (
              <div key={site.id}>
                <div style={{
                  background: CARD_BG,
                  border: `1px solid ${CARD_BORDER}`,
                  borderRadius: 12, overflow: "hidden",
                }}>
                  <div style={{
                    padding: "20px 28px",
                    borderBottom: `1px solid ${BORDER}`,
                    display: "flex", alignItems: "center", justifyContent: "space-between", flexWrap: "wrap", gap: 12,
                  }}>
                    <div>
                      <div style={{ fontFamily: "monospace", fontSize: "0.6rem", letterSpacing: 3, color: "rgba(255,255,255,0.35)", textTransform: "uppercase", marginBottom: 4 }}>
                        Площадка
                      </div>
                      <div style={{ fontWeight: 700, fontSize: "0.95rem", color: "#fff", wordBreak: "break-all" }}>
                        {site.url}
                      </div>
                    </div>
                    <div style={{ display: "flex", gap: 12, flexWrap: "wrap" }}>
                      <div style={{ background: "rgba(201,255,71,0.06)", border: "1px solid rgba(201,255,71,0.15)", borderRadius: 6, padding: "6px 14px", textAlign: "center" }}>
                        <div style={{ fontFamily: "monospace", fontSize: "0.6rem", color: "rgba(255,255,255,0.4)", marginBottom: 2 }}>ПЛАН</div>
                        <div style={{ color: C, fontWeight: 700, fontSize: "0.9rem" }}>
                          {site.reviewsPerMonth} {periodLabel(site.reviewsPeriod)}
                        </div>
                      </div>
                      <div style={{ background: "rgba(255,255,255,0.03)", border: `1px solid ${BORDER}`, borderRadius: 6, padding: "6px 14px", textAlign: "center" }}>
                        <div style={{ fontFamily: "monospace", fontSize: "0.6rem", color: "rgba(255,255,255,0.4)", marginBottom: 2 }}>В ДЕНЬ</div>
                        <div style={{ color: "#fff", fontWeight: 700, fontSize: "0.9rem" }}>{site.dailyTarget}</div>
                      </div>
                    </div>
                  </div>

                  <div className="cab-pad" style={{ padding: "24px 28px" }}>
                    <div className="cab-grid" style={{ display: "grid", gridTemplateColumns: "repeat(3, 1fr)", gap: 16, marginBottom: 28 }}>
                      <StatBox label="Всего за всё время" value={site.reviewsAllTime} accent />
                      <StatBox label={`За ${monthName}`} value={site.reviewsThisMonth} />
                      <StatBox label="Сегодня" value={site.reviewsToday} />
                    </div>

                    {site.chartData.length > 0 ? (
                      <div>
                        <div style={{ fontFamily: "monospace", fontSize: "0.65rem", letterSpacing: 2, color: "rgba(255,255,255,0.35)", textTransform: "uppercase", marginBottom: 16 }}>
                          Динамика по дням — {monthName}
                        </div>
                        <ResponsiveContainer width="100%" height={160}>
                          <BarChart data={site.chartData} margin={{ top: 4, right: 8, left: -10, bottom: 0 }}>
                            <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.05)" vertical={false} />
                            <XAxis
                              dataKey="date"
                              tick={{ fill: "rgba(255,255,255,0.3)", fontSize: 10, fontFamily: "monospace" }}
                              tickFormatter={(v) => v.slice(8)}
                              axisLine={false} tickLine={false}
                            />
                            <YAxis tick={{ fill: "rgba(255,255,255,0.3)", fontSize: 10 }} axisLine={false} tickLine={false} />
                            <Tooltip
                              contentStyle={{ background: "#0a0a0a", border: "1px solid rgba(255,255,255,0.12)", borderRadius: 6, fontSize: 12 }}
                              labelStyle={{ color: "#fff", fontFamily: "monospace" }}
                              itemStyle={{ color: C }}
                            />
                            <Bar dataKey="count" fill={C} radius={[3, 3, 0, 0]} name="Отзывов" />
                          </BarChart>
                        </ResponsiveContainer>
                      </div>
                    ) : (
                      <div style={{ textAlign: "center", color: "rgba(255,255,255,0.25)", fontFamily: "monospace", fontSize: "0.8rem", padding: "20px 0" }}>
                        Данных за текущий месяц ещё нет
                      </div>
                    )}
                  </div>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </ClientLayout>
  );
}
