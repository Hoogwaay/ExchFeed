import { useEffect, useState, useCallback } from "react";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from "recharts";
import AdminLayout from "./AdminLayout";

interface Stats {
  clientsActive: number;
  clientsPaused: number;
  reviewsToday: number;
  reviewsDoneThisMonth: number;
  reviewsRemainingThisMonth: number;
  reviewsTotalThisMonth: number;
  chartData: { date: string; count: number }[];
  earningsPerMonth: number;
  reviewsAllTime: number;
  earningsAllTime: number;
}

const C = "hsl(186 100% 50%)";
const CARD_BG = "hsl(240 12% 8%)";
const BORDER = "hsl(240 10% 15%)";

function StatCard({ label, value, sub, accent }: { label: string; value: string | number; sub?: string; accent?: boolean }) {
  return (
    <div style={{
      background: CARD_BG, border: `1px solid ${accent ? "rgba(0,245,255,0.2)" : BORDER}`,
      borderRadius: 10, padding: "24px 28px",
    }}>
      <div style={{ fontSize: "0.75rem", color: "hsl(0 0% 55%)", fontWeight: 500, marginBottom: 12, textTransform: "uppercase", letterSpacing: 1 }}>
        {label}
      </div>
      <div style={{ fontSize: "2rem", fontWeight: 800, color: accent ? C : "#fff", lineHeight: 1 }}>
        {value}
      </div>
      {sub && <div style={{ fontSize: "0.8rem", color: "hsl(0 0% 45%)", marginTop: 8 }}>{sub}</div>}
    </div>
  );
}

export default function Dashboard() {
  const [stats, setStats] = useState<Stats | null>(null);
  const [loading, setLoading] = useState(true);
  const [syncing, setSyncing] = useState(false);
  const [syncResult, setSyncResult] = useState<{ ok: boolean; synced?: number; errors?: string[] } | null>(null);

  const loadStats = useCallback(() => {
    setLoading(true);
    fetch("/api/admin/reviews/stats")
      .then((r) => r.json())
      .then((d) => { if (d.ok) setStats(d.stats); })
      .finally(() => setLoading(false));
  }, []);

  useEffect(() => { loadStats(); }, [loadStats]);

  const syncSheets = async () => {
    setSyncing(true);
    setSyncResult(null);
    try {
      const res = await fetch("/api/admin/sheets/sync", { method: "POST" });
      const data = await res.json();
      setSyncResult(data);
      if (data.ok) loadStats();
    } catch {
      setSyncResult({ ok: false });
    } finally {
      setSyncing(false);
    }
  };

  const now = new Date();
  const monthName = now.toLocaleString("ru-RU", { month: "long", year: "numeric" });

  return (
    <AdminLayout>
      <div style={{ padding: "40px 48px" }}>
        <div style={{ display: "flex", alignItems: "flex-start", justifyContent: "space-between", marginBottom: 32, flexWrap: "wrap", gap: 16 }}>
          <div>
            <div style={{ fontSize: "0.7rem", letterSpacing: 3, color: C, textTransform: "uppercase", marginBottom: 8, fontFamily: "monospace" }}>
              Дашборд
            </div>
            <h1 style={{ fontSize: "1.75rem", fontWeight: 800, color: "#fff", letterSpacing: -0.5 }}>
              Сводка — {monthName}
            </h1>
          </div>

          <div style={{ display: "flex", flexDirection: "column", alignItems: "flex-end", gap: 8 }}>
            <button
              onClick={syncSheets}
              disabled={syncing}
              style={{
                padding: "10px 20px",
                background: syncing ? "rgba(0,245,255,0.05)" : "rgba(0,245,255,0.1)",
                border: `1px solid rgba(0,245,255,0.3)`,
                borderRadius: 6, color: C, fontWeight: 700, fontSize: "0.85rem",
                cursor: syncing ? "wait" : "pointer",
                opacity: syncing ? 0.7 : 1,
                transition: "all 0.2s",
              }}
            >
              {syncing ? "⟳ Синхронизация..." : "⟳ Обновить статистику"}
            </button>
            {syncResult && (
              <div style={{
                fontSize: "0.75rem", fontFamily: "monospace",
                color: syncResult.ok ? C : "#ff6666",
                padding: "4px 10px", borderRadius: 4,
                background: syncResult.ok ? "rgba(0,245,255,0.05)" : "rgba(255,68,68,0.08)",
              }}>
                {syncResult.ok
                  ? `✓ Обновлено: ${syncResult.synced} источн.${syncResult.errors && syncResult.errors.length > 0 ? `, ${syncResult.errors.length} ошибок` : ""}`
                  : "✕ Ошибка синхронизации"}
              </div>
            )}
          </div>
        </div>

        {loading ? (
          <div style={{ color: "hsl(0 0% 50%)", padding: "40px 0" }}>Загрузка...</div>
        ) : stats ? (
          <>
            {/* All-time totals */}
            <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(240px, 1fr))", gap: 16, marginBottom: 16 }}>
              <StatCard
                label="Отзывов за всё время"
                value={stats.reviewsAllTime.toLocaleString("ru-RU")}
                accent
              />
              <StatCard
                label="Заработано за всё время"
                value={`${stats.earningsAllTime.toLocaleString("ru-RU", { minimumFractionDigits: 0, maximumFractionDigits: 0 })} ₽`}
                accent
              />
            </div>

            {/* Monthly stats */}
            <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(220px, 1fr))", gap: 16, marginBottom: 32 }}>
              <StatCard label="Клиентов в работе" value={stats.clientsActive} />
              <StatCard label="Клиентов на паузе" value={stats.clientsPaused} />
              <StatCard label="Отзывов сегодня" value={stats.reviewsToday} />
              <StatCard label="Сделано за месяц" value={stats.reviewsDoneThisMonth} />
              <StatCard label="Осталось за месяц" value={stats.reviewsRemainingThisMonth} sub="от плана" />
              <StatCard label="Всего за месяц (план)" value={stats.reviewsTotalThisMonth} />
              <StatCard
                label="Заработано за месяц (план)"
                value={`${stats.earningsPerMonth.toLocaleString("ru-RU", { minimumFractionDigits: 0, maximumFractionDigits: 0 })} ₽`}
              />
            </div>

            {/* Chart */}
            <div style={{ background: CARD_BG, border: `1px solid ${BORDER}`, borderRadius: 10, padding: "28px 28px 20px" }}>
              <div style={{ fontSize: "0.75rem", color: "hsl(0 0% 55%)", fontWeight: 500, marginBottom: 20, textTransform: "uppercase", letterSpacing: 1 }}>
                Отзывы по дням — {monthName}
              </div>
              {stats.chartData.length > 0 ? (
                <ResponsiveContainer width="100%" height={220}>
                  <BarChart data={stats.chartData} margin={{ top: 4, right: 8, left: -10, bottom: 0 }}>
                    <CartesianGrid strokeDasharray="3 3" stroke="hsl(240 10% 15%)" vertical={false} />
                    <XAxis
                      dataKey="date"
                      tick={{ fill: "hsl(0 0% 45%)", fontSize: 11 }}
                      tickFormatter={(v) => v.slice(8)}
                      axisLine={false} tickLine={false}
                    />
                    <YAxis tick={{ fill: "hsl(0 0% 45%)", fontSize: 11 }} axisLine={false} tickLine={false} />
                    <Tooltip
                      contentStyle={{ background: "hsl(240 12% 10%)", border: "1px solid hsl(240 10% 20%)", borderRadius: 6, fontSize: 12 }}
                      labelStyle={{ color: "#fff" }}
                      itemStyle={{ color: C }}
                    />
                    <Bar dataKey="count" fill={C} radius={[4, 4, 0, 0]} name="Отзывов" />
                  </BarChart>
                </ResponsiveContainer>
              ) : (
                <div style={{ color: "hsl(0 0% 45%)", padding: "40px 0", textAlign: "center" }}>
                  Нет данных за текущий месяц
                </div>
              )}
            </div>
          </>
        ) : (
          <div style={{ color: "hsl(0 84% 60%)" }}>Ошибка загрузки данных</div>
        )}
      </div>
    </AdminLayout>
  );
}
