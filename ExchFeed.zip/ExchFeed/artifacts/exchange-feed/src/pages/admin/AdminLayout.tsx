import { useLocation } from "wouter";
import { useEffect } from "react";

const NAV_ITEMS = [
  { path: "/admin", label: "Дашборд", icon: "⬡" },
  { path: "/admin/clients", label: "Клиенты", icon: "◈" },
  { path: "/admin/accounting", label: "Бухгалтерия", icon: "◉" },
  { path: "/admin/schedule", label: "График работы", icon: "◫" },
  { path: "/admin/resources", label: "Ресурсы", icon: "◧" },
];

export default function AdminLayout({ children }: { children: React.ReactNode }) {
  const [location, navigate] = useLocation();

  useEffect(() => {
    const token = localStorage.getItem("admin_token");
    if (!token) navigate("/login");
  }, [navigate]);

  const handleLogout = () => {
    localStorage.removeItem("admin_token");
    navigate("/login");
  };

  return (
    <div style={{ display: "flex", minHeight: "100vh", background: "hsl(240 15% 4%)", color: "#fff", fontFamily: "'Inter', sans-serif" }}>
      {/* Sidebar */}
      <aside style={{
        width: 240, flexShrink: 0, background: "hsl(240 12% 6%)",
        borderRight: "1px solid hsl(240 10% 15%)",
        display: "flex", flexDirection: "column",
        position: "fixed", top: 0, left: 0, bottom: 0, zIndex: 100,
      }}>
        {/* Logo */}
        <div style={{ padding: "24px 24px 20px", borderBottom: "1px solid hsl(240 10% 15%)" }}>
          <div style={{ fontFamily: "monospace", fontSize: "0.6rem", letterSpacing: 4, color: "hsl(186 100% 50%)", textTransform: "uppercase", marginBottom: 6 }}>
            Admin Panel
          </div>
          <div style={{ fontWeight: 800, fontSize: "1rem", letterSpacing: -0.5, color: "#fff" }}>Exchange Feed</div>
        </div>

        {/* Nav */}
        <nav style={{ flex: 1, padding: "16px 12px" }}>
          {NAV_ITEMS.map((item) => {
            const isActive = item.path === "/admin"
              ? location === "/admin"
              : location.startsWith(item.path);
            return (
              <button
                key={item.path}
                onClick={() => navigate(item.path)}
                style={{
                  display: "flex", alignItems: "center", gap: 12,
                  width: "100%", padding: "10px 12px", marginBottom: 4,
                  background: isActive ? "hsl(240 10% 12%)" : "transparent",
                  border: isActive ? "1px solid hsl(240 10% 20%)" : "1px solid transparent",
                  borderRadius: 6, cursor: "pointer",
                  color: isActive ? "#fff" : "hsl(0 0% 62%)",
                  fontSize: "0.875rem", fontWeight: isActive ? 600 : 400,
                  transition: "all 0.15s", textAlign: "left",
                }}
                onMouseOver={(e) => { if (!isActive) e.currentTarget.style.background = "hsl(240 10% 10%)"; e.currentTarget.style.color = "#fff"; }}
                onMouseOut={(e) => { if (!isActive) { e.currentTarget.style.background = "transparent"; e.currentTarget.style.color = "hsl(0 0% 62%)"; } }}
              >
                <span style={{ color: isActive ? "hsl(186 100% 50%)" : "inherit", fontSize: "1rem", fontFamily: "monospace" }}>{item.icon}</span>
                {item.label}
                {isActive && <span style={{ marginLeft: "auto", width: 4, height: 4, borderRadius: "50%", background: "hsl(186 100% 50%)" }} />}
              </button>
            );
          })}
        </nav>

        {/* Logout */}
        <div style={{ padding: "16px 12px", borderTop: "1px solid hsl(240 10% 15%)" }}>
          <button
            onClick={handleLogout}
            style={{
              display: "flex", alignItems: "center", gap: 12,
              width: "100%", padding: "10px 12px",
              background: "transparent", border: "1px solid transparent",
              borderRadius: 6, cursor: "pointer", color: "hsl(0 84% 60%)",
              fontSize: "0.875rem", fontWeight: 500, transition: "all 0.15s", textAlign: "left",
            }}
            onMouseOver={(e) => { e.currentTarget.style.background = "rgba(255,68,68,0.08)"; e.currentTarget.style.borderColor = "rgba(255,68,68,0.2)"; }}
            onMouseOut={(e) => { e.currentTarget.style.background = "transparent"; e.currentTarget.style.borderColor = "transparent"; }}
          >
            <span style={{ fontSize: "1rem" }}>⊘</span>
            Выйти
          </button>
        </div>
      </aside>

      {/* Main content */}
      <main style={{ flex: 1, marginLeft: 240, minHeight: "100vh", overflow: "auto" }}>
        {children}
      </main>
    </div>
  );
}
