import { useEffect, useState } from "react";
import AdminLayout from "./AdminLayout";

interface ClientSite {
  id?: number;
  url: string;
  reviewsPerMonth: number;
  reviewsPeriod: string;
  pricePerReview: string;
}

interface Client {
  id: number;
  name: string;
  status: string;
  login: string | null;
  passwordHash: string | null;
  googleSheetUrl: string | null;
  sites: ClientSite[];
}

const C = "hsl(186 100% 50%)";
const CARD_BG = "hsl(240 12% 8%)";
const BORDER = "hsl(240 10% 15%)";
const INPUT_STYLE: React.CSSProperties = {
  background: "hsl(240 10% 12%)", border: `1px solid ${BORDER}`,
  borderRadius: 6, color: "#fff", padding: "9px 12px", fontSize: "0.875rem",
  outline: "none", width: "100%", fontFamily: "inherit",
};

function emptySite(): ClientSite {
  return { url: "", reviewsPerMonth: 0, reviewsPeriod: "month", pricePerReview: "0" };
}
function emptyClient(): Omit<Client, "id" | "login" | "passwordHash"> {
  return { name: "", status: "active", googleSheetUrl: "", sites: [emptySite()] };
}

function periodLabel(period: string) {
  if (period === "day") return "отз/день";
  if (period === "week") return "отз/нед";
  return "отз/мес";
}

function dailyFromPeriod(count: number, period: string): string {
  if (period === "day") return `${count} в день`;
  if (period === "week") {
    const d = Math.round(count / 7);
    return `~${d} в день`;
  }
  const daysInMonth = new Date(new Date().getFullYear(), new Date().getMonth() + 1, 0).getDate();
  const base = Math.floor(count / daysInMonth);
  const extra = count % daysInMonth;
  if (extra === 0) return `${base} в день`;
  return `${base}–${base + 1} в день`;
}

export default function Clients() {
  const [clients, setClients] = useState<Client[]>([]);
  const [loading, setLoading] = useState(true);
  const [showForm, setShowForm] = useState(false);
  const [editing, setEditing] = useState<Client | null>(null);
  const [form, setForm] = useState<Omit<Client, "id" | "login" | "passwordHash">>(emptyClient());
  const [saving, setSaving] = useState(false);
  const [addingReviews, setAddingReviews] = useState<{ clientId: number; siteId: number } | null>(null);
  const [reviewDate, setReviewDate] = useState(new Date().toISOString().split("T")[0]);
  const [reviewCount, setReviewCount] = useState(1);
  const [credentials, setCredentials] = useState<{ login: string; password: string } | null>(null);
  const [generatingFor, setGeneratingFor] = useState<number | null>(null);

  const load = () => {
    setLoading(true);
    fetch("/api/admin/clients")
      .then((r) => r.json())
      .then((d) => { if (d.ok) setClients(d.clients); })
      .finally(() => setLoading(false));
  };

  useEffect(() => { load(); }, []);

  const openAdd = () => { setForm(emptyClient()); setEditing(null); setShowForm(true); };
  const openEdit = (c: Client) => {
    setEditing(c);
    setForm({
      name: c.name,
      status: c.status,
      googleSheetUrl: c.googleSheetUrl || "",
      sites: c.sites.map((s) => ({
        ...s,
        reviewsPeriod: s.reviewsPeriod || "month",
      })),
    });
    setShowForm(true);
  };

  const addSite = () => setForm((f) => ({ ...f, sites: [...f.sites, emptySite()] }));
  const removeSite = (i: number) => setForm((f) => ({ ...f, sites: f.sites.filter((_, idx) => idx !== i) }));
  const updateSite = (i: number, key: keyof ClientSite, value: string | number) => {
    setForm((f) => ({ ...f, sites: f.sites.map((s, idx) => idx === i ? { ...s, [key]: value } : s) }));
  };

  const save = async () => {
    setSaving(true);
    const url = editing ? `/api/admin/clients/${editing.id}` : "/api/admin/clients";
    const method = editing ? "PUT" : "POST";
    const res = await fetch(url, { method, headers: { "Content-Type": "application/json" }, body: JSON.stringify(form) });
    const data = await res.json();
    if (data.ok) { setShowForm(false); load(); }
    setSaving(false);
  };

  const deleteClient = async (id: number) => {
    if (!confirm("Удалить клиента?")) return;
    await fetch(`/api/admin/clients/${id}`, { method: "DELETE" });
    load();
  };

  const generateCredentials = async (clientId: number) => {
    setGeneratingFor(clientId);
    const res = await fetch(`/api/admin/clients/${clientId}/generate-credentials`, { method: "POST" });
    const data = await res.json();
    if (data.ok) {
      setCredentials({ login: data.login, password: data.password });
      load();
    }
    setGeneratingFor(null);
  };

  const addReviewRecord = async () => {
    if (!addingReviews) return;
    await fetch("/api/admin/reviews", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ clientSiteId: addingReviews.siteId, reviewDate, count: reviewCount }),
    });
    setAddingReviews(null);
  };

  return (
    <AdminLayout>
      <div style={{ padding: "40px 48px" }}>
        <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: 32 }}>
          <div>
            <div style={{ fontSize: "0.7rem", letterSpacing: 3, color: C, textTransform: "uppercase", marginBottom: 8, fontFamily: "monospace" }}>Клиенты</div>
            <h1 style={{ fontSize: "1.75rem", fontWeight: 800, color: "#fff", letterSpacing: -0.5 }}>База клиентов</h1>
          </div>
          <button
            onClick={openAdd}
            style={{ padding: "10px 20px", background: C, border: "none", borderRadius: 6, color: "#050505", fontWeight: 700, fontSize: "0.85rem", cursor: "pointer" }}
          >
            + Добавить клиента
          </button>
        </div>

        {loading ? (
          <div style={{ color: "hsl(0 0% 50%)" }}>Загрузка...</div>
        ) : clients.length === 0 ? (
          <div style={{ background: CARD_BG, border: `1px solid ${BORDER}`, borderRadius: 10, padding: "48px", textAlign: "center", color: "hsl(0 0% 45%)" }}>
            Нет клиентов. Добавьте первого клиента.
          </div>
        ) : (
          <div style={{ display: "flex", flexDirection: "column", gap: 16 }}>
            {clients.map((client) => (
              <div key={client.id} style={{ background: CARD_BG, border: `1px solid ${BORDER}`, borderRadius: 10, padding: "20px 24px" }}>
                <div style={{ display: "flex", alignItems: "flex-start", justifyContent: "space-between", marginBottom: 16, gap: 12, flexWrap: "wrap" }}>
                  <div>
                    <div style={{ display: "flex", alignItems: "center", gap: 12, marginBottom: 8 }}>
                      <span style={{ fontWeight: 700, fontSize: "1.05rem", color: "#fff" }}>{client.name}</span>
                      <span style={{
                        padding: "3px 10px", borderRadius: 20, fontSize: "0.72rem", fontWeight: 600,
                        background: client.status === "active" ? "rgba(0,245,255,0.12)" : "rgba(255,255,255,0.07)",
                        color: client.status === "active" ? C : "hsl(0 0% 55%)",
                        border: `1px solid ${client.status === "active" ? "rgba(0,245,255,0.3)" : "hsl(240 10% 20%)"}`,
                      }}>
                        {client.status === "active" ? "В работе" : "На паузе"}
                      </span>
                    </div>
                    <div style={{ display: "flex", alignItems: "center", gap: 16, flexWrap: "wrap" }}>
                      {client.login ? (
                        <div style={{ fontSize: "0.78rem", color: "hsl(0 0% 50%)", fontFamily: "monospace" }}>
                          Логин: <span style={{ color: C }}>{client.login}</span>
                        </div>
                      ) : (
                        <div style={{ fontSize: "0.78rem", color: "hsl(0 0% 40%)", fontFamily: "monospace" }}>
                          Логин не создан
                        </div>
                      )}
                      {client.googleSheetUrl && (
                        <div style={{ fontSize: "0.72rem", color: "hsl(0 0% 40%)", fontFamily: "monospace", maxWidth: 320, overflow: "hidden", textOverflow: "ellipsis", whiteSpace: "nowrap" }}>
                          📊 <a href={client.googleSheetUrl} target="_blank" rel="noopener noreferrer" style={{ color: "hsl(120 50% 55%)", textDecoration: "none" }}>Google Таблица</a>
                        </div>
                      )}
                    </div>
                  </div>
                  <div style={{ display: "flex", gap: 8, flexWrap: "wrap" }}>
                    <button
                      onClick={() => generateCredentials(client.id)}
                      disabled={generatingFor === client.id}
                      style={{ padding: "6px 14px", background: "rgba(201,255,71,0.08)", border: "1px solid rgba(201,255,71,0.25)", borderRadius: 6, color: C, cursor: "pointer", fontSize: "0.8rem", opacity: generatingFor === client.id ? 0.6 : 1 }}
                    >
                      {generatingFor === client.id ? "..." : (client.login ? "🔑 Новый пароль" : "🔑 Создать доступ")}
                    </button>
                    <button onClick={() => openEdit(client)} style={{ padding: "6px 14px", background: "hsl(240 10% 14%)", border: `1px solid ${BORDER}`, borderRadius: 6, color: "#fff", cursor: "pointer", fontSize: "0.8rem" }}>
                      Редактировать
                    </button>
                    <button onClick={() => deleteClient(client.id)} style={{ padding: "6px 14px", background: "rgba(255,68,68,0.1)", border: "1px solid rgba(255,68,68,0.3)", borderRadius: 6, color: "#ff6666", cursor: "pointer", fontSize: "0.8rem" }}>
                      Удалить
                    </button>
                  </div>
                </div>

                {client.sites.length > 0 && (
                  <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
                    {client.sites.map((site) => (
                      <div key={site.id} style={{ padding: "10px 14px", background: "hsl(240 10% 11%)", borderRadius: 6, border: `1px solid ${BORDER}` }}>
                        <div style={{ display: "flex", alignItems: "center", gap: 12, flexWrap: "wrap" }}>
                          <span style={{ flex: 1, color: "hsl(0 0% 75%)", fontSize: "0.875rem", wordBreak: "break-all", minWidth: 120 }}>{site.url}</span>
                          <span style={{ color: "hsl(0 0% 55%)", fontSize: "0.8rem", whiteSpace: "nowrap" }}>
                            {site.reviewsPerMonth} {periodLabel(site.reviewsPeriod || "month")}
                          </span>
                          <span style={{ color: "hsl(0 0% 45%)", fontSize: "0.75rem", whiteSpace: "nowrap" }}>
                            {dailyFromPeriod(site.reviewsPerMonth, site.reviewsPeriod || "month")}
                          </span>
                          <span style={{ color: C, fontSize: "0.8rem", fontWeight: 600, whiteSpace: "nowrap" }}>
                            {site.pricePerReview} ₽/отз
                          </span>
                          <button
                            onClick={() => setAddingReviews({ clientId: client.id, siteId: site.id! })}
                            style={{ padding: "4px 10px", background: "rgba(0,245,255,0.1)", border: "1px solid rgba(0,245,255,0.25)", borderRadius: 4, color: C, cursor: "pointer", fontSize: "0.75rem", whiteSpace: "nowrap" }}
                          >
                            + Отзыв
                          </button>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>
            ))}
          </div>
        )}
      </div>

      {/* Add/Edit Modal */}
      {showForm && (
        <div style={{ position: "fixed", inset: 0, background: "rgba(0,0,0,0.8)", display: "flex", alignItems: "center", justifyContent: "center", zIndex: 1000, padding: 24 }}>
          <div style={{ background: "hsl(240 12% 8%)", border: `1px solid ${BORDER}`, borderRadius: 12, padding: "32px", width: "100%", maxWidth: 680, maxHeight: "90vh", overflowY: "auto" }}>
            <h2 style={{ fontSize: "1.2rem", fontWeight: 700, color: "#fff", marginBottom: 24 }}>
              {editing ? "Редактировать клиента" : "Добавить клиента"}
            </h2>
            <div style={{ display: "grid", gridTemplateColumns: "1fr 140px", gap: 12, marginBottom: 20 }}>
              <div>
                <label style={{ fontSize: "0.75rem", color: "hsl(0 0% 55%)", display: "block", marginBottom: 6 }}>Название</label>
                <input style={INPUT_STYLE} value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} placeholder="Название клиента" />
              </div>
              <div>
                <label style={{ fontSize: "0.75rem", color: "hsl(0 0% 55%)", display: "block", marginBottom: 6 }}>Статус</label>
                <select style={{ ...INPUT_STYLE }} value={form.status} onChange={(e) => setForm({ ...form, status: e.target.value })}>
                  <option value="active">В работе</option>
                  <option value="paused">На паузе</option>
                </select>
              </div>
            </div>

            <div style={{ marginBottom: 20 }}>
              <label style={{ fontSize: "0.75rem", color: "hsl(0 0% 55%)", display: "block", marginBottom: 6 }}>Google Таблица (URL)</label>
              <input
                style={INPUT_STYLE}
                value={form.googleSheetUrl || ""}
                onChange={(e) => setForm({ ...form, googleSheetUrl: e.target.value })}
                placeholder="https://docs.google.com/spreadsheets/d/..."
              />
              <div style={{ fontSize: "0.7rem", color: "hsl(0 0% 40%)", marginTop: 5 }}>
                Одна таблица на клиента. Строки с URL площадок будут автоматически разбиты по сайтам.
              </div>
            </div>

            <div style={{ marginBottom: 16 }}>
              <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: 12 }}>
                <label style={{ fontSize: "0.75rem", color: "hsl(0 0% 55%)" }}>Площадки</label>
                <button onClick={addSite} style={{ padding: "4px 12px", background: "rgba(0,245,255,0.1)", border: "1px solid rgba(0,245,255,0.25)", borderRadius: 4, color: C, cursor: "pointer", fontSize: "0.75rem" }}>
                  + Добавить
                </button>
              </div>

              {form.sites.map((site, i) => (
                <div key={i} style={{ background: "hsl(240 10% 10%)", border: `1px solid ${BORDER}`, borderRadius: 8, padding: "16px", marginBottom: 12 }}>
                  <div style={{ display: "grid", gridTemplateColumns: "1fr auto", gap: 8, marginBottom: 10 }}>
                    <div>
                      <label style={{ fontSize: "0.7rem", color: "hsl(0 0% 45%)", display: "block", marginBottom: 4 }}>Ссылка на площадку</label>
                      <input style={INPUT_STYLE} value={site.url} onChange={(e) => updateSite(i, "url", e.target.value)} placeholder="https://example.com" />
                    </div>
                    {form.sites.length > 1 && (
                      <div style={{ display: "flex", alignItems: "flex-end" }}>
                        <button onClick={() => removeSite(i)} style={{ padding: "9px 12px", background: "transparent", border: `1px solid ${BORDER}`, borderRadius: 6, color: "#ff6666", cursor: "pointer", fontSize: "1rem" }}>×</button>
                      </div>
                    )}
                  </div>

                  <div style={{ display: "grid", gridTemplateColumns: "1fr 130px 110px", gap: 8, marginBottom: 10 }}>
                    <div>
                      <label style={{ fontSize: "0.7rem", color: "hsl(0 0% 45%)", display: "block", marginBottom: 4 }}>Количество отзывов</label>
                      <input style={INPUT_STYLE} type="number" value={site.reviewsPerMonth} onChange={(e) => updateSite(i, "reviewsPerMonth", Number(e.target.value))} placeholder="0" min={0} />
                    </div>
                    <div>
                      <label style={{ fontSize: "0.7rem", color: "hsl(0 0% 45%)", display: "block", marginBottom: 4 }}>Период</label>
                      <select style={{ ...INPUT_STYLE }} value={site.reviewsPeriod} onChange={(e) => updateSite(i, "reviewsPeriod", e.target.value)}>
                        <option value="day">В день</option>
                        <option value="week">В неделю</option>
                        <option value="month">В месяц</option>
                      </select>
                    </div>
                    <div>
                      <label style={{ fontSize: "0.7rem", color: "hsl(0 0% 45%)", display: "block", marginBottom: 4 }}>Цена ₽/отзыв</label>
                      <input style={INPUT_STYLE} type="number" value={site.pricePerReview} onChange={(e) => updateSite(i, "pricePerReview", e.target.value)} placeholder="0" min={0} step="0.01" />
                    </div>
                  </div>

                  {site.reviewsPerMonth > 0 && (
                    <div style={{ padding: "6px 10px", background: "rgba(0,245,255,0.05)", borderRadius: 4, fontSize: "0.75rem", color: C, fontFamily: "monospace" }}>
                      ≈ {dailyFromPeriod(site.reviewsPerMonth, site.reviewsPeriod)}
                    </div>
                  )}
                </div>
              ))}
            </div>

            <div style={{ display: "flex", gap: 12, marginTop: 8 }}>
              <button onClick={save} disabled={saving} style={{ flex: 1, padding: "11px", background: C, border: "none", borderRadius: 6, color: "#050505", fontWeight: 700, cursor: "pointer", fontSize: "0.875rem" }}>
                {saving ? "Сохранение..." : "Сохранить"}
              </button>
              <button onClick={() => setShowForm(false)} style={{ padding: "11px 20px", background: "transparent", border: `1px solid ${BORDER}`, borderRadius: 6, color: "#fff", cursor: "pointer", fontSize: "0.875rem" }}>
                Отмена
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Credentials Modal */}
      {credentials && (
        <div style={{ position: "fixed", inset: 0, background: "rgba(0,0,0,0.85)", display: "flex", alignItems: "center", justifyContent: "center", zIndex: 1000, padding: 24 }}>
          <div style={{ background: "hsl(240 12% 8%)", border: `1px solid rgba(201,255,71,0.3)`, borderRadius: 12, padding: "32px", width: "100%", maxWidth: 420 }}>
            <div style={{ textAlign: "center", marginBottom: 24 }}>
              <div style={{ fontSize: "2rem", marginBottom: 12 }}>🔑</div>
              <h2 style={{ fontSize: "1.2rem", fontWeight: 700, color: "#fff", marginBottom: 8 }}>Доступ сгенерирован</h2>
              <p style={{ fontSize: "0.8rem", color: "hsl(0 0% 50%)" }}>Сохраните данные — пароль больше не отобразится</p>
            </div>

            <div style={{ background: "hsl(240 10% 11%)", border: `1px solid ${BORDER}`, borderRadius: 8, padding: "16px 20px", marginBottom: 20 }}>
              <div style={{ marginBottom: 12 }}>
                <div style={{ fontSize: "0.7rem", color: "hsl(0 0% 45%)", marginBottom: 4, fontFamily: "monospace", letterSpacing: 1 }}>ЛОГИН</div>
                <div style={{ fontSize: "1.1rem", fontWeight: 700, color: C, fontFamily: "monospace" }}>{credentials.login}</div>
              </div>
              <div>
                <div style={{ fontSize: "0.7rem", color: "hsl(0 0% 45%)", marginBottom: 4, fontFamily: "monospace", letterSpacing: 1 }}>ПАРОЛЬ</div>
                <div style={{ fontSize: "1.1rem", fontWeight: 700, color: "#fff", fontFamily: "monospace" }}>{credentials.password}</div>
              </div>
            </div>

            <button
              onClick={() => {
                navigator.clipboard?.writeText(`Логин: ${credentials.login}\nПароль: ${credentials.password}`);
                setCredentials(null);
              }}
              style={{ width: "100%", padding: "12px", background: C, border: "none", borderRadius: 6, color: "#050505", fontWeight: 700, cursor: "pointer", fontSize: "0.875rem", marginBottom: 10 }}
            >
              Скопировать и закрыть
            </button>
            <button
              onClick={() => setCredentials(null)}
              style={{ width: "100%", padding: "10px", background: "transparent", border: `1px solid ${BORDER}`, borderRadius: 6, color: "#fff", cursor: "pointer", fontSize: "0.875rem" }}
            >
              Закрыть
            </button>
          </div>
        </div>
      )}

      {/* Add Review Record Modal */}
      {addingReviews && (
        <div style={{ position: "fixed", inset: 0, background: "rgba(0,0,0,0.75)", display: "flex", alignItems: "center", justifyContent: "center", zIndex: 1000, padding: 24 }}>
          <div style={{ background: "hsl(240 12% 8%)", border: `1px solid ${BORDER}`, borderRadius: 12, padding: "28px", width: "100%", maxWidth: 380 }}>
            <h2 style={{ fontSize: "1.1rem", fontWeight: 700, color: "#fff", marginBottom: 20 }}>Добавить отзыв</h2>
            <div style={{ marginBottom: 16 }}>
              <label style={{ fontSize: "0.75rem", color: "hsl(0 0% 55%)", display: "block", marginBottom: 6 }}>Дата</label>
              <input type="date" style={INPUT_STYLE} value={reviewDate} onChange={(e) => setReviewDate(e.target.value)} />
            </div>
            <div style={{ marginBottom: 20 }}>
              <label style={{ fontSize: "0.75rem", color: "hsl(0 0% 55%)", display: "block", marginBottom: 6 }}>Количество отзывов</label>
              <input type="number" style={INPUT_STYLE} value={reviewCount} onChange={(e) => setReviewCount(Number(e.target.value))} min={1} />
            </div>
            <div style={{ display: "flex", gap: 12 }}>
              <button onClick={addReviewRecord} style={{ flex: 1, padding: "10px", background: C, border: "none", borderRadius: 6, color: "#050505", fontWeight: 700, cursor: "pointer", fontSize: "0.875rem" }}>
                Добавить
              </button>
              <button onClick={() => setAddingReviews(null)} style={{ padding: "10px 18px", background: "transparent", border: `1px solid ${BORDER}`, borderRadius: 6, color: "#fff", cursor: "pointer", fontSize: "0.875rem" }}>
                Отмена
              </button>
            </div>
          </div>
        </div>
      )}
    </AdminLayout>
  );
}
