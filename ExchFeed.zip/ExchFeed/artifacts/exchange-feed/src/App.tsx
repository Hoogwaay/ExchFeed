import { Switch, Route, Router as WouterRouter } from "wouter";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { useState, useCallback, useEffect } from "react";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/not-found";
import Home from "@/pages/Home";
import Login from "@/pages/Login";
import Dashboard from "@/pages/admin/Dashboard";
import Clients from "@/pages/admin/Clients";
import Accounting from "@/pages/admin/Accounting";
import Schedule from "@/pages/admin/Schedule";
import Resources from "@/pages/admin/Resources";
import Cabinet from "@/pages/client/Cabinet";
import Loader from "@/components/Loader";
import { CursorContext } from "@/lib/cursor-context";

const queryClient = new QueryClient();

function Router() {
  return (
    <Switch>
      <Route path="/" component={Home} />
      <Route path="/login" component={Login} />
      <Route path="/cabinet" component={Cabinet} />
      <Route path="/admin" component={Dashboard} />
      <Route path="/admin/clients" component={Clients} />
      <Route path="/admin/accounting" component={Accounting} />
      <Route path="/admin/schedule" component={Schedule} />
      <Route path="/admin/resources" component={Resources} />
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  const [loaded, setLoaded] = useState(false);
  const [contentVisible, setContentVisible] = useState(false);
  const [cursor, setCursor] = useState({ x: -200, y: -200 });
  const [cursorBig, setCursorBig] = useState(false);

  useEffect(() => {
    const move = (e: MouseEvent) => setCursor({ x: e.clientX, y: e.clientY });
    window.addEventListener("mousemove", move);
    return () => window.removeEventListener("mousemove", move);
  }, []);

  const hoverOn = useCallback(() => setCursorBig(true), []);
  const hoverOff = useCallback(() => setCursorBig(false), []);

  const handleLoaderDone = useCallback(() => {
    setLoaded(true);
    requestAnimationFrame(() => {
      requestAnimationFrame(() => setContentVisible(true));
    });
  }, []);

  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <CursorContext.Provider value={{ hoverOn, hoverOff }}>
          {/* Global cursor — outside opacity wrapper & no transform, so position:fixed works */}
          <div
            style={{
              position: "fixed",
              left: cursor.x,
              top: cursor.y,
              width: cursorBig ? 44 : 10,
              height: cursorBig ? 44 : 10,
              borderRadius: "50%",
              background: cursorBig ? "transparent" : "#c9ff47",
              border: cursorBig ? "1.5px solid #c9ff47" : "none",
              transform: "translate(-50%,-50%)",
              pointerEvents: "none",
              zIndex: 999999,
              transition: "width 0.22s cubic-bezier(0.16,1,0.3,1), height 0.22s cubic-bezier(0.16,1,0.3,1), background 0.22s, border 0.22s",
              mixBlendMode: "difference",
            }}
          />

          {/* Film grain overlay */}
          <div
            style={{
              position: "fixed", inset: 0, zIndex: 99998, pointerEvents: "none",
              backgroundImage: `url("data:image/svg+xml,%3Csvg viewBox='0 0 256 256' xmlns='http://www.w3.org/2000/svg'%3E%3Cfilter id='noise'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.9' numOctaves='4' stitchTiles='stitch'/%3E%3C/filter%3E%3Crect width='100%25' height='100%25' filter='url(%23noise)' opacity='1'/%3E%3C/svg%3E")`,
              opacity: 0.03,
            }}
          />

          {!loaded && <Loader onDone={handleLoaderDone} />}

          {/* Pure opacity fade — no transform, so position:fixed header remains fixed during scroll */}
          <div style={{ opacity: contentVisible ? 1 : 0, transition: "opacity 0.9s cubic-bezier(0.16,1,0.3,1)" }}>
            <WouterRouter base={import.meta.env.BASE_URL.replace(/\/$/, "")}>
              <Router />
            </WouterRouter>
          </div>

          <Toaster />
        </CursorContext.Provider>
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
