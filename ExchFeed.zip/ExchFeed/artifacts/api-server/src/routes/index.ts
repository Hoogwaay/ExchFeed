import { Router, type IRouter } from "express";
import healthRouter from "./health";
import contactRouter from "./contact";
import platformsRouter from "./platforms";
import adminRouter from "./admin/index";
import clientRouter from "./client/index";

const router: IRouter = Router();

router.use(healthRouter);
router.use(contactRouter);
router.use(platformsRouter);
router.use("/admin", adminRouter);
router.use("/client", clientRouter);

export default router;
