import { Router } from "express";
import bcrypt from "bcryptjs";
import { db } from "@workspace/db";
import { clientsTable, clientSitesTable, sheetReviewsTable, reviewRecordsTable } from "@workspace/db";
import { eq, and, gte, lte, sql } from "drizzle-orm";

const router = Router();

function getClientIdFromToken(token: string): number | null {
  const match = token.match(/^client-(\d+)-valid$/);
  return match ? Number(match[1]) : null;
}

router.post("/auth/login", async (req, res) => {
  const { login, password } = req.body;
  try {
    const [client] = await db.select().from(clientsTable).where(eq(clientsTable.login, login));
    if (client && client.passwordHash) {
      const match = await bcrypt.compare(password, client.passwordHash);
      if (match) {
        res.json({ ok: true, token: `client-${client.id}-valid`, clientId: client.id, name: client.name });
        return;
      }
    }
    res.status(401).json({ ok: false, error: "Неверный логин или пароль" });
  } catch (err) {
    req.log.error({ err }, "Client login error");
    res.status(500).json({ ok: false, error: "Server error" });
  }
});

router.get("/profile", async (req, res) => {
  const auth = req.headers.authorization?.replace("Bearer ", "");
  if (!auth) return res.status(401).json({ ok: false, error: "Unauthorized" });

  const clientId = getClientIdFromToken(auth);
  if (!clientId) return res.status(401).json({ ok: false, error: "Invalid token" });

  try {
    const [client] = await db.select().from(clientsTable).where(eq(clientsTable.id, clientId));
    if (!client) return res.status(404).json({ ok: false, error: "Client not found" });

    const sites = await db.select().from(clientSitesTable).where(eq(clientSitesTable.clientId, clientId));

    const now = new Date();
    const year = now.getFullYear();
    const month = now.getMonth() + 1;
    const monthStart = `${year}-${String(month).padStart(2, "0")}-01`;
    const lastDay = new Date(year, month, 0).getDate();
    const monthEnd = `${year}-${String(month).padStart(2, "0")}-${lastDay}`;
    const today = now.toISOString().split("T")[0];

    const siteIds = sites.map((s) => s.id);
    const sitesData = await Promise.all(
      sites.map(async (site) => {
        const [sheetCount] = await db
          .select({ total: sql<number>`coalesce(count(*), 0)` })
          .from(sheetReviewsTable)
          .where(eq(sheetReviewsTable.clientSiteId, site.id));

        const [manualCount] = await db
          .select({ total: sql<number>`coalesce(sum(count), 0)` })
          .from(reviewRecordsTable)
          .where(eq(reviewRecordsTable.clientSiteId, site.id));

        const [sheetThisMonth] = await db
          .select({ total: sql<number>`coalesce(count(*), 0)` })
          .from(sheetReviewsTable)
          .where(
            and(
              eq(sheetReviewsTable.clientSiteId, site.id),
              gte(sheetReviewsTable.reviewDate, monthStart),
              lte(sheetReviewsTable.reviewDate, monthEnd)
            )
          );

        const [manualThisMonth] = await db
          .select({ total: sql<number>`coalesce(sum(count), 0)` })
          .from(reviewRecordsTable)
          .where(
            and(
              eq(reviewRecordsTable.clientSiteId, site.id),
              gte(reviewRecordsTable.reviewDate, monthStart),
              lte(reviewRecordsTable.reviewDate, monthEnd)
            )
          );

        const [sheetToday] = await db
          .select({ total: sql<number>`coalesce(count(*), 0)` })
          .from(sheetReviewsTable)
          .where(and(eq(sheetReviewsTable.clientSiteId, site.id), eq(sheetReviewsTable.reviewDate, today)));

        const [manualToday] = await db
          .select({ total: sql<number>`coalesce(sum(count), 0)` })
          .from(reviewRecordsTable)
          .where(and(eq(reviewRecordsTable.clientSiteId, site.id), eq(reviewRecordsTable.reviewDate, today)));

        const sheetRecentRows = await db
          .select()
          .from(sheetReviewsTable)
          .where(
            and(
              eq(sheetReviewsTable.clientSiteId, site.id),
              gte(sheetReviewsTable.reviewDate, monthStart),
              lte(sheetReviewsTable.reviewDate, monthEnd)
            )
          )
          .orderBy(sheetReviewsTable.reviewDate);

        const byDay: Record<string, number> = {};
        for (const r of sheetRecentRows) {
          byDay[r.reviewDate] = (byDay[r.reviewDate] || 0) + 1;
        }

        const daysInMonth = lastDay;
        const count = site.reviewsPerMonth;
        const period = site.reviewsPeriod || "month";
        let dailyTarget: number;
        if (period === "day") dailyTarget = count;
        else if (period === "week") dailyTarget = Math.round(count / 7);
        else dailyTarget = Math.round(count / daysInMonth);

        return {
          ...site,
          reviewsAllTime: (Number(sheetCount.total) || 0) + (Number(manualCount.total) || 0),
          reviewsThisMonth: (Number(sheetThisMonth.total) || 0) + (Number(manualThisMonth.total) || 0),
          reviewsToday: (Number(sheetToday.total) || 0) + (Number(manualToday.total) || 0),
          chartData: Object.entries(byDay).map(([date, count]) => ({ date, count })).sort((a, b) => a.date.localeCompare(b.date)),
          dailyTarget,
        };
      })
    );

    res.json({
      ok: true,
      client: { id: client.id, name: client.name, status: client.status },
      sites: sitesData,
    });
  } catch (err) {
    req.log.error({ err }, "Client profile error");
    res.status(500).json({ ok: false, error: "Server error" });
  }
});

export default router;
