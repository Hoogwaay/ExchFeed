import { Router } from "express";
import bcrypt from "bcryptjs";
import { db } from "@workspace/db";
import { clientsTable } from "@workspace/db";
import { eq } from "drizzle-orm";

const router = Router();

const ADMIN_LOGIN = "dxPHGdDmefyrTjhrhF87bZRLS1jfXG";
const ADMIN_PASSWORD = "XwTAO0WtQGMhv3oixZhwRZJezXVdG4";

router.post("/login", async (req, res) => {
  const { login, password } = req.body;

  if (login === ADMIN_LOGIN && password === ADMIN_PASSWORD) {
    res.json({ ok: true, token: "admin-session-valid", role: "admin" });
    return;
  }

  try {
    const [client] = await db.select().from(clientsTable).where(eq(clientsTable.login, login));
    if (client && client.passwordHash) {
      const match = await bcrypt.compare(password, client.passwordHash);
      if (match) {
        res.json({ ok: true, token: `client-${client.id}-valid`, role: "client", clientId: client.id });
        return;
      }
    }
  } catch (err) {
    req.log.error({ err }, "Client auth DB error");
  }

  res.status(401).json({ ok: false, error: "Неверный логин или пароль" });
});

export default router;
