import { Router } from "express";
import authRouter from "./auth";
import clientsRouter from "./clients";
import reviewsRouter from "./reviews";
import accountingRouter from "./accounting";
import schedulesRouter from "./schedules";
import resourcesRouter from "./resources";
import sheetsRouter from "./sheets";

const router = Router();

router.use("/auth", authRouter);
router.use("/clients", clientsRouter);
router.use("/reviews", reviewsRouter);
router.use("/accounting", accountingRouter);
router.use("/schedules", schedulesRouter);
router.use("/resources", resourcesRouter);
router.use("/sheets", sheetsRouter);

export default router;
