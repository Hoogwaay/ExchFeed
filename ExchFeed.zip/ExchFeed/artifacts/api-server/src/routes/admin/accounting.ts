import { Router } from "express";
import { db } from "@workspace/db";
import { accountingRecordsTable } from "@workspace/db";
import { eq, desc } from "drizzle-orm";

const router = Router();

router.get("/", async (req, res) => {
  try {
    const records = await db.select().from(accountingRecordsTable).orderBy(desc(accountingRecordsTable.recordDate));
    res.json({ ok: true, records });
  } catch (err) {
    req.log.error({ err }, "Failed to fetch accounting");
    res.status(500).json({ ok: false, error: "DB error" });
  }
});

router.post("/", async (req, res) => {
  try {
    const { type, amount, description, category, recordDate } = req.body;
    const [record] = await db.insert(accountingRecordsTable).values({ type, amount, description, category, recordDate }).returning();
    res.json({ ok: true, record });
  } catch (err) {
    req.log.error({ err }, "Failed to create accounting record");
    res.status(500).json({ ok: false, error: "DB error" });
  }
});

router.put("/:id", async (req, res) => {
  try {
    const id = Number(req.params.id);
    const { type, amount, description, category, recordDate } = req.body;
    const [record] = await db.update(accountingRecordsTable).set({ type, amount, description, category, recordDate }).where(eq(accountingRecordsTable.id, id)).returning();
    res.json({ ok: true, record });
  } catch (err) {
    req.log.error({ err }, "Failed to update accounting record");
    res.status(500).json({ ok: false, error: "DB error" });
  }
});

router.delete("/:id", async (req, res) => {
  try {
    const id = Number(req.params.id);
    await db.delete(accountingRecordsTable).where(eq(accountingRecordsTable.id, id));
    res.json({ ok: true });
  } catch (err) {
    req.log.error({ err }, "Failed to delete accounting record");
    res.status(500).json({ ok: false, error: "DB error" });
  }
});

export default router;
