import { Router } from "express";
import { syncSheets } from "../../lib/sheets-sync";

const router = Router();

router.post("/sync", async (req, res) => {
  try {
    const result = await syncSheets();
    res.json({ ok: true, ...result });
  } catch (err) {
    req.log.error({ err }, "Sheets sync failed");
    res.status(500).json({ ok: false, error: String(err) });
  }
});

export default router;
