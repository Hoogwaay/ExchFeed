import { Router } from "express";
import { db } from "@workspace/db";
import { resourcesTable } from "@workspace/db";
import { eq, asc } from "drizzle-orm";

const router = Router();

router.get("/", async (req, res) => {
  try {
    const resources = await db.select().from(resourcesTable).orderBy(asc(resourcesTable.id));
    res.json({ ok: true, resources });
  } catch (err) {
    req.log.error({ err }, "Failed to fetch resources");
    res.status(500).json({ ok: false, error: "DB error" });
  }
});

router.post("/", async (req, res) => {
  try {
    const { name, url, language, format } = req.body;
    const [resource] = await db.insert(resourcesTable).values({ name, url, language, format }).returning();
    res.json({ ok: true, resource });
  } catch (err) {
    req.log.error({ err }, "Failed to create resource");
    res.status(500).json({ ok: false, error: "DB error" });
  }
});

router.delete("/:id", async (req, res) => {
  try {
    const id = Number(req.params.id);
    await db.delete(resourcesTable).where(eq(resourcesTable.id, id));
    res.json({ ok: true });
  } catch (err) {
    req.log.error({ err }, "Failed to delete resource");
    res.status(500).json({ ok: false, error: "DB error" });
  }
});

export default router;
