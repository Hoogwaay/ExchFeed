import { Router } from "express";
import { db } from "@workspace/db";
import { staffSchedulesTable } from "@workspace/db";
import { eq, asc } from "drizzle-orm";

const router = Router();

router.get("/", async (req, res) => {
  try {
    const schedules = await db.select().from(staffSchedulesTable).orderBy(asc(staffSchedulesTable.workDate));
    res.json({ ok: true, schedules });
  } catch (err) {
    req.log.error({ err }, "Failed to fetch schedules");
    res.status(500).json({ ok: false, error: "DB error" });
  }
});

router.post("/", async (req, res) => {
  try {
    const { staffName, workDate, startTime, endTime, notes } = req.body;
    const [schedule] = await db.insert(staffSchedulesTable).values({ staffName, workDate, startTime, endTime, notes }).returning();
    res.json({ ok: true, schedule });
  } catch (err) {
    req.log.error({ err }, "Failed to create schedule");
    res.status(500).json({ ok: false, error: "DB error" });
  }
});

router.put("/:id", async (req, res) => {
  try {
    const id = Number(req.params.id);
    const { staffName, workDate, startTime, endTime, notes } = req.body;
    const [schedule] = await db.update(staffSchedulesTable).set({ staffName, workDate, startTime, endTime, notes }).where(eq(staffSchedulesTable.id, id)).returning();
    res.json({ ok: true, schedule });
  } catch (err) {
    req.log.error({ err }, "Failed to update schedule");
    res.status(500).json({ ok: false, error: "DB error" });
  }
});

router.delete("/:id", async (req, res) => {
  try {
    const id = Number(req.params.id);
    await db.delete(staffSchedulesTable).where(eq(staffSchedulesTable.id, id));
    res.json({ ok: true });
  } catch (err) {
    req.log.error({ err }, "Failed to delete schedule");
    res.status(500).json({ ok: false, error: "DB error" });
  }
});

export default router;
