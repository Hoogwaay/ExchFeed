import { Router } from "express";
import bcrypt from "bcryptjs";
import crypto from "crypto";
import { db } from "@workspace/db";
import { clientsTable, clientSitesTable } from "@workspace/db";
import { eq, asc } from "drizzle-orm";

const router = Router();

function generateLogin(name: string): string {
  const base = name
    .toLowerCase()
    .replace(/[^a-zа-яё0-9]/gi, "")
    .substring(0, 8) || "client";
  const suffix = crypto.randomBytes(3).toString("hex");
  return `${base}${suffix}`;
}

function generatePassword(): string {
  return crypto.randomBytes(8).toString("base64url").substring(0, 12);
}

router.get("/", async (req, res) => {
  try {
    const clients = await db.select().from(clientsTable).orderBy(asc(clientsTable.id));
    const sites = await db.select().from(clientSitesTable);
    const result = clients.map((c) => ({
      ...c,
      sites: sites.filter((s) => s.clientId === c.id),
    }));
    res.json({ ok: true, clients: result });
  } catch (err) {
    req.log.error({ err }, "Failed to fetch clients");
    res.status(500).json({ ok: false, error: "DB error" });
  }
});

router.post("/", async (req, res) => {
  try {
    const { name, status = "active", googleSheetUrl, sites = [] } = req.body;
    const [client] = await db
      .insert(clientsTable)
      .values({ name, status, googleSheetUrl: googleSheetUrl || null })
      .returning();
    if (sites.length > 0) {
      await db.insert(clientSitesTable).values(
        sites.map((s: { url: string; reviewsPerMonth: number; reviewsPeriod: string; pricePerReview: string }) => ({
          clientId: client.id,
          url: s.url,
          reviewsPerMonth: s.reviewsPerMonth,
          reviewsPeriod: s.reviewsPeriod || "month",
          pricePerReview: s.pricePerReview,
        }))
      );
    }
    const clientSites = await db.select().from(clientSitesTable).where(eq(clientSitesTable.clientId, client.id));
    res.json({ ok: true, client: { ...client, sites: clientSites } });
  } catch (err) {
    req.log.error({ err }, "Failed to create client");
    res.status(500).json({ ok: false, error: "DB error" });
  }
});

router.put("/:id", async (req, res) => {
  try {
    const id = Number(req.params.id);
    const { name, status, googleSheetUrl, sites = [] } = req.body;
    const [client] = await db
      .update(clientsTable)
      .set({ name, status, googleSheetUrl: googleSheetUrl || null })
      .where(eq(clientsTable.id, id))
      .returning();
    await db.delete(clientSitesTable).where(eq(clientSitesTable.clientId, id));
    if (sites.length > 0) {
      await db.insert(clientSitesTable).values(
        sites.map((s: { url: string; reviewsPerMonth: number; reviewsPeriod: string; pricePerReview: string }) => ({
          clientId: id,
          url: s.url,
          reviewsPerMonth: s.reviewsPerMonth,
          reviewsPeriod: s.reviewsPeriod || "month",
          pricePerReview: s.pricePerReview,
        }))
      );
    }
    const clientSites = await db.select().from(clientSitesTable).where(eq(clientSitesTable.clientId, id));
    res.json({ ok: true, client: { ...client, sites: clientSites } });
  } catch (err) {
    req.log.error({ err }, "Failed to update client");
    res.status(500).json({ ok: false, error: "DB error" });
  }
});

router.delete("/:id", async (req, res) => {
  try {
    const id = Number(req.params.id);
    await db.delete(clientsTable).where(eq(clientsTable.id, id));
    res.json({ ok: true });
  } catch (err) {
    req.log.error({ err }, "Failed to delete client");
    res.status(500).json({ ok: false, error: "DB error" });
  }
});

router.post("/:id/generate-credentials", async (req, res) => {
  try {
    const id = Number(req.params.id);
    const [existing] = await db.select().from(clientsTable).where(eq(clientsTable.id, id));
    if (!existing) return res.status(404).json({ ok: false, error: "Client not found" });

    const login = generateLogin(existing.name);
    const password = generatePassword();
    const passwordHash = await bcrypt.hash(password, 10);

    await db.update(clientsTable).set({ login, passwordHash }).where(eq(clientsTable.id, id));

    res.json({ ok: true, login, password });
  } catch (err) {
    req.log.error({ err }, "Failed to generate credentials");
    res.status(500).json({ ok: false, error: "DB error" });
  }
});

export default router;
