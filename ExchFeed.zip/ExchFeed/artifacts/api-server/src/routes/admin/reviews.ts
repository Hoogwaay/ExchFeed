import { Router } from "express";
import { db } from "@workspace/db";
import { reviewRecordsTable, clientSitesTable, clientsTable, sheetReviewsTable } from "@workspace/db";
import { eq, gte, lte, and, sql } from "drizzle-orm";

const router = Router();

router.get("/", async (req, res) => {
  try {
    const records = await db
      .select({
        id: reviewRecordsTable.id,
        clientSiteId: reviewRecordsTable.clientSiteId,
        reviewDate: reviewRecordsTable.reviewDate,
        count: reviewRecordsTable.count,
        siteUrl: clientSitesTable.url,
        clientId: clientSitesTable.clientId,
        clientName: clientsTable.name,
      })
      .from(reviewRecordsTable)
      .leftJoin(clientSitesTable, eq(reviewRecordsTable.clientSiteId, clientSitesTable.id))
      .leftJoin(clientsTable, eq(clientSitesTable.clientId, clientsTable.id));
    res.json({ ok: true, records });
  } catch (err) {
    req.log.error({ err }, "Failed to fetch reviews");
    res.status(500).json({ ok: false, error: "DB error" });
  }
});

router.post("/", async (req, res) => {
  try {
    const { clientSiteId, reviewDate, count } = req.body;
    const [record] = await db.insert(reviewRecordsTable).values({ clientSiteId, reviewDate, count }).returning();
    res.json({ ok: true, record });
  } catch (err) {
    req.log.error({ err }, "Failed to create review");
    res.status(500).json({ ok: false, error: "DB error" });
  }
});

router.get("/stats", async (req, res) => {
  try {
    const now = new Date();
    const year = now.getFullYear();
    const month = now.getMonth() + 1;
    const monthStart = `${year}-${String(month).padStart(2, "0")}-01`;
    const lastDay = new Date(year, month, 0).getDate();
    const monthEnd = `${year}-${String(month).padStart(2, "0")}-${lastDay}`;
    const today = now.toISOString().split("T")[0];

    const [clientsAll] = await db
      .select({
        active: sql<number>`count(*) filter (where status = 'active')`,
        paused: sql<number>`count(*) filter (where status = 'paused')`,
      })
      .from(clientsTable);

    const [todayManual] = await db
      .select({ total: sql<number>`coalesce(sum(count), 0)` })
      .from(reviewRecordsTable)
      .where(eq(reviewRecordsTable.reviewDate, today));

    const [todaySheet] = await db
      .select({ total: sql<number>`coalesce(count(*), 0)` })
      .from(sheetReviewsTable)
      .where(eq(sheetReviewsTable.reviewDate, today));

    const reviewsToday = (Number(todayManual.total) || 0) + (Number(todaySheet.total) || 0);

    const monthManual = await db
      .select({ count: reviewRecordsTable.count, reviewDate: reviewRecordsTable.reviewDate })
      .from(reviewRecordsTable)
      .where(and(gte(reviewRecordsTable.reviewDate, monthStart), lte(reviewRecordsTable.reviewDate, monthEnd)));

    const monthSheet = await db
      .select({ reviewDate: sheetReviewsTable.reviewDate })
      .from(sheetReviewsTable)
      .where(and(gte(sheetReviewsTable.reviewDate, monthStart), lte(sheetReviewsTable.reviewDate, monthEnd)));

    const doneThisMonth =
      monthManual.reduce((s, r) => s + (r.count || 0), 0) + monthSheet.length;

    const allSites = await db
      .select()
      .from(clientSitesTable)
      .leftJoin(clientsTable, eq(clientSitesTable.clientId, clientsTable.id));

    const daysInMonth = lastDay;
    const totalForMonth = allSites
      .filter((r) => r.clients?.status === "active")
      .reduce((s, r) => {
        const count = r.client_sites.reviewsPerMonth || 0;
        const period = r.client_sites.reviewsPeriod || "month";
        let monthly: number;
        if (period === "day") monthly = count * daysInMonth;
        else if (period === "week") monthly = Math.round((count / 7) * daysInMonth);
        else monthly = count;
        return s + monthly;
      }, 0);

    const remainingThisMonth = Math.max(0, totalForMonth - doneThisMonth);

    const byDay: Record<string, number> = {};
    for (const r of monthManual) {
      byDay[r.reviewDate] = (byDay[r.reviewDate] || 0) + (r.count || 0);
    }
    for (const r of monthSheet) {
      byDay[r.reviewDate] = (byDay[r.reviewDate] || 0) + 1;
    }
    const chartData = Object.entries(byDay)
      .map(([date, count]) => ({ date, count }))
      .sort((a, b) => a.date.localeCompare(b.date));

    const earningsPerMonth = allSites
      .filter((r) => r.clients?.status === "active")
      .reduce((s, r) => {
        const price = parseFloat(r.client_sites.pricePerReview?.toString() || "0");
        const count = r.client_sites.reviewsPerMonth || 0;
        const period = r.client_sites.reviewsPeriod || "month";
        let monthly: number;
        if (period === "day") monthly = count * daysInMonth;
        else if (period === "week") monthly = Math.round((count / 7) * daysInMonth);
        else monthly = count;
        return s + price * monthly;
      }, 0);

    const [allTimeManual] = await db
      .select({ total: sql<number>`coalesce(sum(count), 0)` })
      .from(reviewRecordsTable);

    const [allTimeSheet] = await db
      .select({ total: sql<number>`coalesce(count(*), 0)` })
      .from(sheetReviewsTable);

    const reviewsAllTime =
      (Number(allTimeManual.total) || 0) + (Number(allTimeSheet.total) || 0);

    const earningsAllTimeResult = await db
      .select({
        count: reviewRecordsTable.count,
        pricePerReview: clientSitesTable.pricePerReview,
      })
      .from(reviewRecordsTable)
      .leftJoin(clientSitesTable, eq(reviewRecordsTable.clientSiteId, clientSitesTable.id));

    const earningsManualAllTime = earningsAllTimeResult.reduce((s, r) => {
      const price = parseFloat(r.pricePerReview?.toString() || "0");
      return s + price * (r.count || 0);
    }, 0);

    const sheetEarningsResult = await db
      .select({ pricePerReview: clientSitesTable.pricePerReview })
      .from(sheetReviewsTable)
      .leftJoin(clientSitesTable, eq(sheetReviewsTable.clientSiteId, clientSitesTable.id));

    const earningsSheetAllTime = sheetEarningsResult.reduce((s, r) => {
      const price = parseFloat(r.pricePerReview?.toString() || "0");
      return s + price;
    }, 0);

    const earningsAllTime = earningsManualAllTime + earningsSheetAllTime;

    res.json({
      ok: true,
      stats: {
        clientsActive: Number(clientsAll.active) || 0,
        clientsPaused: Number(clientsAll.paused) || 0,
        reviewsToday,
        reviewsDoneThisMonth: doneThisMonth,
        reviewsRemainingThisMonth: remainingThisMonth,
        reviewsTotalThisMonth: totalForMonth,
        chartData,
        earningsPerMonth,
        reviewsAllTime,
        earningsAllTime,
      },
    });
  } catch (err) {
    req.log.error({ err }, "Failed to fetch stats");
    res.status(500).json({ ok: false, error: "DB error" });
  }
});

export default router;
