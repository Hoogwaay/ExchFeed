import { logger } from "./logger";

// TODO: подключить парсер Google Таблиц
// Функция parseSheet будет добавлена позже.
// Когда она появится — импортировать здесь и раскомментировать логику в syncSheets.

export async function syncSheets(): Promise<{ synced: number; errors: string[] }> {
  logger.info("Sheet sync called — parser not connected yet");
  return { synced: 0, errors: [] };
}

let syncInterval: ReturnType<typeof setInterval> | null = null;

export function startHourlySync() {
  if (syncInterval) return;
  syncInterval = setInterval(async () => {
    logger.info("Starting hourly sheet sync...");
    const result = await syncSheets();
    logger.info({ synced: result.synced, errors: result.errors.length }, "Hourly sheet sync complete");
  }, 60 * 60 * 1000);
  logger.info("Hourly sheet sync scheduled");
}
