#!/bin/bash

# Build and start the API server in the background (port 8081)
echo "Building and starting API server on port 8081..."
PORT=8081 pnpm --filter @workspace/api-server run dev &
API_PID=$!

# Wait for API server to be ready
echo "Waiting for API server..."
for i in $(seq 1 30); do
  if curl -s http://localhost:8081/api/healthz > /dev/null 2>&1; then
    echo "API server is ready."
    break
  fi
  sleep 1
done

# Start the Vite frontend dev server on port 5000
echo "Starting frontend dev server on port 5000..."
PORT=5000 BASE_PATH=/ pnpm --filter @workspace/exchange-feed run dev
