import { pgTable, serial, text, integer, numeric, timestamp, date } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";

export const clientsTable = pgTable("clients", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  status: text("status").notNull().default("active"),
  login: text("login").unique(),
  passwordHash: text("password_hash"),
  googleSheetUrl: text("google_sheet_url"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const clientSitesTable = pgTable("client_sites", {
  id: serial("id").primaryKey(),
  clientId: integer("client_id").notNull().references(() => clientsTable.id, { onDelete: "cascade" }),
  url: text("url").notNull(),
  reviewsPerMonth: integer("reviews_per_month").notNull().default(0),
  reviewsPeriod: text("reviews_period").notNull().default("month"),
  pricePerReview: numeric("price_per_review", { precision: 10, scale: 2 }).notNull().default("0"),
  createdAt: timestamp("created_at").defaultNow(),
});

export const reviewRecordsTable = pgTable("review_records", {
  id: serial("id").primaryKey(),
  clientSiteId: integer("client_site_id").notNull().references(() => clientSitesTable.id, { onDelete: "cascade" }),
  reviewDate: date("review_date").notNull(),
  count: integer("count").notNull().default(1),
  createdAt: timestamp("created_at").defaultNow(),
});

export const sheetReviewsTable = pgTable("sheet_reviews", {
  id: serial("id").primaryKey(),
  clientSiteId: integer("client_site_id").notNull().references(() => clientSitesTable.id, { onDelete: "cascade" }),
  reviewDate: date("review_date").notNull(),
  reviewUrl: text("review_url"),
  requestId: text("request_id"),
  email: text("email"),
  name: text("name").default("NoName"),
  syncedAt: timestamp("synced_at").defaultNow(),
});

export const insertClientSchema = createInsertSchema(clientsTable).omit({ id: true, createdAt: true });
export const insertClientSiteSchema = createInsertSchema(clientSitesTable).omit({ id: true, createdAt: true });
export const insertReviewRecordSchema = createInsertSchema(reviewRecordsTable).omit({ id: true, createdAt: true });
export const insertSheetReviewSchema = createInsertSchema(sheetReviewsTable).omit({ id: true, syncedAt: true });

export type InsertClient = z.infer<typeof insertClientSchema>;
export type Client = typeof clientsTable.$inferSelect;
export type InsertClientSite = z.infer<typeof insertClientSiteSchema>;
export type ClientSite = typeof clientSitesTable.$inferSelect;
export type InsertReviewRecord = z.infer<typeof insertReviewRecordSchema>;
export type ReviewRecord = typeof reviewRecordsTable.$inferSelect;
export type SheetReview = typeof sheetReviewsTable.$inferSelect;
