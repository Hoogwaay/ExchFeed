import { pgTable, serial, text, numeric, timestamp, date } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";

export const accountingRecordsTable = pgTable("accounting_records", {
  id: serial("id").primaryKey(),
  type: text("type").notNull(),
  amount: numeric("amount", { precision: 12, scale: 2 }).notNull(),
  description: text("description").notNull(),
  category: text("category"),
  recordDate: date("record_date").notNull(),
  createdAt: timestamp("created_at").defaultNow(),
});

export const insertAccountingRecordSchema = createInsertSchema(accountingRecordsTable).omit({ id: true, createdAt: true });
export type InsertAccountingRecord = z.infer<typeof insertAccountingRecordSchema>;
export type AccountingRecord = typeof accountingRecordsTable.$inferSelect;
