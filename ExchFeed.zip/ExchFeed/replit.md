# Exchange Feed Workspace

## Overview

pnpm workspace monorepo using TypeScript. Contains a React frontend (exchange-feed), Node.js API server, and mockup sandbox.

## Stack

- **Monorepo tool**: pnpm workspaces
- **Node.js version**: 24
- **Package manager**: pnpm 10
- **TypeScript version**: 5.9
- **Frontend**: React + Vite (exchange-feed), served on port 5000 at path "/"
- **API framework**: Express 5 (api-server), served on port 8081 at path "/api"
- **Database**: PostgreSQL 16 + Drizzle ORM (Replit built-in)
- **Validation**: Zod (`zod/v4`), `drizzle-zod`
- **API codegen**: Orval (from OpenAPI spec)
- **Build**: esbuild (CJS bundle for backend)
- **Telegram bot**: Integrated in api-server (TELEGRAM_BOT_TOKEN env var)

## Artifacts

- `artifacts/exchange-feed` — React + Vite frontend, port 5000, preview path "/"
- `artifacts/api-server` — Node.js Express API, port 8081, preview path "/api"
- `artifacts/mockup-sandbox` — Design mockup sandbox, port 8081, preview path "/__mockup"

## Shared Libraries (lib/)

- `lib/api-client-react` — React Query hooks (generated via Orval)
- `lib/api-spec` — OpenAPI spec (openapi.yaml)
- `lib/api-zod` — Zod schemas (generated)
- `lib/db` — Drizzle ORM database schema and client

## Key Commands

- `pnpm run typecheck` — full typecheck across all packages
- `pnpm run build` — typecheck + build all packages
- `pnpm --filter @workspace/api-spec run codegen` — regenerate API hooks and Zod schemas from OpenAPI spec
- `pnpm --filter @workspace/db run push` — push DB schema changes (dev only)
- `pnpm --filter @workspace/api-server run dev` — run API server locally
- `pnpm --filter @workspace/exchange-feed run dev` — run frontend locally
- `bash start.sh` — start both frontend and API server (main workflow command)

## Environment Variables

- `TELEGRAM_BOT_TOKEN` — Telegram bot token (set in Replit Secrets)
- `TELEGRAM_CHAT_ID` — Telegram chat ID (set in Replit Secrets)
- `DATABASE_URL` — PostgreSQL connection string (Replit built-in, auto-set)
- `PORT` — Set to 5000 (shared env var, frontend uses it)
- `BASE_PATH` — Set to "/" (shared env var, frontend uses it)
- API server uses PORT=8081 (explicitly set in start.sh)

## Startup

The `start.sh` script in the workspace root:
1. Builds and starts the API server on port 8081 in the background (with PORT=8081)
2. Waits for the API server to be ready
3. Starts the Vite frontend dev server on port 5000

The Vite dev server proxies `/api` requests to `localhost:8081`.

## Database

- Replit built-in PostgreSQL (DATABASE_URL, PGHOST, etc. auto-configured)
- Schema: `platforms`, `clients`, `accounting`, `staff`, `resources` tables
- DB schema changes: run `pnpm --filter @workspace/db run push` after modifying `lib/db/src/schema/`

## Deployment

- Target: autoscale
- Build: builds frontend and API server via pnpm
- Run: `python main.py` (Flask serves static frontend + proxies /api to Node.js API server)
- The Flask app handles both static file serving and proxying to the API server

## Setup Notes

- Installed from ExchFeed (2).zip (GitHub import)
- Node.js 24 and pnpm 10 installed via Replit modules
- Python 3.11 installed via Replit modules
- Flask and requests installed via pip
- Database provisioned and schema pushed on initial setup
- Vite configured with `allowedHosts: true` for Replit proxy compatibility
- start.sh explicitly sets PORT=8081 for API server to avoid conflict with frontend port 5000
