import { sql } from "drizzle-orm";
import { pgTable, text, varchar, integer, timestamp, numeric, pgEnum } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;

export const clientStatusEnum = pgEnum("client_status", ["in_work", "potential", "refused", "paused"]);

export const clients = pgTable("clients", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  name: text("name").notNull(),
  email: text("email"),
  phone: text("phone"),
  status: clientStatusEnum("status").notNull().default("potential"),
  notes: text("notes"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

const datePreprocess = z.preprocess(
  v => (typeof v === "string" && v ? new Date(v) : v instanceof Date ? v : new Date()),
  z.date()
);

export const insertClientSchema = createInsertSchema(clients).omit({ id: true, createdAt: true });
export type InsertClient = z.infer<typeof insertClientSchema>;
export type Client = typeof clients.$inferSelect;

export const reviews = pgTable("reviews", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  clientId: varchar("client_id").references(() => clients.id),
  count: integer("count").notNull().default(1),
  earnedAmount: numeric("earned_amount", { precision: 12, scale: 2 }).notNull().default("0"),
  date: timestamp("date").defaultNow().notNull(),
  notes: text("notes"),
});

export const insertReviewSchema = createInsertSchema(reviews).omit({ id: true }).extend({
  date: datePreprocess.optional(),
});
export type InsertReview = z.infer<typeof insertReviewSchema>;
export type Review = typeof reviews.$inferSelect;

export const transactionTypeEnum = pgEnum("transaction_type", ["income", "expense"]);

export const transactions = pgTable("transactions", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  type: transactionTypeEnum("type").notNull(),
  amount: numeric("amount", { precision: 12, scale: 2 }).notNull(),
  description: text("description"),
  date: timestamp("date").defaultNow().notNull(),
});

export const insertTransactionSchema = createInsertSchema(transactions).omit({ id: true }).extend({
  date: datePreprocess.optional(),
});
export type InsertTransaction = z.infer<typeof insertTransactionSchema>;
export type Transaction = typeof transactions.$inferSelect;
