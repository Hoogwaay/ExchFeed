# Admin Panel

A full-stack admin panel built with React + Express + PostgreSQL.

## Architecture

- **Frontend**: React (Vite), Wouter routing, TanStack Query, shadcn/ui, Tailwind CSS, Recharts
- **Backend**: Express, Drizzle ORM, PostgreSQL
- **Shared**: Drizzle schema + Zod validation in `shared/schema.ts`

## Pages

| Route | Page | Description |
|-------|------|-------------|
| `/` | Overview | Dashboard with stats, chart, client summary, recent payments/reviews |
| `/customers` | Customers | Full CRUD for client management with status filtering |
| `/reviews` | Reviews | Track review counts and earnings per client |
| `/balance` | Balance | Track income/expenses with running totals |

## Database Tables

- `users` - Auth (existing)
- `clients` - Client management (status: in_work, potential, paused, refused)
- `reviews` - Review entries with count, earned amount, date, optional client link
- `transactions` - Income/expense transactions

## Theme

- **Light mode**: White/gray background, blue (`#2563eb`) buttons and accents
- **Dark mode**: Dark navy background (`#0f1117`), acid-green (`#39ff14`) buttons and accents
- Toggle button in sidebar footer

## API Routes

All routes prefixed with `/api`:

- `GET/POST /api/clients`
- `PATCH/DELETE /api/clients/:id`
- `GET/POST /api/reviews`
- `GET /api/reviews/stats` — aggregate stats (totals, chart data by day/week/month)
- `PATCH/DELETE /api/reviews/:id`
- `GET/POST /api/transactions`
- `PATCH/DELETE /api/transactions/:id`

## Running

```bash
npm run dev       # Start dev server (port 5000)
npm run db:push   # Push schema changes to PostgreSQL
npm run build     # Build for production
```
