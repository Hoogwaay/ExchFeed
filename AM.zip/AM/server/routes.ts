import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { insertClientSchema, insertReviewSchema, insertTransactionSchema } from "@shared/schema";
import { z } from "zod";

export async function registerRoutes(
  httpServer: Server,
  app: Express
): Promise<Server> {
  // Clients
  app.get("/api/clients", async (req, res) => {
    try {
      const data = await storage.getClients();
      res.json(data);
    } catch (e) {
      res.status(500).json({ error: "Failed to get clients" });
    }
  });

  app.post("/api/clients", async (req, res) => {
    try {
      const parsed = insertClientSchema.parse(req.body);
      const client = await storage.createClient(parsed);
      res.json(client);
    } catch (e) {
      if (e instanceof z.ZodError) return res.status(400).json({ error: e.errors });
      res.status(500).json({ error: "Failed to create client" });
    }
  });

  app.patch("/api/clients/:id", async (req, res) => {
    try {
      const parsed = insertClientSchema.partial().parse(req.body);
      const client = await storage.updateClient(req.params.id, parsed);
      if (!client) return res.status(404).json({ error: "Client not found" });
      res.json(client);
    } catch (e) {
      if (e instanceof z.ZodError) return res.status(400).json({ error: e.errors });
      res.status(500).json({ error: "Failed to update client" });
    }
  });

  app.delete("/api/clients/:id", async (req, res) => {
    try {
      await storage.deleteClient(req.params.id);
      res.json({ ok: true });
    } catch (e) {
      res.status(500).json({ error: "Failed to delete client" });
    }
  });

  // Reviews
  app.get("/api/reviews", async (req, res) => {
    try {
      const data = await storage.getReviews();
      res.json(data);
    } catch (e) {
      res.status(500).json({ error: "Failed to get reviews" });
    }
  });

  app.get("/api/reviews/stats", async (req, res) => {
    try {
      const stats = await storage.getReviewStats();
      res.json(stats);
    } catch (e) {
      res.status(500).json({ error: "Failed to get stats" });
    }
  });

  app.post("/api/reviews", async (req, res) => {
    try {
      const parsed = insertReviewSchema.parse(req.body);
      const review = await storage.createReview(parsed);
      res.json(review);
    } catch (e) {
      if (e instanceof z.ZodError) return res.status(400).json({ error: e.errors });
      res.status(500).json({ error: "Failed to create review" });
    }
  });

  app.patch("/api/reviews/:id", async (req, res) => {
    try {
      const parsed = insertReviewSchema.partial().parse(req.body);
      const review = await storage.updateReview(req.params.id, parsed);
      if (!review) return res.status(404).json({ error: "Review not found" });
      res.json(review);
    } catch (e) {
      if (e instanceof z.ZodError) return res.status(400).json({ error: e.errors });
      res.status(500).json({ error: "Failed to update review" });
    }
  });

  app.delete("/api/reviews/:id", async (req, res) => {
    try {
      await storage.deleteReview(req.params.id);
      res.json({ ok: true });
    } catch (e) {
      res.status(500).json({ error: "Failed to delete review" });
    }
  });

  // Transactions
  app.get("/api/transactions", async (req, res) => {
    try {
      const data = await storage.getTransactions();
      res.json(data);
    } catch (e) {
      res.status(500).json({ error: "Failed to get transactions" });
    }
  });

  app.post("/api/transactions", async (req, res) => {
    try {
      const parsed = insertTransactionSchema.parse(req.body);
      const tx = await storage.createTransaction(parsed);
      res.json(tx);
    } catch (e) {
      if (e instanceof z.ZodError) return res.status(400).json({ error: e.errors });
      res.status(500).json({ error: "Failed to create transaction" });
    }
  });

  app.patch("/api/transactions/:id", async (req, res) => {
    try {
      const parsed = insertTransactionSchema.partial().parse(req.body);
      const tx = await storage.updateTransaction(req.params.id, parsed);
      if (!tx) return res.status(404).json({ error: "Transaction not found" });
      res.json(tx);
    } catch (e) {
      if (e instanceof z.ZodError) return res.status(400).json({ error: e.errors });
      res.status(500).json({ error: "Failed to update transaction" });
    }
  });

  app.delete("/api/transactions/:id", async (req, res) => {
    try {
      await storage.deleteTransaction(req.params.id);
      res.json({ ok: true });
    } catch (e) {
      res.status(500).json({ error: "Failed to delete transaction" });
    }
  });

  return httpServer;
}
