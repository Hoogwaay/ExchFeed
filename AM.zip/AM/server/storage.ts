import { eq, desc, sql, gte, and } from "drizzle-orm";
import { db } from "./db";
import {
  users, clients, reviews, transactions,
  type User, type InsertUser,
  type Client, type InsertClient,
  type Review, type InsertReview,
  type Transaction, type InsertTransaction,
} from "@shared/schema";
import { randomUUID } from "crypto";

export interface IStorage {
  getUser(id: string): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;

  getClients(): Promise<Client[]>;
  getClient(id: string): Promise<Client | undefined>;
  createClient(client: InsertClient): Promise<Client>;
  updateClient(id: string, client: Partial<InsertClient>): Promise<Client | undefined>;
  deleteClient(id: string): Promise<void>;

  getReviews(): Promise<Review[]>;
  createReview(review: InsertReview): Promise<Review>;
  updateReview(id: string, review: Partial<InsertReview>): Promise<Review | undefined>;
  deleteReview(id: string): Promise<void>;
  getReviewStats(): Promise<{
    totalAllTime: number;
    totalThisMonth: number;
    totalEarned: string;
    byDay: { date: string; count: number }[];
    byWeek: { date: string; count: number }[];
    byMonth: { date: string; count: number }[];
  }>;

  getTransactions(): Promise<Transaction[]>;
  createTransaction(transaction: InsertTransaction): Promise<Transaction>;
  updateTransaction(id: string, transaction: Partial<InsertTransaction>): Promise<Transaction | undefined>;
  deleteTransaction(id: string): Promise<void>;
}

export class DbStorage implements IStorage {
  async getUser(id: string): Promise<User | undefined> {
    const result = await db.select().from(users).where(eq(users.id, id));
    return result[0];
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    const result = await db.select().from(users).where(eq(users.username, username));
    return result[0];
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = randomUUID();
    const result = await db.insert(users).values({ ...insertUser, id }).returning();
    return result[0];
  }

  async getClients(): Promise<Client[]> {
    return db.select().from(clients).orderBy(desc(clients.createdAt));
  }

  async getClient(id: string): Promise<Client | undefined> {
    const result = await db.select().from(clients).where(eq(clients.id, id));
    return result[0];
  }

  async createClient(client: InsertClient): Promise<Client> {
    const id = randomUUID();
    const result = await db.insert(clients).values({ ...client, id }).returning();
    return result[0];
  }

  async updateClient(id: string, client: Partial<InsertClient>): Promise<Client | undefined> {
    const result = await db.update(clients).set(client).where(eq(clients.id, id)).returning();
    return result[0];
  }

  async deleteClient(id: string): Promise<void> {
    await db.delete(clients).where(eq(clients.id, id));
  }

  async getReviews(): Promise<Review[]> {
    return db.select().from(reviews).orderBy(desc(reviews.date));
  }

  async createReview(review: InsertReview): Promise<Review> {
    const id = randomUUID();
    const result = await db.insert(reviews).values({ ...review, id }).returning();
    return result[0];
  }

  async updateReview(id: string, review: Partial<InsertReview>): Promise<Review | undefined> {
    const result = await db.update(reviews).set(review).where(eq(reviews.id, id)).returning();
    return result[0];
  }

  async deleteReview(id: string): Promise<void> {
    await db.delete(reviews).where(eq(reviews.id, id));
  }

  async getReviewStats() {
    const now = new Date();
    const startOfMonth = new Date(now.getFullYear(), now.getMonth(), 1);

    const allReviews = await db.select().from(reviews);
    const totalAllTime = allReviews.reduce((sum, r) => sum + r.count, 0);
    const totalThisMonth = allReviews
      .filter(r => new Date(r.date) >= startOfMonth)
      .reduce((sum, r) => sum + r.count, 0);
    const totalEarned = allReviews
      .reduce((sum, r) => sum + parseFloat(r.earnedAmount || "0"), 0)
      .toFixed(2);

    const byDayMap = new Map<string, number>();
    const byWeekMap = new Map<string, number>();
    const byMonthMap = new Map<string, number>();

    allReviews.forEach(r => {
      const d = new Date(r.date);
      const day = d.toISOString().split("T")[0];
      const week = `${d.getFullYear()}-W${String(getWeekNumber(d)).padStart(2, "0")}`;
      const month = `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}`;

      byDayMap.set(day, (byDayMap.get(day) || 0) + r.count);
      byWeekMap.set(week, (byWeekMap.get(week) || 0) + r.count);
      byMonthMap.set(month, (byMonthMap.get(month) || 0) + r.count);
    });

    const sortKeys = (map: Map<string, number>) =>
      Array.from(map.entries())
        .sort((a, b) => a[0].localeCompare(b[0]))
        .slice(-30);

    return {
      totalAllTime,
      totalThisMonth,
      totalEarned,
      byDay: sortKeys(byDayMap).map(([date, count]) => ({ date, count })),
      byWeek: sortKeys(byWeekMap).map(([week, count]) => ({ date: week, count })),
      byMonth: sortKeys(byMonthMap).map(([month, count]) => ({ date: month, count })),
    };
  }

  async getTransactions(): Promise<Transaction[]> {
    return db.select().from(transactions).orderBy(desc(transactions.date));
  }

  async createTransaction(transaction: InsertTransaction): Promise<Transaction> {
    const id = randomUUID();
    const result = await db.insert(transactions).values({ ...transaction, id }).returning();
    return result[0];
  }

  async updateTransaction(id: string, transaction: Partial<InsertTransaction>): Promise<Transaction | undefined> {
    const result = await db.update(transactions).set(transaction).where(eq(transactions.id, id)).returning();
    return result[0];
  }

  async deleteTransaction(id: string): Promise<void> {
    await db.delete(transactions).where(eq(transactions.id, id));
  }
}

function getWeekNumber(d: Date): number {
  const date = new Date(Date.UTC(d.getFullYear(), d.getMonth(), d.getDate()));
  const dayNum = date.getUTCDay() || 7;
  date.setUTCDate(date.getUTCDate() + 4 - dayNum);
  const yearStart = new Date(Date.UTC(date.getUTCFullYear(), 0, 1));
  return Math.ceil((((date.getTime() - yearStart.getTime()) / 86400000) + 1) / 7);
}

export const storage = new DbStorage();
