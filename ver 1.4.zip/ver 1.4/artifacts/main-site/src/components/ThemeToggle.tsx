import { useTheme } from "@/lib/theme";

export function ThemeToggle() {
  const { theme, setTheme } = useTheme();

  return (
    <button
      onClick={() => setTheme(theme === "dark" ? "light" : "dark")}
      className="p-2 rounded-md hover:bg-accent transition"
      title="Toggle theme"
    >
      {theme === "dark" ? (
        <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 20 20">
          <path d="M10.5 1.5H9.5V.5h1v1zm0 17H9.5v-1h1v1zm8-8.5v1h-1v-1h1zm-17 0v1H.5v-1h1zm11.854-5.854l-.707-.707.707.707zm-11.07 11.07l-.707-.707.707.707zm0-11.07l.707.707-.707-.707zm11.07 11.07l.707.707-.707-.707zM10 5a5 5 0 110 10 5 5 0 010-10z" />
        </svg>
      ) : (
        <svg className="w-5 h-5" fill="currentColor" viewBox="0 0 20 20">
          <path d="M17.293 13.293A8 8 0 016.707 2.707a8.001 8.001 0 1010.586 10.586z" />
        </svg>
      )}
    </button>
  );
}
