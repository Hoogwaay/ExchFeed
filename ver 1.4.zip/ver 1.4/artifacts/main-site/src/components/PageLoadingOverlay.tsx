import { useEffect, useState } from "react";

interface PageLoadingOverlayProps {
  isOpen: boolean;
  onComplete?: () => void;
  duration?: number;
}

export function PageLoadingOverlay({
  isOpen,
  onComplete,
  duration = 2000,
}: PageLoadingOverlayProps) {
  const [isExiting, setIsExiting] = useState(false);

  useEffect(() => {
    if (!isOpen) {
      setIsExiting(false);
      return;
    }

    const timer = setTimeout(() => {
      setIsExiting(true);
      setTimeout(onComplete, 600);
    }, duration);

    return () => clearTimeout(timer);
  }, [isOpen, duration, onComplete]);

  if (!isOpen && !isExiting) return null;

  return (
    <>
      <style>{`
        @keyframes spin-loader {
          0% { transform: rotate(0deg); }
          100% { transform: rotate(360deg); }
        }
      `}</style>

      <div
        style={{
          position: "fixed",
          inset: 0,
          zIndex: 99997,
          background: "rgba(5, 5, 5, 0.95)",
          backdropFilter: "blur(4px)",
          display: "flex",
          alignItems: "center",
          justifyContent: "center",
          opacity: isExiting ? 0 : 1,
          transition: "opacity 0.6s cubic-bezier(0.76, 0, 0.24, 1)",
          pointerEvents: isExiting ? "none" : "all",
        }}
      >
        <div style={{ display: "flex", flexDirection: "column", alignItems: "center", gap: "24px" }}>
          {/* Animated spinner */}
          <div
            style={{
              width: "48px",
              height: "48px",
              border: "3px solid rgba(201, 255, 71, 0.2)",
              borderTop: "3px solid #c9ff47",
              borderRadius: "50%",
              animation: "spin-loader 1s linear infinite",
            }}
          />
          <div
            style={{
              fontFamily: "monospace",
              fontSize: "0.875rem",
              letterSpacing: "2px",
              color: "rgba(255, 255, 255, 0.6)",
              textTransform: "uppercase",
            }}
          >
            Загрузка...
          </div>
        </div>
      </div>
    </>
  );
}
