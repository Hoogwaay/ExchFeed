import { createContext } from "react";

export interface CursorContextValue {
  hoverOn: () => void;
  hoverOff: () => void;
}

export const CursorContext = createContext<CursorContextValue>({
  hoverOn: () => {},
  hoverOff: () => {},
});
