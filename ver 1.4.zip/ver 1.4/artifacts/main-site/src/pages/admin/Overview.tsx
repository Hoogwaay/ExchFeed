import { useEffect, useState } from "react";
import { api } from "@/api/client";

interface Stats {
  clientsActive: number;
  clientsPaused: number;
  reviewsToday: number;
  reviewsDoneThisMonth: number;
  earningsPerMonth: string;
  reviewsAllTime: number;
  earningsAllTime: string;
}

export default function AdminOverview() {
  const [stats, setStats] = useState<Stats | null>(null);

  useEffect(() => {
    api.get<Stats>("/admin/reviews/stats")
      .then(setStats)
      .catch(console.error);
  }, []);

  return (
    <div>
      <h1 className="text-2xl font-bold mb-6">Overview</h1>
      {stats && (
        <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
          {[
            { label: "Active Clients", value: stats.clientsActive },
            { label: "Paused Clients", value: stats.clientsPaused },
            { label: "Reviews Today", value: stats.reviewsToday },
            { label: "Reviews This Month", value: stats.reviewsDoneThisMonth },
            { label: "Earnings This Month", value: `$${stats.earningsPerMonth}` },
            { label: "All Time Reviews", value: stats.reviewsAllTime },
          ].map((item) => (
            <div
              key={item.label}
              className="rounded-xl border border-border bg-card p-5"
            >
              <p className="text-sm text-muted-foreground">{item.label}</p>
              <p className="text-2xl font-bold mt-1">{item.value}</p>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
