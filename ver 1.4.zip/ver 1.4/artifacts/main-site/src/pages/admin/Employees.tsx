export default function AdminEmployees() {
  return (
    <div>
      <h1 className="text-2xl font-bold mb-6">Employees</h1>
      <p className="text-muted-foreground">Employee management coming soon.</p>
    </div>
  );
}
