import { useEffect, useState } from "react";
import { api } from "@/api/client";

interface Client {
  id: string;
  name: string;
  status: string;
  login: string | null;
}

export default function AdminCustomers() {
  const [clients, setClients] = useState<Client[]>([]);

  useEffect(() => {
    api.get<{ ok: boolean; clients: Client[] }>("/admin/clients")
      .then((d) => setClients(d.clients))
      .catch(console.error);
  }, []);

  return (
    <div>
      <h1 className="text-2xl font-bold mb-6">Customers</h1>
      <div className="rounded-xl border border-border overflow-hidden">
        <table className="w-full text-sm">
          <thead className="bg-muted text-muted-foreground">
            <tr>
              <th className="text-left px-4 py-3 font-medium">Name</th>
              <th className="text-left px-4 py-3 font-medium">Status</th>
              <th className="text-left px-4 py-3 font-medium">Login</th>
            </tr>
          </thead>
          <tbody>
            {clients.map((c) => (
              <tr key={c.id} className="border-t border-border">
                <td className="px-4 py-3">{c.name}</td>
                <td className="px-4 py-3">{c.status}</td>
                <td className="px-4 py-3 text-muted-foreground">{c.login ?? "—"}</td>
              </tr>
            ))}
            {clients.length === 0 && (
              <tr>
                <td colSpan={3} className="px-4 py-8 text-center text-muted-foreground">
                  No customers yet
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
}
