export default function AdminCampaign() {
  return (
    <div>
      <h1 className="text-2xl font-bold mb-6">Campaign</h1>
      <p className="text-muted-foreground">Campaign management coming soon.</p>
    </div>
  );
}
