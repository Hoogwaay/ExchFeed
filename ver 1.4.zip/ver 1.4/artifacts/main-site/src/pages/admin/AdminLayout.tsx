import { useLocation } from "wouter";
import { ThemeToggle } from "@/components/ThemeToggle";

const navItems = [
  { label: "Overview", href: "/admin" },
  { label: "Analytics", href: "/admin/analytics" },
  { label: "Customers", href: "/admin/customers" },
  { label: "Reviews", href: "/admin/reviews" },
  { label: "Campaign", href: "/admin/campaign" },
  { label: "Balance", href: "/admin/balance" },
  { label: "Employees", href: "/admin/employees" },
  { label: "Activity", href: "/admin/activity" },
];

export default function AdminLayout({ children }: { children: React.ReactNode }) {
  const [location] = useLocation();

  return (
    <div className="flex min-h-screen bg-background">
      <aside className="w-56 border-r border-border bg-card p-4 flex flex-col">
        <div className="font-bold text-lg mb-6">Admin Panel</div>
        <nav className="flex-1 space-y-1">
          {navItems.map((item) => (
            <a
              key={item.href}
              href={item.href}
              className={`block rounded-md px-3 py-2 text-sm transition ${
                location === item.href
                  ? "bg-primary text-primary-foreground"
                  : "text-muted-foreground hover:bg-accent hover:text-accent-foreground"
              }`}
            >
              {item.label}
            </a>
          ))}
        </nav>
        <div className="flex items-center gap-2">
          <ThemeToggle />
          <button
            onClick={() => {
              localStorage.removeItem("adminToken");
              document.body.style.opacity = "0.5";
              document.body.style.transition = "opacity 0.6s cubic-bezier(0.76, 0, 0.24, 1)";
              setTimeout(() => {
                window.location.href = "/admin/login";
              }, 600);
            }}
            className="flex-1 text-sm text-muted-foreground hover:text-foreground mt-4"
          >
            Logout
          </button>
        </div>
      </aside>
      <main className="flex-1 p-8 overflow-auto">{children}</main>
    </div>
  );
}
