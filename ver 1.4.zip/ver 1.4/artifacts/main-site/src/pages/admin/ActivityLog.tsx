export default function AdminActivityLog() {
  return (
    <div>
      <h1 className="text-2xl font-bold mb-6">Activity Log</h1>
      <p className="text-muted-foreground">Activity log coming soon.</p>
    </div>
  );
}
