import { useEffect, useState } from "react";
import { api } from "@/api/client";

interface Record {
  id: string;
  type: "income" | "expense";
  amount: string;
  description: string;
  recordDate: string;
}

export default function AdminBalance() {
  const [records, setRecords] = useState<Record[]>([]);

  useEffect(() => {
    api.get<{ ok: boolean; records: Record[] }>("/admin/accounting")
      .then((d) => setRecords(d.records))
      .catch(console.error);
  }, []);

  const total = records.reduce((sum, r) => {
    return r.type === "income" ? sum + Number(r.amount) : sum - Number(r.amount);
  }, 0);

  return (
    <div>
      <h1 className="text-2xl font-bold mb-2">Balance</h1>
      <p className="text-3xl font-bold mb-6 text-primary">
        {total >= 0 ? "+" : ""}${total.toFixed(2)}
      </p>
      <div className="rounded-xl border border-border overflow-hidden">
        <table className="w-full text-sm">
          <thead className="bg-muted text-muted-foreground">
            <tr>
              <th className="text-left px-4 py-3 font-medium">Date</th>
              <th className="text-left px-4 py-3 font-medium">Type</th>
              <th className="text-left px-4 py-3 font-medium">Amount</th>
              <th className="text-left px-4 py-3 font-medium">Description</th>
            </tr>
          </thead>
          <tbody>
            {records.map((r) => (
              <tr key={r.id} className="border-t border-border">
                <td className="px-4 py-3">{r.recordDate}</td>
                <td className="px-4 py-3">
                  <span className={r.type === "income" ? "text-green-600" : "text-red-600"}>
                    {r.type}
                  </span>
                </td>
                <td className="px-4 py-3">${r.amount}</td>
                <td className="px-4 py-3 text-muted-foreground">{r.description}</td>
              </tr>
            ))}
            {records.length === 0 && (
              <tr>
                <td colSpan={4} className="px-4 py-8 text-center text-muted-foreground">
                  No records yet
                </td>
              </tr>
            )}
          </tbody>
        </table>
      </div>
    </div>
  );
}
