import { api } from "@/api/client";
import { useEffect, useState } from "react";
import { ThemeToggle } from "@/components/ThemeToggle";

export default function Home() {
  const [platforms, setPlatforms] = useState<{ id: string; name: string }[]>([]);

  useEffect(() => {
    api.get<{ ok: boolean; platforms: { id: string; name: string }[] }>("/platforms")
      .then((data) => setPlatforms(data.platforms))
      .catch(() => {});
  }, []);

  return (
    <main
      className="min-h-screen bg-background p-8"
      style={{
        animation: "fade-in-up 0.8s cubic-bezier(0.16,1,0.3,1)",
      }}
    >
      <style>{`
        @keyframes fade-in-up {
          from {
            opacity: 0;
            transform: translateY(32px);
          }
          to {
            opacity: 1;
            transform: translateY(0);
          }
        }
      `}</style>
      <div className="mx-auto max-w-4xl">
        <div className="flex justify-between items-center mb-8">
          <h1 className="text-4xl font-bold text-foreground">
            Exchange Feed
          </h1>
          <ThemeToggle />
        </div>
        <div className="grid grid-cols-2 md:grid-cols-3 gap-4">
          {platforms.map((p) => (
            <div
              key={p.id}
              className="rounded-lg border border-border p-4 bg-card text-card-foreground"
            >
              {p.name}
            </div>
          ))}
        </div>
        <div className="mt-12 flex gap-4">
          <a
            href="/login"
            className="rounded-md bg-primary px-6 py-3 text-primary-foreground font-medium hover:opacity-90 transition"
          >
            Client Login
          </a>
          <a
            href="/admin/login"
            className="rounded-md border border-border px-6 py-3 text-foreground font-medium hover:bg-accent transition"
          >
            Admin Panel
          </a>
        </div>
      </div>
    </main>
  );
}
