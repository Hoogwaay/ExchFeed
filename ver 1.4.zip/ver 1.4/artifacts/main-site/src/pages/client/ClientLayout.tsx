import { ThemeToggle } from "@/components/ThemeToggle";

export default function ClientLayout({ children }: { children: React.ReactNode }) {
  return (
    <div className="min-h-screen bg-background">
      <header className="border-b border-border bg-card px-6 py-4 flex items-center justify-between">
        <span className="font-bold">Client Cabinet</span>
        <div className="flex items-center gap-4">
          <ThemeToggle />
          <button
            onClick={() => {
              localStorage.removeItem("token");
              document.body.style.opacity = "0.5";
              document.body.style.transition = "opacity 0.6s cubic-bezier(0.76, 0, 0.24, 1)";
              setTimeout(() => {
                window.location.href = "/login";
              }, 600);
            }}
            className="text-sm text-muted-foreground hover:text-foreground"
          >
            Logout
          </button>
        </div>
      </header>
      <main className="p-8">{children}</main>
    </div>
  );
}
