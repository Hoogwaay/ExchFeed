export default function Cabinet() {
  return (
    <div>
      <h1 className="text-2xl font-bold mb-6">My Cabinet</h1>
      <p className="text-muted-foreground">Your review dashboard.</p>
    </div>
  );
}
