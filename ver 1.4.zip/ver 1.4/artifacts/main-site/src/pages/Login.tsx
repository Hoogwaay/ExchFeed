import { useState } from "react";
import { useLocation } from "wouter";
import { api } from "@/api/client";
import { ThemeToggle } from "@/components/ThemeToggle";
import { PageLoadingOverlay } from "@/components/PageLoadingOverlay";

export default function Login() {
  const [, navigate] = useLocation();
  const [form, setForm] = useState({ login: "", password: "" });
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);
  const [showLoader, setShowLoader] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError("");
    setLoading(true);
    try {
      const res = await api.post<{ ok: boolean; role: string; token: string; error?: string }>(
        "/auth/login",
        form
      );
      if (res.ok) {
        localStorage.setItem("token", res.token);
        localStorage.setItem("role", res.role);
        setShowLoader(true);
        const destination =
          res.role === "admin" ? "/admin" : res.role === "worker" ? "/crm/home" : "/cabinet";
        setTimeout(() => navigate(destination), 2200);
      } else {
        setError(res.error ?? "Login failed");
      }
    } catch (e) {
      setError(String(e));
    } finally {
      setLoading(false);
    }
  };

  return (
    <>
      <PageLoadingOverlay isOpen={showLoader} onComplete={() => setShowLoader(false)} />
      <div className="flex min-h-screen items-center justify-center bg-background">
        <div className="absolute top-4 right-4">
          <ThemeToggle />
        </div>
        <div className="w-full max-w-sm rounded-xl border border-border bg-card p-8 shadow-sm">
        <h1 className="text-2xl font-bold mb-6">Login</h1>
        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className="block text-sm font-medium mb-1">Login</label>
            <input
              type="text"
              className="w-full rounded-md border border-input bg-background px-3 py-2 text-sm"
              value={form.login}
              onChange={(e) => setForm({ ...form, login: e.target.value })}
              required
            />
          </div>
          <div>
            <label className="block text-sm font-medium mb-1">Password</label>
            <input
              type="password"
              className="w-full rounded-md border border-input bg-background px-3 py-2 text-sm"
              value={form.password}
              onChange={(e) => setForm({ ...form, password: e.target.value })}
              required
            />
          </div>
          {error && <p className="text-sm text-destructive">{error}</p>}
          <button
            type="submit"
            disabled={loading}
            className="w-full rounded-md bg-primary py-2 text-primary-foreground font-medium hover:opacity-90 disabled:opacity-50"
          >
            {loading ? "Loading..." : "Login"}
          </button>
        </form>
      </div>
      </div>
    </>
  );
}
