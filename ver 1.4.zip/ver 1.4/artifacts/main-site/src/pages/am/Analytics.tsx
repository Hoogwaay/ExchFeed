export default function AmAnalytics() {
  return <div><h1 className="text-2xl font-bold mb-6">AM Analytics</h1></div>;
}
