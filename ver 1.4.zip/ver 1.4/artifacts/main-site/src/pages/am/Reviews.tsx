export default function AmReviews() {
  return <div><h1 className="text-2xl font-bold mb-6">AM Reviews</h1></div>;
}
