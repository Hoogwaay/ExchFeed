export default function AmActivityLog() {
  return <div><h1 className="text-2xl font-bold mb-6">AM Activity Log</h1></div>;
}
