export default function AmOverview() {
  return (
    <div>
      <h1 className="text-2xl font-bold mb-6">AM Overview</h1>
      <p className="text-muted-foreground">Analytics manager overview.</p>
    </div>
  );
}
