export default function AmEmployees() {
  return <div><h1 className="text-2xl font-bold mb-6">AM Employees</h1></div>;
}
