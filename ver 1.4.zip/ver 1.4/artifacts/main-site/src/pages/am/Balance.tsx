export default function AmBalance() {
  return <div><h1 className="text-2xl font-bold mb-6">AM Balance</h1></div>;
}
