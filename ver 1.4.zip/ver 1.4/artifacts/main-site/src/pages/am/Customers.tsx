export default function AmCustomers() {
  return <div><h1 className="text-2xl font-bold mb-6">AM Customers</h1></div>;
}
