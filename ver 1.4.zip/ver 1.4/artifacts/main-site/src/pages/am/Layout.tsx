import { ThemeToggle } from "@/components/ThemeToggle";

const navItems = [
  { label: "Overview", href: "/am/overview" },
  { label: "Analytics", href: "/am/analytics" },
  { label: "Customers", href: "/am/customers" },
  { label: "Reviews", href: "/am/reviews" },
  { label: "Campaign", href: "/am/campaign" },
  { label: "Balance", href: "/am/balance" },
  { label: "Employees", href: "/am/employees" },
  { label: "Activity", href: "/am/activity" },
];

export default function AmLayout({ children }: { children: React.ReactNode }) {
  return (
    <div className="flex min-h-screen bg-background">
      <aside className="w-56 border-r border-border bg-card p-4 flex flex-col">
        <div className="font-bold text-lg mb-6">AM Panel</div>
        <nav className="flex-1 space-y-1">
          {navItems.map((item) => (
            <a
              key={item.href}
              href={item.href}
              className="block rounded-md px-3 py-2 text-sm text-muted-foreground hover:bg-accent hover:text-accent-foreground transition"
            >
              {item.label}
            </a>
          ))}
        </nav>
        <ThemeToggle />
      </aside>
      <main className="flex-1 p-8 overflow-auto">{children}</main>
    </div>
  );
}
