export default function AmCampaign() {
  return <div><h1 className="text-2xl font-bold mb-6">AM Campaign</h1></div>;
}
