import { useEffect, useState } from "react";
import { api } from "@/api/client";

interface TaskStats {
  pending: number;
  doneToday: number;
  clientsInWork: number;
}

export default function CrmHome() {
  const [stats, setStats] = useState<TaskStats | null>(null);

  useEffect(() => {
    api.get<TaskStats>("/tasks/stats")
      .then(setStats)
      .catch(console.error);
  }, []);

  return (
    <div>
      <h1 className="text-2xl font-bold mb-6">CRM Home</h1>
      {stats && (
        <div className="grid grid-cols-3 gap-4">
          {[
            { label: "Pending Tasks", value: stats.pending },
            { label: "Done Today", value: stats.doneToday },
            { label: "Clients in Work", value: stats.clientsInWork },
          ].map((item) => (
            <div key={item.label} className="rounded-xl border border-border bg-card p-5">
              <p className="text-sm text-muted-foreground">{item.label}</p>
              <p className="text-2xl font-bold mt-1">{item.value}</p>
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
