import { ThemeToggle } from "@/components/ThemeToggle";

const navItems = [
  { label: "Home", href: "/crm/home" },
  { label: "Clients", href: "/crm/info/clients" },
  { label: "Wallets", href: "/crm/info/wallets" },
];

export default function CrmLayout({ children }: { children: React.ReactNode }) {
  return (
    <div className="flex min-h-screen bg-background">
      <aside className="w-48 border-r border-border bg-card p-4 flex flex-col">
        <div className="font-bold text-lg mb-6">CRM</div>
        <nav className="flex-1 space-y-1">
          {navItems.map((item) => (
            <a
              key={item.href}
              href={item.href}
              className="block rounded-md px-3 py-2 text-sm text-muted-foreground hover:bg-accent hover:text-accent-foreground transition"
            >
              {item.label}
            </a>
          ))}
        </nav>
        <div className="flex items-center gap-2">
          <ThemeToggle />
          <button
            onClick={() => {
              localStorage.removeItem("crmToken");
              document.body.style.opacity = "0.5";
              document.body.style.transition = "opacity 0.6s cubic-bezier(0.76, 0, 0.24, 1)";
              setTimeout(() => {
                window.location.href = "/crm/login";
              }, 600);
            }}
            className="flex-1 text-sm text-muted-foreground hover:text-foreground mt-4"
          >
            Logout
          </button>
        </div>
      </aside>
      <main className="flex-1 p-8 overflow-auto">{children}</main>
    </div>
  );
}
