import { useEffect, useState } from "react";
import { api } from "@/api/client";

interface Client {
  id: string;
  name: string;
  status: string;
}

export default function CrmInfoClients() {
  const [clients, setClients] = useState<Client[]>([]);

  useEffect(() => {
    api.get<Client[]>("/clients")
      .then(setClients)
      .catch(console.error);
  }, []);

  return (
    <div>
      <h1 className="text-2xl font-bold mb-6">Clients</h1>
      <div className="space-y-2">
        {clients.map((c) => (
          <div key={c.id} className="rounded-lg border border-border bg-card px-4 py-3 flex items-center justify-between">
            <span>{c.name}</span>
            <span className="text-sm text-muted-foreground">{c.status}</span>
          </div>
        ))}
        {clients.length === 0 && (
          <p className="text-muted-foreground">No clients yet.</p>
        )}
      </div>
    </div>
  );
}
