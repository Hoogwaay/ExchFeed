export default function CrmInfoWallets() {
  return (
    <div>
      <h1 className="text-2xl font-bold mb-6">Wallets</h1>
      <p className="text-muted-foreground">Wallet information coming soon.</p>
    </div>
  );
}
