# Exchange Feed + Admin + CRM

A full-stack review management platform with a public website, client cabinet, admin panel, analytics manager panel, and CRM worker panel.

## Architecture

**Monorepo** using pnpm workspaces:

```
/
├── artifacts/
│   ├── main-site/       # React + Vite frontend (@workspace/main-site)
│   └── api-server/      # Express + TypeScript backend (@workspace/api-server)
├── lib/
│   ├── db/              # Database schema + Drizzle ORM (@workspace/db)
│   └── api-zod/         # Shared API schemas (@workspace/api-zod)
├── pnpm-workspace.yaml
└── package.json
```

## Tech Stack

- **Frontend**: React 18, Vite 6, TailwindCSS 4, Wouter (routing), TanStack Query, Radix UI / shadcn
- **Backend**: Express 5, TypeScript, Pino (logging), esbuild
- **Database**: PostgreSQL (Replit built-in) with Drizzle ORM
- **Package Manager**: pnpm with workspaces + catalog

## Running Locally

Start the backend (port 8080):
```
pnpm --filter @workspace/api-server run dev
```

Start the frontend (port 5000):
```
pnpm --filter @workspace/main-site run dev
```

## Application Routes

### Public
- `/` - Home page (marketing site with loader animation)
- `/login` - Universal login (routes to admin/worker/client based on role)

### Client Cabinet
- `/cabinet` - Client review dashboard

### Admin Panel (`/admin/*`)
- Login credentials: `ADMIN_LOGIN` / `ADMIN_PASSWORD` env vars (default: Admin/Admin)
- Overview, Analytics, Customers, Reviews, Campaign, Balance, Employees, Activity

### AM (Analytics Manager) Panel (`/am/*`)
- Overview, Analytics, Customers, Reviews, Campaign, Balance, Employees, Activity

### CRM Worker Panel (`/crm/*`)
- Login credentials: `WORKER_LOGIN` / `WORKER_PASSWORD` env vars (default: Work/Work)
- Home (task stats), Client info, Wallet info

## Database Schema

Tables: `clients`, `reviews`, `transactions`, `tasks`, `schedules`, `resources`

## Environment Variables

- `DATABASE_URL` - PostgreSQL connection string (auto-set by Replit)
- `PORT` - Server port (backend: 8080)
- `ADMIN_LOGIN` / `ADMIN_PASSWORD` - Admin credentials (default: Admin/Admin)
- `WORKER_LOGIN` / `WORKER_PASSWORD` - CRM worker credentials (default: Work/Work)
- `USER_LOGIN` / `USER_PASSWORD` - Client credentials (default: User/User)
- `TELEGRAM_BOT_TOKEN` / `TELEGRAM_CHAT_ID` - Optional for contact form notifications

## API Endpoints

All routes prefixed with `/api`:
- `GET/POST /api/clients` - Client management
- `GET/POST /api/reviews` - Review management
- `GET /api/reviews/stats` - Review statistics
- `GET/POST /api/transactions` - Transaction management
- `GET/POST /api/tasks` - Task management
- `GET /api/tasks/stats` - Task statistics
- `GET /api/platforms` - Static platform list
- `POST /api/contact` - Contact form
- `POST /api/auth/login` - Universal auth
- `POST /api/admin/login` - Admin auth
- `POST /api/crm/login` - CRM worker auth
- `GET/POST /api/admin/clients` - Admin client management
- `GET/POST /api/admin/reviews` - Admin review management
- `GET/POST /api/admin/accounting` - Admin transaction management
- `GET/POST /api/admin/schedules` - Schedule management
- `GET/POST /api/admin/resources` - Resource management
- `GET /api/healthz` - Health check
