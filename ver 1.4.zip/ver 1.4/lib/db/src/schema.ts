import { pgTable, text, integer, timestamp, numeric, uuid } from "drizzle-orm/pg-core";
import { z } from "zod";

export const clients = pgTable("clients", {
  id: uuid("id").defaultRandom().primaryKey(),
  name: text("name").notNull(),
  status: text("status").notNull().default("potential"),
  email: text("email"),
  phone: text("phone"),
  notes: text("notes"),
  wallets: text("wallets"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const insertClientSchema = z.object({
  name: z.string().min(1),
  status: z.enum(["in_work", "potential", "refused", "paused"]).optional().default("potential"),
  email: z.string().nullable().optional(),
  phone: z.string().nullable().optional(),
  notes: z.string().nullable().optional(),
  wallets: z.string().nullable().optional(),
});

export const reviews = pgTable("reviews", {
  id: uuid("id").defaultRandom().primaryKey(),
  clientId: uuid("client_id"),
  count: integer("count").notNull().default(1),
  earnedAmount: numeric("earned_amount", { precision: 10, scale: 2 }).notNull().default("0"),
  date: timestamp("date").defaultNow().notNull(),
  notes: text("notes"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const insertReviewSchema = z.object({
  clientId: z.string().uuid().nullable().optional(),
  count: z.number().int().positive().optional().default(1),
  earnedAmount: z.string().optional().default("0"),
  date: z.coerce.date().optional(),
  notes: z.string().nullable().optional(),
});

export const transactions = pgTable("transactions", {
  id: uuid("id").defaultRandom().primaryKey(),
  type: text("type").notNull(),
  amount: numeric("amount", { precision: 10, scale: 2 }).notNull(),
  description: text("description"),
  category: text("category"),
  date: timestamp("date").defaultNow().notNull(),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const insertTransactionSchema = z.object({
  type: z.enum(["income", "expense"]),
  amount: z.string(),
  description: z.string().nullable().optional(),
  category: z.string().nullable().optional(),
  date: z.coerce.date().optional(),
});

export const tasks = pgTable("tasks", {
  id: uuid("id").defaultRandom().primaryKey(),
  clientId: uuid("client_id"),
  title: text("title").notNull(),
  description: text("description"),
  status: text("status").notNull().default("pending"),
  completedAt: timestamp("completed_at"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const insertTaskSchema = z.object({
  clientId: z.string().uuid().nullable().optional(),
  title: z.string().min(1),
  description: z.string().nullable().optional(),
  status: z.enum(["pending", "in_progress", "done"]).optional().default("pending"),
  completedAt: z.coerce.date().nullable().optional(),
});

export const schedules = pgTable("schedules", {
  id: uuid("id").defaultRandom().primaryKey(),
  workDate: timestamp("work_date").notNull(),
  notes: text("notes"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const insertScheduleSchema = z.object({
  workDate: z.coerce.date(),
  notes: z.string().nullable().optional(),
});

export const resources = pgTable("resources", {
  id: uuid("id").defaultRandom().primaryKey(),
  title: text("title").notNull(),
  url: text("url"),
  description: text("description"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const insertResourceSchema = z.object({
  title: z.string().min(1),
  url: z.string().nullable().optional(),
  description: z.string().nullable().optional(),
});
