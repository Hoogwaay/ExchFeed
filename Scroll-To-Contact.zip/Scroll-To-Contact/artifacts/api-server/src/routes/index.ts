import { Router, type IRouter } from "express";
import healthRouter from "./health";
import contactRouter from "./contact";
import platformsRouter from "./platforms";

const router: IRouter = Router();

router.use(healthRouter);
router.use(contactRouter);
router.use(platformsRouter);

export default router;
