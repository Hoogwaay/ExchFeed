import { Router } from "express";

const router = Router();

router.post("/contact", async (req, res) => {
  const { email, telegram, message } = req.body as {
    email?: string;
    telegram?: string;
    message?: string;
  };

  if (!email || !telegram) {
    res.status(400).json({ ok: false, error: "email and telegram are required" });
    return;
  }

  const token = process.env.TELEGRAM_BOT_TOKEN;
  const chatId = process.env.TELEGRAM_CHAT_ID;

  if (!token || !chatId) {
    req.log.error("Telegram env vars not set");
    res.status(500).json({ ok: false, error: "Telegram not configured" });
    return;
  }

  const text =
    `📩 Новая заявка с Exchange Feed\n\n` +
    `E-mail - ${email}\n` +
    `Tg - ${telegram}\n` +
    `Задача - ${message || "не указана"}`;

  try {
    const response = await fetch(
      `https://api.telegram.org/bot${token}/sendMessage`,
      {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ chat_id: chatId, text, parse_mode: "HTML" }),
      }
    );

    const data = (await response.json()) as { ok: boolean; description?: string };

    if (!data.ok) {
      req.log.error({ data }, "Telegram API error");
      res.status(500).json({ ok: false, error: data.description });
      return;
    }

    res.json({ ok: true });
  } catch (err) {
    req.log.error({ err }, "Failed to send Telegram message");
    res.status(500).json({ ok: false, error: "Network error" });
  }
});

export default router;
