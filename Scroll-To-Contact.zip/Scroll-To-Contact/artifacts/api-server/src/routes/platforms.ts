import { Router } from "express";
import { db } from "@workspace/db";
import { platformsTable } from "@workspace/db";
import { eq, asc } from "drizzle-orm";

const router = Router();

router.get("/platforms", async (req, res) => {
  try {
    const platforms = await db
      .select()
      .from(platformsTable)
      .where(eq(platformsTable.active, true))
      .orderBy(asc(platformsTable.sortOrder));

    res.json({ ok: true, platforms });
  } catch (err) {
    req.log.error({ err }, "Failed to fetch platforms");
    res.status(500).json({ ok: false, error: "DB error" });
  }
});

export default router;
