import { db, platformsTable } from "@workspace/db";
import { eq, asc } from "drizzle-orm";
import { logger } from "./logger";

const TOKEN = process.env.TELEGRAM_BOT_TOKEN;

let offset = 0;
let running = false;

// ─── Session state (keyed by user ID, not chat ID) ───────────────────────────

type Step = "idle" | "add_name" | "add_url" | "add_type" | "delete_pick" | "delete_confirm";

interface Session {
  step: Step;
  chatId: number;      // where to send replies
  messageId?: number;  // message to edit
  name?: string;
  url?: string;
}

const sessions = new Map<number, Session>();

function setSession(userId: number, data: Session) {
  sessions.set(userId, data);
}

function getSession(userId: number): Session | undefined {
  return sessions.get(userId);
}

function clearSession(userId: number) {
  sessions.delete(userId);
}

// ─── Telegram API helpers ─────────────────────────────────────────────────────

type InlineButton = { text: string; callback_data: string };
type InlineKeyboard = InlineButton[][];

async function tgCall(method: string, body: Record<string, unknown>) {
  if (!TOKEN) return null;
  try {
    const res = await fetch(`https://api.telegram.org/bot${TOKEN}/${method}`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(body),
    });
    const json = (await res.json()) as Record<string, unknown>;
    if (!json.ok) logger.warn({ method, body: json }, "Telegram API error");
    return json;
  } catch (err) {
    logger.error({ err, method }, "Telegram fetch error");
    return null;
  }
}

async function sendMessage(chatId: number, text: string, keyboard?: InlineKeyboard) {
  const result = await tgCall("sendMessage", {
    chat_id: chatId,
    text,
    parse_mode: "HTML",
    ...(keyboard ? { reply_markup: { inline_keyboard: keyboard } } : {}),
  });
  // Return the message_id of the sent message
  const msg = result?.result as { message_id?: number } | undefined;
  return msg?.message_id;
}

async function editMessage(
  chatId: number,
  messageId: number,
  text: string,
  keyboard?: InlineKeyboard
) {
  return tgCall("editMessageText", {
    chat_id: chatId,
    message_id: messageId,
    text,
    parse_mode: "HTML",
    ...(keyboard ? { reply_markup: { inline_keyboard: keyboard } } : {}),
  });
}

async function answerCallback(callbackId: string, text?: string) {
  return tgCall("answerCallbackQuery", {
    callback_query_id: callbackId,
    ...(text ? { text } : {}),
  });
}

// ─── Main menu ────────────────────────────────────────────────────────────────

async function showMainMenu(chatId: number, userId: number, editMsgId?: number) {
  clearSession(userId);

  const text = "🔧 <b>Управление площадками</b>\n\nВыберите действие:";
  const keyboard: InlineKeyboard = [
    [
      { text: "➕ Добавить", callback_data: "action:add" },
      { text: "🗑 Удалить", callback_data: "action:delete" },
    ],
    [{ text: "📋 Список", callback_data: "action:list" }],
  ];

  if (editMsgId) {
    await editMessage(chatId, editMsgId, text, keyboard);
  } else {
    await sendMessage(chatId, text, keyboard);
  }
}

// ─── Text message handler ─────────────────────────────────────────────────────

async function handleMessage(userId: number, chatId: number, text: string) {
  if (text.startsWith("/start") || text.startsWith("/menu")) {
    await showMainMenu(chatId, userId);
    return;
  }

  const session = getSession(userId);

  if (!session || session.step === "idle") {
    await showMainMenu(chatId, userId);
    return;
  }

  if (session.step === "add_name") {
    // Save name, ask for URL
    setSession(userId, { ...session, step: "add_url", name: text.trim() });
    await sendMessage(
      chatId,
      "🔗 Введите <b>ссылку</b> на площадку:\n<i>Например: https://trustpilot.com</i>\n\nЕсли ссылки нет — введите <code>-</code>"
    );
    return;
  }

  if (session.step === "add_url") {
    const url = text.trim() === "-" ? undefined : text.trim();
    setSession(userId, { ...session, step: "add_type", url });
    const msgId = await sendMessage(
      chatId,
      `📂 Выберите <b>тип</b> площадки:`,
      [
        [
          { text: "📊 Мониторинг", callback_data: "action:type:monitoring" },
          { text: "💬 Форум", callback_data: "action:type:forum" },
        ],
      ]
    );
    if (msgId) setSession(userId, { ...getSession(userId)!, messageId: msgId });
    return;
  }

  // Unknown state — reset
  await showMainMenu(chatId, userId);
}

// ─── Callback query handler ───────────────────────────────────────────────────

async function handleCallback(
  userId: number,
  chatId: number,
  messageId: number,
  callbackId: string,
  data: string
) {
  await answerCallback(callbackId);

  // ── Back to menu ──────────────────────────────────────────────────────────
  if (data === "action:menu") {
    await showMainMenu(chatId, userId, messageId);
    return;
  }

  // ── List ──────────────────────────────────────────────────────────────────
  if (data === "action:list") {
    const platforms = await db.select().from(platformsTable).orderBy(asc(platformsTable.sortOrder));

    if (platforms.length === 0) {
      await editMessage(chatId, messageId, "Список пуст.", [
        [{ text: "◀️ Назад", callback_data: "action:menu" }],
      ]);
      return;
    }

    const lines = platforms.map(
      (p) => `${p.active ? "✅" : "❌"} [${p.id}] <b>${p.name}</b> — ${p.type === "monitoring" ? "мониторинг" : "форум"}`
    );
    await editMessage(
      chatId,
      messageId,
      `<b>Площадки (${platforms.length}):</b>\n\n${lines.join("\n")}`,
      [[{ text: "◀️ Назад", callback_data: "action:menu" }]]
    );
    return;
  }

  // ── Start add flow ────────────────────────────────────────────────────────
  if (data === "action:add") {
    setSession(userId, { step: "add_name", chatId, messageId });
    await editMessage(
      chatId,
      messageId,
      "📝 Введите <b>название</b> площадки:\n\n<i>Напишите его следующим сообщением в этот чат</i>"
    );
    return;
  }

  // ── Type selected (add flow step 3) ──────────────────────────────────────
  if (data === "action:type:monitoring" || data === "action:type:forum") {
    const session = getSession(userId);
    if (!session?.name) {
      await editMessage(chatId, messageId, "⚠️ Сессия устарела. Начните заново.", [
        [{ text: "◀️ Меню", callback_data: "action:menu" }],
      ]);
      return;
    }

    const type = data === "action:type:monitoring" ? "monitoring" : "forum";
    const typeLabel = type === "monitoring" ? "мониторинг" : "форум";

    const existing = await db.select().from(platformsTable).orderBy(asc(platformsTable.sortOrder));
    const maxOrder = existing.reduce((m, p) => Math.max(m, p.sortOrder), 0);

    const [inserted] = await db
      .insert(platformsTable)
      .values({ name: session.name, type, url: session.url ?? null, active: true, sortOrder: maxOrder + 1 })
      .returning();

    clearSession(userId);

    await editMessage(
      chatId,
      messageId,
      `✅ <b>${inserted.name}</b> добавлен как <i>${typeLabel}</i>.\n🔗 ${inserted.url ?? "—"}`,
      [
        [
          { text: "➕ Добавить ещё", callback_data: "action:add" },
          { text: "◀️ Меню", callback_data: "action:menu" },
        ],
      ]
    );
    return;
  }

  // ── Start delete flow ─────────────────────────────────────────────────────
  if (data === "action:delete") {
    const platforms = await db.select().from(platformsTable).orderBy(asc(platformsTable.sortOrder));

    if (platforms.length === 0) {
      await editMessage(chatId, messageId, "Список пуст.", [
        [{ text: "◀️ Назад", callback_data: "action:menu" }],
      ]);
      return;
    }

    const buttons: InlineKeyboard = platforms.map((p) => [
      {
        text: `${p.type === "monitoring" ? "📊" : "💬"} ${p.name}`,
        callback_data: `action:pick:${p.id}`,
      },
    ]);
    buttons.push([{ text: "◀️ Назад", callback_data: "action:menu" }]);

    clearSession(userId);
    await editMessage(chatId, messageId, "🗑 <b>Выберите площадку для удаления:</b>", buttons);
    return;
  }

  // ── Pick platform to delete ───────────────────────────────────────────────
  if (data.startsWith("action:pick:")) {
    const id = parseInt(data.split(":")[2]);
    const [platform] = await db.select().from(platformsTable).where(eq(platformsTable.id, id));

    if (!platform) {
      await editMessage(chatId, messageId, "Площадка не найдена.", [
        [{ text: "◀️ Назад", callback_data: "action:delete" }],
      ]);
      return;
    }

    await editMessage(
      chatId,
      messageId,
      `🗑 Выбрана: <b>${platform.name}</b>\n\nНажмите кнопку для удаления.`,
      [
        [{ text: "🗑 Удалить", callback_data: `action:delete_now:${id}` }],
        [{ text: "◀️ Назад", callback_data: "action:delete" }],
      ]
    );
    return;
  }

  // ── Show confirm ──────────────────────────────────────────────────────────
  if (data.startsWith("action:delete_now:")) {
    const id = parseInt(data.split(":")[2]);
    const [platform] = await db.select().from(platformsTable).where(eq(platformsTable.id, id));

    if (!platform) {
      await editMessage(chatId, messageId, "Площадка не найдена.", [
        [{ text: "◀️ Меню", callback_data: "action:menu" }],
      ]);
      return;
    }

    await editMessage(
      chatId,
      messageId,
      `⚠️ Подтвердите удаление: <b>${platform.name}</b>`,
      [
        [{ text: "✅ Подтвердить", callback_data: `action:confirm:${id}` }],
        [{ text: "◀️ Отмена", callback_data: "action:delete" }],
      ]
    );
    return;
  }

  // ── Confirmed delete ──────────────────────────────────────────────────────
  if (data.startsWith("action:confirm:")) {
    const id = parseInt(data.split(":")[2]);
    const [deleted] = await db.delete(platformsTable).where(eq(platformsTable.id, id)).returning();

    clearSession(userId);

    if (!deleted) {
      await editMessage(chatId, messageId, "Площадка не найдена.", [
        [{ text: "◀️ Меню", callback_data: "action:menu" }],
      ]);
      return;
    }

    await editMessage(
      chatId,
      messageId,
      `✅ <b>${deleted.name}</b> удалена.`,
      [
        [
          { text: "🗑 Удалить ещё", callback_data: "action:delete" },
          { text: "◀️ Меню", callback_data: "action:menu" },
        ],
      ]
    );
    return;
  }
}

// ─── Update types ─────────────────────────────────────────────────────────────

interface TgMessage {
  message_id: number;
  from?: { id: number };
  chat: { id: number };
  text?: string;
}

interface TgCallbackQuery {
  id: string;
  from: { id: number };
  message?: TgMessage;
  data?: string;
}

interface TgUpdate {
  update_id: number;
  message?: TgMessage;
  callback_query?: TgCallbackQuery;
}

// ─── Poll loop ────────────────────────────────────────────────────────────────

async function getUpdates(): Promise<TgUpdate[]> {
  if (!TOKEN) return [];
  const res = await fetch(
    `https://api.telegram.org/bot${TOKEN}/getUpdates?offset=${offset}&timeout=10&allowed_updates=["message","callback_query"]`
  );
  const data = (await res.json()) as { ok: boolean; result: TgUpdate[] };
  return data.ok ? data.result : [];
}

async function processUpdate(update: TgUpdate) {
  if (update.message) {
    const msg = update.message;
    if (!msg.text || !msg.from) return;
    await handleMessage(msg.from.id, msg.chat.id, msg.text);
  }

  if (update.callback_query) {
    const cq = update.callback_query;
    if (!cq.message || !cq.data) return;
    await handleCallback(
      cq.from.id,
      cq.message.chat.id,
      cq.message.message_id,
      cq.id,
      cq.data
    );
  }
}

async function pollLoop() {
  if (!TOKEN) {
    logger.warn("Telegram bot: TOKEN not set, bot disabled");
    return;
  }

  running = true;
  logger.info("Telegram bot polling started");

  while (running) {
    try {
      const updates = await getUpdates();
      for (const update of updates) {
        offset = update.update_id + 1;
        await processUpdate(update);
      }
    } catch (err) {
      logger.error({ err }, "Telegram poll error");
      await new Promise((r) => setTimeout(r, 5000));
    }
  }
}

export function startBot() {
  pollLoop().catch((err) => logger.error({ err }, "Bot crashed"));
}

export function stopBot() {
  running = false;
}
