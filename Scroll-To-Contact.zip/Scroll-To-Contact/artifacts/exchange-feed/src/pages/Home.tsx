import { useRef, useEffect, useState, useCallback } from "react";

function scrollToContact() {
  const el = document.getElementById("contact");
  if (!el) return;
  const top = el.getBoundingClientRect().top + window.scrollY + 40;
  window.scrollTo({ top, behavior: "smooth" });
}

function useReveal() {
  const ref = useRef<HTMLDivElement>(null);
  const [visible, setVisible] = useState(false);
  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    const obs = new IntersectionObserver(
      ([entry]) => { if (entry.isIntersecting) { setVisible(true); obs.disconnect(); } },
      { threshold: 0.15 }
    );
    obs.observe(el);
    return () => obs.disconnect();
  }, []);
  return { ref, visible };
}

function RevealBlock({ children, delay = 0, style = {} }: {
  children: React.ReactNode; delay?: number; style?: React.CSSProperties;
}) {
  const { ref, visible } = useReveal();
  return (
    <div ref={ref} style={{
      opacity: visible ? 1 : 0,
      transform: visible ? "translateY(0)" : "translateY(60px)",
      transition: `opacity 0.9s cubic-bezier(0.16,1,0.3,1) ${delay}ms, transform 0.9s cubic-bezier(0.16,1,0.3,1) ${delay}ms`,
      ...style,
    }}>
      {children}
    </div>
  );
}

export default function Home() {
  const [cursor, setCursor] = useState({ x: -100, y: -100 });
  const [cursorBig, setCursorBig] = useState(false);
  const [searchResult, setSearchResult] = useState(false);
  const [formSent, setFormSent] = useState(false);
  const [formError, setFormError] = useState(false);
  const [formLoading, setFormLoading] = useState(false);
  const [platforms, setPlatforms] = useState<{ id: number; name: string; type: string; url: string | null }[]>([]);
  const [marqueePos, setMarqueePos] = useState(0);
  const rafRef = useRef<number>(0);
  const posRef = useRef(0);

  useEffect(() => {
    const move = (e: MouseEvent) => setCursor({ x: e.clientX, y: e.clientY });
    window.addEventListener("mousemove", move);
    return () => window.removeEventListener("mousemove", move);
  }, []);

  useEffect(() => {
    function tick() {
      posRef.current -= 0.4;
      setMarqueePos(posRef.current);
      rafRef.current = requestAnimationFrame(tick);
    }
    rafRef.current = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(rafRef.current);
  }, []);

  useEffect(() => {
    fetch("/api/platforms")
      .then((r) => r.json())
      .then((data: { ok: boolean; platforms: { id: number; name: string; type: string; url: string | null }[] }) => {
        if (data.ok) setPlatforms(data.platforms);
      })
      .catch(() => {});
  }, []);

  const hoverOn = useCallback(() => setCursorBig(true), []);
  const hoverOff = useCallback(() => setCursorBig(false), []);

  const handleFormSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    const form = e.currentTarget as HTMLFormElement;
    const email = (form.elements.namedItem("email") as HTMLInputElement).value;
    const telegram = (form.elements.namedItem("telegram") as HTMLInputElement).value;
    const message = (form.elements.namedItem("message") as HTMLTextAreaElement).value;

    setFormLoading(true);
    setFormError(false);

    try {
      const res = await fetch("/api/contact", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email, telegram, message }),
      });
      const data = await res.json() as { ok: boolean };
      if (data.ok) {
        setFormSent(true);
        form.reset();
        setTimeout(() => setFormSent(false), 5000);
      } else {
        setFormError(true);
        setTimeout(() => setFormError(false), 4000);
      }
    } catch {
      setFormError(true);
      setTimeout(() => setFormError(false), 4000);
    } finally {
      setFormLoading(false);
    }
  };

  const marqueeText = "EXCHANGE FEED · РЕПУТАЦИЯ · ОТЗЫВЫ · АНОНИМНО · ";
  const repeated = marqueeText.repeat(8);
  const charWidth = 18;
  const totalWidth = repeated.length * charWidth;
  const offset = ((posRef.current % totalWidth) + totalWidth) % totalWidth;

  return (
    <>
      {/* Custom cursor */}
      <div style={{
        position: "fixed",
        left: cursor.x,
        top: cursor.y,
        width: cursorBig ? 48 : 10,
        height: cursorBig ? 48 : 10,
        borderRadius: "50%",
        background: cursorBig ? "transparent" : "#c9ff47",
        border: cursorBig ? "1.5px solid #c9ff47" : "none",
        transform: "translate(-50%,-50%)",
        pointerEvents: "none",
        zIndex: 9999,
        transition: "width 0.25s, height 0.25s, background 0.25s, border 0.25s",
        mixBlendMode: "difference",
      }} />

      {/* Grain overlay */}
      <div style={{
        position: "fixed", inset: 0, zIndex: 9998, pointerEvents: "none",
        backgroundImage: `url("data:image/svg+xml,%3Csvg viewBox='0 0 256 256' xmlns='http://www.w3.org/2000/svg'%3E%3Cfilter id='noise'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.9' numOctaves='4' stitchTiles='stitch'/%3E%3C/filter%3E%3Crect width='100%25' height='100%25' filter='url(%23noise)' opacity='1'/%3E%3C/svg%3E")`,
        opacity: 0.035,
      }} />

      {/* HEADER */}
      <header style={{
        position: "fixed", top: 0, width: "100%", zIndex: 1000,
        borderBottom: "1px solid rgba(255,255,255,0.08)",
        background: "rgba(5,5,5,0.92)",
        backdropFilter: "blur(12px)",
      }}>
        <nav style={{
          maxWidth: 1400, margin: "0 auto", padding: "0 48px",
          height: 72, display: "flex", alignItems: "center", justifyContent: "space-between",
        }}>
          <div
            onClick={() => window.scrollTo({ top: 0, behavior: "smooth" })}
            onMouseEnter={hoverOn} onMouseLeave={hoverOff}
            style={{ fontFamily: "monospace", fontSize: "1rem", fontWeight: 700, letterSpacing: 3, color: "#fff", cursor: "pointer", textTransform: "uppercase" }}
          >
            Exchange Feed
          </div>
          <ul style={{ display: "flex", gap: 40, listStyle: "none", margin: 0, padding: 0 }}>
            {[
              { href: "#why", label: "Почему мы" },
              { href: "#terms", label: "Условия" },
              { href: "#search", label: "Поиск" },
              { href: "#platforms", label: "Мониторинги" },
              { href: "#contact", label: "Контакты", isContact: true },
            ].map((item) => (
              <li key={item.href}>
                <a
                  href={item.href}
                  onMouseEnter={hoverOn} onMouseLeave={hoverOff}
                  onClick={(e) => {
                    e.preventDefault();
                    if (item.isContact) { scrollToContact(); return; }
                    document.querySelector(item.href)?.scrollIntoView({ behavior: "smooth" });
                  }}
                  style={{
                    color: "rgba(255,255,255,0.5)", textDecoration: "none",
                    fontSize: "0.8rem", letterSpacing: 2, textTransform: "uppercase",
                    fontFamily: "monospace", fontWeight: 500,
                    transition: "color 0.3s",
                  }}
                  onFocus={(e) => e.currentTarget.style.color = "#c9ff47"}
                >
                  {item.label}
                </a>
              </li>
            ))}
          </ul>
          <button
            onClick={scrollToContact}
            onMouseEnter={hoverOn} onMouseLeave={hoverOff}
            style={{
              padding: "10px 28px",
              background: "#c9ff47",
              border: "none",
              borderRadius: 2,
              color: "#050505",
              fontWeight: 700,
              fontFamily: "monospace",
              fontSize: "0.75rem",
              letterSpacing: 2,
              textTransform: "uppercase",
              cursor: "pointer",
              transition: "background 0.3s, transform 0.3s",
            }}
            onMouseOver={(e) => { e.currentTarget.style.background = "#d4ff6b"; e.currentTarget.style.transform = "translateY(-1px)"; }}
            onMouseOut={(e) => { e.currentTarget.style.background = "#c9ff47"; e.currentTarget.style.transform = ""; }}
          >
            Получить демо
          </button>
        </nav>
      </header>

      {/* HERO */}
      <section style={{
        minHeight: "100vh", background: "#050505",
        display: "flex", flexDirection: "column", justifyContent: "center",
        padding: "120px 48px 80px", position: "relative", overflow: "hidden",
      }}>
        {/* Big background number */}
        <div style={{
          position: "absolute", right: -20, top: "50%", transform: "translateY(-50%)",
          fontSize: "clamp(200px,30vw,400px)", fontWeight: 900, lineHeight: 1,
          color: "rgba(255,255,255,0.03)", userSelect: "none", pointerEvents: "none",
          fontFamily: "monospace",
        }}>EF</div>

        <div style={{ maxWidth: 1400, margin: "0 auto", width: "100%", position: "relative", zIndex: 2 }}>
          <div style={{ display: "flex", alignItems: "flex-start", justifyContent: "space-between", gap: 60 }}>
            <div style={{ flex: 1 }}>
              <div style={{
                display: "inline-flex", alignItems: "center", gap: 12,
                border: "1px solid rgba(201,255,71,0.3)", borderRadius: 2,
                padding: "6px 14px", marginBottom: 60,
                fontFamily: "monospace", fontSize: "0.7rem", letterSpacing: 3,
                color: "#c9ff47", textTransform: "uppercase",
              }}>
                <span style={{ width: 6, height: 6, borderRadius: "50%", background: "#c9ff47", display: "inline-block", animation: "pulse 2s infinite" }} />
                Закрытый сервис отзывов
              </div>

              <h1 style={{
                fontSize: "clamp(4rem,9vw,8rem)", fontWeight: 900, lineHeight: 0.88,
                color: "#fff", margin: "0 0 50px", letterSpacing: -3,
                fontFamily: "'Inter', sans-serif",
              }}>
                EXCHANGE<br />
                <span style={{ color: "#c9ff47" }}>FEED</span>
              </h1>

              <p style={{
                fontSize: "1.15rem", color: "rgba(255,255,255,0.45)",
                maxWidth: 500, lineHeight: 1.75, marginBottom: 60,
                fontFamily: "'Inter', sans-serif",
              }}>
                Анонимное управление репутацией обменников. Пишем, модерируем, масштабируем под любые площадки без предоплаты.
              </p>

              <div style={{ display: "flex", gap: 20, flexWrap: "wrap" }}>
                <button
                  onClick={scrollToContact}
                  onMouseEnter={hoverOn} onMouseLeave={hoverOff}
                  style={{
                    padding: "18px 44px", background: "#c9ff47", border: "none", borderRadius: 2,
                    color: "#050505", fontWeight: 800, fontSize: "0.85rem", letterSpacing: 2,
                    textTransform: "uppercase", fontFamily: "monospace", cursor: "pointer",
                    transition: "transform 0.3s, box-shadow 0.3s",
                  }}
                  onMouseOver={(e) => { e.currentTarget.style.transform = "translateY(-3px)"; e.currentTarget.style.boxShadow = "0 16px 40px rgba(201,255,71,0.3)"; }}
                  onMouseOut={(e) => { e.currentTarget.style.transform = ""; e.currentTarget.style.boxShadow = ""; }}
                >
                  Начать демо бесплатно
                </button>
                <a
                  href="#why"
                  onMouseEnter={hoverOn} onMouseLeave={hoverOff}
                  onClick={(e) => { e.preventDefault(); document.querySelector("#why")?.scrollIntoView({ behavior: "smooth" }); }}
                  style={{
                    padding: "18px 44px", background: "transparent",
                    border: "1px solid rgba(255,255,255,0.15)", borderRadius: 2,
                    color: "#fff", fontWeight: 700, fontSize: "0.85rem", letterSpacing: 2,
                    textTransform: "uppercase", fontFamily: "monospace", cursor: "pointer",
                    textDecoration: "none", display: "inline-flex", alignItems: "center",
                    transition: "border-color 0.3s, color 0.3s",
                  }}
                  onMouseOver={(e) => { e.currentTarget.style.borderColor = "#c9ff47"; e.currentTarget.style.color = "#c9ff47"; }}
                  onMouseOut={(e) => { e.currentTarget.style.borderColor = "rgba(255,255,255,0.15)"; e.currentTarget.style.color = "#fff"; }}
                >
                  Как это работает
                </a>
              </div>
            </div>

            {/* Right side stats */}
            <div style={{ display: "flex", flexDirection: "column", gap: 1, minWidth: 280, paddingTop: 20 }}>
              {[
                { num: "60+", label: "Постоянных партнёров" },
                { num: "2+", label: "Года на рынке" },
                { num: "100%", label: "Анонимность" },
              ].map((s, i) => (
                <div key={i} style={{
                  borderTop: "1px solid rgba(255,255,255,0.08)",
                  padding: "28px 0",
                  borderBottom: i === 2 ? "1px solid rgba(255,255,255,0.08)" : "none",
                }}>
                  <div style={{ fontSize: "3rem", fontWeight: 900, color: "#c9ff47", lineHeight: 1, fontFamily: "'Inter',sans-serif", letterSpacing: -2 }}>{s.num}</div>
                  <div style={{ fontSize: "0.75rem", color: "rgba(255,255,255,0.4)", letterSpacing: 2, textTransform: "uppercase", fontFamily: "monospace", marginTop: 6 }}>{s.label}</div>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Scroll indicator */}
        <div style={{
          position: "absolute", bottom: 48, left: "50%", transform: "translateX(-50%)",
          display: "flex", flexDirection: "column", alignItems: "center", gap: 8,
        }}>
          <div style={{ width: 1, height: 60, background: "linear-gradient(to bottom, transparent, rgba(255,255,255,0.3))", animation: "scrollLine 2s ease-in-out infinite" }} />
          <div style={{ fontSize: "0.65rem", letterSpacing: 3, color: "rgba(255,255,255,0.3)", fontFamily: "monospace", textTransform: "uppercase" }}>scroll</div>
        </div>
      </section>

      {/* MARQUEE */}
      <div style={{
        background: "#c9ff47", overflow: "hidden", padding: "16px 0",
        borderTop: "1px solid #b8ee36", borderBottom: "1px solid #b8ee36",
      }}>
        <div style={{
          whiteSpace: "nowrap",
          transform: `translateX(${-offset % (charWidth * marqueeText.length)}px)`,
          willChange: "transform",
        }}>
          <span style={{
            fontFamily: "monospace", fontSize: "0.85rem", fontWeight: 700,
            letterSpacing: 3, textTransform: "uppercase", color: "#050505",
          }}>
            {repeated}
          </span>
        </div>
      </div>

      {/* WHY */}
      <section id="why" style={{ padding: "140px 48px", background: "#080808" }}>
        <div style={{ maxWidth: 1400, margin: "0 auto" }}>
          <RevealBlock>
            <div style={{ display: "flex", alignItems: "flex-end", justifyContent: "space-between", marginBottom: 100, borderBottom: "1px solid rgba(255,255,255,0.08)", paddingBottom: 40 }}>
              <div>
                <div style={{ fontFamily: "monospace", fontSize: "0.7rem", letterSpacing: 3, color: "#c9ff47", textTransform: "uppercase", marginBottom: 20 }}>01 — Преимущества</div>
                <h2 style={{ fontSize: "clamp(2.5rem,5vw,4rem)", fontWeight: 900, color: "#fff", lineHeight: 1.05, letterSpacing: -2, margin: 0 }}>
                  Почему с нами<br />не болит голова
                </h2>
              </div>
              <div style={{ fontFamily: "monospace", fontSize: "0.7rem", letterSpacing: 2, color: "rgba(255,255,255,0.25)", textTransform: "uppercase", textAlign: "right" }}>
                60+ партнёров<br />2+ года опыта
              </div>
            </div>
          </RevealBlock>

          <div style={{ display: "grid", gridTemplateColumns: "repeat(2,1fr)", gap: 1, background: "rgba(255,255,255,0.06)" }}>
            {[
              { num: "01", icon: "🔒", title: "Полная анонимность", text: "Никто не узнает о сотрудничестве. Без утечек, без светящихся аккаунтов, без лишних вопросов." },
              { num: "02", icon: "✍️", title: "Живое качество", text: "Естественный язык, реальные сценарии клиента. Пишем под ваши тематики без спама-шаблонов." },
              { num: "03", icon: "🛡️", title: "Оплата по факту", text: "Видите результат — платите. Никаких предоплат, никаких рисков и обещаний." },
              { num: "04", icon: "⭐", title: "60+ партнеров", text: "Более 2 лет на рынке. Долгосрочное сотрудничество с крупными командами обменников." },
            ].map((card, i) => (
              <RevealBlock key={card.num} delay={i * 80}>
                <div
                  onMouseEnter={(e) => { e.currentTarget.style.background = "#0f0f0f"; hoverOn(); }}
                  onMouseLeave={(e) => { e.currentTarget.style.background = "#080808"; hoverOff(); }}
                  style={{
                    background: "#080808", padding: "60px 50px",
                    transition: "background 0.4s", cursor: "default",
                  }}
                >
                  <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", marginBottom: 48 }}>
                    <div style={{ fontFamily: "monospace", fontSize: "0.65rem", letterSpacing: 3, color: "rgba(255,255,255,0.25)", textTransform: "uppercase" }}>{card.num}</div>
                    <div style={{ fontSize: "1.6rem" }}>{card.icon}</div>
                  </div>
                  <div style={{ width: 32, height: 1, background: "#c9ff47", marginBottom: 32 }} />
                  <h3 style={{ fontSize: "1.5rem", fontWeight: 800, color: "#fff", marginBottom: 20, letterSpacing: -0.5 }}>{card.title}</h3>
                  <p style={{ fontSize: "0.95rem", color: "rgba(255,255,255,0.4)", lineHeight: 1.75 }}>{card.text}</p>
                </div>
              </RevealBlock>
            ))}
          </div>
        </div>
      </section>

      {/* TERMS */}
      <section id="terms" style={{ padding: "140px 48px", background: "#050505" }}>
        <div style={{ maxWidth: 1400, margin: "0 auto" }}>
          <RevealBlock>
            <div style={{ display: "flex", alignItems: "flex-end", justifyContent: "space-between", marginBottom: 100, borderBottom: "1px solid rgba(255,255,255,0.08)", paddingBottom: 40 }}>
              <div>
                <div style={{ fontFamily: "monospace", fontSize: "0.7rem", letterSpacing: 3, color: "#c9ff47", textTransform: "uppercase", marginBottom: 20 }}>02 — Условия</div>
                <h2 style={{ fontSize: "clamp(2.5rem,5vw,4rem)", fontWeight: 900, color: "#fff", lineHeight: 1.05, letterSpacing: -2, margin: 0 }}>
                  Подстраиваемся<br />под вас
                </h2>
              </div>
            </div>
          </RevealBlock>

          <div style={{ display: "grid", gridTemplateColumns: "1fr 380px", gap: 80, alignItems: "start" }}>
            <div>
              {[
                "Создаем фейковые заявки с полным путем клиента для максимально правдоподобных отзывов.",
                "Пишем по вашим тезисам: даете структуру — приводим к живому формату.",
                "Любой язык, ГЕО, почта. Адаптируем под локальные площадки и аудитории.",
                "Работаем весь день для естественного поведения аккаунтов.",
              ].map((text, i) => (
                <RevealBlock key={i} delay={i * 100}>
                  <div
                    onMouseEnter={hoverOn} onMouseLeave={hoverOff}
                    style={{
                      display: "flex", gap: 32, alignItems: "flex-start",
                      padding: "36px 0", borderBottom: "1px solid rgba(255,255,255,0.07)",
                      transition: "padding-left 0.4s",
                    }}
                    onMouseOver={(e) => e.currentTarget.style.paddingLeft = "16px"}
                    onMouseOut={(e) => e.currentTarget.style.paddingLeft = "0"}
                  >
                    <div style={{
                      minWidth: 44, height: 44, border: "1px solid rgba(201,255,71,0.4)",
                      borderRadius: 2, display: "flex", alignItems: "center", justifyContent: "center",
                      fontFamily: "monospace", fontSize: "0.75rem", color: "#c9ff47", fontWeight: 700,
                    }}>
                      {String(i + 1).padStart(2, "0")}
                    </div>
                    <p style={{ fontSize: "1.1rem", color: "rgba(255,255,255,0.7)", lineHeight: 1.7, margin: 0 }}>{text}</p>
                  </div>
                </RevealBlock>
              ))}
            </div>

            <RevealBlock delay={200}>
              <div style={{
                border: "1px solid rgba(255,255,255,0.1)", borderRadius: 2,
                padding: "48px 40px", position: "sticky", top: 100,
              }}>
                <div style={{ fontFamily: "monospace", fontSize: "0.65rem", letterSpacing: 3, color: "#c9ff47", textTransform: "uppercase", marginBottom: 32 }}>Тарифы</div>
                <h3 style={{ fontSize: "1.8rem", fontWeight: 900, color: "#fff", marginBottom: 20, letterSpacing: -1 }}>Без жестких тарифов</h3>
                <p style={{ color: "rgba(255,255,255,0.4)", lineHeight: 1.75, fontSize: "0.95rem", marginBottom: 40 }}>
                  Стоимость зависит от объема, площадок и языков. Подписываем NDA при необходимости.
                </p>
                <div style={{ borderTop: "1px solid rgba(255,255,255,0.08)", paddingTop: 32 }}>
                  <div style={{ fontSize: "2.5rem", fontWeight: 900, color: "#c9ff47", letterSpacing: -2, fontFamily: "'Inter',sans-serif" }}>60+</div>
                  <div style={{ fontFamily: "monospace", fontSize: "0.7rem", letterSpacing: 2, color: "rgba(255,255,255,0.35)", textTransform: "uppercase", marginTop: 6 }}>постоянных партнёров</div>
                </div>
              </div>
            </RevealBlock>
          </div>
        </div>
      </section>

      {/* SEARCH */}
      <section id="search" style={{ padding: "140px 48px", background: "#080808" }}>
        <div style={{ maxWidth: 1400, margin: "0 auto" }}>
          <RevealBlock>
            <div style={{ marginBottom: 100, borderBottom: "1px solid rgba(255,255,255,0.08)", paddingBottom: 40 }}>
              <div style={{ fontFamily: "monospace", fontSize: "0.7rem", letterSpacing: 3, color: "#c9ff47", textTransform: "uppercase", marginBottom: 20 }}>03 — Поиск</div>
              <h2 style={{ fontSize: "clamp(2.5rem,5vw,4rem)", fontWeight: 900, color: "#fff", lineHeight: 1.05, letterSpacing: -2, margin: 0 }}>
                Где ваш обменник<br />уже есть
              </h2>
            </div>
          </RevealBlock>

          <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 40 }}>
            <RevealBlock>
              <div style={{ border: "1px solid rgba(255,255,255,0.08)", borderRadius: 2, padding: "50px" }}>
                <div style={{ fontFamily: "monospace", fontSize: "0.65rem", letterSpacing: 3, color: "#c9ff47", textTransform: "uppercase", marginBottom: 32 }}>Проверка обменника</div>
                <div style={{ display: "flex", gap: 12, marginBottom: 24 }}>
                  <input
                    id="exchange-url"
                    placeholder="https://мой-обменник.com"
                    style={{
                      flex: 1, padding: "16px 20px",
                      background: "rgba(255,255,255,0.04)",
                      border: "1px solid rgba(255,255,255,0.1)",
                      borderRadius: 2, color: "#fff", fontSize: "0.95rem",
                      fontFamily: "'Inter',sans-serif", outline: "none",
                    }}
                    onFocus={(e) => { e.currentTarget.style.borderColor = "#c9ff47"; }}
                    onBlur={(e) => { e.currentTarget.style.borderColor = "rgba(255,255,255,0.1)"; }}
                  />
                  <button
                    onClick={() => setSearchResult(true)}
                    onMouseEnter={hoverOn} onMouseLeave={hoverOff}
                    style={{
                      padding: "16px 24px", background: "#c9ff47", border: "none",
                      borderRadius: 2, color: "#050505", fontWeight: 800,
                      fontSize: "0.75rem", letterSpacing: 2, textTransform: "uppercase",
                      fontFamily: "monospace", cursor: "pointer",
                      transition: "opacity 0.2s",
                    }}
                    onMouseOver={(e) => e.currentTarget.style.opacity = "0.85"}
                    onMouseOut={(e) => e.currentTarget.style.opacity = "1"}
                  >
                    Найти
                  </button>
                </div>
                <p style={{ color: "rgba(255,255,255,0.3)", fontSize: "0.85rem", lineHeight: 1.7 }}>
                  Получите список площадок где уже есть профиль + рекомендации по расширению.
                </p>
              </div>
            </RevealBlock>

            <RevealBlock delay={120}>
              <div style={{
                border: `1px solid ${searchResult ? "rgba(201,255,71,0.3)" : "rgba(255,255,255,0.08)"}`,
                borderRadius: 2, padding: "50px",
                transition: "border-color 0.4s",
              }}>
                <div style={{ fontFamily: "monospace", fontSize: "0.65rem", letterSpacing: 3, color: "#c9ff47", textTransform: "uppercase", marginBottom: 32 }}>Результаты анализа</div>
                <div style={{ display: "flex", flexWrap: "wrap", gap: 10, marginBottom: 24 }}>
                  {[
                    { label: "BestChange", active: true },
                    { label: "TrustPilot", active: true },
                    { label: "ForumBits", active: false },
                  ].map((tag) => (
                    <span key={tag.label} style={{
                      padding: "8px 16px", borderRadius: 2, fontSize: "0.8rem",
                      fontFamily: "monospace", letterSpacing: 1,
                      border: `1px solid ${tag.active ? "rgba(201,255,71,0.4)" : "rgba(255,255,255,0.1)"}`,
                      color: tag.active ? "#c9ff47" : "rgba(255,255,255,0.3)",
                      background: tag.active ? "rgba(201,255,71,0.07)" : "transparent",
                    }}>
                      {tag.active ? "✓ " : "➕ "}{tag.label}
                    </span>
                  ))}
                </div>
                <p style={{ color: "rgba(255,255,255,0.25)", fontSize: "0.8rem", fontFamily: "monospace", letterSpacing: 1 }}>
                  ➕ Рекомендуем добавить · ✓ Уже размещено
                </p>
              </div>
            </RevealBlock>
          </div>
        </div>
      </section>

      {/* PLATFORMS */}
      <section id="platforms" style={{ padding: "140px 48px", background: "#080808" }}>
        <div style={{ maxWidth: 1400, margin: "0 auto" }}>
          <RevealBlock>
            <div style={{ marginBottom: 80, borderBottom: "1px solid rgba(255,255,255,0.08)", paddingBottom: 40 }}>
              <div style={{ fontFamily: "monospace", fontSize: "0.7rem", letterSpacing: 3, color: "#c9ff47", textTransform: "uppercase", marginBottom: 20 }}>04 — Площадки</div>
              <h2 style={{ fontSize: "clamp(2.5rem,5vw,4rem)", fontWeight: 900, color: "#fff", lineHeight: 1.05, letterSpacing: -2, margin: 0 }}>
                Мониторинги и форумы
              </h2>
              <p style={{ marginTop: 24, color: "rgba(255,255,255,0.4)", fontSize: "1.1rem", maxWidth: 600 }}>
                Площадки, с которыми мы работаем. Размещаем и управляем отзывами напрямую.
              </p>
            </div>
          </RevealBlock>

          {/* Monitoring */}
          <RevealBlock delay={100}>
            <div style={{ marginBottom: 64 }}>
              <div style={{ fontFamily: "monospace", fontSize: "0.65rem", letterSpacing: 3, color: "rgba(255,255,255,0.3)", textTransform: "uppercase", marginBottom: 28 }}>
                — Мониторинги
              </div>
              <div style={{ display: "flex", flexWrap: "wrap", gap: 16 }}>
                {platforms.filter((p) => p.type === "monitoring").map((p) => (
                  <a
                    key={p.id}
                    href={p.url ?? "#"}
                    target="_blank"
                    rel="noopener noreferrer"
                    onMouseEnter={hoverOn} onMouseLeave={hoverOff}
                    style={{
                      display: "inline-flex", alignItems: "center", gap: 10,
                      padding: "14px 24px",
                      border: "1px solid rgba(255,255,255,0.1)",
                      borderRadius: 2, textDecoration: "none",
                      color: "#fff", fontFamily: "monospace",
                      fontSize: "0.85rem", letterSpacing: 1,
                      transition: "border-color 0.3s, background 0.3s",
                    }}
                    onMouseOver={(e) => {
                      e.currentTarget.style.borderColor = "#c9ff47";
                      e.currentTarget.style.background = "rgba(201,255,71,0.05)";
                    }}
                    onMouseOut={(e) => {
                      e.currentTarget.style.borderColor = "rgba(255,255,255,0.1)";
                      e.currentTarget.style.background = "transparent";
                    }}
                  >
                    <span style={{ width: 6, height: 6, borderRadius: "50%", background: "#c9ff47", flexShrink: 0 }} />
                    {p.name}
                  </a>
                ))}
                {platforms.filter((p) => p.type === "monitoring").length === 0 && (
                  <span style={{ color: "rgba(255,255,255,0.2)", fontFamily: "monospace", fontSize: "0.8rem" }}>Загрузка...</span>
                )}
              </div>
            </div>
          </RevealBlock>

          {/* Forums */}
          <RevealBlock delay={200}>
            <div>
              <div style={{ fontFamily: "monospace", fontSize: "0.65rem", letterSpacing: 3, color: "rgba(255,255,255,0.3)", textTransform: "uppercase", marginBottom: 28 }}>
                — Форумы
              </div>
              <div style={{ display: "flex", flexWrap: "wrap", gap: 16 }}>
                {platforms.filter((p) => p.type === "forum").map((p) => (
                  <a
                    key={p.id}
                    href={p.url ?? "#"}
                    target="_blank"
                    rel="noopener noreferrer"
                    onMouseEnter={hoverOn} onMouseLeave={hoverOff}
                    style={{
                      display: "inline-flex", alignItems: "center", gap: 10,
                      padding: "14px 24px",
                      border: "1px solid rgba(255,255,255,0.1)",
                      borderRadius: 2, textDecoration: "none",
                      color: "#fff", fontFamily: "monospace",
                      fontSize: "0.85rem", letterSpacing: 1,
                      transition: "border-color 0.3s, background 0.3s",
                    }}
                    onMouseOver={(e) => {
                      e.currentTarget.style.borderColor = "rgba(255,255,255,0.4)";
                      e.currentTarget.style.background = "rgba(255,255,255,0.04)";
                    }}
                    onMouseOut={(e) => {
                      e.currentTarget.style.borderColor = "rgba(255,255,255,0.1)";
                      e.currentTarget.style.background = "transparent";
                    }}
                  >
                    <span style={{ width: 6, height: 6, borderRadius: 1, background: "rgba(255,255,255,0.4)", flexShrink: 0 }} />
                    {p.name}
                  </a>
                ))}
                {platforms.filter((p) => p.type === "forum").length === 0 && (
                  <span style={{ color: "rgba(255,255,255,0.2)", fontFamily: "monospace", fontSize: "0.8rem" }}>Загрузка...</span>
                )}
              </div>
            </div>
          </RevealBlock>
        </div>
      </section>

      {/* CONTACT */}
      <section id="contact" style={{ padding: "140px 48px", background: "#050505" }}>
        <div style={{ maxWidth: 1400, margin: "0 auto" }}>
          <RevealBlock>
            <div style={{ marginBottom: 100, borderBottom: "1px solid rgba(255,255,255,0.08)", paddingBottom: 40 }}>
              <div style={{ fontFamily: "monospace", fontSize: "0.7rem", letterSpacing: 3, color: "#c9ff47", textTransform: "uppercase", marginBottom: 20 }}>05 — Контакты</div>
              <h2 style={{ fontSize: "clamp(2.5rem,5vw,4rem)", fontWeight: 900, color: "#fff", lineHeight: 1.05, letterSpacing: -2, margin: 0 }}>
                Начните демо-период
              </h2>
            </div>
          </RevealBlock>

          <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 80, alignItems: "start" }}>
            <RevealBlock>
              <div>
                <p style={{ fontSize: "1.1rem", color: "rgba(255,255,255,0.45)", lineHeight: 1.8, marginBottom: 60 }}>
                  Понимаем боль владельцев обменников: рейтинг проседает, появляется негатив. Exchange Feed решает это системно.
                </p>
                <div style={{ marginBottom: 48 }}>
                  {[
                    { label: "Email", value: "support@exchange-feed.com" },
                    { label: "Telegram", value: "@exchange_feed_bot" },
                    { label: "Телефон", value: "+7 (999) 123-45-67" },
                  ].map((item, i, arr) => (
                    <div key={item.label} style={{
                      display: "flex", justifyContent: "space-between", alignItems: "center",
                      padding: "24px 0",
                      borderBottom: i < arr.length - 1 ? "1px solid rgba(255,255,255,0.07)" : "none",
                    }}>
                      <span style={{ fontFamily: "monospace", fontSize: "0.7rem", letterSpacing: 2, color: "rgba(255,255,255,0.3)", textTransform: "uppercase" }}>{item.label}</span>
                      <span style={{ fontSize: "0.95rem", color: "#fff" }}>{item.value}</span>
                    </div>
                  ))}
                </div>
                <div style={{ border: "1px solid rgba(201,255,71,0.15)", borderRadius: 2, padding: "32px" }}>
                  <div style={{ fontFamily: "monospace", fontSize: "0.65rem", letterSpacing: 3, color: "#c9ff47", textTransform: "uppercase", marginBottom: 16 }}>Как начать</div>
                  <div style={{ fontSize: "0.95rem", color: "rgba(255,255,255,0.5)", lineHeight: 1.7 }}>
                    Тестовые отзывы → Согласование → Масштабирование → Результат
                  </div>
                </div>
              </div>
            </RevealBlock>

            <RevealBlock delay={150}>
              <form onSubmit={handleFormSubmit} style={{ border: "1px solid rgba(255,255,255,0.1)", borderRadius: 2, padding: "60px 50px" }}>
                <div style={{ fontFamily: "monospace", fontSize: "0.65rem", letterSpacing: 3, color: "#c9ff47", textTransform: "uppercase", marginBottom: 48 }}>Получить демо</div>

                {[
                  { id: "email", label: "E-mail", type: "email", placeholder: "you@example.com" },
                  { id: "telegram", label: "Telegram", type: "text", placeholder: "@username" },
                ].map((f) => (
                  <div key={f.id} style={{ marginBottom: 28 }}>
                    <label htmlFor={f.id} style={{ display: "block", fontFamily: "monospace", fontSize: "0.65rem", letterSpacing: 2, color: "rgba(255,255,255,0.4)", textTransform: "uppercase", marginBottom: 10 }}>
                      {f.label}
                    </label>
                    <input
                      id={f.id} name={f.id} type={f.type} placeholder={f.placeholder} required
                      onMouseEnter={hoverOn} onMouseLeave={hoverOff}
                      style={{
                        width: "100%", padding: "16px 20px",
                        background: "rgba(255,255,255,0.04)",
                        border: "1px solid rgba(255,255,255,0.1)",
                        borderRadius: 2, color: "#fff", fontSize: "0.95rem",
                        fontFamily: "'Inter',sans-serif", outline: "none",
                        boxSizing: "border-box",
                      }}
                      onFocus={(e) => { e.currentTarget.style.borderColor = "#c9ff47"; e.currentTarget.style.background = "rgba(201,255,71,0.04)"; }}
                      onBlur={(e) => { e.currentTarget.style.borderColor = "rgba(255,255,255,0.1)"; e.currentTarget.style.background = "rgba(255,255,255,0.04)"; }}
                    />
                  </div>
                ))}

                <div style={{ marginBottom: 36 }}>
                  <label htmlFor="message" style={{ display: "block", fontFamily: "monospace", fontSize: "0.65rem", letterSpacing: 2, color: "rgba(255,255,255,0.4)", textTransform: "uppercase", marginBottom: 10 }}>
                    Задача
                  </label>
                  <textarea
                    id="message" name="message" placeholder="Какие площадки и объемы интересуют?"
                    onMouseEnter={hoverOn} onMouseLeave={hoverOff}
                    style={{
                      width: "100%", padding: "16px 20px",
                      background: "rgba(255,255,255,0.04)",
                      border: "1px solid rgba(255,255,255,0.1)",
                      borderRadius: 2, color: "#fff", fontSize: "0.95rem",
                      fontFamily: "'Inter',sans-serif", outline: "none",
                      minHeight: 120, maxHeight: 200, resize: "vertical", boxSizing: "border-box",
                    }}
                    onFocus={(e) => { e.currentTarget.style.borderColor = "#c9ff47"; e.currentTarget.style.background = "rgba(201,255,71,0.04)"; }}
                    onBlur={(e) => { e.currentTarget.style.borderColor = "rgba(255,255,255,0.1)"; e.currentTarget.style.background = "rgba(255,255,255,0.04)"; }}
                  />
                </div>

                <button
                  type="submit"
                  disabled={formLoading}
                  onMouseEnter={hoverOn} onMouseLeave={hoverOff}
                  style={{
                    width: "100%", padding: "18px",
                    background: formSent ? "#080808" : formError ? "#1a0505" : "#c9ff47",
                    border: formSent ? "1px solid #c9ff47" : formError ? "1px solid #ff4444" : "none",
                    borderRadius: 2,
                    color: formSent ? "#c9ff47" : formError ? "#ff4444" : "#050505",
                    fontWeight: 800, fontSize: "0.8rem", letterSpacing: 2,
                    textTransform: "uppercase", fontFamily: "monospace", cursor: formLoading ? "default" : "none",
                    transition: "all 0.4s", opacity: formLoading ? 0.6 : 1,
                  }}
                  onMouseOver={(e) => { if (!formSent && !formError && !formLoading) e.currentTarget.style.opacity = "0.85"; }}
                  onMouseOut={(e) => { e.currentTarget.style.opacity = formLoading ? "0.6" : "1"; }}
                >
                  {formLoading
                    ? "Отправка..."
                    : formSent
                    ? "✓ Отправлено · Свяжемся в течение часа"
                    : formError
                    ? "✗ Ошибка · Попробуйте ещё раз"
                    : "Получить демо →"}
                </button>
              </form>
            </RevealBlock>
          </div>
        </div>
      </section>

      {/* FOOTER */}
      <footer style={{ borderTop: "1px solid rgba(255,255,255,0.08)", padding: "32px 48px", background: "#050505" }}>
        <div style={{ maxWidth: 1400, margin: "0 auto", display: "flex", justifyContent: "space-between", alignItems: "center" }}>
          <div style={{ fontFamily: "monospace", fontSize: "0.7rem", letterSpacing: 2, color: "rgba(255,255,255,0.2)", textTransform: "uppercase" }}>
            Exchange Feed © 2024
          </div>
          <div style={{ fontFamily: "monospace", fontSize: "0.7rem", letterSpacing: 2, color: "rgba(255,255,255,0.2)", textTransform: "uppercase" }}>
            Анонимно · Надёжно · Результат
          </div>
        </div>
      </footer>

      <style>{`
        * { box-sizing: border-box; margin: 0; padding: 0; }
        html { scroll-behavior: smooth; }
        body {
          font-family: 'Inter', -apple-system, sans-serif;
          background: #050505;
          color: #fff;
          overflow-x: hidden;
          cursor: none;
        }
        ::selection { background: #c9ff47; color: #050505; }
        input::placeholder, textarea::placeholder { color: rgba(255,255,255,0.2); }
        @keyframes pulse {
          0%, 100% { opacity: 1; transform: scale(1); }
          50% { opacity: 0.5; transform: scale(0.8); }
        }
        @keyframes scrollLine {
          0% { opacity: 0; transform: scaleY(0); transform-origin: top; }
          50% { opacity: 1; transform: scaleY(1); }
          100% { opacity: 0; transform: scaleY(1); transform-origin: bottom; }
        }
        a { cursor: none; }
        button { cursor: none; }
      `}</style>
    </>
  );
}
