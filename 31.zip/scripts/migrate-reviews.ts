import { execSync } from "child_process";
import Database from "better-sqlite3";
import path from "path";
import { fileURLToPath } from "url";
import { randomUUID } from "crypto";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const WORKSPACE_ROOT = path.resolve(__dirname, "../");
const SQLITE_PATH = process.argv[2] || path.join(WORKSPACE_ROOT, "attached_assets/Reviews_1775380279279.db");
const LOCAL_DB_PATH = path.join(WORKSPACE_ROOT, "Reviews.db");

const CLIENT_TABLES = [
  "1WM",
  "Bitok777",
  "Exchange.Express",
  "EXWM",
  "Fastex",
  "Multival",
  "ObmenMoney",
  "Obmenoff",
  "VObmenka",
  "W-box",
  "WM.Money",
  "WX.Money",
];

function readSqliteTable(table: string): { date: string; link: string; email: string; application: string; name: string }[] {
  const source = new Database(SQLITE_PATH, { readonly: true });
  const rows = source.prepare(`SELECT date, link, email, "заявка" as application, name FROM "${table}"`).all() as {
    date: string;
    link: string;
    email: string;
    application: string;
    name: string;
  }[];
  source.close();
  return rows;
}

async function main() {
  const db = new Database(LOCAL_DB_PATH);
  db.pragma("foreign_keys = ON");

  const selectClient = db.prepare("SELECT id FROM clients WHERE name = ?");
  const insertClient = db.prepare("INSERT INTO clients (id, name, status) VALUES (?, ?, 'in_work')");
  const countReviews = db.prepare("SELECT COUNT(*) as count FROM client_reviews WHERE client_id = ?");
  const insertReview = db.prepare("INSERT INTO client_reviews (id, client_id, review_date, link, email, application, reviewer_name) VALUES (?, ?, ?, ?, ?, ?, ?)");

  const tx = db.transaction(() => {
    for (const tableName of CLIENT_TABLES) {
      console.log(`\nProcessing client: ${tableName}`);
      let client = selectClient.get(tableName) as { id: string } | undefined;
      let clientId: string;
      if (client) {
        clientId = client.id;
        console.log(`  Client already exists: ${clientId}`);
      } else {
        clientId = randomUUID();
        insertClient.run(clientId, tableName);
        console.log(`  Created client: ${clientId}`);
      }

      const existing = countReviews.get(clientId) as { count: number };
      if (existing.count > 0) {
        console.log(`  Already has ${existing.count} reviews, skipping import`);
        continue;
      }

      const rows = readSqliteTable(tableName);
      console.log(`  Importing ${rows.length} reviews...`);
      for (const row of rows) {
        insertReview.run(randomUUID(), clientId, row.date, row.link, row.email, row.application, row.name);
      }
    }
  });

  tx();
  db.close();
  console.log("Migration complete!");
}

main().catch(err => {
  console.error("Migration failed:", err);
  process.exit(1);
});