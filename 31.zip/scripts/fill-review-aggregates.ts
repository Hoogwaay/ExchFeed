import Database from "better-sqlite3";
import path from "path";
import { fileURLToPath } from "url";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const dbPath = path.resolve(__dirname, "..", "Reviews.db");
const db = new Database(dbPath);

db.pragma("foreign_keys = ON");
const clients = db.prepare("SELECT id FROM clients").all() as { id: string }[];
const insertReview = db.prepare("INSERT INTO reviews (id, client_id, count, earned_amount, date, notes) VALUES (?, ?, ?, ?, ?, ?)");
const deleteReviews = db.prepare("DELETE FROM reviews");

deleteReviews.run();
const importRows = db.prepare(`
  SELECT client_id, COUNT(*) as count
  FROM client_reviews
  GROUP BY client_id
`).all() as { client_id: string; count: number }[];

const clientIds = new Set(clients.map(c => c.id));
for (const row of importRows) {
  if (!clientIds.has(row.client_id)) continue;
  insertReview.run(
    crypto.randomUUID(),
    row.client_id,
    row.count,
    0,
    new Date().toISOString(),
    "Imported aggregate"
  );
}

db.close();
console.log("Review aggregates filled");