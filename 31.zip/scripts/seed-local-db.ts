import Database from "better-sqlite3";
import { drizzle } from "drizzle-orm/better-sqlite3";
import path from "path";
import { fileURLToPath } from "url";
import { clients, reviews, transactions, tasks, schedules, resources, clientReviews } from "../database/schema.js";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const dbPath = path.resolve(__dirname, "..", "Reviews.db");
const sqlite = new Database(dbPath);
sqlite.pragma("foreign_keys = ON");
const db = drizzle(sqlite);

const existingClients = db.select().from(clients).all();
if (existingClients.length === 0) {
  const [c1] = db.insert(clients).values({ name: "Alpha Capital", email: "alpha", phone: "secret", status: "in_work", notes: "https://sheet.example/alpha", wallets: JSON.stringify([{ name: "site-1", url: "https://example.com" }]), tz: "MSK" }).returning().all();
  const [c2] = db.insert(clients).values({ name: "Beta Exchange", email: "beta", phone: "secret", status: "potential", notes: "https://sheet.example/beta", wallets: JSON.stringify([{ name: "site-2", url: "https://example.org" }]), tz: "UTC" }).returning().all();
  db.insert(reviews).values([
    { clientId: c1.id, count: 12, earnedAmount: 1200, notes: "Initial import" },
    { clientId: c2.id, count: 7, earnedAmount: 640, notes: "Initial import" },
  ]).run();
  db.insert(clientReviews).values([
    { clientId: c1.id, reviewDate: "2025-05-03", link: "https://review/1", email: "user1@example.com", application: "app-1", reviewerName: "NoName" },
    { clientId: c2.id, reviewDate: "2025-05-04", link: "https://review/2", email: "user2@example.com", application: "app-2", reviewerName: "NoName" },
  ]).run();
  db.insert(transactions).values([
    { type: "income", amount: 5000, description: "First payment", category: "clients" },
    { type: "expense", amount: 800, description: "Service fee", category: "operations" },
  ]).run();
  db.insert(tasks).values([
    { clientId: c1.id, reviewText: "Great service", reviewAmount: 100, reviewerName: "Alex", status: "pending" },
  ]).run();
  db.insert(schedules).values([
    { staffName: "Manager 1", workDate: "2026-04-05", startTime: "09:00", endTime: "18:00", notes: "Default schedule" },
  ]).run();
  db.insert(resources).values([
    { name: "Main Sheet", url: "https://sheet.example/main", language: "RU", format: "monitoring" },
  ]).run();
}

sqlite.close();
console.log("Seed complete");