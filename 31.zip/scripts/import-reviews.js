const { exec } = require('child_process');
const { Pool } = require('pg');
const { promisify } = require('util');
const fs = require('fs');

const execPromise = promisify(exec);

const DATABASE_URL = process.env.DATABASE_URL;
if (!DATABASE_URL) throw new Error('DATABASE_URL is not set');

async function importReviews() {
  const pool = new Pool({ connectionString: DATABASE_URL });
  
  try {
    // Get table names using sqlite3 CLI
    const { stdout } = await execPromise('sqlite3 attached_assets/Reviews_1775389423434.db ".tables"');
    const tableNames = stdout.trim().split(/\s+/).filter(t => t !== 'sqlite_sequence');
    
    console.log(`Found ${tableNames.length} tables in SQLite database`);
    
    for (const clientName of tableNames) {
      console.log(`\nProcessing client: ${clientName}`);
      
      // Check if client exists
      const clientCheck = await pool.query(
        'SELECT id FROM clients WHERE name = $1',
        [clientName]
      );
      
      let clientId = clientCheck.rows[0]?.id;
      
      if (!clientId) {
        // Create client
        const clientResult = await pool.query(
          'INSERT INTO clients (name, status, notes) VALUES ($1, $2, $3) RETURNING id',
          [
            clientName,
            'in_work',
            `Imported from Reviews database on ${new Date().toISOString()}`
          ]
        );
        clientId = clientResult.rows[0].id;
        console.log(`  Created new client: ${clientName}`);
      } else {
        console.log(`  Client already exists: ${clientName}`);
      }
      
      // Export reviews from SQLite as JSON
      const { stdout: jsonData } = await execPromise(
        `sqlite3 attached_assets/Reviews_1775389423434.db ".mode json" "SELECT * FROM \\"${clientName}\\""`,
        { maxBuffer: 10 * 1024 * 1024 }
      );
      
      const reviews = JSON.parse(jsonData || '[]');
      console.log(`  Found ${reviews.length} reviews for ${clientName}`);
      
      // Insert reviews in chunks
      if (reviews.length > 0) {
        const CHUNK_SIZE = 100;
        for (let i = 0; i < reviews.length; i += CHUNK_SIZE) {
          const chunk = reviews.slice(i, i + CHUNK_SIZE);
          
          for (const review of chunk) {
            await pool.query(
              `INSERT INTO client_reviews (client_id, review_date, link, email, application, reviewer_name)
               VALUES ($1, $2, $3, $4, $5, $6)`,
              [
                clientId,
                review.date || new Date().toISOString().split('T')[0],
                review.link || null,
                review.email || null,
                review.заявка || null,
                review.name || null
              ]
            );
          }
          
          console.log(`  Inserted ${Math.min(CHUNK_SIZE, reviews.length - i)} reviews`);
        }
      }
    }
    
    console.log('\n✓ Import completed successfully!');
  } catch (error) {
    console.error('Error during import:', error);
    throw error;
  } finally {
    await pool.end();
  }
}

importReviews();
