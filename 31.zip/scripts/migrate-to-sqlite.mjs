import { Pool } from "pg";
import Database from "better-sqlite3";
import fs from "fs";

const DATABASE_URL = process.env.DATABASE_URL;
if (!DATABASE_URL) throw new Error("DATABASE_URL is not set");

async function migrateToSQLite() {
  console.log("Starting migration from PostgreSQL to SQLite...");

  // Connect to PostgreSQL
  const pgPool = new Pool({ connectionString: DATABASE_URL });

  // Create SQLite database
  const dbPath = "Reviews.db";
  const db = new Database(dbPath);

  try {
    // Create tables in SQLite with same schema
    db.exec(`
      CREATE TABLE IF NOT EXISTS users (
        id TEXT PRIMARY KEY,
        username TEXT UNIQUE NOT NULL,
        password TEXT NOT NULL
      );

      CREATE TABLE IF NOT EXISTS clients (
        id TEXT PRIMARY KEY,
        name TEXT NOT NULL,
        email TEXT,
        phone TEXT,
        status TEXT NOT NULL DEFAULT 'potential',
        notes TEXT,
        tz TEXT,
        wallets TEXT,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP
      );

      CREATE TABLE IF NOT EXISTS client_reviews (
        id TEXT PRIMARY KEY,
        client_id TEXT NOT NULL,
        review_date TEXT NOT NULL,
        link TEXT,
        email TEXT,
        application TEXT,
        reviewer_name TEXT,
        imported_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        FOREIGN KEY (client_id) REFERENCES clients(id) ON DELETE CASCADE
      );

      CREATE TABLE IF NOT EXISTS reviews (
        id TEXT PRIMARY KEY,
        client_id TEXT,
        count INTEGER DEFAULT 1,
        earned_amount TEXT DEFAULT '0',
        date DATETIME DEFAULT CURRENT_TIMESTAMP,
        notes TEXT,
        FOREIGN KEY (client_id) REFERENCES clients(id)
      );

      CREATE TABLE IF NOT EXISTS transactions (
        id TEXT PRIMARY KEY,
        type TEXT NOT NULL,
        amount TEXT NOT NULL,
        description TEXT,
        category TEXT,
        date DATETIME DEFAULT CURRENT_TIMESTAMP
      );

      CREATE TABLE IF NOT EXISTS tasks (
        id TEXT PRIMARY KEY,
        client_id TEXT,
        review_language TEXT DEFAULT 'RU',
        review_text TEXT NOT NULL,
        review_amount TEXT DEFAULT '0',
        reviewer_name TEXT DEFAULT '',
        login_email TEXT,
        login_password TEXT,
        confirm_link TEXT,
        service TEXT,
        review_type TEXT,
        task_number TEXT,
        status TEXT DEFAULT 'pending',
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
        completed_at DATETIME,
        FOREIGN KEY (client_id) REFERENCES clients(id)
      );

      CREATE TABLE IF NOT EXISTS schedules (
        id TEXT PRIMARY KEY,
        staff_name TEXT NOT NULL,
        work_date TEXT NOT NULL,
        start_time TEXT,
        end_time TEXT,
        notes TEXT,
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP
      );

      CREATE TABLE IF NOT EXISTS resources (
        id TEXT PRIMARY KEY,
        name TEXT NOT NULL,
        url TEXT NOT NULL,
        language TEXT DEFAULT 'RU',
        format TEXT DEFAULT 'monitoring',
        created_at DATETIME DEFAULT CURRENT_TIMESTAMP
      );
    `);

    // Helper function to migrate table
    async function migrateTable(tableName, sqliteTableName = tableName) {
      try {
        const pgResult = await pgPool.query(`SELECT * FROM "${tableName}"`);
        const rows = pgResult.rows;

        if (rows.length === 0) {
          console.log(`  ${tableName}: 0 rows`);
          return;
        }

        // Get column names
        const columns = Object.keys(rows[0]);
        const placeholders = columns.map(() => "?").join(", ");
        const columnNames = columns.map(c => `"${c}"`).join(", ");

        const stmt = db.prepare(
          `INSERT INTO ${sqliteTableName} (${columnNames}) VALUES (${placeholders})`
        );

        const insertMany = db.transaction((items) => {
          for (const item of items) {
            stmt.run(...columns.map(col => item[col]));
          }
        });

        insertMany(rows);
        console.log(`  ${tableName}: ${rows.length} rows`);
      } catch (e) {
        console.log(`  ${tableName}: error (likely empty table)`);
      }
    }

    // Migrate all tables
    console.log("\nMigrating tables:");
    await migrateTable("users");
    await migrateTable("clients");
    await migrateTable("client_reviews");
    await migrateTable("reviews");
    await migrateTable("transactions");
    await migrateTable("tasks");
    await migrateTable("schedules");
    await migrateTable("resources");

    console.log(`\n✓ Migration complete! Database saved to: ${dbPath}`);
    console.log(`File size: ${(fs.statSync(dbPath).size / 1024 / 1024).toFixed(2)} MB`);
  } finally {
    db.close();
    await pgPool.end();
  }
}

migrateToSQLite();
