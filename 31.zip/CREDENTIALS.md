# Данные для входа / Login Credentials

## Админ-панель / Admin Panel
- **URL:** `/admin/login`
- **Логин:** Admin
- **Пароль:** Admin

## Рабочая панель (CRM) / Worker Panel (CRM)
- **URL:** `/crm/login`
- **Логин:** Work
- **Пароль:** Work

## Личный кабинет (Юзер) / User Cabinet
- **URL:** `/login`
- **Логин:** User
- **Пароль:** User
