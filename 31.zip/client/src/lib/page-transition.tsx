import { createContext, useContext, useState, useCallback, useRef } from "react";
import type { ReactNode } from "react";

interface TransitionCtx {
  startTransition: (cb: () => void) => void;
}

const Ctx = createContext<TransitionCtx>({ startTransition: (cb) => cb() });

const FADE_IN_MS = 320;
const HOLD_MS = 1680;
const FADE_OUT_MS = 420;

export function PageTransitionProvider({ children }: { children: ReactNode }) {
  const [visible, setVisible] = useState(false);
  const [opacity, setOpacity] = useState(0);
  const timerRef = useRef<ReturnType<typeof setTimeout> | null>(null);

  const startTransition = useCallback((cb: () => void) => {
    if (timerRef.current) clearTimeout(timerRef.current);

    setVisible(true);
    requestAnimationFrame(() => {
      requestAnimationFrame(() => setOpacity(1));
    });

    timerRef.current = setTimeout(() => {
      cb();
      timerRef.current = setTimeout(() => {
        setOpacity(0);
        timerRef.current = setTimeout(() => {
          setVisible(false);
        }, FADE_OUT_MS);
      }, 80);
    }, FADE_IN_MS + HOLD_MS);
  }, []);

  return (
    <Ctx.Provider value={{ startTransition }}>
      {children}
      {visible && (
        <div
          style={{
            position: "fixed",
            inset: 0,
            zIndex: 99990,
            background: "#050505",
            display: "flex",
            alignItems: "center",
            justifyContent: "center",
            flexDirection: "column",
            gap: 28,
            opacity,
            transition: `opacity ${opacity ? FADE_IN_MS : FADE_OUT_MS}ms cubic-bezier(0.16,1,0.3,1)`,
            pointerEvents: "all",
          }}
        >
          <style>{`
            @keyframes pg-spin { to { transform: rotate(360deg); } }
          `}</style>
          <div
            style={{
              width: 36,
              height: 36,
              border: "1.5px solid rgba(201,255,71,0.15)",
              borderTop: "1.5px solid #c9ff47",
              borderRadius: "50%",
              animation: "pg-spin 0.75s linear infinite",
            }}
          />
          <div
            style={{
              fontFamily: "monospace",
              fontSize: "0.58rem",
              letterSpacing: 5,
              color: "rgba(255,255,255,0.18)",
              textTransform: "uppercase",
            }}
          >
            Exchange Feed
          </div>
        </div>
      )}
    </Ctx.Provider>
  );
}

export function usePageTransition() {
  return useContext(Ctx);
}
