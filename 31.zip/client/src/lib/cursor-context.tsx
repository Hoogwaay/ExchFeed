import { createContext, useContext } from "react";

interface CursorContextType {
  hoverOn: () => void;
  hoverOff: () => void;
}

export const CursorContext = createContext<CursorContextType>({
  hoverOn: () => {},
  hoverOff: () => {},
});

export function useCursor() {
  return useContext(CursorContext);
}
