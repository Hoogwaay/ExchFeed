import { z } from "zod";

export type ClientStatus = "in_work" | "potential" | "refused" | "paused";

export interface Client {
  id: string;
  name: string;
  email: string | null;
  phone: string | null;
  status: ClientStatus;
  notes: string | null;
  tz?: string | null;
  wallets?: string | null;
  createdAt: string | Date;
}

export interface InsertClient {
  name: string;
  email?: string | null;
  phone?: string | null;
  status?: ClientStatus;
  notes?: string | null;
  tz?: string | null;
  wallets?: string | null;
}

export const insertClientSchema = z.object({
  name: z.string().min(1, "Name is required"),
  email: z.string().email().optional().nullable(),
  phone: z.string().optional().nullable(),
  status: z.enum(["in_work", "potential", "refused", "paused"]).default("potential"),
  notes: z.string().optional().nullable(),
  tz: z.string().optional().nullable(),
  wallets: z.string().optional().nullable(),
});

export interface Review {
  id: string;
  clientId: string | null;
  count: number;
  earnedAmount: string;
  date: string | Date;
  notes: string | null;
}

export interface InsertReview {
  clientId?: string | null;
  count?: number;
  earnedAmount?: string;
  date?: string | Date;
  notes?: string | null;
}

export interface Transaction {
  id: string;
  type: "income" | "expense";
  amount: string;
  description: string | null;
  date: string | Date;
}

export interface InsertTransaction {
  type: "income" | "expense";
  amount: string;
  description?: string | null;
  date?: string | Date;
}

export type TaskStatus = "pending" | "done" | "rejected";
export type ReviewLang = "RU" | "EN";

export interface Task {
  id: string;
  clientId: string | null;
  reviewLanguage: ReviewLang;
  reviewText: string;
  reviewAmount: string;
  reviewerName: string;
  loginEmail: string | null;
  loginPassword: string | null;
  confirmLink: string | null;
  service: string | null;
  reviewType: string | null;
  taskNumber: string | null;
  status: TaskStatus;
  createdAt: string | Date;
  completedAt: string | Date | null;
}

export interface InsertTask {
  clientId?: string | null;
  reviewLanguage?: ReviewLang;
  reviewText: string;
  reviewAmount?: string;
  reviewerName?: string;
  loginEmail?: string | null;
  loginPassword?: string | null;
  confirmLink?: string | null;
  service?: string | null;
  reviewType?: string | null;
  taskNumber?: string | null;
  status?: TaskStatus;
}
