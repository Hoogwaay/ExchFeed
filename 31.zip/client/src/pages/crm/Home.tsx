import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { useState, useRef, useEffect } from "react";
import { Check, X, Copy, ExternalLink, Star, CheckCircle2, Users, Plus } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import type { Task, Client } from "@shared/schema";

const SERVICES = [
  "Яндекс Карты",
  "Google Maps",
  "2ГИС",
  "Otzovik",
  "Яндекс Маркет",
  "Авито",
  "TripAdvisor",
  "Zoon",
  "Flamp",
];

const REVIEW_TYPES = [
  "Положительный",
  "Нейтральный",
  "Отрицательный",
];

function playNotificationSound() {
  try {
    const ctx = new (window.AudioContext || (window as any).webkitAudioContext)();
    const times = [0, 0.18, 0.36];
    times.forEach((t, i) => {
      const osc = ctx.createOscillator();
      const gain = ctx.createGain();
      osc.connect(gain);
      gain.connect(ctx.destination);
      osc.type = "sine";
      osc.frequency.setValueAtTime(880 + i * 220, ctx.currentTime + t);
      gain.gain.setValueAtTime(0, ctx.currentTime + t);
      gain.gain.linearRampToValueAtTime(0.35, ctx.currentTime + t + 0.02);
      gain.gain.exponentialRampToValueAtTime(0.001, ctx.currentTime + t + 0.14);
      osc.start(ctx.currentTime + t);
      osc.stop(ctx.currentTime + t + 0.15);
    });
  } catch {}
}

async function fetchJson(url: string) {
  const r = await fetch(url);
  if (!r.ok) throw new Error("Request failed");
  return r.json();
}

async function patchJson(url: string, body: object) {
  const r = await fetch(url, {
    method: "PATCH",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(body),
  });
  if (!r.ok) throw new Error("Request failed");
  return r.json();
}

async function postJson(url: string, body: object) {
  const r = await fetch(url, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(body),
  });
  if (!r.ok) throw new Error("Request failed");
  return r.json();
}

function StatCard({ icon, label, value, color }: {
  icon: React.ReactNode; label: string; value: number | string; color: string;
}) {
  return (
    <div className="bg-[--admin-sidebar] border border-[--admin-border] rounded-xl p-4 flex items-center gap-4 flex-1 min-w-0">
      <div className={`w-10 h-10 rounded-lg flex items-center justify-center shrink-0 ${color}`}>
        {icon}
      </div>
      <div className="min-w-0">
        <div className="text-2xl font-bold text-[--admin-text]">{value}</div>
        <div className="text-xs text-[--admin-muted] mt-0.5 leading-tight">{label}</div>
      </div>
    </div>
  );
}

function NewTaskModal({ clients, onClose, onCreated }: {
  clients: Client[];
  onClose: () => void;
  onCreated: () => void;
}) {
  const { toast } = useToast();
  const [loading, setLoading] = useState(false);
  const [form, setForm] = useState({
    clientId: "",
    service: "",
    reviewType: "",
    reviewText: "",
    taskNumber: "",
  });

  const set = (key: string, value: string) =>
    setForm(prev => ({ ...prev, [key]: value }));

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!form.clientId) {
      toast({ title: "Ошибка", description: "Выберите клиента", variant: "destructive" });
      return;
    }
    if (!form.service) {
      toast({ title: "Ошибка", description: "Выберите сервис", variant: "destructive" });
      return;
    }
    if (!form.reviewType) {
      toast({ title: "Ошибка", description: "Выберите вид отзыва", variant: "destructive" });
      return;
    }
    if (!form.reviewText.trim()) {
      toast({ title: "Ошибка", description: "Введите текст отзыва", variant: "destructive" });
      return;
    }
    if (!form.taskNumber.trim()) {
      toast({ title: "Ошибка", description: "Введите номер заявки", variant: "destructive" });
      return;
    }
    setLoading(true);
    try {
      await postJson("/api/tasks", {
        clientId: form.clientId,
        service: form.service,
        reviewType: form.reviewType,
        reviewText: form.reviewText.trim(),
        taskNumber: form.taskNumber.trim(),
        reviewLanguage: "RU",
        reviewerName: "",
        reviewAmount: "0",
        status: "pending",
      });
      toast({ title: "Заявка создана", description: "Новая заявка добавлена в очередь" });
      onCreated();
      onClose();
    } catch {
      toast({ title: "Ошибка", description: "Не удалось создать заявку", variant: "destructive" });
    } finally {
      setLoading(false);
    }
  };

  const inputClass =
    "w-full h-9 px-3 text-sm rounded-lg border border-[--admin-border] bg-[--admin-bg] text-[--admin-text] placeholder:text-[--admin-muted] focus:outline-none focus:ring-2 focus:ring-[--admin-accent]";
  const selectClass =
    "w-full h-9 px-3 text-sm rounded-lg border border-[--admin-border] bg-[--admin-bg] text-[--admin-text] focus:outline-none focus:ring-2 focus:ring-[--admin-accent] appearance-none";
  const labelClass = "block text-xs font-medium text-[--admin-muted] mb-1";

  const activeClients = clients.filter(c => c.status === "in_work");

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
      <div className="absolute inset-0 bg-black/40 backdrop-blur-sm" onClick={onClose} />
      <div className="relative bg-[--admin-sidebar] border border-[--admin-border] rounded-2xl shadow-2xl w-full max-w-md p-6">
        <div className="flex items-center justify-between mb-5">
          <h2 className="text-base font-bold text-[--admin-text]">Новая заявка</h2>
          <button
            onClick={onClose}
            className="w-8 h-8 rounded-lg hover:bg-[--admin-hover] flex items-center justify-center text-[--admin-muted] transition-colors"
          >
            <X size={16} />
          </button>
        </div>

        <form onSubmit={handleSubmit} className="space-y-4">
          <div>
            <label className={labelClass}>Клиент</label>
            <div className="relative">
              <select
                className={selectClass}
                value={form.clientId}
                onChange={e => set("clientId", e.target.value)}
              >
                <option value="">— выберите клиента —</option>
                {activeClients.map(c => (
                  <option key={c.id} value={c.id}>{c.name}</option>
                ))}
                {activeClients.length === 0 && clients.map(c => (
                  <option key={c.id} value={c.id}>{c.name}</option>
                ))}
              </select>
            </div>
          </div>

          <div>
            <label className={labelClass}>Сервис</label>
            <div className="relative">
              <select
                className={selectClass}
                value={form.service}
                onChange={e => set("service", e.target.value)}
              >
                <option value="">— выберите сервис —</option>
                {SERVICES.map(s => (
                  <option key={s} value={s}>{s}</option>
                ))}
              </select>
            </div>
          </div>

          <div>
            <label className={labelClass}>Вид отзыва</label>
            <div className="relative">
              <select
                className={selectClass}
                value={form.reviewType}
                onChange={e => set("reviewType", e.target.value)}
              >
                <option value="">— выберите вид —</option>
                {REVIEW_TYPES.map(rt => (
                  <option key={rt} value={rt}>{rt}</option>
                ))}
              </select>
            </div>
          </div>

          <div>
            <label className={labelClass}>Текст отзыва</label>
            <textarea
              rows={4}
              value={form.reviewText}
              onChange={e => set("reviewText", e.target.value)}
              placeholder="Введите текст отзыва..."
              className="w-full px-3 py-2 text-sm rounded-lg border border-[--admin-border] bg-[--admin-bg] text-[--admin-text] placeholder:text-[--admin-muted] focus:outline-none focus:ring-2 focus:ring-[--admin-accent] resize-none"
            />
          </div>

          <div>
            <label className={labelClass}>Номер заявки</label>
            <input
              type="text"
              value={form.taskNumber}
              onChange={e => set("taskNumber", e.target.value)}
              placeholder="Например: 12345"
              className={inputClass}
            />
          </div>

          <div className="flex gap-2 pt-1">
            <button
              type="button"
              onClick={onClose}
              className="flex-1 h-9 rounded-lg border border-[--admin-border] text-sm text-[--admin-text] hover:bg-[--admin-hover] transition-colors"
            >
              Отмена
            </button>
            <button
              type="submit"
              disabled={loading}
              className="flex-1 h-9 rounded-lg bg-[--admin-accent] text-white dark:text-black text-sm font-semibold hover:opacity-90 transition-opacity disabled:opacity-60"
            >
              {loading ? "Создаём..." : "Создать заявку"}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}

function TaskCard({ task, clients, onStatusChange }: {
  task: Task;
  clients: Client[];
  onStatusChange: (id: string, status: "done" | "rejected") => void;
}) {
  const [confirmLink, setConfirmLink] = useState(task.confirmLink || "");
  const [saving, setSaving] = useState(false);
  const { toast } = useToast();
  const qc = useQueryClient();

  const client = clients.find(c => c.id === task.clientId);

  const copy = (text: string | null | undefined, label: string) => {
    if (!text) {
      toast({ title: "Нет данных", description: `${label} не задан`, variant: "destructive" });
      return;
    }
    navigator.clipboard.writeText(text).then(() => {
      toast({ title: "Скопировано", description: `${label} скопирован в буфер` });
    });
  };

  const openMail = () => {
    window.open("https://mail.ru", "_blank", "noopener,noreferrer");
  };

  const saveLink = async () => {
    setSaving(true);
    try {
      await patchJson(`/api/tasks/${task.id}`, { confirmLink });
      await qc.invalidateQueries({ queryKey: ["/api/tasks"] });
      toast({ title: "Сохранено", description: "Ссылка подтверждения обновлена" });
    } catch {
      toast({ title: "Ошибка", description: "Не удалось сохранить", variant: "destructive" });
    } finally {
      setSaving(false);
    }
  };

  const reviewTypeColor = task.reviewType === "Положительный"
    ? "bg-green-100 text-green-700 dark:bg-green-900/30 dark:text-green-300"
    : task.reviewType === "Отрицательный"
      ? "bg-red-100 text-red-700 dark:bg-red-900/30 dark:text-red-300"
      : "bg-gray-100 text-gray-600 dark:bg-gray-800 dark:text-gray-300";

  return (
    <div className="bg-[--admin-bg] border border-[--admin-border] rounded-xl p-4 space-y-3">
      <div className="flex items-center gap-3">
        <span className="font-semibold text-[--admin-text] text-sm truncate flex-1">
          {client?.name ?? "Клиент не указан"}
        </span>
        {task.service && (
          <span className="text-xs font-medium px-2 py-0.5 rounded-full bg-blue-100 text-blue-700 dark:bg-blue-900/30 dark:text-blue-300 shrink-0">
            {task.service}
          </span>
        )}
        {task.reviewType && (
          <span className={`text-xs font-medium px-2 py-0.5 rounded-full shrink-0 ${reviewTypeColor}`}>
            {task.reviewType}
          </span>
        )}
        <div className="flex gap-1.5 shrink-0">
          <button
            onClick={() => onStatusChange(task.id, "done")}
            title="Принять"
            className="w-8 h-8 rounded-lg bg-green-500 hover:bg-green-600 text-white flex items-center justify-center transition-colors"
          >
            <Check size={15} strokeWidth={2.5} />
          </button>
          <button
            onClick={() => onStatusChange(task.id, "rejected")}
            title="Отклонить"
            className="w-8 h-8 rounded-lg bg-red-500 hover:bg-red-600 text-white flex items-center justify-center transition-colors"
          >
            <X size={15} strokeWidth={2.5} />
          </button>
        </div>
      </div>

      <div className="grid grid-cols-3 gap-2 text-xs">
        <div className="bg-[--admin-sidebar] rounded-lg p-2.5 min-w-0 col-span-2">
          <div className="text-[--admin-muted] mb-0.5">Текст отзыва</div>
          <div className="text-[--admin-text] font-medium line-clamp-2" title={task.reviewText}>
            {task.reviewText}
          </div>
        </div>
        <div className="bg-[--admin-sidebar] rounded-lg p-2.5 min-w-0">
          <div className="text-[--admin-muted] mb-0.5">Номер заявки</div>
          <div className="text-[--admin-text] font-semibold font-mono">
            {task.taskNumber ? `#${task.taskNumber}` : `#${task.id.slice(0, 8).toUpperCase()}`}
          </div>
        </div>
      </div>

      {!task.service && (
        <div className="flex gap-2 items-center">
          <input
            type="text"
            value={confirmLink}
            onChange={e => setConfirmLink(e.target.value)}
            onBlur={saveLink}
            onKeyDown={e => e.key === "Enter" && saveLink()}
            placeholder="Ссылка подтверждения..."
            className="flex-1 min-w-0 h-8 px-3 text-xs rounded-lg border border-[--admin-border] bg-[--admin-sidebar] text-[--admin-text] placeholder:text-[--admin-muted] focus:outline-none focus:ring-1 focus:ring-[--admin-accent]"
          />
          {task.loginEmail && (
            <button
              onClick={() => copy(task.loginEmail, "Логин (email)")}
              title="Скопировать логин"
              className="h-8 px-3 text-xs rounded-lg border border-[--admin-border] bg-[--admin-sidebar] text-[--admin-text] hover:bg-[--admin-hover] transition-colors shrink-0 flex items-center gap-1.5"
            >
              <Copy size={12} />
              Login
            </button>
          )}
          {task.loginPassword && (
            <button
              onClick={() => copy(task.loginPassword, "Пароль")}
              title="Скопировать пароль"
              className="h-8 px-3 text-xs rounded-lg border border-[--admin-border] bg-[--admin-sidebar] text-[--admin-text] hover:bg-[--admin-hover] transition-colors shrink-0 flex items-center gap-1.5"
            >
              <Copy size={12} />
              Password
            </button>
          )}
          <button
            onClick={openMail}
            title="Открыть mail.ru"
            className="h-8 px-3 text-xs rounded-lg bg-[--admin-accent] hover:opacity-90 text-white dark:text-black font-medium transition-opacity shrink-0 flex items-center gap-1.5"
          >
            <ExternalLink size={12} />
            Mail
          </button>
        </div>
      )}
    </div>
  );
}

export default function CrmHome() {
  const qc = useQueryClient();
  const { toast } = useToast();
  const prevPendingRef = useRef<number | null>(null);
  const isFirstLoadRef = useRef(true);
  const [showNewTask, setShowNewTask] = useState(false);

  const { data: tasks = [], isLoading: tasksLoading } = useQuery<Task[]>({
    queryKey: ["/api/tasks"],
    queryFn: () => fetchJson("/api/tasks"),
    refetchInterval: 5000,
  });

  const { data: clients = [] } = useQuery<Client[]>({
    queryKey: ["/api/clients"],
    queryFn: () => fetchJson("/api/clients"),
  });

  const { data: stats } = useQuery<{ pending: number; doneToday: number; clientsInWork: number }>({
    queryKey: ["/api/tasks/stats"],
    queryFn: () => fetchJson("/api/tasks/stats"),
    refetchInterval: 5000,
  });

  const statusMutation = useMutation({
    mutationFn: ({ id, status }: { id: string; status: "done" | "rejected" }) =>
      patchJson(`/api/tasks/${id}`, {
        status,
        completedAt: status === "done" ? new Date().toISOString() : null,
      }),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ["/api/tasks"] });
      qc.invalidateQueries({ queryKey: ["/api/tasks/stats"] });
    },
    onError: () => {
      toast({ title: "Ошибка", description: "Не удалось обновить статус", variant: "destructive" });
    },
  });

  const pendingTasks = tasks.filter(t => t.status === "pending");
  const pendingCount = pendingTasks.length;

  useEffect(() => {
    if (isFirstLoadRef.current) {
      if (!tasksLoading) {
        isFirstLoadRef.current = false;
        prevPendingRef.current = pendingCount;
      }
      return;
    }
    if (prevPendingRef.current !== null && pendingCount > prevPendingRef.current) {
      playNotificationSound();
      toast({ title: "Новая заявка!", description: "Поступила новая заявка на отзыв" });
    }
    prevPendingRef.current = pendingCount;
  }, [pendingCount, tasksLoading]);

  useEffect(() => {
    if (pendingCount > 0) {
      let show = true;
      document.title = `${pendingCount} ожидает`;
      const id = setInterval(() => {
        show = !show;
        document.title = show ? `${pendingCount} ожидает` : "Work - ExchFeed";
      }, 2000);
      return () => {
        clearInterval(id);
        document.title = "Work - ExchFeed";
      };
    } else {
      document.title = "Work - ExchFeed";
    }
  }, [pendingCount]);

  return (
    <>
      {showNewTask && (
        <NewTaskModal
          clients={clients}
          onClose={() => setShowNewTask(false)}
          onCreated={() => {
            qc.invalidateQueries({ queryKey: ["/api/tasks"] });
            qc.invalidateQueries({ queryKey: ["/api/tasks/stats"] });
          }}
        />
      )}

      <div className="space-y-5">
        <div>
          <h1 className="text-xl font-bold text-[--admin-text]">Главная</h1>
          <p className="text-sm text-[--admin-muted] mt-0.5">Входящие заявки на отзывы</p>
        </div>

        <div className="flex gap-3 flex-wrap">
          <StatCard
            icon={<Star size={18} className="text-yellow-500" />}
            label="Осталось отзывов сегодня"
            value={stats?.pending ?? 0}
            color="bg-yellow-50 dark:bg-yellow-900/20"
          />
          <StatCard
            icon={<CheckCircle2 size={18} className="text-green-500" />}
            label="Сделано отзывов сегодня"
            value={stats?.doneToday ?? 0}
            color="bg-green-50 dark:bg-green-900/20"
          />
          <StatCard
            icon={<Users size={18} className="text-blue-500" />}
            label="Клиентов в работе"
            value={stats?.clientsInWork ?? 0}
            color="bg-blue-50 dark:bg-blue-900/20"
          />
        </div>

        <div className="bg-[--admin-sidebar] border border-[--admin-border] rounded-xl">
          <div className="flex items-center justify-between px-4 py-3 border-b border-[--admin-border]">
            <div>
              <span className="text-sm font-semibold text-[--admin-text]">Заявки</span>
              {pendingCount > 0 && (
                <span className="ml-2 text-xs font-bold px-1.5 py-0.5 rounded-full bg-[--admin-accent] text-white dark:text-black">
                  {pendingCount}
                </span>
              )}
            </div>
            <button
              onClick={() => setShowNewTask(true)}
              title="Добавить заявку вручную"
              className="w-7 h-7 rounded-lg bg-[--admin-accent] hover:opacity-90 text-white dark:text-black flex items-center justify-center transition-opacity"
            >
              <Plus size={15} strokeWidth={2.5} />
            </button>
          </div>

          <div className="p-3 space-y-3">
            {tasksLoading && (
              <div className="text-center text-[--admin-muted] py-12 text-sm">Загрузка...</div>
            )}
            {!tasksLoading && pendingTasks.length === 0 && (
              <div className="text-center py-12 text-[--admin-muted]">
                <CheckCircle2 size={36} className="mx-auto mb-3 opacity-30" />
                <p className="text-sm font-medium">Нет активных заявок</p>
                <p className="text-xs mt-1 opacity-60">Новые заявки появятся здесь</p>
              </div>
            )}
            {pendingTasks.map(task => (
              <TaskCard
                key={task.id}
                task={task}
                clients={clients}
                onStatusChange={(id, status) => statusMutation.mutate({ id, status })}
              />
            ))}
          </div>
        </div>
      </div>
    </>
  );
}
