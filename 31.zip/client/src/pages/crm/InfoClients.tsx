import { useQuery } from "@tanstack/react-query";
import { FileText, Users } from "lucide-react";
import type { Client } from "@shared/schema";

async function fetchJson(url: string) {
  const r = await fetch(url);
  if (!r.ok) throw new Error("Request failed");
  return r.json();
}

const statusColors: Record<string, string> = {
  in_work: "bg-green-100 text-green-700 dark:bg-green-900/30 dark:text-green-400",
  potential: "bg-blue-100 text-blue-700 dark:bg-blue-900/30 dark:text-blue-400",
  paused: "bg-yellow-100 text-yellow-700 dark:bg-yellow-900/30 dark:text-yellow-400",
  refused: "bg-red-100 text-red-700 dark:bg-red-900/30 dark:text-red-400",
};

const statusLabels: Record<string, string> = {
  in_work: "В работе",
  potential: "Потенциальный",
  paused: "Пауза",
  refused: "Отказ",
};

function ClientCard({ client }: { client: Client }) {
  return (
    <div className="bg-[--admin-sidebar] border border-[--admin-border] rounded-xl p-4 space-y-3">
      <div className="flex items-center justify-between gap-3">
        <h3 className="font-semibold text-[--admin-text] text-base">{client.name}</h3>
        <span className={`text-xs font-medium px-2.5 py-1 rounded-full shrink-0 ${statusColors[client.status] ?? ""}`}>
          {statusLabels[client.status] ?? client.status}
        </span>
      </div>

      {client.tz ? (
        <div className="space-y-1.5">
          <div className="flex items-center gap-1.5 text-xs font-semibold text-[--admin-muted] uppercase tracking-wide">
            <FileText size={12} />
            Техническое задание
          </div>
          <div className="bg-[--admin-bg] rounded-lg p-3 text-sm text-[--admin-text] leading-relaxed whitespace-pre-wrap">
            {client.tz}
          </div>
        </div>
      ) : (
        <div className="text-sm text-[--admin-muted] text-center py-2">
          ТЗ не заполнено. Заполняется с панели администратора.
        </div>
      )}
    </div>
  );
}

export default function InfoClients() {
  const { data: clients = [], isLoading } = useQuery<Client[]>({
    queryKey: ["/api/clients"],
    queryFn: () => fetchJson("/api/clients"),
  });

  const inWork = clients.filter(c => c.status === "in_work");
  const others = clients.filter(c => c.status !== "in_work");

  return (
    <div className="space-y-5">
      <div>
        <h1 className="text-xl font-bold text-[--admin-text]">Клиенты</h1>
        <p className="text-sm text-[--admin-muted] mt-0.5">Техническое задание по каждому клиенту</p>
      </div>

      {isLoading && (
        <div className="text-center text-[--admin-muted] py-12 text-sm">Загрузка...</div>
      )}

      {!isLoading && clients.length === 0 && (
        <div className="text-center py-16 text-[--admin-muted]">
          <Users size={40} className="mx-auto mb-3 opacity-30" />
          <p className="text-sm font-medium">Нет клиентов</p>
          <p className="text-xs mt-1 opacity-60">Клиенты добавляются с панели администратора</p>
        </div>
      )}

      {inWork.length > 0 && (
        <div className="space-y-3">
          <h2 className="text-xs font-semibold text-[--admin-muted] uppercase tracking-wide">В работе</h2>
          {inWork.map(c => <ClientCard key={c.id} client={c} />)}
        </div>
      )}

      {others.length > 0 && (
        <div className="space-y-3">
          <h2 className="text-xs font-semibold text-[--admin-muted] uppercase tracking-wide">Остальные</h2>
          {others.map(c => <ClientCard key={c.id} client={c} />)}
        </div>
      )}
    </div>
  );
}
