import { Megaphone, Plus, TrendingUp, Users, MousePointerClick } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";

const campaigns = [
  { name: "Spring Review Drive", status: "active", reach: 1240, clicks: 340, conversion: "27.4%" },
  { name: "VIP Client Outreach", status: "active", reach: 580, clicks: 210, conversion: "36.2%" },
  { name: "Q1 Feedback Push", status: "completed", reach: 2100, clicks: 890, conversion: "42.4%" },
  { name: "New Year Promo", status: "draft", reach: 0, clicks: 0, conversion: "—" },
];

const statusStyle: Record<string, string> = {
  active: "bg-green-100 text-green-700 dark:bg-green-900/40 dark:text-green-400",
  completed: "bg-blue-100 text-blue-700 dark:bg-blue-900/40 dark:text-blue-400",
  draft: "bg-yellow-100 text-yellow-700 dark:bg-yellow-900/40 dark:text-yellow-400",
};

export default function Campaign() {
  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-[--admin-text]">Campaign</h1>
          <p className="text-[--admin-muted] text-sm mt-1">Manage marketing campaigns and outreach</p>
        </div>
        <Button data-testid="btn-add-campaign" className="admin-btn-primary">
          <Plus size={16} className="mr-1.5" /> New Campaign
        </Button>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        {[
          { icon: Megaphone, label: "Active Campaigns", value: campaigns.filter(c => c.status === "active").length },
          { icon: Users, label: "Total Reach", value: campaigns.reduce((s, c) => s + c.reach, 0).toLocaleString() },
          { icon: MousePointerClick, label: "Total Clicks", value: campaigns.reduce((s, c) => s + c.clicks, 0).toLocaleString() },
        ].map(({ icon: Icon, label, value }) => (
          <div key={label} className="bg-[--admin-card] rounded-xl border border-[--admin-border] p-5 flex items-start gap-4">
            <div className="w-11 h-11 rounded-xl bg-[--admin-accent]/10 flex items-center justify-center shrink-0">
              <Icon size={20} className="text-[--admin-accent]" />
            </div>
            <div>
              <p className="text-[--admin-muted] text-xs uppercase tracking-wide mb-1">{label}</p>
              <p className="text-2xl font-bold text-[--admin-text]">{value}</p>
            </div>
          </div>
        ))}
      </div>

      <div className="bg-[--admin-card] rounded-xl border border-[--admin-border] overflow-hidden">
        <table className="w-full text-sm">
          <thead>
            <tr className="border-b border-[--admin-border]">
              <th className="text-left px-4 py-3 text-[--admin-muted] font-medium">Campaign</th>
              <th className="text-left px-4 py-3 text-[--admin-muted] font-medium">Status</th>
              <th className="text-left px-4 py-3 text-[--admin-muted] font-medium hidden sm:table-cell">Reach</th>
              <th className="text-left px-4 py-3 text-[--admin-muted] font-medium hidden sm:table-cell">Clicks</th>
              <th className="text-left px-4 py-3 text-[--admin-muted] font-medium">Conversion</th>
            </tr>
          </thead>
          <tbody>
            {campaigns.map((c, i) => (
              <tr key={i} data-testid={`row-campaign-${i}`} className="border-b border-[--admin-border] last:border-0 hover:bg-[--admin-hover] transition-colors">
                <td className="px-4 py-3 font-medium text-[--admin-text]">{c.name}</td>
                <td className="px-4 py-3">
                  <span className={`inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium capitalize ${statusStyle[c.status]}`}>
                    {c.status}
                  </span>
                </td>
                <td className="px-4 py-3 text-[--admin-muted] hidden sm:table-cell">{c.reach.toLocaleString()}</td>
                <td className="px-4 py-3 text-[--admin-muted] hidden sm:table-cell">{c.clicks.toLocaleString()}</td>
                <td className="px-4 py-3 font-semibold text-[--admin-text]">{c.conversion}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      <div className="bg-[--admin-card] rounded-xl border border-[--admin-border] p-5">
        <p className="text-[--admin-muted] text-sm text-center">
          Campaign management with real data integration coming soon. Currently showing sample data.
        </p>
      </div>
    </div>
  );
}
