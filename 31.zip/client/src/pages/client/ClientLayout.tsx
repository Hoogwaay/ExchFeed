import { useLocation } from "wouter";
import { useEffect } from "react";

const C = "#c9ff47";
const BG = "#050505";
const SIDEBAR_BG = "rgba(10,10,10,0.95)";
const BORDER = "rgba(255,255,255,0.08)";

const NAV_ITEMS = [
  { path: "/cabinet", label: "Обзор", icon: "⬡" },
];

export default function ClientLayout({ children }: { children: React.ReactNode }) {
  const [location, navigate] = useLocation();

  useEffect(() => {
    const token = localStorage.getItem("client_token");
    if (!token) navigate("/");
  }, [navigate]);

  const handleLogout = () => {
    localStorage.removeItem("client_token");
    localStorage.removeItem("client_id");
    navigate("/");
  };

  return (
    <div style={{ display: "flex", minHeight: "100vh", background: BG, color: "#fff", fontFamily: "'Inter', sans-serif" }}>
      <style>{`
        * { box-sizing: border-box; }
        ::-webkit-scrollbar { width: 4px; }
        ::-webkit-scrollbar-track { background: transparent; }
        ::-webkit-scrollbar-thumb { background: rgba(255,255,255,0.1); border-radius: 2px; }
      `}</style>

      <aside style={{
        width: 240, flexShrink: 0,
        background: SIDEBAR_BG,
        borderRight: `1px solid ${BORDER}`,
        backdropFilter: "blur(20px)",
        display: "flex", flexDirection: "column",
        position: "fixed", top: 0, left: 0, bottom: 0, zIndex: 100,
      }}>
        <div style={{ padding: "24px 24px 20px", borderBottom: `1px solid ${BORDER}` }}>
          <div style={{ fontFamily: "monospace", fontSize: "0.6rem", letterSpacing: 4, color: C, textTransform: "uppercase", marginBottom: 6 }}>
            Личный кабинет
          </div>
          <div style={{ fontWeight: 800, fontSize: "1rem", letterSpacing: -0.5, color: "#fff" }}>Exchange Feed</div>
        </div>

        <nav style={{ flex: 1, padding: "16px 12px" }}>
          {NAV_ITEMS.map((item) => {
            const isActive = location === item.path || location.startsWith(item.path + "/");
            return (
              <button
                key={item.path}
                onClick={() => navigate(item.path)}
                style={{
                  display: "flex", alignItems: "center", gap: 12,
                  width: "100%", padding: "10px 12px", marginBottom: 4,
                  background: isActive ? "rgba(201,255,71,0.06)" : "transparent",
                  border: isActive ? `1px solid rgba(201,255,71,0.15)` : "1px solid transparent",
                  borderRadius: 6, cursor: "pointer",
                  color: isActive ? "#fff" : "rgba(255,255,255,0.5)",
                  fontSize: "0.875rem", fontWeight: isActive ? 600 : 400,
                  transition: "all 0.15s", textAlign: "left",
                }}
              >
                <span style={{ color: isActive ? C : "inherit", fontSize: "1rem", fontFamily: "monospace" }}>{item.icon}</span>
                {item.label}
                {isActive && <span style={{ marginLeft: "auto", width: 4, height: 4, borderRadius: "50%", background: C }} />}
              </button>
            );
          })}
        </nav>

        <div style={{ padding: "16px 12px", borderTop: `1px solid ${BORDER}` }}>
          <button
            onClick={handleLogout}
            style={{
              display: "flex", alignItems: "center", gap: 12,
              width: "100%", padding: "10px 12px",
              background: "transparent", border: "1px solid transparent",
              borderRadius: 6, cursor: "pointer", color: "rgba(255,100,100,0.8)",
              fontSize: "0.875rem", fontWeight: 500, transition: "all 0.15s", textAlign: "left",
            }}
            onMouseOver={(e) => { e.currentTarget.style.background = "rgba(255,68,68,0.08)"; e.currentTarget.style.borderColor = "rgba(255,68,68,0.2)"; }}
            onMouseOut={(e) => { e.currentTarget.style.background = "transparent"; e.currentTarget.style.borderColor = "transparent"; }}
          >
            <span style={{ fontSize: "1rem" }}>⊘</span>
            Выйти
          </button>
        </div>
      </aside>

      <main style={{ flex: 1, marginLeft: 240, minHeight: "100vh", overflow: "auto" }}>
        {children}
      </main>
    </div>
  );
}
