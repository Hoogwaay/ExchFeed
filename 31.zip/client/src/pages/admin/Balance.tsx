import { useQuery, useMutation } from "@tanstack/react-query";
import { useState } from "react";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { type Transaction, type InsertTransaction } from "@shared/schema";
import { z } from "zod";
import { Plus, Pencil, Trash2, ArrowUpRight, ArrowDownLeft, TrendingUp, TrendingDown, DollarSign } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Form, FormField, FormItem, FormLabel, FormControl, FormMessage } from "@/components/ui/form";

const formSchema = z.object({
  type: z.enum(["income", "expense"]),
  amount: z.coerce.number().min(0.01, "Amount must be positive"),
  description: z.string().optional(),
  date: z.string(),
});

type FormValues = z.infer<typeof formSchema>;

function TransactionForm({
  defaultValues,
  onSubmit,
  isPending,
}: {
  defaultValues: Partial<FormValues>;
  onSubmit: (data: InsertTransaction) => void;
  isPending: boolean;
}) {
  const form = useForm<FormValues>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      type: "income",
      amount: 0,
      description: "",
      date: new Date().toISOString().split("T")[0],
      ...defaultValues,
    },
  });

  return (
    <Form {...form}>
      <form onSubmit={form.handleSubmit(data => onSubmit({
        type: data.type,
        amount: String(data.amount),
        description: data.description,
        date: data.date ? new Date(data.date) : new Date(),
      }))} className="space-y-4">
        <FormField control={form.control} name="type" render={({ field }) => (
          <FormItem>
            <FormLabel>Type *</FormLabel>
            <Select onValueChange={field.onChange} defaultValue={field.value}>
              <FormControl>
                <SelectTrigger data-testid="select-tx-type" className="admin-select">
                  <SelectValue placeholder="Select type" />
                </SelectTrigger>
              </FormControl>
              <SelectContent>
                <SelectItem value="income">Income</SelectItem>
                <SelectItem value="expense">Expense</SelectItem>
              </SelectContent>
            </Select>
            <FormMessage />
          </FormItem>
        )} />
        <FormField control={form.control} name="amount" render={({ field }) => (
          <FormItem>
            <FormLabel>Amount ($) *</FormLabel>
            <FormControl><Input data-testid="input-tx-amount" type="number" min={0.01} step="0.01" {...field} className="admin-input" /></FormControl>
            <FormMessage />
          </FormItem>
        )} />
        <FormField control={form.control} name="description" render={({ field }) => (
          <FormItem>
            <FormLabel>Description</FormLabel>
            <FormControl><Input data-testid="input-tx-description" placeholder="Payment description..." {...field} value={field.value ?? ""} className="admin-input" /></FormControl>
            <FormMessage />
          </FormItem>
        )} />
        <FormField control={form.control} name="date" render={({ field }) => (
          <FormItem>
            <FormLabel>Date</FormLabel>
            <FormControl>
              <Input
                data-testid="input-tx-date"
                type="date"
                value={field.value ? new Date(field.value).toISOString().split("T")[0] : ""}
                onChange={e => field.onChange(e.target.value ? new Date(e.target.value).toISOString() : new Date().toISOString())}
                className="admin-input"
              />
            </FormControl>
            <FormMessage />
          </FormItem>
        )} />
        <DialogFooter>
          <Button data-testid="btn-submit-tx" type="submit" disabled={isPending} className="admin-btn-primary">
            {isPending ? "Saving…" : "Save"}
          </Button>
        </DialogFooter>
      </form>
    </Form>
  );
}

export default function Balance() {
  const { toast } = useToast();
  const [dialogOpen, setDialogOpen] = useState(false);
  const [editingTx, setEditingTx] = useState<Transaction | null>(null);
  const [deleteTarget, setDeleteTarget] = useState<Transaction | null>(null);
  const [typeFilter, setTypeFilter] = useState<string>("all");

  const { data: transactions = [], isLoading } = useQuery<Transaction[]>({ queryKey: ["/api/transactions"] });

  const createMutation = useMutation({
    mutationFn: (data: InsertTransaction) => apiRequest("POST", "/api/transactions", data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/transactions"] });
      toast({ title: "Transaction added" });
      setDialogOpen(false);
    },
    onError: () => toast({ title: "Failed to add transaction", variant: "destructive" }),
  });

  const updateMutation = useMutation({
    mutationFn: ({ id, data }: { id: string; data: Partial<InsertTransaction> }) =>
      apiRequest("PATCH", `/api/transactions/${id}`, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/transactions"] });
      toast({ title: "Transaction updated" });
      setDialogOpen(false);
      setEditingTx(null);
    },
    onError: () => toast({ title: "Failed to update transaction", variant: "destructive" }),
  });

  const deleteMutation = useMutation({
    mutationFn: (id: string) => apiRequest("DELETE", `/api/transactions/${id}`),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/transactions"] });
      toast({ title: "Transaction deleted" });
      setDeleteTarget(null);
    },
    onError: () => toast({ title: "Failed to delete transaction", variant: "destructive" }),
  });

  const totalIncome = transactions.filter(t => t.type === "income").reduce((s, t) => s + parseFloat(t.amount), 0);
  const totalExpense = transactions.filter(t => t.type === "expense").reduce((s, t) => s + parseFloat(t.amount), 0);
  const balance = totalIncome - totalExpense;

  const filtered = transactions.filter(t => typeFilter === "all" || t.type === typeFilter);

  const openAdd = () => { setEditingTx(null); setDialogOpen(true); };
  const openEdit = (t: Transaction) => { setEditingTx(t); setDialogOpen(true); };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-admin-text">Balance</h1>
          <p className="text-admin-muted text-sm mt-1">Track income and expenses</p>
        </div>
        <Button data-testid="btn-add-tx" onClick={openAdd} className="admin-btn-primary">
          <Plus size={16} className="mr-1.5" /> Add Transaction
        </Button>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        <div className="admin-card p-5 flex items-start gap-4">
          <div className="w-11 h-11 rounded-xl bg-green-100 dark:bg-green-900/30 flex items-center justify-center">
            <TrendingUp size={20} className="text-green-600 dark:text-green-400" />
          </div>
          <div>
            <p className="text-admin-muted text-xs uppercase tracking-wide mb-1">Total Income</p>
            <p className="text-2xl font-bold text-admin-text">${totalIncome.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</p>
          </div>
        </div>
        <div className="admin-card p-5 flex items-start gap-4">
          <div className="w-11 h-11 rounded-xl bg-red-100 dark:bg-red-900/30 flex items-center justify-center">
            <TrendingDown size={20} className="text-red-600 dark:text-red-400" />
          </div>
          <div>
            <p className="text-admin-muted text-xs uppercase tracking-wide mb-1">Total Expenses</p>
            <p className="text-2xl font-bold text-admin-text">${totalExpense.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</p>
          </div>
        </div>
        <div className="admin-card p-5 flex items-start gap-4">
          <div className={`w-11 h-11 rounded-xl flex items-center justify-center ${balance >= 0 ? "bg-admin-accent/10" : "bg-red-100 dark:bg-red-900/30"}`}>
            <DollarSign size={20} className={balance >= 0 ? "text-admin-accent" : "text-red-600 dark:text-red-400"} />
          </div>
          <div>
            <p className="text-admin-muted text-xs uppercase tracking-wide mb-1">Net Balance</p>
            <p className={`text-2xl font-bold ${balance >= 0 ? "text-admin-text" : "text-red-600 dark:text-red-400"}`}>
              {balance >= 0 ? "" : "-"}${Math.abs(balance).toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
            </p>
          </div>
        </div>
      </div>

      <div className="flex items-center gap-3">
        <Select value={typeFilter} onValueChange={setTypeFilter}>
          <SelectTrigger data-testid="select-filter-tx-type" className="w-40 admin-select">
            <SelectValue placeholder="All types" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Types</SelectItem>
            <SelectItem value="income">Income</SelectItem>
            <SelectItem value="expense">Expense</SelectItem>
          </SelectContent>
        </Select>
      </div>

      <div className="admin-card overflow-hidden">
        {isLoading ? (
          <div className="p-8 text-center text-admin-muted text-sm">Loading…</div>
        ) : filtered.length === 0 ? (
          <div className="p-8 text-center text-admin-muted text-sm">No transactions yet</div>
        ) : (
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-admin-border">
                <th className="text-left px-4 py-3 text-admin-muted font-medium">Date</th>
                <th className="text-left px-4 py-3 text-admin-muted font-medium">Type</th>
                <th className="text-left px-4 py-3 text-admin-muted font-medium hidden sm:table-cell">Description</th>
                <th className="text-right px-4 py-3 text-admin-muted font-medium">Amount</th>
                <th className="text-right px-4 py-3 text-admin-muted font-medium">Actions</th>
              </tr>
            </thead>
            <tbody>
              {filtered.map(tx => (
                <tr key={tx.id} data-testid={`row-tx-${tx.id}`}
                  className="border-b border-admin-border last:border-0 hover:bg-admin-hover transition-colors">
                  <td className="px-4 py-3 text-admin-muted">{new Date(tx.date).toLocaleDateString()}</td>
                  <td className="px-4 py-3">
                    <span className={`inline-flex items-center gap-1.5 px-2 py-0.5 rounded-full text-xs font-medium
                      ${tx.type === "income"
                        ? "bg-green-100 text-green-700 dark:bg-green-900/40 dark:text-green-400"
                        : "bg-red-100 text-red-700 dark:bg-red-900/40 dark:text-red-400"}`}>
                      {tx.type === "income"
                        ? <ArrowUpRight size={11} />
                        : <ArrowDownLeft size={11} />}
                      {tx.type === "income" ? "Income" : "Expense"}
                    </span>
                  </td>
                  <td className="px-4 py-3 text-admin-muted hidden sm:table-cell">{tx.description || "—"}</td>
                  <td className={`px-4 py-3 font-semibold text-right ${tx.type === "income" ? "text-green-600 dark:text-green-400" : "text-red-600 dark:text-red-400"}`}>
                    {tx.type === "income" ? "+" : "-"}${parseFloat(tx.amount).toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                  </td>
                  <td className="px-4 py-3">
                    <div className="flex items-center justify-end gap-1">
                      <button
                        data-testid={`btn-edit-tx-${tx.id}`}
                        onClick={() => openEdit(tx)}
                        className="p-1.5 rounded-md text-admin-muted hover:text-admin-text hover:bg-admin-hover transition-colors"
                      >
                        <Pencil size={14} />
                      </button>
                      <button
                        data-testid={`btn-delete-tx-${tx.id}`}
                        onClick={() => setDeleteTarget(tx)}
                        className="p-1.5 rounded-md text-admin-muted hover:text-red-500 hover:bg-red-50 dark:hover:bg-red-900/20 transition-colors"
                      >
                        <Trash2 size={14} />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>

      <Dialog open={dialogOpen} onOpenChange={o => { setDialogOpen(o); if (!o) setEditingTx(null); }}>
        <DialogContent className="admin-dialog">
          <DialogHeader>
            <DialogTitle className="text-admin-text">{editingTx ? "Edit Transaction" : "Add Transaction"}</DialogTitle>
          </DialogHeader>
          <TransactionForm
            defaultValues={editingTx ? {
              type: editingTx.type,
              amount: parseFloat(editingTx.amount),
              description: editingTx.description ?? "",
              date: new Date(editingTx.date).toISOString().split("T")[0],
            } : {}}
            onSubmit={data => {
              if (editingTx) {
                updateMutation.mutate({ id: editingTx.id, data });
              } else {
                createMutation.mutate(data);
              }
            }}
            isPending={createMutation.isPending || updateMutation.isPending}
          />
        </DialogContent>
      </Dialog>

      <Dialog open={!!deleteTarget} onOpenChange={o => { if (!o) setDeleteTarget(null); }}>
        <DialogContent className="admin-dialog">
          <DialogHeader>
            <DialogTitle className="text-admin-text">Delete Transaction</DialogTitle>
          </DialogHeader>
          <p className="text-admin-muted text-sm">Are you sure you want to delete this transaction?</p>
          <DialogFooter className="gap-2">
            <Button variant="outline" onClick={() => setDeleteTarget(null)} className="admin-btn-outline">Cancel</Button>
            <Button
              data-testid="btn-confirm-delete-tx"
              onClick={() => deleteTarget && deleteMutation.mutate(deleteTarget.id)}
              disabled={deleteMutation.isPending}
              className="bg-red-600 hover:bg-red-700 text-white"
            >
              {deleteMutation.isPending ? "Deleting…" : "Delete"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
