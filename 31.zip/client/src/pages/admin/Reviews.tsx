import { useQuery, useMutation } from "@tanstack/react-query";
import { useState } from "react";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { type Review, type InsertReview, type Client } from "@shared/schema";
import { z } from "zod";
import { Plus, Pencil, Trash2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Form, FormField, FormItem, FormLabel, FormControl, FormMessage } from "@/components/ui/form";

const formSchema = z.object({
  clientId: z.string().nullable().optional(),
  count: z.coerce.number().int().min(1, "Must be at least 1"),
  earnedAmount: z.coerce.number().min(0),
  date: z.string(),
  notes: z.string().nullable().optional(),
});

type FormValues = z.infer<typeof formSchema>;

function ReviewForm({
  defaultValues,
  clients,
  onSubmit,
  isPending,
}: {
  defaultValues: Partial<FormValues>;
  clients: Client[];
  onSubmit: (data: InsertReview) => void;
  isPending: boolean;
}) {
  const form = useForm<FormValues>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      count: 1,
      earnedAmount: 0,
      notes: "",
      clientId: null,
      date: new Date().toISOString().split("T")[0],
      ...defaultValues,
    },
  });

  return (
    <Form {...form}>
      <form onSubmit={form.handleSubmit(data => onSubmit({
        count: data.count,
        earnedAmount: String(data.earnedAmount),
        clientId: data.clientId === "none" ? null : data.clientId,
        date: data.date ? new Date(data.date) : new Date(),
        notes: data.notes,
      }))} className="space-y-4">
        <FormField control={form.control} name="clientId" render={({ field }) => (
          <FormItem>
            <FormLabel>Client (optional)</FormLabel>
            <Select onValueChange={field.onChange} defaultValue={field.value ?? undefined}>
              <FormControl>
                <SelectTrigger data-testid="select-review-client" className="admin-select">
                  <SelectValue placeholder="Select client" />
                </SelectTrigger>
              </FormControl>
              <SelectContent>
                <SelectItem value="none">No client</SelectItem>
                {clients.map(c => (
                  <SelectItem key={c.id} value={c.id}>{c.name}</SelectItem>
                ))}
              </SelectContent>
            </Select>
            <FormMessage />
          </FormItem>
        )} />
        <div className="grid grid-cols-2 gap-3">
          <FormField control={form.control} name="count" render={({ field }) => (
            <FormItem>
              <FormLabel>Number of Reviews *</FormLabel>
              <FormControl><Input data-testid="input-review-count" type="number" min={1} {...field} className="admin-input" /></FormControl>
              <FormMessage />
            </FormItem>
          )} />
          <FormField control={form.control} name="earnedAmount" render={({ field }) => (
            <FormItem>
              <FormLabel>Amount Earned ($)</FormLabel>
              <FormControl><Input data-testid="input-review-amount" type="number" min={0} step="0.01" {...field} className="admin-input" /></FormControl>
              <FormMessage />
            </FormItem>
          )} />
        </div>
        <FormField control={form.control} name="date" render={({ field }) => (
          <FormItem>
            <FormLabel>Date</FormLabel>
            <FormControl>
              <Input
                data-testid="input-review-date"
                type="date"
                value={field.value ? new Date(field.value).toISOString().split("T")[0] : ""}
                onChange={e => field.onChange(e.target.value ? new Date(e.target.value).toISOString() : new Date().toISOString())}
                className="admin-input"
              />
            </FormControl>
            <FormMessage />
          </FormItem>
        )} />
        <FormField control={form.control} name="notes" render={({ field }) => (
          <FormItem>
            <FormLabel>Notes</FormLabel>
            <FormControl>
              <textarea
                data-testid="input-review-notes"
                placeholder="Notes..."
                {...field}
                value={field.value ?? ""}
                className="admin-input w-full min-h-[80px] resize-none rounded-md border border-admin-border bg-admin-input px-3 py-2 text-sm text-admin-text placeholder:text-admin-muted focus:outline-none focus:ring-2 focus:ring-admin-accent"
              />
            </FormControl>
            <FormMessage />
          </FormItem>
        )} />
        <DialogFooter>
          <Button data-testid="btn-submit-review" type="submit" disabled={isPending} className="admin-btn-primary">
            {isPending ? "Saving…" : "Save"}
          </Button>
        </DialogFooter>
      </form>
    </Form>
  );
}

export default function Reviews() {
  const { toast } = useToast();
  const [dialogOpen, setDialogOpen] = useState(false);
  const [editingReview, setEditingReview] = useState<Review | null>(null);
  const [deleteTarget, setDeleteTarget] = useState<Review | null>(null);

  const { data: reviews = [], isLoading } = useQuery<Review[]>({ queryKey: ["/api/reviews"] });
  const { data: clients = [] } = useQuery<Client[]>({ queryKey: ["/api/clients"] });

  const clientMap = Object.fromEntries(clients.map(c => [c.id, c.name]));

  const createMutation = useMutation({
    mutationFn: (data: InsertReview) => apiRequest("POST", "/api/reviews", data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/reviews"] });
      queryClient.invalidateQueries({ queryKey: ["/api/reviews/stats"] });
      toast({ title: "Review added" });
      setDialogOpen(false);
    },
    onError: () => toast({ title: "Failed to add review", variant: "destructive" }),
  });

  const updateMutation = useMutation({
    mutationFn: ({ id, data }: { id: string; data: Partial<InsertReview> }) =>
      apiRequest("PATCH", `/api/reviews/${id}`, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/reviews"] });
      queryClient.invalidateQueries({ queryKey: ["/api/reviews/stats"] });
      toast({ title: "Review updated" });
      setDialogOpen(false);
      setEditingReview(null);
    },
    onError: () => toast({ title: "Failed to update review", variant: "destructive" }),
  });

  const deleteMutation = useMutation({
    mutationFn: (id: string) => apiRequest("DELETE", `/api/reviews/${id}`),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/reviews"] });
      queryClient.invalidateQueries({ queryKey: ["/api/reviews/stats"] });
      toast({ title: "Review deleted" });
      setDeleteTarget(null);
    },
    onError: () => toast({ title: "Failed to delete review", variant: "destructive" }),
  });

  const openAdd = () => { setEditingReview(null); setDialogOpen(true); };
  const openEdit = (r: Review) => { setEditingReview(r); setDialogOpen(true); };

  const totalReviews = reviews.reduce((s, r) => s + r.count, 0);
  const totalEarned = reviews.reduce((s, r) => s + parseFloat(r.earnedAmount || "0"), 0);

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-admin-text">Reviews</h1>
          <p className="text-admin-muted text-sm mt-1">Track reviews and earnings</p>
        </div>
        <Button data-testid="btn-add-review" onClick={openAdd} className="admin-btn-primary">
          <Plus size={16} className="mr-1.5" /> Add Review
        </Button>
      </div>

      <div className="grid grid-cols-2 gap-4">
        <div className="admin-card p-4">
          <p className="text-admin-muted text-xs uppercase tracking-wide mb-1">Total Reviews</p>
          <p className="text-2xl font-bold text-admin-text">{totalReviews}</p>
        </div>
        <div className="admin-card p-4">
          <p className="text-admin-muted text-xs uppercase tracking-wide mb-1">Total Earned</p>
          <p className="text-2xl font-bold text-admin-text">${totalEarned.toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}</p>
        </div>
      </div>

      <div className="admin-card overflow-hidden">
        {isLoading ? (
          <div className="p-8 text-center text-admin-muted text-sm">Loading…</div>
        ) : reviews.length === 0 ? (
          <div className="p-8 text-center text-admin-muted text-sm">No reviews yet. Add your first one!</div>
        ) : (
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-admin-border">
                <th className="text-left px-4 py-3 text-admin-muted font-medium">Date</th>
                <th className="text-left px-4 py-3 text-admin-muted font-medium hidden sm:table-cell">Client</th>
                <th className="text-left px-4 py-3 text-admin-muted font-medium">Count</th>
                <th className="text-left px-4 py-3 text-admin-muted font-medium">Earned</th>
                <th className="text-left px-4 py-3 text-admin-muted font-medium hidden lg:table-cell">Notes</th>
                <th className="text-right px-4 py-3 text-admin-muted font-medium">Actions</th>
              </tr>
            </thead>
            <tbody>
              {reviews.map(r => (
                <tr key={r.id} data-testid={`row-review-${r.id}`}
                  className="border-b border-admin-border last:border-0 hover:bg-admin-hover transition-colors">
                  <td className="px-4 py-3 text-admin-text">{new Date(r.date).toLocaleDateString()}</td>
                  <td className="px-4 py-3 text-admin-muted hidden sm:table-cell">
                    {r.clientId ? clientMap[r.clientId] || "Unknown" : "—"}
                  </td>
                  <td className="px-4 py-3 font-semibold text-admin-text">{r.count}</td>
                  <td className="px-4 py-3 text-green-600 dark:text-green-400 font-medium">
                    ${parseFloat(r.earnedAmount).toLocaleString(undefined, { minimumFractionDigits: 2, maximumFractionDigits: 2 })}
                  </td>
                  <td className="px-4 py-3 text-admin-muted hidden lg:table-cell max-w-[200px] truncate">{r.notes || "—"}</td>
                  <td className="px-4 py-3">
                    <div className="flex items-center justify-end gap-1">
                      <button
                        data-testid={`btn-edit-review-${r.id}`}
                        onClick={() => openEdit(r)}
                        className="p-1.5 rounded-md text-admin-muted hover:text-admin-text hover:bg-admin-hover transition-colors"
                      >
                        <Pencil size={14} />
                      </button>
                      <button
                        data-testid={`btn-delete-review-${r.id}`}
                        onClick={() => setDeleteTarget(r)}
                        className="p-1.5 rounded-md text-admin-muted hover:text-red-500 hover:bg-red-50 dark:hover:bg-red-900/20 transition-colors"
                      >
                        <Trash2 size={14} />
                      </button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>

      <Dialog open={dialogOpen} onOpenChange={o => { setDialogOpen(o); if (!o) setEditingReview(null); }}>
        <DialogContent className="admin-dialog">
          <DialogHeader>
            <DialogTitle className="text-admin-text">{editingReview ? "Edit Review" : "Add Review"}</DialogTitle>
          </DialogHeader>
          <ReviewForm
            defaultValues={editingReview ? {
              clientId: editingReview.clientId,
              count: editingReview.count,
              earnedAmount: parseFloat(editingReview.earnedAmount),
              date: new Date(editingReview.date).toISOString().split("T")[0],
              notes: editingReview.notes,
            } : {}}
            clients={clients}
            onSubmit={data => {
              if (editingReview) {
                updateMutation.mutate({ id: editingReview.id, data });
              } else {
                createMutation.mutate(data);
              }
            }}
            isPending={createMutation.isPending || updateMutation.isPending}
          />
        </DialogContent>
      </Dialog>

      <Dialog open={!!deleteTarget} onOpenChange={o => { if (!o) setDeleteTarget(null); }}>
        <DialogContent className="admin-dialog">
          <DialogHeader>
            <DialogTitle className="text-admin-text">Delete Review</DialogTitle>
          </DialogHeader>
          <p className="text-admin-muted text-sm">Are you sure you want to delete this review entry?</p>
          <DialogFooter className="gap-2">
            <Button variant="outline" onClick={() => setDeleteTarget(null)} className="admin-btn-outline">Cancel</Button>
            <Button
              data-testid="btn-confirm-delete-review"
              onClick={() => deleteTarget && deleteMutation.mutate(deleteTarget.id)}
              disabled={deleteMutation.isPending}
              className="bg-red-600 hover:bg-red-700 text-white"
            >
              {deleteMutation.isPending ? "Deleting…" : "Delete"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
