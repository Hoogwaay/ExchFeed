import { useState } from "react";
import { Plus, Pencil, Trash2, Search } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { useToast } from "@/hooks/use-toast";

interface Employee {
  id: number;
  name: string;
  role: string;
  department: string;
  status: "active" | "inactive";
}

const SAMPLE: Employee[] = [
  { id: 1, name: "Alex Johnson", role: "Account Manager", department: "Sales", status: "active" },
  { id: 2, name: "Maria Garcia", role: "Review Specialist", department: "Operations", status: "active" },
  { id: 3, name: "David Kim", role: "Support Agent", department: "Support", status: "active" },
  { id: 4, name: "Sara Lee", role: "Campaign Manager", department: "Marketing", status: "inactive" },
];

export default function Employees() {
  const { toast } = useToast();
  const [employees, setEmployees] = useState<Employee[]>(SAMPLE);
  const [search, setSearch] = useState("");
  const [deptFilter, setDeptFilter] = useState("all");
  const [dialogOpen, setDialogOpen] = useState(false);
  const [editing, setEditing] = useState<Employee | null>(null);
  const [form, setForm] = useState({ name: "", role: "", department: "", status: "active" as "active" | "inactive" });
  const [deleteTarget, setDeleteTarget] = useState<Employee | null>(null);

  const filtered = employees.filter(e => {
    const matchSearch = e.name.toLowerCase().includes(search.toLowerCase());
    const matchDept = deptFilter === "all" || e.department === deptFilter;
    return matchSearch && matchDept;
  });

  const departments = Array.from(new Set(employees.map(e => e.department)));

  const openAdd = () => {
    setEditing(null);
    setForm({ name: "", role: "", department: "", status: "active" });
    setDialogOpen(true);
  };

  const openEdit = (e: Employee) => {
    setEditing(e);
    setForm({ name: e.name, role: e.role, department: e.department, status: e.status });
    setDialogOpen(true);
  };

  const handleSubmit = () => {
    if (!form.name.trim()) return toast({ title: "Name is required", variant: "destructive" });
    if (editing) {
      setEmployees(prev => prev.map(e => e.id === editing.id ? { ...e, ...form } : e));
      toast({ title: "Employee updated" });
    } else {
      setEmployees(prev => [...prev, { ...form, id: Date.now() }]);
      toast({ title: "Employee added" });
    }
    setDialogOpen(false);
  };

  const handleDelete = () => {
    if (!deleteTarget) return;
    setEmployees(prev => prev.filter(e => e.id !== deleteTarget.id));
    toast({ title: "Employee removed" });
    setDeleteTarget(null);
  };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-admin-text">Employees</h1>
          <p className="text-admin-muted text-sm mt-1">Manage your team members</p>
        </div>
        <Button data-testid="btn-add-employee" onClick={openAdd} className="admin-btn-primary">
          <Plus size={16} className="mr-1.5" /> Add Employee
        </Button>
      </div>

      <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
        {[
          { label: "Total", value: employees.length },
          { label: "Active", value: employees.filter(e => e.status === "active").length },
          { label: "Inactive", value: employees.filter(e => e.status === "inactive").length },
          { label: "Departments", value: departments.length },
        ].map(({ label, value }) => (
          <div key={label} className="admin-card p-4">
            <p className="text-admin-muted text-xs uppercase tracking-wide mb-1">{label}</p>
            <p className="text-xl font-bold text-admin-text">{value}</p>
          </div>
        ))}
      </div>

      <div className="flex flex-col sm:flex-row gap-3">
        <div className="relative flex-1">
          <Search size={15} className="absolute left-3 top-1/2 -translate-y-1/2 text-admin-muted" />
          <Input data-testid="input-search-employees" placeholder="Search by name..." value={search} onChange={e => setSearch(e.target.value)} className="pl-9 admin-input" />
        </div>
        <Select value={deptFilter} onValueChange={setDeptFilter}>
          <SelectTrigger data-testid="select-filter-dept" className="w-44 admin-select">
            <SelectValue placeholder="All departments" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Departments</SelectItem>
            {departments.map(d => <SelectItem key={d} value={d}>{d}</SelectItem>)}
          </SelectContent>
        </Select>
      </div>

      <div className="admin-card overflow-hidden">
        {filtered.length === 0 ? (
          <div className="p-8 text-center text-admin-muted text-sm">No employees found</div>
        ) : (
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-admin-border">
                <th className="text-left px-4 py-3 text-admin-muted font-medium">Name</th>
                <th className="text-left px-4 py-3 text-admin-muted font-medium hidden sm:table-cell">Role</th>
                <th className="text-left px-4 py-3 text-admin-muted font-medium hidden md:table-cell">Department</th>
                <th className="text-left px-4 py-3 text-admin-muted font-medium">Status</th>
                <th className="text-right px-4 py-3 text-admin-muted font-medium">Actions</th>
              </tr>
            </thead>
            <tbody>
              {filtered.map(e => (
                <tr key={e.id} data-testid={`row-employee-${e.id}`} className="border-b border-admin-border last:border-0 hover:bg-admin-hover transition-colors">
                  <td className="px-4 py-3 font-medium text-admin-text">{e.name}</td>
                  <td className="px-4 py-3 text-admin-muted hidden sm:table-cell">{e.role}</td>
                  <td className="px-4 py-3 text-admin-muted hidden md:table-cell">{e.department}</td>
                  <td className="px-4 py-3">
                    <span className={`inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium ${e.status === "active" ? "bg-green-100 text-green-700 dark:bg-green-900/40 dark:text-green-400" : "bg-gray-100 text-gray-600 dark:bg-gray-800 dark:text-gray-400"}`}>
                      {e.status === "active" ? "Active" : "Inactive"}
                    </span>
                  </td>
                  <td className="px-4 py-3">
                    <div className="flex items-center justify-end gap-1">
                      <button data-testid={`btn-edit-employee-${e.id}`} onClick={() => openEdit(e)} className="p-1.5 rounded-md text-admin-muted hover:text-admin-text hover:bg-admin-hover transition-colors"><Pencil size={14} /></button>
                      <button data-testid={`btn-delete-employee-${e.id}`} onClick={() => setDeleteTarget(e)} className="p-1.5 rounded-md text-admin-muted hover:text-red-500 hover:bg-red-50 dark:hover:bg-red-900/20 transition-colors"><Trash2 size={14} /></button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>

      <Dialog open={dialogOpen} onOpenChange={o => { setDialogOpen(o); }}>
        <DialogContent className="admin-dialog">
          <DialogHeader>
            <DialogTitle className="text-admin-text">{editing ? "Edit Employee" : "Add Employee"}</DialogTitle>
          </DialogHeader>
          <div className="space-y-4">
            <div>
              <label className="text-sm font-medium text-admin-text block mb-1.5">Name *</label>
              <Input data-testid="input-employee-name" placeholder="Full name" value={form.name} onChange={e => setForm(f => ({ ...f, name: e.target.value }))} className="admin-input" />
            </div>
            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="text-sm font-medium text-admin-text block mb-1.5">Role</label>
                <Input data-testid="input-employee-role" placeholder="Job title" value={form.role} onChange={e => setForm(f => ({ ...f, role: e.target.value }))} className="admin-input" />
              </div>
              <div>
                <label className="text-sm font-medium text-admin-text block mb-1.5">Department</label>
                <Input data-testid="input-employee-dept" placeholder="Department" value={form.department} onChange={e => setForm(f => ({ ...f, department: e.target.value }))} className="admin-input" />
              </div>
            </div>
            <div>
              <label className="text-sm font-medium text-admin-text block mb-1.5">Status</label>
              <Select value={form.status} onValueChange={v => setForm(f => ({ ...f, status: v as "active" | "inactive" }))}>
                <SelectTrigger data-testid="select-employee-status" className="admin-select"><SelectValue /></SelectTrigger>
                <SelectContent>
                  <SelectItem value="active">Active</SelectItem>
                  <SelectItem value="inactive">Inactive</SelectItem>
                </SelectContent>
              </Select>
            </div>
          </div>
          <DialogFooter className="mt-2">
            <Button data-testid="btn-submit-employee" onClick={handleSubmit} className="admin-btn-primary">
              {editing ? "Update" : "Add Employee"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      <Dialog open={!!deleteTarget} onOpenChange={o => { if (!o) setDeleteTarget(null); }}>
        <DialogContent className="admin-dialog">
          <DialogHeader>
            <DialogTitle className="text-admin-text">Remove Employee</DialogTitle>
          </DialogHeader>
          <p className="text-admin-muted text-sm">Are you sure you want to remove <strong className="text-admin-text">{deleteTarget?.name}</strong>?</p>
          <DialogFooter className="gap-2">
            <Button variant="outline" onClick={() => setDeleteTarget(null)} className="admin-btn-outline">Cancel</Button>
            <Button data-testid="btn-confirm-delete-employee" onClick={handleDelete} className="bg-red-600 hover:bg-red-700 text-white">Remove</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
