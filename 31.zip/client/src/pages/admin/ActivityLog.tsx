import { useQuery } from "@tanstack/react-query";
import { ActivitySquare, Star, Users, DollarSign, Megaphone } from "lucide-react";
import type { Client, Review, Transaction } from "@shared/schema";

interface LogEntry {
  type: "review" | "client" | "transaction" | "campaign";
  message: string;
  date: Date;
  icon: typeof Star;
  color: string;
}

export default function ActivityLog() {
  const { data: clients = [] } = useQuery<Client[]>({ queryKey: ["/api/clients"] });
  const { data: reviews = [] } = useQuery<Review[]>({ queryKey: ["/api/reviews"] });
  const { data: transactions = [] } = useQuery<Transaction[]>({ queryKey: ["/api/transactions"] });

  const entries: LogEntry[] = [
    ...reviews.map(r => ({
      type: "review" as const,
      message: `${r.count} review${r.count !== 1 ? "s" : ""} added${r.earnedAmount !== "0" ? ` · $${parseFloat(r.earnedAmount).toFixed(2)} earned` : ""}${r.notes ? ` · "${r.notes}"` : ""}`,
      date: new Date(r.date),
      icon: Star,
      color: "bg-blue-100 text-blue-600 dark:bg-blue-900/40 dark:text-blue-400",
    })),
    ...clients.map(c => ({
      type: "client" as const,
      message: `Client "${c.name}" added · Status: ${c.status.replace("_", " ")}`,
      date: new Date(c.createdAt),
      icon: Users,
      color: "bg-purple-100 text-purple-600 dark:bg-purple-900/40 dark:text-purple-400",
    })),
    ...transactions.map(t => ({
      type: "transaction" as const,
      message: `${t.type === "income" ? "Income" : "Expense"} of $${parseFloat(t.amount).toFixed(2)}${t.description ? ` · ${t.description}` : ""}`,
      date: new Date(t.date),
      icon: DollarSign,
      color: t.type === "income"
        ? "bg-green-100 text-green-600 dark:bg-green-900/40 dark:text-green-400"
        : "bg-red-100 text-red-600 dark:bg-red-900/40 dark:text-red-400",
    })),
  ].sort((a, b) => b.date.getTime() - a.date.getTime());

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold text-admin-text">Activity Log</h1>
        <p className="text-admin-muted text-sm mt-1">All recent activity across the platform</p>
      </div>

      <div className="admin-card p-5">
        {entries.length === 0 ? (
          <div className="py-12 flex flex-col items-center justify-center gap-3 text-admin-muted">
            <ActivitySquare size={36} className="opacity-30" />
            <p className="text-sm">No activity yet. Start by adding clients, reviews, or transactions.</p>
          </div>
        ) : (
          <div className="relative">
            <div className="absolute left-[22px] top-0 bottom-0 w-px bg-admin-border" />
            <div className="space-y-4">
              {entries.map((entry, i) => {
                const Icon = entry.icon;
                return (
                  <div key={i} data-testid={`activity-entry-${i}`} className="flex items-start gap-4 relative">
                    <div className={`w-11 h-11 rounded-full flex items-center justify-center shrink-0 relative z-10 ${entry.color}`}>
                      <Icon size={16} />
                    </div>
                    <div className="flex-1 min-w-0 pt-2.5">
                      <p className="text-sm text-admin-text">{entry.message}</p>
                      <p className="text-xs text-admin-muted mt-0.5">
                        {entry.date.toLocaleString(undefined, {
                          year: "numeric", month: "short", day: "numeric",
                          hour: "2-digit", minute: "2-digit"
                        })}
                      </p>
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
