import { useQuery } from "@tanstack/react-query";
import { useParams, useLocation } from "wouter";
import { useState } from "react";
import {
  LineChart, Line, XAxis, YAxis, Tooltip, ResponsiveContainer, CartesianGrid,
} from "recharts";
import { ArrowLeft, Star, TrendingUp, Calendar, ExternalLink, Search } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import type { Client } from "@shared/schema";

type Period = "day" | "week" | "month";
type PageSize = "25" | "50" | "100";

interface ClientStatsData {
  client: Client;
  totalAllTime: number;
  totalThisMonth: number;
  byDay: { date: string; count: number }[];
  byWeek: { date: string; count: number }[];
  byMonth: { date: string; count: number }[];
}

interface ReviewsData {
  data: {
    id: string;
    clientId: string;
    reviewDate: string;
    link: string | null;
    email: string | null;
    application: string | null;
    reviewerName: string | null;
  }[];
  total: number;
  page: number;
  limit: number;
}

function StatCard({ icon: Icon, label, value, sub }: {
  icon: typeof Star;
  label: string;
  value: string | number;
  sub?: string;
}) {
  return (
    <div className="admin-card p-5 flex items-start gap-4">
      <div className="w-11 h-11 rounded-xl bg-admin-accent/10 flex items-center justify-center shrink-0">
        <Icon size={20} className="text-admin-accent" />
      </div>
      <div className="min-w-0">
        <p className="text-admin-muted text-xs font-medium uppercase tracking-wide mb-1">{label}</p>
        <p className="text-admin-text text-2xl font-bold">{value}</p>
        {sub && <p className="text-admin-muted text-xs mt-0.5">{sub}</p>}
      </div>
    </div>
  );
}

export default function ClientStats() {
  const { id } = useParams<{ id: string }>();
  const [, navigate] = useLocation();
  const [period, setPeriod] = useState<Period>("month");
  const [page, setPage] = useState(1);
  const [pageSize, setPageSize] = useState<PageSize>("50");
  const [search, setSearch] = useState("");

  const { data: stats, isLoading: statsLoading } = useQuery<ClientStatsData>({
    queryKey: [`/api/clients/${id}/reviews/stats`],
    enabled: !!id,
  });

  const { data: reviews, isLoading: reviewsLoading } = useQuery<ReviewsData>({
    queryKey: [`/api/clients/${id}/reviews`, page, pageSize],
    queryFn: () =>
      fetch(`/api/clients/${id}/reviews?page=${page}&limit=${pageSize}`)
        .then(r => r.json()),
    enabled: !!id,
  });

  const chartData = stats
    ? period === "day" ? stats.byDay.slice(-30)
      : period === "week" ? stats.byWeek.slice(-20)
      : stats.byMonth
    : [];

  const filteredReviews = (reviews?.data ?? []).filter(r => {
    if (!search) return true;
    const q = search.toLowerCase();
    return (
      (r.email?.toLowerCase().includes(q) ?? false) ||
      (r.application?.toLowerCase().includes(q) ?? false) ||
      (r.reviewerName?.toLowerCase().includes(q) ?? false) ||
      (r.reviewDate?.includes(q) ?? false)
    );
  });

  const totalPages = Math.ceil((reviews?.total ?? 0) / parseInt(pageSize));

  return (
    <div className="space-y-6">
      <div className="flex items-center gap-3">
        <Button
          variant="outline"
          size="sm"
          onClick={() => navigate("/admin/customers")}
          className="admin-btn-outline"
        >
          <ArrowLeft size={15} className="mr-1.5" />
          Back
        </Button>
        <div>
          <h1 className="text-2xl font-bold text-admin-text">
            {statsLoading ? "Loading…" : stats?.client.name ?? "Client"}
          </h1>
          <p className="text-admin-muted text-sm mt-0.5">Review statistics</p>
        </div>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-3 gap-4">
        <StatCard
          icon={Star}
          label="Total Reviews (All Time)"
          value={statsLoading ? "…" : stats?.totalAllTime ?? 0}
        />
        <StatCard
          icon={TrendingUp}
          label="Reviews This Month"
          value={statsLoading ? "…" : stats?.totalThisMonth ?? 0}
          sub="Current month"
        />
        <StatCard
          icon={Calendar}
          label="Active Months"
          value={statsLoading ? "…" : stats?.byMonth.length ?? 0}
          sub="Months with activity"
        />
      </div>

      <div className="admin-card p-5">
        <div className="flex items-center justify-between mb-4">
          <h2 className="text-admin-text font-semibold">Reviews Over Time</h2>
          <Select value={period} onValueChange={v => setPeriod(v as Period)}>
            <SelectTrigger className="w-32 h-8 text-xs admin-select">
              <SelectValue />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="day">By Day</SelectItem>
              <SelectItem value="week">By Week</SelectItem>
              <SelectItem value="month">By Month</SelectItem>
            </SelectContent>
          </Select>
        </div>
        {chartData.length === 0 ? (
          <div className="h-48 flex items-center justify-center text-admin-muted text-sm">
            No data available
          </div>
        ) : (
          <ResponsiveContainer width="100%" height={220}>
            <LineChart data={chartData} margin={{ top: 5, right: 0, left: -20, bottom: 0 }}>
              <CartesianGrid strokeDasharray="3 3" stroke="var(--admin-border-color)" />
              <XAxis dataKey="date" tick={{ fontSize: 10, fill: "white" }} />
              <YAxis tick={{ fontSize: 11, fill: "white" }} allowDecimals={false} />
              <Tooltip
                contentStyle={{
                  background: "var(--admin-card-bg)",
                  border: "1px solid var(--admin-border-color)",
                  borderRadius: "8px",
                  color: "white",
                }}
                labelStyle={{ color: "white" }}
              />
              <Line
                type="monotone"
                dataKey="count"
                stroke="#22c55e"
                dot={{ fill: "#22c55e", r: 3 }}
                activeDot={{ r: 5 }}
                strokeWidth={2}
              />
            </LineChart>
          </ResponsiveContainer>
        )}
      </div>

      <div className="admin-card overflow-hidden">
        <div className="p-4 border-b border-admin-border flex flex-col sm:flex-row gap-3 items-start sm:items-center justify-between">
          <h2 className="text-admin-text font-semibold">
            Reviews
            <span className="ml-2 text-sm font-normal text-admin-muted">({reviews?.total ?? 0} total)</span>
          </h2>
          <div className="flex items-center gap-2 flex-1 sm:flex-none">
            <div className="relative flex-1 sm:w-56">
              <Search size={14} className="absolute left-3 top-1/2 -translate-y-1/2 text-admin-muted" />
              <Input
                placeholder="Search…"
                value={search}
                onChange={e => setSearch(e.target.value)}
                className="pl-8 admin-input h-8 text-xs"
              />
            </div>
            <Select value={pageSize} onValueChange={v => { setPageSize(v as PageSize); setPage(1); }}>
              <SelectTrigger className="w-20 h-8 text-xs admin-select">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="25">25</SelectItem>
                <SelectItem value="50">50</SelectItem>
                <SelectItem value="100">100</SelectItem>
              </SelectContent>
            </Select>
          </div>
        </div>

        {reviewsLoading ? (
          <div className="p-8 text-center text-admin-muted text-sm">Loading…</div>
        ) : filteredReviews.length === 0 ? (
          <div className="p-8 text-center text-admin-muted text-sm">No reviews found</div>
        ) : (
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-admin-border">
                  <th className="text-left px-4 py-3 text-admin-muted font-medium">#</th>
                  <th className="text-left px-4 py-3 text-admin-muted font-medium">Date</th>
                  <th className="text-left px-4 py-3 text-admin-muted font-medium">Link</th>
                  <th className="text-left px-4 py-3 text-admin-muted font-medium hidden sm:table-cell">Email</th>
                  <th className="text-left px-4 py-3 text-admin-muted font-medium hidden md:table-cell">Application</th>
                  <th className="text-left px-4 py-3 text-admin-muted font-medium hidden lg:table-cell">Name</th>
                </tr>
              </thead>
              <tbody>
                {filteredReviews.map((r, i) => (
                  <tr key={r.id} className="border-b border-admin-border last:border-0 hover:bg-admin-hover transition-colors">
                    <td className="px-4 py-2.5 text-admin-muted text-xs">
                      {(page - 1) * parseInt(pageSize) + i + 1}
                    </td>
                    <td className="px-4 py-2.5 text-admin-text whitespace-nowrap">{r.reviewDate}</td>
                    <td className="px-4 py-2.5">
                      {r.link ? (
                        <a
                          href={r.link}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="inline-flex items-center gap-1 text-admin-accent hover:underline text-xs max-w-[180px] truncate"
                          title={r.link}
                        >
                          <ExternalLink size={11} />
                          {r.link.replace(/^https?:\/\//, "").split("?")[0].slice(0, 30)}…
                        </a>
                      ) : "—"}
                    </td>
                    <td className="px-4 py-2.5 text-admin-muted hidden sm:table-cell text-xs">{r.email || "—"}</td>
                    <td className="px-4 py-2.5 text-admin-muted hidden md:table-cell text-xs">{r.application || "—"}</td>
                    <td className="px-4 py-2.5 text-admin-text hidden lg:table-cell text-xs">{r.reviewerName || "—"}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}

        {totalPages > 1 && (
          <div className="p-4 border-t border-admin-border flex items-center justify-between">
            <p className="text-xs text-admin-muted">
              Page {page} of {totalPages}
            </p>
            <div className="flex gap-2">
              <Button
                variant="outline"
                size="sm"
                onClick={() => setPage(p => Math.max(1, p - 1))}
                disabled={page <= 1}
                className="admin-btn-outline h-7 text-xs"
              >
                Prev
              </Button>
              <Button
                variant="outline"
                size="sm"
                onClick={() => setPage(p => Math.min(totalPages, p + 1))}
                disabled={page >= totalPages}
                className="admin-btn-outline h-7 text-xs"
              >
                Next
              </Button>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
