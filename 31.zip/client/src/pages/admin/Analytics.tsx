import { useQuery } from "@tanstack/react-query";
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, CartesianGrid, LineChart, Line, PieChart, Pie, Cell, Legend } from "recharts";
import { useState } from "react";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import type { Client, Transaction } from "@shared/schema";

interface Stats {
  totalAllTime: number;
  totalThisMonth: number;
  totalEarned: string;
  byDay: { date: string; count: number }[];
  byWeek: { date: string; count: number }[];
  byMonth: { date: string; count: number }[];
}

const COLORS = ["#2563eb", "#39ff14", "#f59e0b", "#ef4444"];

export default function Analytics() {
  const [period, setPeriod] = useState<"day" | "week" | "month">("month");

  const { data: stats } = useQuery<Stats>({ queryKey: ["/api/reviews/stats"] });
  const { data: clients = [] } = useQuery<Client[]>({ queryKey: ["/api/clients"] });
  const { data: transactions = [] } = useQuery<Transaction[]>({ queryKey: ["/api/transactions"] });

  const chartData = stats
    ? period === "day" ? stats.byDay
      : period === "week" ? stats.byWeek
      : stats.byMonth
    : [];

  const statusData = [
    { name: "In Work", value: clients.filter(c => c.status === "in_work").length },
    { name: "Potential", value: clients.filter(c => c.status === "potential").length },
    { name: "Paused", value: clients.filter(c => c.status === "paused").length },
    { name: "Refused", value: clients.filter(c => c.status === "refused").length },
  ].filter(d => d.value > 0);

  const income = transactions.filter(t => t.type === "income").reduce((s, t) => s + parseFloat(t.amount), 0);
  const expense = transactions.filter(t => t.type === "expense").reduce((s, t) => s + parseFloat(t.amount), 0);

  const financeByMonth: Record<string, { income: number; expense: number }> = {};
  transactions.forEach(t => {
    const m = new Date(t.date).toISOString().substring(0, 7);
    if (!financeByMonth[m]) financeByMonth[m] = { income: 0, expense: 0 };
    financeByMonth[m][t.type] += parseFloat(t.amount);
  });
  const financeData = Object.entries(financeByMonth)
    .sort((a, b) => a[0].localeCompare(b[0]))
    .slice(-12)
    .map(([month, vals]) => ({ month, ...vals }));

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold text-admin-text">Analytics &amp; Reports</h1>
        <p className="text-admin-muted text-sm mt-1">Performance overview and trends</p>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
        {[
          { label: "Total Reviews", value: stats?.totalAllTime ?? 0 },
          { label: "Total Income", value: `$${income.toLocaleString(undefined, { maximumFractionDigits: 2 })}` },
          { label: "Net Balance", value: `$${(income - expense).toLocaleString(undefined, { maximumFractionDigits: 2 })}` },
        ].map(({ label, value }) => (
          <div key={label} className="admin-card p-5">
            <p className="text-admin-muted text-xs uppercase tracking-wide mb-1">{label}</p>
            <p className="text-2xl font-bold text-admin-text">{value}</p>
          </div>
        ))}
      </div>

      <div className="grid grid-cols-1 xl:grid-cols-2 gap-4">
        <div className="admin-card p-5">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-admin-text font-semibold">Reviews Over Time</h2>
            <Select value={period} onValueChange={v => setPeriod(v as "day" | "week" | "month")}>
              <SelectTrigger data-testid="select-analytics-period" className="w-32 h-8 text-xs admin-select">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="day">By Day</SelectItem>
                <SelectItem value="week">By Week</SelectItem>
                <SelectItem value="month">By Month</SelectItem>
              </SelectContent>
            </Select>
          </div>
          {chartData.length === 0 ? (
            <div className="h-48 flex items-center justify-center text-admin-muted text-sm">No data yet</div>
          ) : (
            <ResponsiveContainer width="100%" height={220}>
              <LineChart data={chartData} margin={{ left: -20 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="var(--admin-border-color)" />
                <XAxis dataKey="date" tick={{ fontSize: 11, fill: "var(--admin-muted-color)" }} />
                <YAxis tick={{ fontSize: 11, fill: "var(--admin-muted-color)" }} allowDecimals={false} />
                <Tooltip contentStyle={{ background: "var(--admin-card-bg)", border: "1px solid var(--admin-border-color)", borderRadius: "8px", color: "var(--admin-text-color)" }} />
                <Line type="monotone" dataKey="count" stroke="var(--admin-accent-color)" strokeWidth={2} dot={false} />
              </LineChart>
            </ResponsiveContainer>
          )}
        </div>

        <div className="admin-card p-5">
          <h2 className="text-admin-text font-semibold mb-4">Client Status Distribution</h2>
          {statusData.length === 0 ? (
            <div className="h-48 flex items-center justify-center text-admin-muted text-sm">No clients yet</div>
          ) : (
            <ResponsiveContainer width="100%" height={220}>
              <PieChart>
                <Pie data={statusData} cx="50%" cy="50%" outerRadius={80} dataKey="value" label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`} labelLine={false}>
                  {statusData.map((_, i) => <Cell key={i} fill={COLORS[i % COLORS.length]} />)}
                </Pie>
                <Legend />
                <Tooltip contentStyle={{ background: "var(--admin-card-bg)", border: "1px solid var(--admin-border-color)", borderRadius: "8px", color: "var(--admin-text-color)" }} />
              </PieChart>
            </ResponsiveContainer>
          )}
        </div>
      </div>

      <div className="admin-card p-5">
        <h2 className="text-admin-text font-semibold mb-4">Income vs Expenses by Month</h2>
        {financeData.length === 0 ? (
          <div className="h-48 flex items-center justify-center text-admin-muted text-sm">No financial data yet</div>
        ) : (
          <ResponsiveContainer width="100%" height={220}>
            <BarChart data={financeData} margin={{ left: -20 }}>
              <CartesianGrid strokeDasharray="3 3" stroke="var(--admin-border-color)" />
              <XAxis dataKey="month" tick={{ fontSize: 11, fill: "var(--admin-muted-color)" }} />
              <YAxis tick={{ fontSize: 11, fill: "var(--admin-muted-color)" }} />
              <Tooltip contentStyle={{ background: "var(--admin-card-bg)", border: "1px solid var(--admin-border-color)", borderRadius: "8px", color: "var(--admin-text-color)" }} />
              <Legend />
              <Bar dataKey="income" fill="#22c55e" radius={[4, 4, 0, 0]} name="Income" />
              <Bar dataKey="expense" fill="#ef4444" radius={[4, 4, 0, 0]} name="Expense" />
            </BarChart>
          </ResponsiveContainer>
        )}
      </div>
    </div>
  );
}
