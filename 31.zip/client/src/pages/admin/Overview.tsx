import { useQuery } from "@tanstack/react-query";
import { useState } from "react";
import { useLocation } from "wouter";
import { LineChart, Line, XAxis, YAxis, Tooltip, ResponsiveContainer, CartesianGrid } from "recharts";
import { Star, DollarSign, Users, TrendingUp, ArrowUpRight, ArrowDownLeft, BarChart2, X } from "lucide-react";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import type { Client, Transaction } from "@shared/schema";

type Period = "day" | "month";
type RecentCount = "5" | "10" | "15" | "50";

interface ClientReviewsStats {
  totalAllTime: number;
  totalThisMonth: number;
  byDay: { date: string; count: number }[];
  byMonth: { date: string; count: number }[];
  perClient: { id: string; name: string; status: string; total: number }[];
}

function StatCard({ icon: Icon, label, value, sub }: {
  icon: typeof Star;
  label: string;
  value: string | number;
  sub?: string;
}) {
  return (
    <div className="admin-card p-5 flex items-start gap-4">
      <div className="w-11 h-11 rounded-xl bg-admin-accent/10 flex items-center justify-center shrink-0">
        <Icon size={20} className="text-admin-accent" />
      </div>
      <div className="min-w-0">
        <p className="text-admin-muted text-xs font-medium uppercase tracking-wide mb-1">{label}</p>
        <p className="text-admin-text text-2xl font-bold">{value}</p>
        {sub && <p className="text-admin-muted text-xs mt-0.5">{sub}</p>}
      </div>
    </div>
  );
}

export default function Overview() {
  const [, navigate] = useLocation();
  const [period, setPeriod] = useState<Period>("month");
  const [txCount, setTxCount] = useState<RecentCount>("5");
  const [chartModalOpen, setChartModalOpen] = useState(false);
  const [chartZoom, setChartZoom] = useState(1);
  const [chartPan, setChartPan] = useState(0);
  const [showMonthChart, setShowMonthChart] = useState(true);

  const { data: stats, isLoading: statsLoading } = useQuery<ClientReviewsStats>({
    queryKey: ["/api/client-reviews/stats"],
  });
  const { data: clients = [] } = useQuery<Client[]>({ queryKey: ["/api/clients"] });
  const { data: transactions = [] } = useQuery<Transaction[]>({ queryKey: ["/api/transactions"] });

  const inWork = clients.filter(c => c.status === "in_work").length;
  const paused = clients.filter(c => c.status === "paused").length;
  const potential = clients.filter(c => c.status === "potential").length;
  const refused = clients.filter(c => c.status === "refused").length;

  const chartData = stats
    ? period === "day" ? stats.byDay.slice(-30)
      : stats.byMonth
    : [];

  // Chart zoom/pan logic
  const maxZoom = Math.max(1, Math.ceil(chartData.length / 8));
  const zoomLevel = Math.max(1, Math.min(chartZoom, maxZoom));
  const itemsPerView = Math.ceil(chartData.length / zoomLevel);
  const maxPan = Math.max(0, chartData.length - itemsPerView);
  const panStart = Math.min(chartPan, maxPan);
  const visibleData = chartData.slice(panStart, panStart + itemsPerView);

  const handleChartWheel = (e: React.WheelEvent) => {
    e.preventDefault();
    const delta = e.deltaY > 0 ? 0.8 : 1.2;
    setChartZoom(z => Math.max(1, Math.min(maxZoom, z * delta)));
  };

  const handleChartDrag = (e: React.MouseEvent) => {
    const startX = e.clientX;
    const startPan = chartPan;

    const handleMouseMove = (moveEvent: MouseEvent) => {
      const diff = (moveEvent.clientX - startX) / 50;
      setChartPan(p => Math.max(0, Math.min(maxPan, startPan - diff)));
    };

    const handleMouseUp = () => {
      document.removeEventListener("mousemove", handleMouseMove);
      document.removeEventListener("mouseup", handleMouseUp);
    };

    document.addEventListener("mousemove", handleMouseMove);
    document.addEventListener("mouseup", handleMouseUp);
  };

  const recentTx = transactions.slice(0, parseInt(txCount));
  const topClients = (stats?.perClient ?? []).slice(0, 10);

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold text-admin-text">Overview</h1>
        <p className="text-admin-muted text-sm mt-1">Dashboard with key metrics</p>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-4 gap-4">
        <StatCard
          icon={Star}
          label="Total Reviews (All Time)"
          value={statsLoading ? "…" : (stats?.totalAllTime ?? 0).toLocaleString()}
        />
        <StatCard
          icon={TrendingUp}
          label="Reviews This Month"
          value={statsLoading ? "…" : (stats?.totalThisMonth ?? 0).toLocaleString()}
          sub="Current month"
        />
        <StatCard
          icon={Users}
          label="Clients In Work / Paused"
          value={`${inWork} / ${paused}`}
          sub="Active clients"
        />
        <StatCard
          icon={DollarSign}
          label="Total Clients"
          value={clients.length}
          sub="All accounts"
        />
      </div>

      <div className="grid grid-cols-1 xl:grid-cols-3 gap-4">
        <div className="xl:col-span-2 admin-card p-5 cursor-pointer hover:opacity-90 transition-opacity" onClick={() => setChartModalOpen(true)}>
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-admin-text font-semibold">Reviews Over Time</h2>
            <Select value={period} onValueChange={v => setPeriod(v as Period)}>
              <SelectTrigger className="w-40 h-8 text-xs admin-select">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="day">By Day (last 30)</SelectItem>
                <SelectItem value="month">By Month</SelectItem>
              </SelectContent>
            </Select>
          </div>
          {chartData.length === 0 ? (
            <div className="h-48 flex items-center justify-center text-admin-muted text-sm">
              {statsLoading ? "Loading…" : "No data yet"}
            </div>
          ) : (
            <ResponsiveContainer width="100%" height={220}>
              <LineChart data={chartData} margin={{ top: 5, right: 0, left: -20, bottom: 0 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="var(--admin-border-color)" />
                <XAxis dataKey="date" tick={{ fontSize: 10, fill: "white" }} />
                <YAxis tick={{ fontSize: 11, fill: "white" }} allowDecimals={false} />
                <Tooltip
                  contentStyle={{
                    background: "var(--admin-card-bg)",
                    border: "1px solid var(--admin-border-color)",
                    borderRadius: "8px",
                    color: "white"
                  }}
                  labelStyle={{ color: "white" }}
                />
                <Line 
                  type="monotone" 
                  dataKey="count" 
                  stroke="#22c55e" 
                  dot={{ fill: "#22c55e", r: 3 }}
                  activeDot={{ r: 5 }}
                  strokeWidth={2}
                />
              </LineChart>
            </ResponsiveContainer>
          )}
        </div>

        <div className="admin-card p-5">
          <h2 className="text-admin-text font-semibold mb-4">Clients Summary</h2>
          <div className="space-y-3">
            {[
              { label: "In Work", value: inWork, color: "bg-green-500" },
              { label: "Potential", value: potential, color: "bg-admin-accent" },
              { label: "Paused", value: paused, color: "bg-yellow-500" },
              { label: "Refused", value: refused, color: "bg-red-500" },
            ].map(({ label, value, color }) => (
              <div key={label} className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <div className={`w-2.5 h-2.5 rounded-full ${color}`} />
                  <span className="text-sm text-admin-muted">{label}</span>
                </div>
                <span className="text-sm font-semibold text-admin-text">{value}</span>
              </div>
            ))}
          </div>
          <div className="mt-4 pt-4 border-t border-admin-border">
            <div className="flex items-center justify-between">
              <span className="text-sm text-admin-muted">Total Clients</span>
              <span className="text-sm font-bold text-admin-text">{clients.length}</span>
            </div>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 xl:grid-cols-2 gap-4">
        <div className="admin-card p-5">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-admin-text font-semibold">Recent Payments</h2>
            <Select value={txCount} onValueChange={v => setTxCount(v as RecentCount)}>
              <SelectTrigger className="w-28 h-8 text-xs admin-select">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="5">Last 5</SelectItem>
                <SelectItem value="10">Last 10</SelectItem>
                <SelectItem value="15">Last 15</SelectItem>
                <SelectItem value="50">Last 50</SelectItem>
              </SelectContent>
            </Select>
          </div>
          {recentTx.length === 0 ? (
            <p className="text-admin-muted text-sm text-center py-6">No payments yet</p>
          ) : (
            <div className="space-y-2">
              {recentTx.map(tx => (
                <div key={tx.id} className="flex items-center justify-between py-2 border-b border-admin-border last:border-0">
                  <div className="flex items-center gap-2.5">
                    <div className={`w-8 h-8 rounded-full flex items-center justify-center ${tx.type === "income" ? "bg-green-100 dark:bg-green-900/30" : "bg-red-100 dark:bg-red-900/30"}`}>
                      {tx.type === "income"
                        ? <ArrowUpRight size={14} className="text-green-600 dark:text-green-400" />
                        : <ArrowDownLeft size={14} className="text-red-600 dark:text-red-400" />}
                    </div>
                    <div>
                      <p className="text-sm text-admin-text font-medium">{tx.description || (tx.type === "income" ? "Income" : "Expense")}</p>
                      <p className="text-xs text-admin-muted">{new Date(tx.date).toLocaleDateString()}</p>
                    </div>
                  </div>
                  <span className={`text-sm font-semibold ${tx.type === "income" ? "text-green-600 dark:text-green-400" : "text-red-600 dark:text-red-400"}`}>
                    {tx.type === "income" ? "+" : "-"}${parseFloat(tx.amount).toLocaleString()}
                  </span>
                </div>
              ))}
            </div>
          )}
        </div>

        <div className="admin-card p-5">
          <h2 className="text-admin-text font-semibold mb-4">
            Reviews by Client
            <span className="ml-2 text-xs font-normal text-admin-muted">(top 10)</span>
          </h2>
          {statsLoading ? (
            <p className="text-admin-muted text-sm text-center py-6">Loading…</p>
          ) : topClients.length === 0 ? (
            <p className="text-admin-muted text-sm text-center py-6">No data</p>
          ) : (
            <div className="space-y-2">
              {topClients.map(c => (
                <div key={c.id} className="flex items-center justify-between py-1.5 border-b border-admin-border last:border-0">
                  <div className="flex items-center gap-2.5 min-w-0">
                    <div className="w-7 h-7 rounded-full bg-admin-accent/10 flex items-center justify-center shrink-0">
                      <Star size={12} className="text-admin-accent" />
                    </div>
                    <span className="text-sm text-admin-text truncate">{c.name}</span>
                  </div>
                  <div className="flex items-center gap-2 shrink-0">
                    <span className="text-sm font-semibold text-admin-text">{c.total.toLocaleString()}</span>
                    <button
                      onClick={() => navigate(`/admin/customers/${c.id}/stats`)}
                      className="p-1 rounded text-admin-muted hover:text-admin-accent transition-colors"
                      title="View stats"
                    >
                      <BarChart2 size={13} />
                    </button>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>

      <Dialog open={chartModalOpen} onOpenChange={setChartModalOpen}>
        <DialogContent 
          className="admin-dialog max-w-5xl animate-in fade-in zoom-in-95 duration-500"
          onOpenAutoFocus={(e) => e.preventDefault()}
        >
          <DialogHeader>
            <DialogTitle className="text-admin-text">Reviews Over Time</DialogTitle>
          </DialogHeader>
          <div className="flex items-center gap-4 mb-4">
            <Select value={period} onValueChange={v => { setPeriod(v as Period); setChartZoom(1); setChartPan(0); }}>
              <SelectTrigger className="w-40 h-8 text-xs admin-select">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="day">By Day (last 30)</SelectItem>
                <SelectItem value="month">By Month</SelectItem>
              </SelectContent>
            </Select>
          </div>
          {chartData.length === 0 ? (
            <div className="h-96 flex items-center justify-center text-admin-muted text-sm">
              {statsLoading ? "Loading…" : "No data yet"}
            </div>
          ) : (
            <div 
              className="relative bg-admin-card rounded-lg overflow-hidden"
              onWheel={handleChartWheel}
              onMouseDown={handleChartDrag}
              style={{ cursor: "grab", userSelect: "none" }}
            >
              <ResponsiveContainer width="100%" height={400}>
                <LineChart data={visibleData} margin={{ top: 10, right: 20, left: 0, bottom: 10 }}>
                  <CartesianGrid strokeDasharray="3 3" stroke="var(--admin-border-color)" />
                  <XAxis dataKey="date" tick={{ fontSize: 11, fill: "white" }} />
                  <YAxis tick={{ fontSize: 12, fill: "white" }} allowDecimals={false} />
                  <Tooltip
                    contentStyle={{
                      background: "var(--admin-card-bg)",
                      border: "1px solid var(--admin-border-color)",
                      borderRadius: "8px",
                      color: "white"
                    }}
                    labelStyle={{ color: "white" }}
                    cursor={{ stroke: "#22c55e", strokeWidth: 1 }}
                  />
                  <Line 
                    type="monotone" 
                    dataKey="count" 
                    stroke="#22c55e" 
                    dot={{ fill: "#22c55e", r: 4 }}
                    activeDot={{ r: 6 }}
                    strokeWidth={3}
                  />
                </LineChart>
              </ResponsiveContainer>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  );
}
