import { useEffect, useState, useRef } from "react";

interface LoaderProps {
  onDone: () => void;
}

export default function Loader({ onDone }: LoaderProps) {
  const [progress, setProgress] = useState(0);
  const [phase, setPhase] = useState<"counting" | "exit">("counting");
  const rafRef = useRef<number | null>(null);
  const startRef = useRef<number>(Date.now());
  const DURATION = 2600;

  useEffect(() => {
    startRef.current = Date.now();

    function tick() {
      const elapsed = Date.now() - startRef.current;
      const t = Math.min(elapsed / DURATION, 1);
      const eased = t < 0.5 ? 2 * t * t : -1 + (4 - 2 * t) * t;
      const val = Math.floor(eased * 100);
      setProgress(val);

      if (t < 1) {
        rafRef.current = requestAnimationFrame(tick);
      } else {
        setProgress(100);
        setTimeout(() => {
          setPhase("exit");
          setTimeout(onDone, 1050);
        }, 220);
      }
    }

    rafRef.current = requestAnimationFrame(tick);
    return () => {
      if (rafRef.current) cancelAnimationFrame(rafRef.current);
    };
  }, [onDone]);

  const exiting = phase === "exit";

  return (
    <>
      <style>{`
        @keyframes ldr-clip-up {
          from { clip-path: inset(100% 0 0 0); }
          to   { clip-path: inset(0% 0 0 0); }
        }
        @keyframes ldr-fade-in {
          from { opacity: 0; }
          to   { opacity: 1; }
        }
      `}</style>

      {/* Curtain: slides UP on exit */}
      <div
        style={{
          position: "fixed",
          inset: 0,
          zIndex: 99998,
          background: "#050505",
          transform: exiting ? "translateY(-100%)" : "translateY(0)",
          transition: exiting ? "transform 1.05s cubic-bezier(0.76, 0, 0.24, 1)" : "none",
          pointerEvents: exiting ? "none" : "all",
        }}
      />

      {/* Content layer */}
      <div
        style={{
          position: "fixed",
          inset: 0,
          zIndex: 99999,
          display: "flex",
          flexDirection: "column",
          justifyContent: "space-between",
          padding: "clamp(24px, 3.5vw, 52px) clamp(24px, 4vw, 56px)",
          pointerEvents: "none",
          opacity: exiting ? 0 : 1,
          transition: exiting ? "opacity 0.3s ease" : "none",
        }}
      >
        {/* Top row */}
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start" }}>
          <div style={{ overflow: "hidden" }}>
            <div
              style={{
                fontFamily: "monospace",
                fontSize: "0.72rem",
                fontWeight: 700,
                letterSpacing: 5,
                color: "rgba(255,255,255,0.5)",
                textTransform: "uppercase",
                animation: "ldr-clip-up 0.8s cubic-bezier(0.16,1,0.3,1) 0.05s both",
              }}
            >
              Exchange Feed
            </div>
          </div>
          <div style={{ overflow: "hidden" }}>
            <div
              style={{
                fontFamily: "monospace",
                fontSize: "0.58rem",
                letterSpacing: 4,
                color: "rgba(255,255,255,0.18)",
                textTransform: "uppercase",
                animation: "ldr-clip-up 0.7s cubic-bezier(0.16,1,0.3,1) 0.15s both",
              }}
            >
              {progress < 30
                ? "Инициализация"
                : progress < 65
                ? "Загрузка данных"
                : progress < 95
                ? "Подготовка"
                : "Готово"}
            </div>
          </div>
        </div>

        {/* Center: large text reveal word by word */}
        <div style={{ paddingBottom: "clamp(12px, 2vw, 28px)" }}>
          {["EXCHANGE", "FEED"].map((word, i) => (
            <div key={word} style={{ overflow: "hidden", lineHeight: 0.88 }}>
              <div
                style={{
                  fontFamily: "'Inter', 'Helvetica Neue', Arial, sans-serif",
                  fontSize: "clamp(5rem, 16vw, 15rem)",
                  fontWeight: 900,
                  color: "#fff",
                  letterSpacing: "-0.04em",
                  animation: `ldr-clip-up 0.95s cubic-bezier(0.16,1,0.3,1) ${0.08 + i * 0.14}s both`,
                  userSelect: "none",
                }}
              >
                {word}
              </div>
            </div>
          ))}

          {/* Progress bar + percentage */}
          <div
            style={{
              display: "flex",
              alignItems: "center",
              gap: 20,
              marginTop: "clamp(20px, 3vw, 44px)",
              animation: "ldr-fade-in 0.5s ease 0.5s both",
            }}
          >
            <div
              style={{
                height: 1,
                flex: 1,
                background: "rgba(255,255,255,0.1)",
                position: "relative",
                overflow: "hidden",
              }}
            >
              <div
                style={{
                  position: "absolute",
                  inset: 0,
                  background: "#c9ff47",
                  transform: `scaleX(${progress / 100})`,
                  transformOrigin: "left",
                  transition: "transform 0.06s linear",
                }}
              />
            </div>
            <div
              style={{
                fontFamily: "monospace",
                fontSize: "0.68rem",
                fontWeight: 700,
                color: "#c9ff47",
                letterSpacing: 2,
                minWidth: 44,
                textAlign: "right",
              }}
            >
              {progress}%
            </div>
          </div>
        </div>

        {/* Bottom row */}
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-end" }}>
          <div style={{ overflow: "hidden" }}>
            <div
              style={{
                fontFamily: "monospace",
                fontSize: "0.55rem",
                letterSpacing: 4,
                color: "rgba(255,255,255,0.15)",
                textTransform: "uppercase",
                animation: "ldr-clip-up 0.7s cubic-bezier(0.16,1,0.3,1) 0.3s both",
              }}
            >
              Репутация · Отзывы · Аналитика
            </div>
          </div>
          <div style={{ overflow: "hidden" }}>
            <div
              style={{
                fontFamily: "monospace",
                fontSize: "0.55rem",
                letterSpacing: 3,
                color: "rgba(255,255,255,0.15)",
                textTransform: "uppercase",
                animation: "ldr-clip-up 0.7s cubic-bezier(0.16,1,0.3,1) 0.35s both",
              }}
            >
              {new Date().getFullYear()}
            </div>
          </div>
        </div>
      </div>
    </>
  );
}
