import { useRef, useEffect, useState } from "react";

interface SplitRevealProps {
  text: string;
  delay?: number;
  stagger?: number;
  className?: string;
  style?: React.CSSProperties;
  wordStyle?: React.CSSProperties;
}

export default function SplitReveal({
  text,
  delay = 0,
  stagger = 60,
  className,
  style,
  wordStyle,
}: SplitRevealProps) {
  const ref = useRef<HTMLDivElement>(null);
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    const obs = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setVisible(true);
          obs.disconnect();
        }
      },
      { threshold: 0.1 }
    );
    obs.observe(el);
    return () => obs.disconnect();
  }, []);

  const words = text.split(" ");

  return (
    <div
      ref={ref}
      className={className}
      style={{
        display: "flex",
        flexWrap: "wrap",
        gap: "0.22em",
        lineHeight: "inherit",
        ...style,
      }}
    >
      {words.map((word, i) => (
        <span
          key={i}
          style={{ overflow: "hidden", display: "inline-block", lineHeight: "inherit" }}
        >
          <span
            style={{
              display: "inline-block",
              transform: visible ? "translateY(0)" : "translateY(115%)",
              opacity: visible ? 1 : 0,
              transition: `transform 0.9s cubic-bezier(0.16,1,0.3,1) ${delay + i * stagger}ms, opacity 0.6s ease ${delay + i * stagger}ms`,
              lineHeight: "inherit",
              ...wordStyle,
            }}
          >
            {word}
          </span>
        </span>
      ))}
    </div>
  );
}
