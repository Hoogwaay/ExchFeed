import Database from "better-sqlite3";
import path from "path";
import { fileURLToPath } from "url";
import { randomUUID } from "crypto";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const TX_DB_PATH = path.resolve(__dirname, "..", "Transactions.db");

let _db: Database.Database | null = null;

function getDb(): Database.Database {
  if (_db) return _db;
  _db = new Database(TX_DB_PATH);
  _db.pragma("journal_mode = WAL");
  _db.exec(`
    CREATE TABLE IF NOT EXISTS transactions (
      id TEXT PRIMARY KEY,
      client_id TEXT,
      type TEXT NOT NULL CHECK(type IN ('income','expense')),
      amount REAL NOT NULL,
      description TEXT,
      notes TEXT,
      category TEXT,
      date INTEGER NOT NULL
    )
  `);
  return _db;
}

export type TransactionType = "income" | "expense";

export interface Transaction {
  id: string;
  clientId: string | null;
  type: TransactionType;
  amount: number;
  description: string | null;
  notes: string | null;
  category: string | null;
  date: string;
}

interface TxRow {
  id: string;
  client_id: string | null;
  type: TransactionType;
  amount: number;
  description: string | null;
  notes: string | null;
  category: string | null;
  date: number;
}

function rowToTx(row: TxRow): Transaction {
  return {
    id: row.id,
    clientId: row.client_id ?? null,
    type: row.type,
    amount: row.amount,
    description: row.description ?? null,
    notes: row.notes ?? null,
    category: row.category ?? null,
    date: new Date(row.date).toISOString(),
  };
}

export const TransactionsDb = {
  getAll(): Transaction[] {
    const db = getDb();
    const rows = db.prepare("SELECT * FROM transactions ORDER BY date DESC").all() as TxRow[];
    return rows.map(rowToTx);
  },

  getByClient(clientId: string): Transaction[] {
    const db = getDb();
    const rows = db.prepare("SELECT * FROM transactions WHERE client_id = ? ORDER BY date DESC").all(clientId) as TxRow[];
    return rows.map(rowToTx);
  },

  getById(id: string): Transaction | undefined {
    const db = getDb();
    const row = db.prepare("SELECT * FROM transactions WHERE id = ?").get(id) as TxRow | undefined;
    return row ? rowToTx(row) : undefined;
  },

  create(data: {
    clientId?: string | null;
    type: TransactionType;
    amount: number;
    description?: string | null;
    notes?: string | null;
    category?: string | null;
    date?: string | Date;
  }): Transaction {
    const db = getDb();
    const id = randomUUID();
    const dateMs = data.date
      ? (typeof data.date === "string" ? new Date(data.date).getTime() : data.date.getTime())
      : Date.now();
    db.prepare(`
      INSERT INTO transactions (id, client_id, type, amount, description, notes, category, date)
      VALUES (?, ?, ?, ?, ?, ?, ?, ?)
    `).run(
      id,
      data.clientId ?? null,
      data.type,
      data.amount,
      data.description ?? null,
      data.notes ?? null,
      data.category ?? null,
      dateMs,
    );
    return this.getById(id)!;
  },

  update(id: string, data: Partial<{
    clientId: string | null;
    type: TransactionType;
    amount: number;
    description: string | null;
    notes: string | null;
    category: string | null;
    date: string | Date;
  }>): Transaction | null {
    const db = getDb();
    const existing = this.getById(id);
    if (!existing) return null;

    const fields: string[] = [];
    const values: unknown[] = [];

    if (data.clientId !== undefined) { fields.push("client_id = ?"); values.push(data.clientId); }
    if (data.type !== undefined) { fields.push("type = ?"); values.push(data.type); }
    if (data.amount !== undefined) { fields.push("amount = ?"); values.push(data.amount); }
    if (data.description !== undefined) { fields.push("description = ?"); values.push(data.description); }
    if (data.notes !== undefined) { fields.push("notes = ?"); values.push(data.notes); }
    if (data.category !== undefined) { fields.push("category = ?"); values.push(data.category); }
    if (data.date !== undefined) {
      const ms = typeof data.date === "string" ? new Date(data.date).getTime() : data.date.getTime();
      fields.push("date = ?"); values.push(ms);
    }

    if (fields.length === 0) return existing;

    values.push(id);
    db.prepare(`UPDATE transactions SET ${fields.join(", ")} WHERE id = ?`).run(...values);
    return this.getById(id)!;
  },

  delete(id: string): boolean {
    const db = getDb();
    const result = db.prepare("DELETE FROM transactions WHERE id = ?").run(id);
    return result.changes > 0;
  },

  initDb(): void {
    getDb();
  },
};
