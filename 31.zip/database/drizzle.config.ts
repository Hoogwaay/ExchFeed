import { defineConfig } from "drizzle-kit";

export default defineConfig({
  schema: "./database/schema.ts",
  dialect: "sqlite",
  dbCredentials: {
    url: "Reviews.db",
  },
});