import fs from "fs";
import path from "path";
import { fileURLToPath } from "url";
import { randomUUID } from "crypto";
import Database from "better-sqlite3";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const CLIENTS_FILE = path.resolve(__dirname, "..", "clients.json");
const REVIEWS_DB_PATH = path.resolve(__dirname, "..", "Reviews.db");

export interface ClientContact {
  id: string;
  type: "telegram" | "email" | "phone" | "skype" | "whatsapp" | "other";
  value: string;
  label?: string;
}

export interface ClientResource {
  id: string;
  name: string;
  url: string;
  language: string;
  format: string;
}

export interface ClientMonitoring {
  id: string;
  url: string;
  price: number;
  period: "day" | "week" | "month";
  quantity: number;
}

export type ClientStatus = "in_work" | "potential" | "refused" | "paused";

export interface ClientRecord {
  id: string;
  name: string;
  status: ClientStatus;
  telegram: string | null;
  email: string | null;
  phone: string | null;
  loginLogin: string | null;
  loginPassword: string | null;
  googleSheetUrl: string | null;
  resourceUrl: string | null;
  notes: string | null;
  contacts: ClientContact[];
  resources: ClientResource[];
  monitorings: ClientMonitoring[];
  createdAt: string;
}

function readFile(): ClientRecord[] {
  try {
    const raw = fs.readFileSync(CLIENTS_FILE, "utf-8");
    return JSON.parse(raw) as ClientRecord[];
  } catch {
    return [];
  }
}

function writeFile(records: ClientRecord[]): void {
  fs.writeFileSync(CLIENTS_FILE, JSON.stringify(records, null, 2), "utf-8");
}

function syncToSQLite(client: ClientRecord, action: "upsert" | "delete"): void {
  try {
    const sqlite = new Database(REVIEWS_DB_PATH);
    if (action === "delete") {
      sqlite.prepare("DELETE FROM clients WHERE id = ?").run(client.id);
    } else {
      const monitorsJson = JSON.stringify(client.monitorings ?? []);
      const existing = sqlite.prepare("SELECT id FROM clients WHERE id = ?").get(client.id);
      if (existing) {
        sqlite.prepare(`
          UPDATE clients SET name=?, email=?, phone=?, status=?, notes=?, tz=?, wallets=?
          WHERE id=?
        `).run(
          client.name,
          client.loginLogin ?? null,
          client.telegram ?? null,
          client.status,
          client.googleSheetUrl ?? null,
          client.resourceUrl ?? null,
          monitorsJson,
          client.id,
        );
      } else {
        sqlite.prepare(`
          INSERT INTO clients (id, name, email, phone, status, notes, tz, wallets, created_at)
          VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
        `).run(
          client.id,
          client.name,
          client.loginLogin ?? null,
          client.telegram ?? null,
          client.status,
          client.googleSheetUrl ?? null,
          client.resourceUrl ?? null,
          monitorsJson,
          Date.now(),
        );
      }
    }
    sqlite.close();
  } catch (e) {
    console.error("[clients-store] SQLite sync error:", e);
  }
}

export function initClientsStore(): void {
  if (fs.existsSync(CLIENTS_FILE)) return;

  const records: ClientRecord[] = [];
  try {
    const sqlite = new Database(REVIEWS_DB_PATH);
    const rows = sqlite.prepare("SELECT * FROM clients ORDER BY created_at ASC").all() as any[];
    sqlite.close();

    for (const row of rows) {
      let monitorings: ClientMonitoring[] = [];
      try {
        const parsed = row.wallets ? JSON.parse(row.wallets) : [];
        monitorings = (Array.isArray(parsed) ? parsed : []).map((m: any) => ({
          id: randomUUID(),
          url: m.url ?? "",
          price: Number(m.price ?? 0),
          period: (m.period ?? "month") as "day" | "week" | "month",
          quantity: Number(m.quantity ?? 0),
        }));
      } catch { /* ignore */ }

      records.push({
        id: row.id,
        name: row.name,
        status: (row.status ?? "potential") as ClientStatus,
        telegram: row.phone ?? null,
        email: null,
        phone: null,
        loginLogin: row.email ?? null,
        loginPassword: null,
        googleSheetUrl: row.notes ?? null,
        resourceUrl: row.tz ?? null,
        notes: null,
        contacts: [],
        resources: [],
        monitorings,
        createdAt: row.created_at
          ? new Date(typeof row.created_at === "number" ? row.created_at : Number(row.created_at)).toISOString()
          : new Date().toISOString(),
      });
    }
  } catch (e) {
    console.error("[clients-store] Migration from SQLite failed:", e);
  }

  writeFile(records);
  console.log(`[clients-store] Initialized clients.json with ${records.length} clients`);
}

export const ClientsStore = {
  getAll(): ClientRecord[] {
    return readFile();
  },

  getById(id: string): ClientRecord | undefined {
    return readFile().find((c) => c.id === id);
  },

  create(data: Omit<ClientRecord, "id" | "createdAt">): ClientRecord {
    const records = readFile();
    const record: ClientRecord = {
      id: randomUUID(),
      createdAt: new Date().toISOString(),
      contacts: data.contacts ?? [],
      resources: data.resources ?? [],
      monitorings: data.monitorings ?? [],
      ...data,
    };
    records.unshift(record);
    writeFile(records);
    syncToSQLite(record, "upsert");
    return record;
  },

  update(id: string, data: Partial<Omit<ClientRecord, "id" | "createdAt">>): ClientRecord | null {
    const records = readFile();
    const idx = records.findIndex((c) => c.id === id);
    if (idx === -1) return null;
    const updated: ClientRecord = { ...records[idx], ...data };
    records[idx] = updated;
    writeFile(records);
    syncToSQLite(updated, "upsert");
    return updated;
  },

  delete(id: string): boolean {
    const records = readFile();
    const idx = records.findIndex((c) => c.id === id);
    if (idx === -1) return false;
    const [removed] = records.splice(idx, 1);
    writeFile(records);
    syncToSQLite(removed, "delete");
    return true;
  },
};
