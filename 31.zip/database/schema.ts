import { sqliteTable, text, integer, real } from "drizzle-orm/sqlite-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";
import { randomUUID } from "crypto";

export const users = sqliteTable("users", {
  id: text("id").primaryKey().$defaultFn(() => randomUUID()),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
});
export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;

export const clients = sqliteTable("clients", {
  id: text("id").primaryKey().$defaultFn(() => randomUUID()),
  name: text("name").notNull(),
  email: text("email"),
  phone: text("phone"),
  status: text("status", { enum: ["in_work", "potential", "refused", "paused"] }).notNull().default("potential"),
  notes: text("notes"),
  tz: text("tz"),
  wallets: text("wallets"),
  createdAt: integer("created_at", { mode: "timestamp" }).$defaultFn(() => new Date()),
});

export const insertClientSchema = createInsertSchema(clients).omit({ id: true, createdAt: true });
export type InsertClient = z.infer<typeof insertClientSchema>;
export type Client = typeof clients.$inferSelect;

export const reviews = sqliteTable("reviews", {
  id: text("id").primaryKey().$defaultFn(() => randomUUID()),
  clientId: text("client_id").references(() => clients.id),
  count: integer("count").notNull().default(1),
  earnedAmount: real("earned_amount").notNull().default(0),
  date: integer("date", { mode: "timestamp" }).$defaultFn(() => new Date()),
  notes: text("notes"),
});

export const insertReviewSchema = createInsertSchema(reviews).omit({ id: true });
export type InsertReview = z.infer<typeof insertReviewSchema>;
export type Review = typeof reviews.$inferSelect;

export const transactions = sqliteTable("transactions", {
  id: text("id").primaryKey().$defaultFn(() => randomUUID()),
  type: text("type", { enum: ["income", "expense"] }).notNull(),
  amount: real("amount").notNull(),
  description: text("description"),
  category: text("category"),
  date: integer("date", { mode: "timestamp" }).$defaultFn(() => new Date()),
});

export const insertTransactionSchema = createInsertSchema(transactions).omit({ id: true });
export type InsertTransaction = z.infer<typeof insertTransactionSchema>;
export type Transaction = typeof transactions.$inferSelect;

export const tasks = sqliteTable("tasks", {
  id: text("id").primaryKey().$defaultFn(() => randomUUID()),
  clientId: text("client_id").references(() => clients.id),
  reviewLanguage: text("review_language", { enum: ["RU", "EN"] }).notNull().default("RU"),
  reviewText: text("review_text").notNull(),
  reviewAmount: real("review_amount").notNull().default(0),
  reviewerName: text("reviewer_name").notNull().default(""),
  loginEmail: text("login_email"),
  loginPassword: text("login_password"),
  confirmLink: text("confirm_link"),
  service: text("service"),
  reviewType: text("review_type"),
  taskNumber: text("task_number"),
  status: text("status", { enum: ["pending", "done", "rejected"] }).notNull().default("pending"),
  createdAt: integer("created_at", { mode: "timestamp" }).$defaultFn(() => new Date()),
  completedAt: integer("completed_at", { mode: "timestamp" }),
});

export const insertTaskSchema = createInsertSchema(tasks)
  .omit({ id: true, createdAt: true, completedAt: true });
export type InsertTask = z.infer<typeof insertTaskSchema>;
export type Task = typeof tasks.$inferSelect;

export const schedules = sqliteTable("schedules", {
  id: text("id").primaryKey().$defaultFn(() => randomUUID()),
  staffName: text("staff_name").notNull(),
  workDate: text("work_date").notNull(),
  startTime: text("start_time"),
  endTime: text("end_time"),
  notes: text("notes"),
  createdAt: integer("created_at", { mode: "timestamp" }).$defaultFn(() => new Date()),
});

export const insertScheduleSchema = createInsertSchema(schedules).omit({ id: true, createdAt: true });
export type InsertSchedule = z.infer<typeof insertScheduleSchema>;
export type Schedule = typeof schedules.$inferSelect;

export const resources = sqliteTable("resources", {
  id: text("id").primaryKey().$defaultFn(() => randomUUID()),
  name: text("name").notNull(),
  url: text("url").notNull(),
  language: text("language").notNull().default("RU"),
  format: text("format").notNull().default("monitoring"),
  createdAt: integer("created_at", { mode: "timestamp" }).$defaultFn(() => new Date()),
});

export const insertResourceSchema = createInsertSchema(resources).omit({ id: true, createdAt: true });
export type InsertResource = z.infer<typeof insertResourceSchema>;
export type Resource = typeof resources.$inferSelect;

export const clientReviews = sqliteTable("client_reviews", {
  id: text("id").primaryKey().$defaultFn(() => randomUUID()),
  clientId: text("client_id").notNull().references(() => clients.id, { onDelete: "cascade" }),
  reviewDate: text("review_date").notNull(),
  link: text("link"),
  email: text("email"),
  application: text("application"),
  reviewerName: text("reviewer_name"),
  importedAt: integer("imported_at", { mode: "timestamp" }).$defaultFn(() => new Date()),
});

export const insertClientReviewSchema = createInsertSchema(clientReviews).omit({ id: true, importedAt: true });
export type InsertClientReview = z.infer<typeof insertClientReviewSchema>;
export type ClientReview = typeof clientReviews.$inferSelect;
