import { Router } from "express";
import { db } from "../../database/index.js";
import { clientReviews } from "../../database/index.js";
import { eq, desc, sql } from "drizzle-orm";
import { ClientsStore } from "../../database/clients-store.js";

const router = Router();

router.get("/clients/:id/reviews", async (req, res) => {
  try {
    const { id } = req.params;
    const page = parseInt(req.query.page as string) || 1;
    const limit = parseInt(req.query.limit as string) || 50;
    const offset = (page - 1) * limit;

    const total = await db
      .select({ count: sql<number>`count(*)` })
      .from(clientReviews)
      .where(eq(clientReviews.clientId, id));

    const rows = await db
      .select()
      .from(clientReviews)
      .where(eq(clientReviews.clientId, id))
      .orderBy(desc(clientReviews.reviewDate))
      .limit(limit)
      .offset(offset);

    res.json({
      data: rows,
      total: Number(total[0]?.count ?? 0),
      page,
      limit,
    });
  } catch (e) {
    res.status(500).json({ error: String(e) });
  }
});

router.get("/clients/:id/reviews/stats", async (req, res) => {
  try {
    const { id } = req.params;

    const client = ClientsStore.getById(id);
    if (!client) return res.status(404).json({ error: "Not found" });

    const allReviews = await db
      .select({ reviewDate: clientReviews.reviewDate })
      .from(clientReviews)
      .where(eq(clientReviews.clientId, id));

    const totalAllTime = allReviews.length;

    const now = new Date();
    const currentMonth = `${String(now.getMonth() + 1).padStart(2, "0")}.${now.getFullYear()}`;
    const totalThisMonth = allReviews.filter(r => {
      const parts = r.reviewDate.split(".");
      if (parts.length !== 3) return false;
      const monthYear = `${parts[1]}.${parts[2]}`;
      return monthYear === currentMonth;
    }).length;

    const byDayMap: Record<string, number> = {};
    const byWeekMap: Record<string, number> = {};
    const byMonthMap: Record<string, number> = {};

    for (const r of allReviews) {
      const parts = r.reviewDate.split(".");
      if (parts.length !== 3) continue;
      const day = r.reviewDate;
      const monthKey = `${parts[2]}-${parts[1]}`;

      byDayMap[day] = (byDayMap[day] || 0) + 1;
      byMonthMap[monthKey] = (byMonthMap[monthKey] || 0) + 1;

      const dateObj = new Date(parseInt(parts[2]), parseInt(parts[1]) - 1, parseInt(parts[0]));
      const monday = new Date(dateObj);
      monday.setDate(dateObj.getDate() - ((dateObj.getDay() + 6) % 7));
      const weekKey = `${String(monday.getDate()).padStart(2, "0")}.${String(monday.getMonth() + 1).padStart(2, "0")}.${monday.getFullYear()}`;
      byWeekMap[weekKey] = (byWeekMap[weekKey] || 0) + 1;
    }

    const sortByDateStr = (a: string, b: string) => {
      const toDate = (s: string) => {
        const p = s.split(".");
        if (p.length === 3) return new Date(parseInt(p[2]), parseInt(p[1]) - 1, parseInt(p[0])).getTime();
        const p2 = s.split("-");
        if (p2.length === 2) return new Date(parseInt(p2[0]), parseInt(p2[1]) - 1, 1).getTime();
        return 0;
      };
      return toDate(a) - toDate(b);
    };

    const byDay = Object.entries(byDayMap)
      .sort((a, b) => sortByDateStr(a[0], b[0]))
      .map(([date, count]) => ({ date, count }));

    const byWeek = Object.entries(byWeekMap)
      .sort((a, b) => sortByDateStr(a[0], b[0]))
      .map(([date, count]) => ({ date, count }));

    const byMonth = Object.entries(byMonthMap)
      .sort((a, b) => a[0].localeCompare(b[0]))
      .map(([date, count]) => ({ date, count }));

    res.json({
      client,
      totalAllTime,
      totalThisMonth,
      byDay,
      byWeek,
      byMonth,
    });
  } catch (e) {
    res.status(500).json({ error: String(e) });
  }
});

router.get("/client-reviews/stats", async (_req, res) => {
  try {
    const all = await db
      .select({ reviewDate: clientReviews.reviewDate, clientId: clientReviews.clientId })
      .from(clientReviews);

    const totalAllTime = all.length;

    const now = new Date();
    const currentMonth = `${String(now.getMonth() + 1).padStart(2, "0")}.${now.getFullYear()}`;
    const totalThisMonth = all.filter(r => {
      const parts = r.reviewDate.split(".");
      if (parts.length !== 3) return false;
      return `${parts[1]}.${parts[2]}` === currentMonth;
    }).length;

    const byDayMap: Record<string, number> = {};
    const byMonthMap: Record<string, number> = {};
    const byClientMap: Record<string, number> = {};

    for (const r of all) {
      const parts = r.reviewDate.split(".");
      if (parts.length !== 3) continue;
      const day = r.reviewDate;
      const monthKey = `${parts[2]}-${parts[1]}`;
      byDayMap[day] = (byDayMap[day] || 0) + 1;
      byMonthMap[monthKey] = (byMonthMap[monthKey] || 0) + 1;
      byClientMap[r.clientId] = (byClientMap[r.clientId] || 0) + 1;
    }

    const allClients = ClientsStore.getAll();
    const perClient = allClients.map(c => ({
      id: c.id,
      name: c.name,
      status: c.status,
      total: byClientMap[c.id] || 0,
    })).sort((a, b) => b.total - a.total);

    const sortByDayStr = (a: string, b: string) => {
      const toTs = (s: string) => {
        const p = s.split(".");
        return p.length === 3 ? new Date(parseInt(p[2]), parseInt(p[1]) - 1, parseInt(p[0])).getTime() : 0;
      };
      return toTs(a) - toTs(b);
    };

    const byDay = Object.entries(byDayMap)
      .sort((a, b) => sortByDayStr(a[0], b[0]))
      .map(([date, count]) => ({ date, count }));

    const byMonth = Object.entries(byMonthMap)
      .sort((a, b) => a[0].localeCompare(b[0]))
      .map(([date, count]) => ({ date, count }));

    res.json({
      totalAllTime,
      totalThisMonth,
      byDay,
      byMonth,
      perClient,
    });
  } catch (e) {
    res.status(500).json({ error: String(e) });
  }
});

export default router;
