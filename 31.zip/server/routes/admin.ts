import { Router } from "express";
import { db } from "../../database/index.js";
import {
  reviews, schedules, resources, clients, clientReviews,
  insertScheduleSchema, insertResourceSchema,
} from "../../database/index.js";
import { eq, desc, gte } from "drizzle-orm";
import { ClientsStore } from "../../database/clients-store.js";
import { TransactionsDb } from "../../database/transactions-db.js";
import type { ClientRecord } from "../../database/clients-store.js";

const router = Router();

const ADMIN_LOGIN = process.env.ADMIN_LOGIN || "Admin";
const ADMIN_PASSWORD = process.env.ADMIN_PASSWORD || "Admin";

const WORKER_LOGIN = process.env.WORKER_LOGIN || "Work";
const WORKER_PASSWORD = process.env.WORKER_PASSWORD || "Work";

const USER_LOGIN = process.env.USER_LOGIN || "User";
const USER_PASSWORD = process.env.USER_PASSWORD || "User";

// ─── Auth ─────────────────────────────────────────────────────────────────────

router.post("/auth/login", (req, res) => {
  const { login, password } = req.body as { login?: string; password?: string };
  if (login === ADMIN_LOGIN && password === ADMIN_PASSWORD) {
    res.json({ ok: true, token: "admin-session-valid", role: "admin" });
    return;
  }
  if (login === WORKER_LOGIN && password === WORKER_PASSWORD) {
    res.json({ ok: true, token: "worker-session-valid", role: "worker" });
    return;
  }
  if (login === USER_LOGIN && password === USER_PASSWORD) {
    res.json({ ok: true, token: "user-session-valid", role: "user" });
    return;
  }
  res.status(401).json({ ok: false, error: "Неверный логин или пароль" });
});

router.post("/admin/login", (req, res) => {
  const { login, password } = req.body as { login?: string; password?: string };
  if (login === ADMIN_LOGIN && password === ADMIN_PASSWORD) {
    res.json({ ok: true, token: "admin-session-valid", role: "admin" });
    return;
  }
  res.status(401).json({ ok: false, error: "Неверный логин или пароль" });
});

router.post("/crm/login", (req, res) => {
  const { login, password } = req.body as { login?: string; password?: string };
  if (login === WORKER_LOGIN && password === WORKER_PASSWORD) {
    res.json({ ok: true, token: "worker-session-valid", role: "worker" });
    return;
  }
  res.status(401).json({ ok: false, error: "Неверный логин или пароль" });
});

router.post("/admin/auth/login", (req, res) => {
  const { login, password } = req.body as { login?: string; password?: string };
  if (login === USER_LOGIN && password === USER_PASSWORD) {
    res.json({ ok: true, token: "user-session-valid", role: "user" });
    return;
  }
  res.status(401).json({ ok: false, error: "Неверный логин или пароль" });
});

// ─── Admin Clients (now via ClientsStore / clients.json) ───────────────────────

function mapClientToAdmin(c: ClientRecord) {
  return {
    id: c.id,
    name: c.name,
    status: c.status,
    login: c.loginLogin ?? null,
    passwordHash: c.loginPassword ?? null,
    googleSheetUrl: c.googleSheetUrl ?? null,
    telegram: c.telegram ?? null,
    email: c.email ?? null,
    phone: c.phone ?? null,
    resourceUrl: c.resourceUrl ?? null,
    notes: c.notes ?? null,
    contacts: c.contacts ?? [],
    resources: c.resources ?? [],
    sites: c.monitorings ?? [],
    monitorings: c.monitorings ?? [],
    createdAt: c.createdAt,
  };
}

router.get("/admin/clients", (_req, res) => {
  try {
    const all = ClientsStore.getAll();
    res.json({ ok: true, clients: all.map(mapClientToAdmin) });
  } catch (e) {
    res.status(500).json({ ok: false, error: String(e) });
  }
});

router.post("/admin/clients", (req, res) => {
  try {
    const body = req.body as any;
    if (!body.name) return res.status(400).json({ ok: false, error: "name required" });

    const monitorings = body.sites ?? body.monitorings ?? [];

    const created = ClientsStore.create({
      name: body.name,
      status: body.status ?? "potential",
      telegram: body.telegram ?? null,
      email: body.email ?? null,
      phone: body.phone ?? null,
      loginLogin: body.loginLogin ?? null,
      loginPassword: body.loginPassword ?? body.passwordHash ?? null,
      googleSheetUrl: body.googleSheetUrl ?? null,
      resourceUrl: body.resourceUrl ?? null,
      notes: body.notes ?? null,
      contacts: body.contacts ?? [],
      resources: body.resources ?? [],
      monitorings,
    });
    res.status(201).json({ ok: true, client: mapClientToAdmin(created) });
  } catch (e) {
    res.status(500).json({ ok: false, error: String(e) });
  }
});

router.put("/admin/clients/:id", (req, res) => {
  try {
    const body = req.body as any;
    const patch: Record<string, any> = {};
    if (body.name !== undefined) patch.name = body.name;
    if (body.status !== undefined) patch.status = body.status;
    if (body.telegram !== undefined) patch.telegram = body.telegram;
    if (body.email !== undefined) patch.email = body.email;
    if (body.phone !== undefined) patch.phone = body.phone;
    if (body.loginLogin !== undefined) patch.loginLogin = body.loginLogin;
    if (body.loginPassword !== undefined) patch.loginPassword = body.loginPassword;
    if (body.passwordHash !== undefined) patch.loginPassword = body.passwordHash;
    if (body.googleSheetUrl !== undefined) patch.googleSheetUrl = body.googleSheetUrl;
    if (body.resourceUrl !== undefined) patch.resourceUrl = body.resourceUrl;
    if (body.notes !== undefined) patch.notes = body.notes;
    if (body.contacts !== undefined) patch.contacts = body.contacts;
    if (body.resources !== undefined) patch.resources = body.resources;
    if (body.monitorings !== undefined) patch.monitorings = body.monitorings;
    if (body.sites !== undefined) patch.monitorings = body.sites;

    const updated = ClientsStore.update(req.params.id, patch);
    if (!updated) return res.status(404).json({ ok: false, error: "Not found" });
    res.json({ ok: true, client: mapClientToAdmin(updated) });
  } catch (e) {
    res.status(500).json({ ok: false, error: String(e) });
  }
});

router.delete("/admin/clients/:id", (req, res) => {
  try {
    const ok = ClientsStore.delete(req.params.id);
    if (!ok) return res.status(404).json({ ok: false, error: "Not found" });
    res.json({ ok: true });
  } catch (e) {
    res.status(500).json({ ok: false, error: String(e) });
  }
});

router.post("/admin/clients/:id/generate-credentials", (req, res) => {
  try {
    const { id } = req.params;
    const client = ClientsStore.getById(id);
    if (!client) return res.status(404).json({ ok: false, error: "Client not found" });

    const login = `client_${id.slice(0, 6)}`;
    const password = Math.random().toString(36).slice(2, 10).toUpperCase();
    ClientsStore.update(id, { loginLogin: login, loginPassword: password });
    res.json({ ok: true, login, password });
  } catch (e) {
    res.status(500).json({ ok: false, error: String(e) });
  }
});

// ─── Admin Reviews ─────────────────────────────────────────────────────────────

function toDate(value: unknown): Date | null {
  if (value instanceof Date) return Number.isNaN(value.getTime()) ? null : value;
  if (typeof value === "string" || typeof value === "number") {
    const d = new Date(value);
    return Number.isNaN(d.getTime()) ? null : d;
  }
  return null;
}

router.post("/admin/reviews", async (req, res) => {
  try {
    const { clientId, count, earnedAmount, date, notes } = req.body as {
      clientId?: string; count?: number; earnedAmount?: string; date?: string; notes?: string;
    };
    const [created] = await db.insert(reviews).values({
      clientId: clientId ?? null,
      count: count ?? 1,
      earnedAmount: earnedAmount ?? "0",
      date: date ? new Date(date) : new Date(),
      notes: notes ?? null,
    }).returning();
    res.status(201).json({ ok: true, review: created });
  } catch (e) {
    res.status(500).json({ ok: false, error: String(e) });
  }
});

router.get("/admin/reviews/stats", async (_req, res) => {
  try {
    const now = new Date();
    const startOfToday = new Date(now.getFullYear(), now.getMonth(), now.getDate());
    const startOfMonth = new Date(now.getFullYear(), now.getMonth(), 1);

    const allReviews = await db.select().from(reviews);
    const allClients = ClientsStore.getAll();

    const totalAllTime = allReviews.reduce((s, r) => s + r.count, 0);
    const earningsAllTime = allReviews.reduce((s, r) => s + Number(r.earnedAmount), 0);

    const monthReviews = allReviews.filter(r => {
      const d = toDate(r.date);
      return d ? d >= startOfMonth : false;
    });
    const reviewsDoneThisMonth = monthReviews.reduce((s, r) => s + r.count, 0);
    const earningsPerMonth = monthReviews.reduce((s, r) => s + Number(r.earnedAmount), 0);

    const todayReviews = allReviews.filter(r => {
      const d = toDate(r.date);
      return d ? d >= startOfToday : false;
    });
    const reviewsToday = todayReviews.reduce((s, r) => s + r.count, 0);

    const clientsActive = allClients.filter(c => c.status === "in_work").length;
    const clientsPaused = allClients.filter(c => c.status === "paused").length;

    const byDayMap: Record<string, number> = {};
    for (const r of allReviews) {
      const d = toDate(r.date);
      if (!d) continue;
      const key = d.toISOString().split("T")[0];
      byDayMap[key] = (byDayMap[key] ?? 0) + r.count;
    }
    const chartData = Object.entries(byDayMap)
      .sort((a, b) => a[0].localeCompare(b[0]))
      .map(([date, count]) => ({ date, count }));

    res.json({
      clientsActive,
      clientsPaused,
      reviewsToday,
      reviewsDoneThisMonth,
      reviewsRemainingThisMonth: 0,
      reviewsTotalThisMonth: reviewsDoneThisMonth,
      chartData,
      earningsPerMonth: earningsPerMonth.toFixed(2),
      reviewsAllTime: totalAllTime,
      earningsAllTime: earningsAllTime.toFixed(2),
    });
  } catch (e) {
    res.status(500).json({ ok: false, error: String(e) });
  }
});

router.get("/admin/reviews/chart", async (req, res) => {
  try {
    const period = (req.query.period as string) || "day";
    const range = (req.query.range as string) || "month";
    const now = new Date();
    let fromDate: Date;
    if (range === "month") {
      fromDate = new Date(now.getFullYear(), now.getMonth(), 1);
    } else if (range === "3months") {
      fromDate = new Date(now.getFullYear(), now.getMonth() - 2, 1);
    } else if (range === "year") {
      fromDate = new Date(now.getFullYear(), 0, 1);
    } else {
      fromDate = new Date(0);
    }

    const filtered = await db.select().from(reviews).where(gte(reviews.date, fromDate));

    function keyFor(d: Date): string {
      if (period === "month") {
        return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}`;
      }
      if (period === "week") {
        const monday = new Date(d);
        monday.setDate(d.getDate() - ((d.getDay() + 6) % 7));
        return monday.toISOString().split("T")[0];
      }
      return d.toISOString().split("T")[0];
    }

    const map: Record<string, number> = {};
    for (const r of filtered) {
      const d = toDate(r.date);
      if (!d) continue;
      const key = keyFor(d);
      map[key] = (map[key] ?? 0) + r.count;
    }
    const data = Object.entries(map)
      .sort((a, b) => a[0].localeCompare(b[0]))
      .map(([date, count]) => ({ date, count }));

    res.json({ ok: true, data });
  } catch (e) {
    res.status(500).json({ ok: false, error: String(e) });
  }
});

// ─── Admin Accounting (uses Transactions.db) ────────────────────────────────────

router.get("/admin/accounting", (_req, res) => {
  try {
    const all = TransactionsDb.getAll();
    res.json({
      ok: true,
      records: all.map(tx => ({
        id: tx.id,
        clientId: tx.clientId,
        type: tx.type,
        amount: tx.amount,
        description: tx.description ?? "",
        notes: tx.notes ?? "",
        category: tx.category ?? null,
        recordDate: tx.date.split("T")[0],
      })),
    });
  } catch (e) {
    res.status(500).json({ ok: false, error: String(e) });
  }
});

router.post("/admin/accounting", (req, res) => {
  try {
    const { type, amount, description, notes, category, recordDate, clientId } = req.body as any;
    if (!type || amount === undefined) return res.status(400).json({ ok: false, error: "type and amount required" });
    const created = TransactionsDb.create({
      clientId: clientId ?? null,
      type: type as "income" | "expense",
      amount: Number(amount),
      description: description ?? null,
      notes: notes ?? null,
      category: category ?? null,
      date: recordDate ? new Date(recordDate) : new Date(),
    });
    res.status(201).json({
      ok: true,
      record: {
        id: created.id,
        clientId: created.clientId,
        type: created.type,
        amount: created.amount,
        description: created.description ?? "",
        notes: created.notes ?? "",
        category: created.category ?? null,
        recordDate: created.date.split("T")[0],
      },
    });
  } catch (e) {
    res.status(500).json({ ok: false, error: String(e) });
  }
});

router.put("/admin/accounting/:id", (req, res) => {
  try {
    const { type, amount, description, notes, category, recordDate, clientId } = req.body as any;
    const patch: Record<string, any> = {};
    if (clientId !== undefined) patch.clientId = clientId;
    if (type !== undefined) patch.type = type;
    if (amount !== undefined) patch.amount = Number(amount);
    if (description !== undefined) patch.description = description;
    if (notes !== undefined) patch.notes = notes;
    if (category !== undefined) patch.category = category;
    if (recordDate !== undefined) patch.date = new Date(recordDate);

    const updated = TransactionsDb.update(req.params.id, patch);
    if (!updated) return res.status(404).json({ ok: false, error: "Not found" });
    res.json({
      ok: true,
      record: {
        id: updated.id,
        clientId: updated.clientId,
        type: updated.type,
        amount: updated.amount,
        description: updated.description ?? "",
        notes: updated.notes ?? "",
        category: updated.category ?? null,
        recordDate: updated.date.split("T")[0],
      },
    });
  } catch (e) {
    res.status(500).json({ ok: false, error: String(e) });
  }
});

router.delete("/admin/accounting/:id", (req, res) => {
  try {
    const ok = TransactionsDb.delete(req.params.id);
    if (!ok) return res.status(404).json({ ok: false, error: "Not found" });
    res.json({ ok: true });
  } catch (e) {
    res.status(500).json({ ok: false, error: String(e) });
  }
});

// ─── Admin Schedules ───────────────────────────────────────────────────────────

router.get("/admin/schedules", async (_req, res) => {
  try {
    const all = await db.select().from(schedules).orderBy(desc(schedules.workDate));
    res.json({ ok: true, schedules: all });
  } catch (e) {
    res.status(500).json({ ok: false, error: String(e) });
  }
});

router.post("/admin/schedules", async (req, res) => {
  try {
    const parsed = insertScheduleSchema.safeParse(req.body);
    if (!parsed.success) return res.status(400).json({ ok: false, error: parsed.error });
    const [created] = await db.insert(schedules).values(parsed.data).returning();
    res.status(201).json({ ok: true, schedule: created });
  } catch (e) {
    res.status(500).json({ ok: false, error: String(e) });
  }
});

router.put("/admin/schedules/:id", async (req, res) => {
  try {
    const parsed = insertScheduleSchema.partial().safeParse(req.body);
    if (!parsed.success) return res.status(400).json({ ok: false, error: parsed.error });
    const [updated] = await db.update(schedules).set(parsed.data).where(eq(schedules.id, req.params.id)).returning();
    if (!updated) return res.status(404).json({ ok: false, error: "Not found" });
    res.json({ ok: true, schedule: updated });
  } catch (e) {
    res.status(500).json({ ok: false, error: String(e) });
  }
});

router.delete("/admin/schedules/:id", async (req, res) => {
  try {
    const [deleted] = await db.delete(schedules).where(eq(schedules.id, req.params.id)).returning();
    if (!deleted) return res.status(404).json({ ok: false, error: "Not found" });
    res.json({ ok: true });
  } catch (e) {
    res.status(500).json({ ok: false, error: String(e) });
  }
});

// ─── Admin Resources ───────────────────────────────────────────────────────────

router.get("/admin/resources", async (_req, res) => {
  try {
    const all = await db.select().from(resources).orderBy(desc(resources.createdAt));
    res.json({ ok: true, resources: all });
  } catch (e) {
    res.status(500).json({ ok: false, error: String(e) });
  }
});

router.post("/admin/resources", async (req, res) => {
  try {
    const parsed = insertResourceSchema.safeParse(req.body);
    if (!parsed.success) return res.status(400).json({ ok: false, error: parsed.error });
    const [created] = await db.insert(resources).values(parsed.data).returning();
    res.status(201).json({ ok: true, resource: created });
  } catch (e) {
    res.status(500).json({ ok: false, error: String(e) });
  }
});

router.delete("/admin/resources/:id", async (req, res) => {
  try {
    const [deleted] = await db.delete(resources).where(eq(resources.id, req.params.id)).returning();
    if (!deleted) return res.status(404).json({ ok: false, error: "Not found" });
    res.json({ ok: true });
  } catch (e) {
    res.status(500).json({ ok: false, error: String(e) });
  }
});

// ─── Google Sheets Sync (stub) ─────────────────────────────────────────────────

router.post("/admin/sheets/sync", (_req, res) => {
  res.json({ ok: true, message: "Sync completed", synced: 0 });
});

// ─── Client profile / reviews ─────────────────────────────────────────────────

router.get("/client/profile", async (req, res) => {
  try {
    const clientId = req.query.clientId as string;
    if (!clientId) return res.status(400).json({ ok: false, error: "clientId required" });

    const client = ClientsStore.getById(clientId);
    if (!client) return res.status(404).json({ ok: false, error: "Not found" });

    const clientReviewRows = await db.select().from(reviews)
      .where(eq(reviews.clientId, clientId))
      .orderBy(desc(reviews.date));

    res.json({
      ok: true,
      client: { id: client.id, name: client.name, status: client.status, sites: client.monitorings },
      reviews: clientReviewRows,
    });
  } catch (e) {
    res.status(500).json({ ok: false, error: String(e) });
  }
});

router.get("/client/reviews", async (req, res) => {
  try {
    const clientId = req.query.clientId as string;
    if (!clientId) return res.status(400).json({ ok: false, error: "clientId required" });
    const clientReviewRows = await db.select().from(reviews)
      .where(eq(reviews.clientId, clientId))
      .orderBy(desc(reviews.date));
    res.json({ ok: true, reviews: clientReviewRows });
  } catch (e) {
    res.status(500).json({ ok: false, error: String(e) });
  }
});

export default router;
