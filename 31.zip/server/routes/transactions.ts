import { Router } from "express";
import { TransactionsDb, type TransactionType } from "../../database/transactions-db.js";

const router = Router();

router.get("/transactions", (_req, res) => {
  try {
    res.json(TransactionsDb.getAll());
  } catch (e) {
    res.status(500).json({ error: String(e) });
  }
});

router.get("/transactions/by-client/:clientId", (req, res) => {
  try {
    res.json(TransactionsDb.getByClient(req.params.clientId));
  } catch (e) {
    res.status(500).json({ error: String(e) });
  }
});

router.get("/transactions/:id", (req, res) => {
  try {
    const tx = TransactionsDb.getById(req.params.id);
    if (!tx) return res.status(404).json({ error: "Not found" });
    res.json(tx);
  } catch (e) {
    res.status(500).json({ error: String(e) });
  }
});

router.post("/transactions", (req, res) => {
  try {
    const body = req.body as any;
    if (!body.type || body.amount === undefined) {
      return res.status(400).json({ error: "type and amount required" });
    }
    const created = TransactionsDb.create({
      clientId: body.clientId ?? null,
      type: body.type as TransactionType,
      amount: Number(body.amount),
      description: body.description ?? null,
      notes: body.notes ?? null,
      category: body.category ?? null,
      date: body.date ? new Date(body.date) : new Date(),
    });
    res.status(201).json(created);
  } catch (e) {
    res.status(500).json({ error: String(e) });
  }
});

const updateHandler = (req: any, res: any) => {
  try {
    const body = req.body as any;
    const patch: Record<string, any> = {};
    if (body.clientId !== undefined) patch.clientId = body.clientId;
    if (body.type !== undefined) patch.type = body.type;
    if (body.amount !== undefined) patch.amount = Number(body.amount);
    if (body.description !== undefined) patch.description = body.description;
    if (body.notes !== undefined) patch.notes = body.notes;
    if (body.category !== undefined) patch.category = body.category;
    if (body.date !== undefined) patch.date = new Date(body.date);

    const updated = TransactionsDb.update(req.params.id, patch);
    if (!updated) return res.status(404).json({ error: "Not found" });
    res.json(updated);
  } catch (e) {
    res.status(500).json({ error: String(e) });
  }
};

router.put("/transactions/:id", updateHandler);
router.patch("/transactions/:id", updateHandler);

router.delete("/transactions/:id", (req, res) => {
  try {
    const ok = TransactionsDb.delete(req.params.id);
    if (!ok) return res.status(404).json({ error: "Not found" });
    res.json({ ok: true });
  } catch (e) {
    res.status(500).json({ error: String(e) });
  }
});

export default router;
