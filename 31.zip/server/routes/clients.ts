import { Router } from "express";
import { ClientsStore } from "../../database/clients-store.js";

const router = Router();

router.get("/clients", (_req, res) => {
  try {
    res.json(ClientsStore.getAll());
  } catch (e) {
    res.status(500).json({ error: String(e) });
  }
});

router.get("/clients/:id", (req, res) => {
  try {
    const client = ClientsStore.getById(req.params.id);
    if (!client) return res.status(404).json({ error: "Not found" });
    res.json(client);
  } catch (e) {
    res.status(500).json({ error: String(e) });
  }
});

router.post("/clients", (req, res) => {
  try {
    const body = req.body as any;
    if (!body.name) return res.status(400).json({ error: "name required" });
    const created = ClientsStore.create({
      name: body.name,
      status: body.status ?? "potential",
      telegram: body.telegram ?? body.phone ?? null,
      email: body.email ?? null,
      phone: body.phone ?? null,
      loginLogin: body.loginLogin ?? null,
      loginPassword: body.loginPassword ?? null,
      googleSheetUrl: body.googleSheetUrl ?? body.notes ?? null,
      resourceUrl: body.resourceUrl ?? body.tz ?? null,
      notes: body.notes ?? null,
      contacts: body.contacts ?? [],
      resources: body.resources ?? [],
      monitorings: body.monitorings ?? (body.wallets ? JSON.parse(body.wallets) : []),
    });
    res.status(201).json(created);
  } catch (e) {
    res.status(500).json({ error: String(e) });
  }
});

const updateHandler = (req: any, res: any) => {
  try {
    const body = req.body as any;
    const patch: Record<string, any> = {};
    if (body.name !== undefined) patch.name = body.name;
    if (body.status !== undefined) patch.status = body.status;
    if (body.telegram !== undefined) patch.telegram = body.telegram;
    if (body.email !== undefined) patch.email = body.email;
    if (body.phone !== undefined) patch.phone = body.phone;
    if (body.loginLogin !== undefined) patch.loginLogin = body.loginLogin;
    if (body.loginPassword !== undefined) patch.loginPassword = body.loginPassword;
    if (body.googleSheetUrl !== undefined) patch.googleSheetUrl = body.googleSheetUrl;
    if (body.resourceUrl !== undefined) patch.resourceUrl = body.resourceUrl;
    if (body.notes !== undefined) patch.notes = body.notes;
    if (body.contacts !== undefined) patch.contacts = body.contacts;
    if (body.resources !== undefined) patch.resources = body.resources;
    if (body.monitorings !== undefined) patch.monitorings = body.monitorings;
    if (body.wallets !== undefined) {
      try { patch.monitorings = JSON.parse(body.wallets); } catch { /* ignore */ }
    }

    const updated = ClientsStore.update(req.params.id, patch);
    if (!updated) return res.status(404).json({ error: "Not found" });
    res.json(updated);
  } catch (e) {
    res.status(500).json({ error: String(e) });
  }
};

router.put("/clients/:id", updateHandler);
router.patch("/clients/:id", updateHandler);

router.delete("/clients/:id", (req, res) => {
  try {
    const ok = ClientsStore.delete(req.params.id);
    if (!ok) return res.status(404).json({ error: "Not found" });
    res.json({ ok: true });
  } catch (e) {
    res.status(500).json({ error: String(e) });
  }
});

export default router;
