import { Router } from "express";

const router = Router();

router.post("/contact", async (req, res) => {
  const { email, telegram, message } = req.body as {
    email?: string;
    telegram?: string;
    message?: string;
  };

  if (!email || !telegram) {
    res.status(400).json({ ok: false, error: "email and telegram are required" });
    return;
  }

  const token = process.env.TELEGRAM_BOT_TOKEN;
  const chatId = process.env.TELEGRAM_CHAT_ID;

  if (!token || !chatId) {
    res.status(200).json({ ok: true, note: "Message received" });
    return;
  }

  const text =
    `📩 Новая заявка\n\nE-mail: ${email}\nTg: ${telegram}\nСообщение: ${message || "—"}`;

  try {
    const r = await fetch(`https://api.telegram.org/bot${token}/sendMessage`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ chat_id: chatId, text }),
    });
    const data = await r.json();
    res.json({ ok: data.ok });
  } catch (e) {
    res.status(500).json({ ok: false, error: String(e) });
  }
});

export default router;
