import { Router } from "express";
import { db } from "../../database/index.js";
import { tasks, clients, insertTaskSchema } from "../../database/index.js";
import { eq, desc, and, gte, sql } from "drizzle-orm";

const router = Router();

router.get("/tasks/stats", async (_req, res) => {
  try {
    const now = new Date();
    const startOfToday = new Date(now.getFullYear(), now.getMonth(), now.getDate());

    const allTasks = await db.select().from(tasks);

    const pending = allTasks.filter(t => t.status === "pending").length;
    const doneToday = allTasks.filter(
      t => t.status === "done" && t.completedAt && new Date(t.completedAt) >= startOfToday,
    ).length;
    const clientsInWork = new Set(
      allTasks.filter(t => t.status === "pending" && t.clientId).map(t => t.clientId),
    ).size;

    res.json({ pending, doneToday, clientsInWork });
  } catch (e) {
    res.status(500).json({ error: String(e) });
  }
});

router.get("/tasks", async (_req, res) => {
  try {
    const all = await db.select().from(tasks).orderBy(desc(tasks.createdAt));
    res.json(all);
  } catch (e) {
    res.status(500).json({ error: String(e) });
  }
});

router.post("/tasks", async (req, res) => {
  try {
    const parsed = insertTaskSchema.safeParse(req.body);
    if (!parsed.success) return res.status(400).json({ error: parsed.error });
    const [created] = await db.insert(tasks).values(parsed.data).returning();
    res.status(201).json(created);
  } catch (e) {
    res.status(500).json({ error: String(e) });
  }
});

router.put("/tasks/:id", async (req, res) => {
  try {
    const parsed = insertTaskSchema.partial().safeParse(req.body);
    if (!parsed.success) return res.status(400).json({ error: parsed.error });
    const data = parsed.data as Record<string, unknown>;
    if (data.status === "done" && !data.completedAt) {
      data.completedAt = new Date();
    }
    const [updated] = await db.update(tasks).set(data).where(eq(tasks.id, req.params.id)).returning();
    if (!updated) return res.status(404).json({ error: "Not found" });
    res.json(updated);
  } catch (e) {
    res.status(500).json({ error: String(e) });
  }
});

router.patch("/tasks/:id", async (req, res) => {
  try {
    const parsed = insertTaskSchema.partial().safeParse(req.body);
    if (!parsed.success) return res.status(400).json({ error: parsed.error });
    const data = parsed.data as Record<string, unknown>;
    if (data.status === "done" && !data.completedAt) {
      data.completedAt = new Date();
    }
    const [updated] = await db.update(tasks).set(data).where(eq(tasks.id, req.params.id)).returning();
    if (!updated) return res.status(404).json({ error: "Not found" });
    res.json(updated);
  } catch (e) {
    res.status(500).json({ error: String(e) });
  }
});

router.delete("/tasks/:id", async (req, res) => {
  try {
    const [deleted] = await db.delete(tasks).where(eq(tasks.id, req.params.id)).returning();
    if (!deleted) return res.status(404).json({ error: "Not found" });
    res.json({ ok: true });
  } catch (e) {
    res.status(500).json({ error: String(e) });
  }
});

export default router;
