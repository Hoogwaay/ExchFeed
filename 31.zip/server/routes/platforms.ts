import { Router } from "express";

const router = Router();

const STATIC_PLATFORMS = [
  { id: 1, name: "Яндекс Карты", type: "monitoring", url: "https://yandex.ru/maps" },
  { id: 2, name: "Google Maps", type: "monitoring", url: "https://maps.google.com" },
  { id: 3, name: "2ГИС", type: "monitoring", url: "https://2gis.ru" },
  { id: 4, name: "Яндекс Маркет", type: "monitoring", url: "https://market.yandex.ru" },
  { id: 5, name: "Zoon", type: "monitoring", url: "https://zoon.ru" },
  { id: 6, name: "Flamp", type: "monitoring", url: "https://flamp.ru" },
  { id: 7, name: "TripAdvisor", type: "monitoring", url: "https://tripadvisor.com" },
  { id: 8, name: "Авито", type: "forum", url: "https://avito.ru" },
  { id: 9, name: "Отзовик", type: "forum", url: "https://otzovik.com" },
];

router.get("/platforms", (_req, res) => {
  res.json({ ok: true, platforms: STATIC_PLATFORMS });
});

export default router;
