# Exchange Feed - Trading/CRM Platform

## Project Overview

Exchange Feed is a multi-role trading/CRM platform. The app is in Russian and includes:

- **Public site** — Landing page with loader animation
- **Admin panel** — Dashboard, Clients, Accounting, Schedule, Resources
- **AM panel** (Analytics Manager) — Overview, Customers, Balance, Reviews, Analytics, Campaign, Activity Log, Employees
- **CRM panel** (Worker) — Home, Client Info, Wallet Info
- **Client cabinet** — Individual client view

## Tech Stack

- **Frontend**: React + Vite + Tailwind CSS + Shadcn/UI, Wouter routing, TanStack Query
- **Backend**: Node.js + Express 5 + Pino logging
- **Database**: Three local data stores (see below)
- **Package Manager**: pnpm (single package, no workspaces)
- **Language**: TypeScript throughout

## Local Data Architecture

All data is stored locally in project files — no external database connection required.

### `clients.json` — Client CRM Store
Full client cards in JSON format. Fields per record:
- `id` (UUID) — shared with `Reviews.db` so client_reviews can reference the same client
- `name`, `status` (`in_work`|`potential`|`refused`|`paused`)
- `telegram`, `email`, `phone` — contact channels
- `loginLogin`, `loginPassword` — generated access credentials
- `googleSheetUrl`, `resourceUrl`, `notes`
- `contacts[]` — `{id, type, value, label}` (telegram/email/phone/skype/whatsapp/other)
- `resources[]` — `{id, name, url, language, format}`
- `monitorings[]` — `{id, url, price, period, quantity}`
- `createdAt`

Managed by `database/clients-store.ts`. Every write is also synced back to the `clients` table in `Reviews.db` so FK constraints on `client_reviews.clientId` remain intact.

### `Reviews.db` — SQLite (Drizzle ORM)
Stores: `client_reviews` (10 302 imported rows), `reviews` (aggregates), `tasks`, `schedules`, `resources`, `users`.  
The `clients` table is kept here solely to satisfy FK constraints for `client_reviews.clientId → clients.id`.  
Connection: `database/index.ts` via `better-sqlite3`. Push schema: `pnpm db:push`.

### `Transactions.db` — SQLite (raw better-sqlite3)
Separate payment ledger file. Table `transactions`:
- `id` (UUID), `client_id` (soft ref to `clients.json` id), `type` (`income`|`expense`)
- `amount`, `description`, `notes`, `category`, `date`

Managed by `database/transactions-db.ts`. Table auto-created on first server start.

## Project Structure

```
client/        # React + Vite frontend (port 5000)
  src/
    pages/     # All pages: admin/, am/, crm/, client/, Home.tsx, Login.tsx
    components/# UI components (shadcn/ui + custom)
    api/       # API client (fetch wrapper)
    hooks/     # React hooks
    lib/       # Utilities, types, theme

server/        # Express API (port 8080)
  routes/      # API route files
  lib/         # Logger
  app.ts       # Express app setup + store init
  index.ts     # Server entry point

database/
  schema.ts          # Drizzle schema for Reviews.db
  index.ts           # DB connection + re-exports
  clients-store.ts   # clients.json CRUD manager
  transactions-db.ts # Transactions.db manager
  drizzle.config.ts

scripts/
  migrate-reviews.ts  # Import tool from source SQLite
  post-merge.sh

clients.json       # Client CRM data (project root)
Reviews.db         # SQLite: reviews + tasks + schedules + resources
Transactions.db    # SQLite: payment transactions
```

## Development

- **Start all**: `pnpm dev` (starts both server and client)
- **Client only**: `pnpm dev:client` → port 5000
- **Server only**: `pnpm dev:server` → port 8080
- **DB push** (Reviews.db): `pnpm db:push`

## Environment Variables

- `PORT` — Server port
- `BASE_PATH` — Frontend base path (set to `/` for dev)
- `NODE_ENV` — Environment mode

## Auth (hardcoded)

- Admin: `Admin` / `Admin` → `/admin/login`
- CRM worker: `Work` / `Work` → `/crm/login`
- Client: `User` / `User` → `/login`

## Key Notes

- Frontend: `host: "0.0.0.0"`, `allowedHosts: true` for Replit proxy
- Backend: runs on `localhost:8080`, proxied via Vite `/api`
- Single `package.json` — no pnpm workspaces
- `clients.json` is auto-generated on first server start from the existing `clients` table in Reviews.db
- `Transactions.db` table is auto-created on first server start
