import { useState } from "react";

export default function InfoClients() {
  const [copied, setCopied] = useState(false);
  const value = "https://t.me/exchfeed";

  return (
    <div className="space-y-4">
      <div>
        <h1 className="text-xl font-bold text-[--admin-text]">Клиенты</h1>
        <p className="text-sm text-[--admin-muted] mt-0.5">Контакты и быстрый доступ</p>
      </div>
      <button
        className="admin-card w-full p-4 text-left hover:bg-[--admin-hover] transition-colors"
        onClick={async () => {
          await navigator.clipboard.writeText(value);
          setCopied(true);
          setTimeout(() => setCopied(false), 1500);
        }}
      >
        <div className="text-sm font-medium text-[--admin-text]">Ссылка поддержки</div>
        <div className="text-xs text-[--admin-muted] font-mono mt-1 break-all">{value}</div>
        <div className="text-xs text-[--admin-accent] mt-2">{copied ? "Скопировано" : "Нажмите, чтобы скопировать"}</div>
      </button>
    </div>
  );
}
