export default function InfoWallets() {
  const wallets = [
    { name: "Main Wallet", address: "0xA1b2c3d4e5f678901234567890abcdef12345678" },
    { name: "Reserve Wallet", address: "0xB1b2c3d4e5f678901234567890abcdef12345679" },
  ];

  return (
    <div className="space-y-4">
      <div>
        <h1 className="text-xl font-bold text-[--admin-text]">База знаний</h1>
        <p className="text-sm text-[--admin-muted] mt-0.5">Адреса и заметки для работы</p>
      </div>
      <div className="space-y-3">
        {wallets.map((w) => (
          <div key={w.name} className="admin-card p-4">
            <div className="text-sm font-medium text-[--admin-text]">{w.name}</div>
            <div className="text-xs text-[--admin-muted] font-mono mt-1 break-all">{w.address}</div>
          </div>
        ))}
      </div>
    </div>
  );
}
