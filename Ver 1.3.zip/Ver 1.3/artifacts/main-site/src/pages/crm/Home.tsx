import { useState, useEffect } from "react";

export default function Home() {
  const [time, setTime] = useState(new Date());

  useEffect(() => {
    const id = setInterval(() => setTime(new Date()), 1000);
    return () => clearInterval(id);
  }, []);

  return (
    <div className="admin-card p-6 space-y-4">
      <div>
        <h1 className="text-xl font-bold text-[--admin-text]">Главная</h1>
        <p className="text-sm text-[--admin-muted] mt-0.5">Панель работника активна</p>
      </div>
      <div className="text-sm text-[--admin-muted]">Текущее время: {time.toLocaleTimeString()}</div>
    </div>
  );
}
