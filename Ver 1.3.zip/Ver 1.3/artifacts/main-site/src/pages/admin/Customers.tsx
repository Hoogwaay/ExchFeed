import { useQuery, useMutation } from "@tanstack/react-query";
import { useState } from "react";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { insertClientSchema, type Client, type InsertClient } from "@shared/schema";
import { z } from "zod";
import { Plus, Pencil, Trash2, Search } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Form, FormField, FormItem, FormLabel, FormControl, FormMessage } from "@/components/ui/form";
import { Badge } from "@/components/ui/badge";

const formSchema = insertClientSchema.extend({
  name: z.string().min(1, "Name is required"),
});

const STATUS_LABELS: Record<string, { label: string; color: string }> = {
  in_work: { label: "In Work", color: "bg-green-100 text-green-700 dark:bg-green-900/40 dark:text-green-400" },
  potential: { label: "Potential", color: "bg-blue-100 text-blue-700 dark:bg-blue-900/40 dark:text-blue-400" },
  paused: { label: "Paused", color: "bg-yellow-100 text-yellow-700 dark:bg-yellow-900/40 dark:text-yellow-400" },
  refused: { label: "Refused", color: "bg-red-100 text-red-700 dark:bg-red-900/40 dark:text-red-400" },
};

function ClientForm({
  defaultValues,
  onSubmit,
  isPending,
}: {
  defaultValues: Partial<InsertClient>;
  onSubmit: (data: InsertClient) => void;
  isPending: boolean;
}) {
  const form = useForm<InsertClient>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      name: "",
      email: "",
      phone: "",
      status: "potential",
      notes: "",
      ...defaultValues,
    },
  });

  return (
    <Form {...form}>
      <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-4">
        <FormField control={form.control} name="name" render={({ field }) => (
          <FormItem>
            <FormLabel>Name *</FormLabel>
            <FormControl><Input data-testid="input-client-name" placeholder="Client name" {...field} className="admin-input" /></FormControl>
            <FormMessage />
          </FormItem>
        )} />
        <div className="grid grid-cols-2 gap-3">
          <FormField control={form.control} name="email" render={({ field }) => (
            <FormItem>
              <FormLabel>Email</FormLabel>
              <FormControl><Input data-testid="input-client-email" placeholder="email@example.com" {...field} value={field.value ?? ""} className="admin-input" /></FormControl>
              <FormMessage />
            </FormItem>
          )} />
          <FormField control={form.control} name="phone" render={({ field }) => (
            <FormItem>
              <FormLabel>Phone</FormLabel>
              <FormControl><Input data-testid="input-client-phone" placeholder="+1 234 567 890" {...field} value={field.value ?? ""} className="admin-input" /></FormControl>
              <FormMessage />
            </FormItem>
          )} />
        </div>
        <FormField control={form.control} name="status" render={({ field }) => (
          <FormItem>
            <FormLabel>Status</FormLabel>
            <Select onValueChange={field.onChange} defaultValue={field.value}>
              <FormControl>
                <SelectTrigger data-testid="select-client-status" className="admin-select">
                  <SelectValue placeholder="Select status" />
                </SelectTrigger>
              </FormControl>
              <SelectContent>
                <SelectItem value="in_work">In Work</SelectItem>
                <SelectItem value="potential">Potential</SelectItem>
                <SelectItem value="paused">Paused</SelectItem>
                <SelectItem value="refused">Refused</SelectItem>
              </SelectContent>
            </Select>
            <FormMessage />
          </FormItem>
        )} />
        <FormField control={form.control} name="notes" render={({ field }) => (
          <FormItem>
            <FormLabel>Notes</FormLabel>
            <FormControl>
              <textarea
                data-testid="input-client-notes"
                placeholder="Notes about this client..."
                {...field}
                value={field.value ?? ""}
                className="admin-input w-full min-h-[80px] resize-none rounded-md border border-admin-border bg-admin-input px-3 py-2 text-sm text-admin-text placeholder:text-admin-muted focus:outline-none focus:ring-2 focus:ring-admin-accent"
              />
            </FormControl>
            <FormMessage />
          </FormItem>
        )} />
        <DialogFooter>
          <Button data-testid="btn-submit-client" type="submit" disabled={isPending} className="admin-btn-primary">
            {isPending ? "Saving…" : "Save"}
          </Button>
        </DialogFooter>
      </form>
    </Form>
  );
}

export default function Customers() {
  const { toast } = useToast();
  const [search, setSearch] = useState("");
  const [statusFilter, setStatusFilter] = useState<string>("all");
  const [dialogOpen, setDialogOpen] = useState(false);
  const [editingClient, setEditingClient] = useState<Client | null>(null);
  const [deleteTarget, setDeleteTarget] = useState<Client | null>(null);

  const { data: clients = [], isLoading } = useQuery<Client[]>({ queryKey: ["/api/clients"] });

  const createMutation = useMutation({
    mutationFn: (data: InsertClient) => apiRequest("POST", "/api/clients", data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/clients"] });
      toast({ title: "Client created" });
      setDialogOpen(false);
    },
    onError: () => toast({ title: "Failed to create client", variant: "destructive" }),
  });

  const updateMutation = useMutation({
    mutationFn: ({ id, data }: { id: string; data: Partial<InsertClient> }) =>
      apiRequest("PATCH", `/api/clients/${id}`, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/clients"] });
      toast({ title: "Client updated" });
      setDialogOpen(false);
      setEditingClient(null);
    },
    onError: () => toast({ title: "Failed to update client", variant: "destructive" }),
  });

  const deleteMutation = useMutation({
    mutationFn: (id: string) => apiRequest("DELETE", `/api/clients/${id}`),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/clients"] });
      toast({ title: "Client deleted" });
      setDeleteTarget(null);
    },
    onError: () => toast({ title: "Failed to delete client", variant: "destructive" }),
  });

  const filtered = clients.filter(c => {
    const matchSearch = c.name.toLowerCase().includes(search.toLowerCase()) ||
      (c.email?.toLowerCase().includes(search.toLowerCase()) ?? false);
    const matchStatus = statusFilter === "all" || c.status === statusFilter;
    return matchSearch && matchStatus;
  });

  const openAdd = () => { setEditingClient(null); setDialogOpen(true); };
  const openEdit = (c: Client) => { setEditingClient(c); setDialogOpen(true); };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-admin-text">Customers</h1>
          <p className="text-admin-muted text-sm mt-1">Manage your client base</p>
        </div>
        <Button data-testid="btn-add-client" onClick={openAdd} className="admin-btn-primary">
          <Plus size={16} className="mr-1.5" /> Add Client
        </Button>
      </div>

      <div className="flex flex-col sm:flex-row gap-3">
        <div className="relative flex-1">
          <Search size={15} className="absolute left-3 top-1/2 -translate-y-1/2 text-admin-muted" />
          <Input
            data-testid="input-search-clients"
            placeholder="Search by name or email..."
            value={search}
            onChange={e => setSearch(e.target.value)}
            className="pl-9 admin-input"
          />
        </div>
        <Select value={statusFilter} onValueChange={setStatusFilter}>
          <SelectTrigger data-testid="select-filter-status" className="w-40 admin-select">
            <SelectValue placeholder="All statuses" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Statuses</SelectItem>
            <SelectItem value="in_work">In Work</SelectItem>
            <SelectItem value="potential">Potential</SelectItem>
            <SelectItem value="paused">Paused</SelectItem>
            <SelectItem value="refused">Refused</SelectItem>
          </SelectContent>
        </Select>
      </div>

      <div className="admin-card overflow-hidden">
        {isLoading ? (
          <div className="p-8 text-center text-admin-muted text-sm">Loading…</div>
        ) : filtered.length === 0 ? (
          <div className="p-8 text-center text-admin-muted text-sm">No clients found</div>
        ) : (
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-admin-border">
                <th className="text-left px-4 py-3 text-admin-muted font-medium">Name</th>
                <th className="text-left px-4 py-3 text-admin-muted font-medium hidden sm:table-cell">Email</th>
                <th className="text-left px-4 py-3 text-admin-muted font-medium hidden md:table-cell">Phone</th>
                <th className="text-left px-4 py-3 text-admin-muted font-medium">Status</th>
                <th className="text-left px-4 py-3 text-admin-muted font-medium hidden lg:table-cell">Notes</th>
                <th className="text-right px-4 py-3 text-admin-muted font-medium">Actions</th>
              </tr>
            </thead>
            <tbody>
              {filtered.map((c, i) => {
                const st = STATUS_LABELS[c.status];
                return (
                  <tr key={c.id} data-testid={`row-client-${c.id}`}
                    className={`border-b border-admin-border last:border-0 hover:bg-admin-hover transition-colors ${i % 2 === 0 ? "" : ""}`}>
                    <td className="px-4 py-3 font-medium text-admin-text">{c.name}</td>
                    <td className="px-4 py-3 text-admin-muted hidden sm:table-cell">{c.email || "—"}</td>
                    <td className="px-4 py-3 text-admin-muted hidden md:table-cell">{c.phone || "—"}</td>
                    <td className="px-4 py-3">
                      <span className={`inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium ${st.color}`}>
                        {st.label}
                      </span>
                    </td>
                    <td className="px-4 py-3 text-admin-muted hidden lg:table-cell max-w-[200px] truncate">{c.notes || "—"}</td>
                    <td className="px-4 py-3">
                      <div className="flex items-center justify-end gap-1">
                        <button
                          data-testid={`btn-edit-client-${c.id}`}
                          onClick={() => openEdit(c)}
                          className="p-1.5 rounded-md text-admin-muted hover:text-admin-text hover:bg-admin-hover transition-colors"
                        >
                          <Pencil size={14} />
                        </button>
                        <button
                          data-testid={`btn-delete-client-${c.id}`}
                          onClick={() => setDeleteTarget(c)}
                          className="p-1.5 rounded-md text-admin-muted hover:text-red-500 hover:bg-red-50 dark:hover:bg-red-900/20 transition-colors"
                        >
                          <Trash2 size={14} />
                        </button>
                      </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        )}
      </div>

      <Dialog open={dialogOpen} onOpenChange={o => { setDialogOpen(o); if (!o) setEditingClient(null); }}>
        <DialogContent className="admin-dialog">
          <DialogHeader>
            <DialogTitle className="text-admin-text">{editingClient ? "Edit Client" : "Add Client"}</DialogTitle>
          </DialogHeader>
          <ClientForm
            defaultValues={editingClient ?? {}}
            onSubmit={data => {
              if (editingClient) {
                updateMutation.mutate({ id: editingClient.id, data });
              } else {
                createMutation.mutate(data);
              }
            }}
            isPending={createMutation.isPending || updateMutation.isPending}
          />
        </DialogContent>
      </Dialog>

      <Dialog open={!!deleteTarget} onOpenChange={o => { if (!o) setDeleteTarget(null); }}>
        <DialogContent className="admin-dialog">
          <DialogHeader>
            <DialogTitle className="text-admin-text">Delete Client</DialogTitle>
          </DialogHeader>
          <p className="text-admin-muted text-sm">
            Are you sure you want to delete <strong className="text-admin-text">{deleteTarget?.name}</strong>? This action cannot be undone.
          </p>
          <DialogFooter className="gap-2">
            <Button variant="outline" onClick={() => setDeleteTarget(null)} className="admin-btn-outline">Cancel</Button>
            <Button
              data-testid="btn-confirm-delete-client"
              onClick={() => deleteTarget && deleteMutation.mutate(deleteTarget.id)}
              disabled={deleteMutation.isPending}
              className="bg-red-600 hover:bg-red-700 text-white"
            >
              {deleteMutation.isPending ? "Deleting…" : "Delete"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
