import { useQuery } from "@tanstack/react-query";
import { useState } from "react";
import { BarChart, Bar, XAxis, YAxis, Tooltip, ResponsiveContainer, CartesianGrid } from "recharts";
import { Star, DollarSign, Users, TrendingUp, ArrowUpRight, ArrowDownLeft } from "lucide-react";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import type { Client, Transaction, Review } from "@shared/schema";

type Period = "day" | "week" | "month";
type RecentCount = "5" | "10" | "15" | "50";

interface Stats {
  totalAllTime: number;
  totalThisMonth: number;
  totalEarned: string;
  byDay: { date: string; count: number }[];
  byWeek: { date: string; count: number }[];
  byMonth: { date: string; count: number }[];
}

function StatCard({ icon: Icon, label, value, sub }: {
  icon: typeof Star;
  label: string;
  value: string | number;
  sub?: string;
}) {
  return (
    <div className="admin-card p-5 flex items-start gap-4">
      <div className="w-11 h-11 rounded-xl bg-admin-accent/10 flex items-center justify-center shrink-0">
        <Icon size={20} className="text-admin-accent" />
      </div>
      <div className="min-w-0">
        <p className="text-admin-muted text-xs font-medium uppercase tracking-wide mb-1">{label}</p>
        <p className="text-admin-text text-2xl font-bold">{value}</p>
        {sub && <p className="text-admin-muted text-xs mt-0.5">{sub}</p>}
      </div>
    </div>
  );
}

export default function Overview() {
  const [period, setPeriod] = useState<Period>("day");
  const [txCount, setTxCount] = useState<RecentCount>("5");
  const [dayCount, setDayCount] = useState<RecentCount>("5");

  const { data: stats, isLoading: statsLoading } = useQuery<Stats>({ queryKey: ["/api/reviews/stats"] });
  const { data: clients = [] } = useQuery<Client[]>({ queryKey: ["/api/clients"] });
  const { data: transactions = [] } = useQuery<Transaction[]>({ queryKey: ["/api/transactions"] });
  const { data: reviews = [] } = useQuery<Review[]>({ queryKey: ["/api/reviews"] });

  const inWork = clients.filter(c => c.status === "in_work").length;
  const paused = clients.filter(c => c.status === "paused").length;
  const potential = clients.filter(c => c.status === "potential").length;
  const refused = clients.filter(c => c.status === "refused").length;

  const chartData = stats
    ? period === "day" ? stats.byDay
      : period === "week" ? stats.byWeek
      : stats.byMonth
    : [];

  const recentTx = transactions.slice(0, parseInt(txCount));

  const reviewsByDay = reviews.reduce((acc, r) => {
    const day = new Date(r.date).toISOString().split("T")[0];
    acc[day] = (acc[day] || 0) + r.count;
    return acc;
  }, {} as Record<string, number>);

  const recentDays = Object.entries(reviewsByDay)
    .sort((a, b) => b[0].localeCompare(a[0]))
    .slice(0, parseInt(dayCount));

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold text-admin-text">Overview</h1>
        <p className="text-admin-muted text-sm mt-1">Dashboard with key metrics</p>
      </div>

      <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-4 gap-4">
        <StatCard
          icon={Star}
          label="Total Reviews (All Time)"
          value={statsLoading ? "…" : stats?.totalAllTime ?? 0}
        />
        <StatCard
          icon={TrendingUp}
          label="Reviews This Month"
          value={statsLoading ? "…" : stats?.totalThisMonth ?? 0}
          sub="Current month"
        />
        <StatCard
          icon={Users}
          label="Clients In Work / Paused"
          value={`${inWork} / ${paused}`}
          sub="Active clients"
        />
        <StatCard
          icon={DollarSign}
          label="Total Earned"
          value={statsLoading ? "…" : `$${parseFloat(stats?.totalEarned || "0").toLocaleString()}`}
          sub="All time"
        />
      </div>

      <div className="grid grid-cols-1 xl:grid-cols-3 gap-4">
        <div className="xl:col-span-2 admin-card p-5">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-admin-text font-semibold">Reviews Over Time</h2>
            <Select value={period} onValueChange={v => setPeriod(v as Period)}>
              <SelectTrigger data-testid="select-chart-period" className="w-32 h-8 text-xs admin-select">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="day">By Day</SelectItem>
                <SelectItem value="week">By Week</SelectItem>
                <SelectItem value="month">By Month</SelectItem>
              </SelectContent>
            </Select>
          </div>
          {chartData.length === 0 ? (
            <div className="h-48 flex items-center justify-center text-admin-muted text-sm">
              No data yet. Add reviews to see the chart.
            </div>
          ) : (
            <ResponsiveContainer width="100%" height={220}>
              <BarChart data={chartData} margin={{ top: 0, right: 0, left: -20, bottom: 0 }}>
                <CartesianGrid strokeDasharray="3 3" stroke="var(--admin-border-color)" />
                <XAxis dataKey="date" tick={{ fontSize: 11, fill: "var(--admin-muted-color)" }} />
                <YAxis tick={{ fontSize: 11, fill: "var(--admin-muted-color)" }} allowDecimals={false} />
                <Tooltip
                  contentStyle={{
                    background: "var(--admin-card-bg)",
                    border: "1px solid var(--admin-border-color)",
                    borderRadius: "8px",
                    color: "var(--admin-text-color)"
                  }}
                />
                <Bar dataKey="count" fill="var(--admin-accent-color)" radius={[4, 4, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          )}
        </div>

        <div className="admin-card p-5">
          <h2 className="text-admin-text font-semibold mb-4">Clients Summary</h2>
          <div className="space-y-3">
            {[
              { label: "In Work", value: inWork, color: "bg-green-500" },
              { label: "Potential", value: potential, color: "bg-admin-accent" },
              { label: "Paused", value: paused, color: "bg-yellow-500" },
              { label: "Refused", value: refused, color: "bg-red-500" },
            ].map(({ label, value, color }) => (
              <div key={label} className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <div className={`w-2.5 h-2.5 rounded-full ${color}`} />
                  <span className="text-sm text-admin-muted">{label}</span>
                </div>
                <span className="text-sm font-semibold text-admin-text">{value}</span>
              </div>
            ))}
          </div>
          <div className="mt-4 pt-4 border-t border-admin-border">
            <div className="flex items-center justify-between">
              <span className="text-sm text-admin-muted">Total Clients</span>
              <span className="text-sm font-bold text-admin-text">{clients.length}</span>
            </div>
          </div>
        </div>
      </div>

      <div className="grid grid-cols-1 xl:grid-cols-2 gap-4">
        <div className="admin-card p-5">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-admin-text font-semibold">Recent Payments</h2>
            <Select value={txCount} onValueChange={v => setTxCount(v as RecentCount)}>
              <SelectTrigger data-testid="select-tx-count" className="w-24 h-8 text-xs admin-select">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="5">Last 5</SelectItem>
                <SelectItem value="10">Last 10</SelectItem>
                <SelectItem value="15">Last 15</SelectItem>
                <SelectItem value="50">Last 50</SelectItem>
              </SelectContent>
            </Select>
          </div>
          {recentTx.length === 0 ? (
            <p className="text-admin-muted text-sm text-center py-6">No payments yet</p>
          ) : (
            <div className="space-y-2">
              {recentTx.map(tx => (
                <div key={tx.id} className="flex items-center justify-between py-2 border-b border-admin-border last:border-0">
                  <div className="flex items-center gap-2.5">
                    <div className={`w-8 h-8 rounded-full flex items-center justify-center ${tx.type === "income" ? "bg-green-100 dark:bg-green-900/30" : "bg-red-100 dark:bg-red-900/30"}`}>
                      {tx.type === "income"
                        ? <ArrowUpRight size={14} className="text-green-600 dark:text-green-400" />
                        : <ArrowDownLeft size={14} className="text-red-600 dark:text-red-400" />}
                    </div>
                    <div>
                      <p className="text-sm text-admin-text font-medium">{tx.description || (tx.type === "income" ? "Income" : "Expense")}</p>
                      <p className="text-xs text-admin-muted">{new Date(tx.date).toLocaleDateString()}</p>
                    </div>
                  </div>
                  <span className={`text-sm font-semibold ${tx.type === "income" ? "text-green-600 dark:text-green-400" : "text-red-600 dark:text-red-400"}`}>
                    {tx.type === "income" ? "+" : "-"}${parseFloat(tx.amount).toLocaleString()}
                  </span>
                </div>
              ))}
            </div>
          )}
        </div>

        <div className="admin-card p-5">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-admin-text font-semibold">Reviews by Day</h2>
            <Select value={dayCount} onValueChange={v => setDayCount(v as RecentCount)}>
              <SelectTrigger data-testid="select-day-count" className="w-24 h-8 text-xs admin-select">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="5">Last 5</SelectItem>
                <SelectItem value="10">Last 10</SelectItem>
                <SelectItem value="15">Last 15</SelectItem>
                <SelectItem value="50">Last 50</SelectItem>
              </SelectContent>
            </Select>
          </div>
          {recentDays.length === 0 ? (
            <p className="text-admin-muted text-sm text-center py-6">No reviews yet</p>
          ) : (
            <div className="space-y-2">
              {recentDays.map(([date, count]) => (
                <div key={date} className="flex items-center justify-between py-2 border-b border-admin-border last:border-0">
                  <div className="flex items-center gap-2.5">
                    <div className="w-8 h-8 rounded-full bg-admin-accent/10 flex items-center justify-center">
                      <Star size={14} className="text-admin-accent" />
                    </div>
                    <p className="text-sm text-admin-muted">{date}</p>
                  </div>
                  <div className="flex items-center gap-1">
                    <span className="text-sm font-semibold text-admin-text">{count}</span>
                    <span className="text-xs text-admin-muted">reviews</span>
                  </div>
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
