import { useEffect, useState, useRef } from "react";

interface LoaderProps {
  onDone: () => void;
}

export default function Loader({ onDone }: LoaderProps) {
  const [progress, setProgress] = useState(0);
  const [phase, setPhase] = useState<"counting" | "exit">("counting");
  const rafRef = useRef<number | null>(null);
  const startRef = useRef<number>(Date.now());
  const DURATION = 2400;

  useEffect(() => {
    startRef.current = Date.now();

    function tick() {
      const elapsed = Date.now() - startRef.current;
      const t = Math.min(elapsed / DURATION, 1);
      const eased = t < 0.5 ? 2 * t * t : -1 + (4 - 2 * t) * t;
      const val = Math.floor(eased * 100);
      setProgress(val);

      if (t < 1) {
        rafRef.current = requestAnimationFrame(tick);
      } else {
        setProgress(100);
        setTimeout(() => {
          setPhase("exit");
          setTimeout(onDone, 1100);
        }, 160);
      }
    }

    rafRef.current = requestAnimationFrame(tick);
    return () => {
      if (rafRef.current) cancelAnimationFrame(rafRef.current);
    };
  }, [onDone]);

  const exiting = phase === "exit";

  return (
    <>
      <style>{`
        @keyframes ldr-line-in {
          from { transform: scaleX(0); }
          to   { transform: scaleX(1); }
        }
        @keyframes ldr-fade-up {
          from { opacity: 0; transform: translateY(18px); }
          to   { opacity: 1; transform: translateY(0); }
        }
      `}</style>

      {/* ── Curtain panel – slides UP on exit ── */}
      <div
        style={{
          position: "fixed",
          inset: 0,
          zIndex: 99998,
          background: "#050505",
          transform: exiting ? "translateY(-100%)" : "translateY(0)",
          transition: exiting
            ? "transform 1s cubic-bezier(0.76, 0, 0.24, 1)"
            : "none",
          pointerEvents: exiting ? "none" : "all",
        }}
      />

      {/* ── Content layer – fades out just before curtain lifts ── */}
      <div
        style={{
          position: "fixed",
          inset: 0,
          zIndex: 99999,
          display: "flex",
          flexDirection: "column",
          justifyContent: "space-between",
          padding: "40px 52px",
          pointerEvents: "none",
          opacity: exiting ? 0 : 1,
          transition: exiting ? "opacity 0.28s ease" : "none",
        }}
      >
        {/* Top row */}
        <div
          style={{
            display: "flex",
            justifyContent: "space-between",
            alignItems: "flex-start",
            animation: "ldr-fade-up 0.7s cubic-bezier(0.16,1,0.3,1) 0.1s both",
          }}
        >
          <div
            style={{
              fontFamily: "monospace",
              fontSize: "0.78rem",
              fontWeight: 700,
              letterSpacing: 5,
              color: "rgba(255,255,255,0.55)",
              textTransform: "uppercase",
            }}
          >
            Exchange Feed
          </div>
          <div
            style={{
              fontFamily: "monospace",
              fontSize: "0.6rem",
              letterSpacing: 4,
              color: "rgba(255,255,255,0.2)",
              textTransform: "uppercase",
            }}
          >
            {progress < 30
              ? "Инициализация"
              : progress < 65
              ? "Загрузка данных"
              : progress < 95
              ? "Подготовка"
              : "Готово"}
          </div>
        </div>

        {/* Center: huge number */}
        <div
          style={{
            display: "flex",
            flexDirection: "column",
            alignItems: "flex-start",
            gap: 0,
            animation: "ldr-fade-up 0.8s cubic-bezier(0.16,1,0.3,1) 0.2s both",
          }}
        >
          <div
            style={{
              fontFamily: "'Inter', monospace",
              fontSize: "clamp(7rem, 20vw, 18rem)",
              fontWeight: 900,
              lineHeight: 0.88,
              letterSpacing: "-0.04em",
              color: "#fff",
              userSelect: "none",
              display: "flex",
              alignItems: "flex-start",
            }}
          >
            <span style={{ minWidth: "2.6ch", display: "inline-block", textAlign: "right" }}>
              {progress}
            </span>
            <span
              style={{
                fontSize: "clamp(2rem, 6vw, 5rem)",
                color: "#c9ff47",
                letterSpacing: "-0.02em",
                marginTop: "0.15em",
                marginLeft: "0.06em",
              }}
            >
              %
            </span>
          </div>

          {/* Thin progress line below the number */}
          <div
            style={{
              marginTop: 36,
              width: "min(520px, 55vw)",
              height: 1,
              background: "rgba(255,255,255,0.08)",
              position: "relative",
              overflow: "hidden",
            }}
          >
            <div
              style={{
                position: "absolute",
                inset: 0,
                right: `${100 - progress}%`,
                background: "#c9ff47",
                transition: "right 0.06s linear",
              }}
            />
          </div>
        </div>

        {/* Bottom row */}
        <div
          style={{
            display: "flex",
            justifyContent: "space-between",
            alignItems: "flex-end",
            animation: "ldr-fade-up 0.7s cubic-bezier(0.16,1,0.3,1) 0.35s both",
          }}
        >
          <div
            style={{
              fontFamily: "monospace",
              fontSize: "0.6rem",
              letterSpacing: 4,
              color: "rgba(255,255,255,0.18)",
              textTransform: "uppercase",
            }}
          >
            Репутация · Отзывы · Аналитика
          </div>
          <div
            style={{
              fontFamily: "monospace",
              fontSize: "0.6rem",
              letterSpacing: 3,
              color: "rgba(255,255,255,0.18)",
              textTransform: "uppercase",
            }}
          >
            {new Date().getFullYear()}
          </div>
        </div>
      </div>
    </>
  );
}
