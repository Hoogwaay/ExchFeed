import { sql } from "drizzle-orm";
import { pgTable, text, varchar, integer, timestamp, numeric, pgEnum } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod/v4";

export const users = pgTable("users", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
});
export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;

export const clientStatusEnum = pgEnum("client_status", ["in_work", "potential", "refused", "paused"]);

export const clients = pgTable("clients", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  name: text("name").notNull(),
  email: text("email"),
  phone: text("phone"),
  status: clientStatusEnum("status").notNull().default("potential"),
  notes: text("notes"),
  tz: text("tz"),
  wallets: text("wallets"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
});

export const insertClientSchema = createInsertSchema(clients).omit({ id: true, createdAt: true });
export type InsertClient = z.infer<typeof insertClientSchema>;
export type Client = typeof clients.$inferSelect;

export const reviews = pgTable("reviews", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  clientId: varchar("client_id").references(() => clients.id),
  count: integer("count").notNull().default(1),
  earnedAmount: numeric("earned_amount", { precision: 12, scale: 2 }).notNull().default("0"),
  date: timestamp("date").defaultNow().notNull(),
  notes: text("notes"),
});

export const insertReviewSchema = createInsertSchema(reviews).omit({ id: true });
export type InsertReview = z.infer<typeof insertReviewSchema>;
export type Review = typeof reviews.$inferSelect;

export const transactionTypeEnum = pgEnum("transaction_type", ["income", "expense"]);

export const transactions = pgTable("transactions", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  type: transactionTypeEnum("type").notNull(),
  amount: numeric("amount", { precision: 12, scale: 2 }).notNull(),
  description: text("description"),
  date: timestamp("date").defaultNow().notNull(),
});

export const insertTransactionSchema = createInsertSchema(transactions).omit({ id: true });
export type InsertTransaction = z.infer<typeof insertTransactionSchema>;
export type Transaction = typeof transactions.$inferSelect;

export const taskStatusEnum = pgEnum("task_status", ["pending", "done", "rejected"]);
export const reviewLangEnum = pgEnum("review_lang", ["RU", "EN"]);

export const tasks = pgTable("tasks", {
  id: varchar("id").primaryKey().default(sql`gen_random_uuid()`),
  clientId: varchar("client_id").references(() => clients.id),
  reviewLanguage: reviewLangEnum("review_language").notNull().default("RU"),
  reviewText: text("review_text").notNull(),
  reviewAmount: numeric("review_amount", { precision: 12, scale: 2 }).notNull().default("0"),
  reviewerName: text("reviewer_name").notNull().default(""),
  loginEmail: text("login_email"),
  loginPassword: text("login_password"),
  confirmLink: text("confirm_link"),
  service: text("service"),
  reviewType: text("review_type"),
  taskNumber: text("task_number"),
  status: taskStatusEnum("status").notNull().default("pending"),
  createdAt: timestamp("created_at").defaultNow().notNull(),
  completedAt: timestamp("completed_at"),
});

export const insertTaskSchema = createInsertSchema(tasks)
  .omit({ id: true, createdAt: true, completedAt: true });
export type InsertTask = z.infer<typeof insertTaskSchema>;
export type Task = typeof tasks.$inferSelect;
