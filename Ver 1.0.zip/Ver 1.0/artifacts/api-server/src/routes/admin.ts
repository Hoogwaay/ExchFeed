import { Router } from "express";

const router = Router();

const ADMIN_LOGIN = process.env.ADMIN_LOGIN || "admin";
const ADMIN_PASSWORD = process.env.ADMIN_PASSWORD || "admin123";

router.post("/admin/login", (req, res) => {
  const { login, password } = req.body as { login?: string; password?: string };
  if (login === ADMIN_LOGIN && password === ADMIN_PASSWORD) {
    res.json({ ok: true, token: "admin-session-valid", role: "admin" });
    return;
  }
  res.status(401).json({ ok: false, error: "Неверный логин или пароль" });
});

export default router;
