import { Router } from "express";
import { db } from "@workspace/db";
import { tasks, insertTaskSchema } from "@workspace/db";
import { eq, desc } from "drizzle-orm";

const router = Router();

router.get("/tasks", async (_req, res) => {
  try {
    const all = await db.select().from(tasks).orderBy(desc(tasks.createdAt));
    res.json(all);
  } catch (e) {
    res.status(500).json({ error: String(e) });
  }
});

router.post("/tasks", async (req, res) => {
  try {
    const parsed = insertTaskSchema.safeParse(req.body);
    if (!parsed.success) return res.status(400).json({ error: parsed.error });
    const [created] = await db.insert(tasks).values(parsed.data).returning();
    res.status(201).json(created);
  } catch (e) {
    res.status(500).json({ error: String(e) });
  }
});

router.put("/tasks/:id", async (req, res) => {
  try {
    const parsed = insertTaskSchema.partial().safeParse(req.body);
    if (!parsed.success) return res.status(400).json({ error: parsed.error });
    const [updated] = await db.update(tasks).set(parsed.data).where(eq(tasks.id, req.params.id)).returning();
    if (!updated) return res.status(404).json({ error: "Not found" });
    res.json(updated);
  } catch (e) {
    res.status(500).json({ error: String(e) });
  }
});

router.delete("/tasks/:id", async (req, res) => {
  try {
    const [deleted] = await db.delete(tasks).where(eq(tasks.id, req.params.id)).returning();
    if (!deleted) return res.status(404).json({ error: "Not found" });
    res.json({ ok: true });
  } catch (e) {
    res.status(500).json({ error: String(e) });
  }
});

export default router;
