import { useEffect, useState, useCallback } from "react";
import {
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Brush,
} from "recharts";
import AdminLayout from "./AdminLayout";

interface Stats {
  clientsActive: number;
  clientsPaused: number;
  reviewsToday: number;
  reviewsDoneThisMonth: number;
  reviewsRemainingThisMonth: number;
  reviewsTotalThisMonth: number;
  chartData: { date: string; count: number }[];
  earningsPerMonth: number;
  reviewsAllTime: number;
  earningsAllTime: number;
}

type Period = "day" | "week" | "month";
type Range = "month" | "3months" | "year" | "all";

const C = "#c9ff47";
const CARD_BG = "hsl(240 12% 8%)";
const BORDER = "hsl(240 10% 15%)";

function StatCard({ label, value, sub, accent }: { label: string; value: string | number; sub?: string; accent?: boolean }) {
  return (
    <div style={{
      background: CARD_BG, border: `1px solid ${accent ? "rgba(201,255,71,0.2)" : BORDER}`,
      borderRadius: 10, padding: "24px 28px",
    }}>
      <div style={{ fontSize: "0.75rem", color: "hsl(0 0% 55%)", fontWeight: 500, marginBottom: 12, textTransform: "uppercase", letterSpacing: 1 }}>
        {label}
      </div>
      <div style={{ fontSize: "2rem", fontWeight: 800, color: accent ? C : "#fff", lineHeight: 1 }}>
        {value}
      </div>
      {sub && <div style={{ fontSize: "0.8rem", color: "hsl(0 0% 45%)", marginTop: 8 }}>{sub}</div>}
    </div>
  );
}

function formatDateLabel(date: string, period: Period): string {
  if (period === "month") {
    const [y, m] = date.split("-");
    const d = new Date(Number(y), Number(m) - 1, 1);
    return d.toLocaleString("ru-RU", { month: "short", year: "2-digit" });
  }
  if (period === "week") {
    const parts = date.split("-");
    return `${parts[2]}.${parts[1]}`;
  }
  const parts = date.split("-");
  return `${parts[2]}.${parts[1]}`;
}

const PERIOD_OPTIONS: { value: Period; label: string }[] = [
  { value: "day", label: "По дням" },
  { value: "week", label: "По неделям" },
  { value: "month", label: "По месяцам" },
];

const RANGE_OPTIONS: { value: Range; label: string }[] = [
  { value: "month", label: "Этот месяц" },
  { value: "3months", label: "3 месяца" },
  { value: "year", label: "Год" },
  { value: "all", label: "Всё время" },
];

function ChartBlock({
  chartData,
  period,
  expanded,
}: {
  chartData: { date: string; count: number }[];
  period: Period;
  expanded: boolean;
}) {
  const height = expanded ? 420 : 220;
  const showBrush = chartData.length > 20;

  return (
    <ResponsiveContainer width="100%" height={height}>
      <BarChart data={chartData} margin={{ top: 4, right: 8, left: -10, bottom: 0 }}>
        <CartesianGrid strokeDasharray="3 3" stroke="hsl(240 10% 15%)" vertical={false} />
        <XAxis
          dataKey="date"
          tick={{ fill: "hsl(0 0% 45%)", fontSize: 11 }}
          tickFormatter={(v) => formatDateLabel(v, period)}
          axisLine={false} tickLine={false}
          interval={chartData.length > 30 ? Math.floor(chartData.length / 15) : 0}
        />
        <YAxis tick={{ fill: "hsl(0 0% 45%)", fontSize: 11 }} axisLine={false} tickLine={false} />
        <Tooltip
          contentStyle={{ background: "hsl(240 12% 10%)", border: "1px solid hsl(240 10% 20%)", borderRadius: 6, fontSize: 12 }}
          labelStyle={{ color: "#fff" }}
          itemStyle={{ color: C }}
          labelFormatter={(v) => formatDateLabel(String(v), period)}
          formatter={(v: number) => [v, "Отзывов"]}
        />
        <Bar dataKey="count" fill={C} radius={[4, 4, 0, 0]} name="Отзывов" />
        {showBrush && (
          <Brush
            dataKey="date"
            height={24}
            stroke="hsl(240 10% 20%)"
            fill="hsl(240 12% 8%)"
            tickFormatter={(v) => formatDateLabel(String(v), period)}
            travellerWidth={6}
          />
        )}
      </BarChart>
    </ResponsiveContainer>
  );
}

export default function Dashboard() {
  const [stats, setStats] = useState<Stats | null>(null);
  const [loading, setLoading] = useState(true);
  const [syncing, setSyncing] = useState(false);
  const [syncResult, setSyncResult] = useState<{ ok: boolean; synced?: number; errors?: string[] } | null>(null);

  const [period, setPeriod] = useState<Period>("day");
  const [range, setRange] = useState<Range>("month");
  const [chartData, setChartData] = useState<{ date: string; count: number }[]>([]);
  const [chartLoading, setChartLoading] = useState(false);
  const [chartExpanded, setChartExpanded] = useState(false);

  const loadStats = useCallback(() => {
    setLoading(true);
    fetch("/api/admin/reviews/stats")
      .then((r) => r.json())
      .then((d) => { if (d.ok) setStats(d.stats); })
      .finally(() => setLoading(false));
  }, []);

  const loadChartData = useCallback(() => {
    setChartLoading(true);
    fetch(`/api/admin/reviews/chart?period=${period}&range=${range}`)
      .then((r) => r.json())
      .then((d) => { if (d.ok) setChartData(d.chartData); })
      .finally(() => setChartLoading(false));
  }, [period, range]);

  useEffect(() => { loadStats(); }, [loadStats]);
  useEffect(() => { loadChartData(); }, [loadChartData]);

  const syncSheets = async () => {
    setSyncing(true);
    setSyncResult(null);
    try {
      const res = await fetch("/api/admin/sheets/sync", { method: "POST" });
      const data = await res.json();
      setSyncResult(data);
      if (data.ok) { loadStats(); loadChartData(); }
    } catch {
      setSyncResult({ ok: false });
    } finally {
      setSyncing(false);
    }
  };

  const now = new Date();
  const monthName = now.toLocaleString("ru-RU", { month: "long", year: "numeric" });

  const totalInRange = chartData.reduce((s, d) => s + d.count, 0);

  return (
    <AdminLayout>
      <style>{`
        @keyframes fadeIn { from { opacity:0 } to { opacity:1 } }
        .period-btn { padding: 6px 14px; border-radius: 6px; border: 1px solid transparent; font-size: 0.8rem; font-weight: 600; cursor: pointer; transition: all 0.15s; background: transparent; color: hsl(0 0% 55%); }
        .period-btn:hover { color: #fff; background: rgba(255,255,255,0.05); }
        .period-btn.active { background: rgba(201,255,71,0.08); border-color: rgba(201,255,71,0.2); color: #c9ff47; }
      `}</style>

      <div style={{ padding: "40px 48px" }}>
        {/* Header */}
        <div style={{ display: "flex", alignItems: "flex-start", justifyContent: "space-between", marginBottom: 32, flexWrap: "wrap", gap: 16 }}>
          <div>
            <div style={{ fontSize: "0.7rem", letterSpacing: 3, color: C, textTransform: "uppercase", marginBottom: 8, fontFamily: "monospace" }}>
              Дашборд
            </div>
            <h1 style={{ fontSize: "1.75rem", fontWeight: 800, color: "#fff", letterSpacing: -0.5 }}>
              Сводка — {monthName}
            </h1>
          </div>

          <div style={{ display: "flex", flexDirection: "column", alignItems: "flex-end", gap: 8 }}>
            <button
              onClick={syncSheets}
              disabled={syncing}
              style={{
                padding: "10px 20px",
                background: syncing ? "rgba(0,245,255,0.05)" : "rgba(0,245,255,0.1)",
                border: `1px solid rgba(0,245,255,0.3)`,
                borderRadius: 6, color: C, fontWeight: 700, fontSize: "0.85rem",
                cursor: syncing ? "wait" : "pointer",
                opacity: syncing ? 0.7 : 1,
                transition: "all 0.2s",
              }}
            >
              {syncing ? "⟳ Синхронизация..." : "⟳ Обновить статистику"}
            </button>
            {syncResult && (
              <div style={{
                fontSize: "0.75rem", fontFamily: "monospace",
                color: syncResult.ok ? C : "#ff6666",
                padding: "4px 10px", borderRadius: 4,
                background: syncResult.ok ? "rgba(201,255,71,0.05)" : "rgba(255,68,68,0.08)",
              }}>
                {syncResult.ok
                  ? `✓ Обновлено: ${syncResult.synced} источн.${syncResult.errors && syncResult.errors.length > 0 ? `, ${syncResult.errors.length} ошибок` : ""}`
                  : "✕ Ошибка синхронизации"}
              </div>
            )}
          </div>
        </div>

        {loading ? (
          <div style={{ color: "hsl(0 0% 50%)", padding: "40px 0" }}>Загрузка...</div>
        ) : stats ? (
          <>
            {/* All-time totals */}
            <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(240px, 1fr))", gap: 16, marginBottom: 16 }}>
              <StatCard label="Отзывов за всё время" value={stats.reviewsAllTime.toLocaleString("ru-RU")} accent />
              <StatCard
                label="Заработано за всё время"
                value={`$${stats.earningsAllTime.toLocaleString("en-US", { minimumFractionDigits: 0, maximumFractionDigits: 0 })}`}
                accent
              />
            </div>

            {/* Monthly stats */}
            <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(200px, 1fr))", gap: 16, marginBottom: 32 }}>
              <StatCard label="Клиентов в работе" value={stats.clientsActive} />
              <StatCard label="Клиентов на паузе" value={stats.clientsPaused} />
              <StatCard label="Отзывов сегодня" value={stats.reviewsToday} />
              <StatCard label="Сделано за месяц" value={stats.reviewsDoneThisMonth} />
              <StatCard label="Осталось за месяц" value={stats.reviewsRemainingThisMonth} sub="от плана" />
              <StatCard label="Всего за месяц (план)" value={stats.reviewsTotalThisMonth} />
              <StatCard
                label="Заработано за месяц (план)"
                value={`$${stats.earningsPerMonth.toLocaleString("en-US", { minimumFractionDigits: 0, maximumFractionDigits: 0 })}`}
              />
            </div>

            {/* Interactive Chart */}
            <div
              style={{ background: CARD_BG, border: `1px solid ${BORDER}`, borderRadius: 10, padding: "24px 28px", cursor: "pointer" }}
              onClick={() => setChartExpanded(true)}
            >
              {/* Chart header */}
              <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: 16, flexWrap: "wrap", gap: 12 }}>
                <div>
                  <div style={{ fontSize: "0.75rem", color: "hsl(0 0% 55%)", fontWeight: 500, textTransform: "uppercase", letterSpacing: 1 }}>
                    График отзывов
                    {!chartLoading && totalInRange > 0 && (
                      <span style={{ color: C, marginLeft: 12 }}>{totalInRange.toLocaleString("ru-RU")} отзывов</span>
                    )}
                  </div>
                  <div style={{ fontSize: "0.7rem", color: "rgba(255,255,255,0.25)", marginTop: 4, fontFamily: "monospace" }}>
                    Нажмите для полного экрана
                  </div>
                </div>

                {/* Controls - stop propagation so clicking controls doesn't open modal */}
                <div style={{ display: "flex", gap: 6, flexWrap: "wrap" }} onClick={(e) => e.stopPropagation()}>
                  {PERIOD_OPTIONS.map((opt) => (
                    <button
                      key={opt.value}
                      className={`period-btn${period === opt.value ? " active" : ""}`}
                      onClick={() => setPeriod(opt.value)}
                    >
                      {opt.label}
                    </button>
                  ))}
                  <div style={{ width: 1, background: BORDER, alignSelf: "stretch", margin: "0 4px" }} />
                  {RANGE_OPTIONS.map((opt) => (
                    <button
                      key={opt.value}
                      className={`period-btn${range === opt.value ? " active" : ""}`}
                      onClick={() => setRange(opt.value)}
                    >
                      {opt.label}
                    </button>
                  ))}
                </div>
              </div>

              {chartLoading ? (
                <div style={{ height: 220, display: "flex", alignItems: "center", justifyContent: "center", color: "hsl(0 0% 45%)", fontFamily: "monospace", fontSize: "0.8rem" }}>
                  Загрузка...
                </div>
              ) : chartData.length > 0 ? (
                <ChartBlock chartData={chartData} period={period} expanded={false} />
              ) : (
                <div style={{ color: "hsl(0 0% 45%)", padding: "40px 0", textAlign: "center" }}>
                  Нет данных за выбранный период
                </div>
              )}
            </div>
          </>
        ) : (
          <div style={{ color: "hsl(0 84% 60%)" }}>Ошибка загрузки данных</div>
        )}
      </div>

      {/* Expanded chart modal */}
      {chartExpanded && (
        <div
          onClick={() => setChartExpanded(false)}
          style={{
            position: "fixed", inset: 0, zIndex: 9000,
            background: "rgba(5,5,5,0.85)",
            backdropFilter: "blur(12px)",
            display: "flex", alignItems: "center", justifyContent: "center",
            padding: 32,
            animation: "fadeIn 0.25s ease",
          }}
        >
          <div
            onClick={(e) => e.stopPropagation()}
            style={{
              background: CARD_BG,
              border: `1px solid ${BORDER}`,
              borderRadius: 12,
              padding: "32px 36px",
              width: "100%",
              maxWidth: 1100,
              maxHeight: "90vh",
              overflow: "auto",
            }}
          >
            <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: 24, flexWrap: "wrap", gap: 12 }}>
              <div>
                <div style={{ fontSize: "1rem", fontWeight: 700, color: "#fff", marginBottom: 4 }}>
                  График отзывов
                  {totalInRange > 0 && <span style={{ color: C, marginLeft: 12, fontWeight: 800 }}>{totalInRange.toLocaleString("ru-RU")}</span>}
                </div>
                <div style={{ fontSize: "0.75rem", color: "hsl(0 0% 45%)", fontFamily: "monospace" }}>
                  Используйте полосу под графиком для зума и навигации
                </div>
              </div>
              <div style={{ display: "flex", gap: 6, flexWrap: "wrap", alignItems: "center" }}>
                {PERIOD_OPTIONS.map((opt) => (
                  <button
                    key={opt.value}
                    className={`period-btn${period === opt.value ? " active" : ""}`}
                    onClick={() => setPeriod(opt.value)}
                  >
                    {opt.label}
                  </button>
                ))}
                <div style={{ width: 1, background: BORDER, alignSelf: "stretch", margin: "0 4px" }} />
                {RANGE_OPTIONS.map((opt) => (
                  <button
                    key={opt.value}
                    className={`period-btn${range === opt.value ? " active" : ""}`}
                    onClick={() => setRange(opt.value)}
                  >
                    {opt.label}
                  </button>
                ))}
                <button
                  onClick={() => setChartExpanded(false)}
                  style={{
                    marginLeft: 8, padding: "6px 14px", borderRadius: 6,
                    background: "rgba(255,68,68,0.1)", border: "1px solid rgba(255,68,68,0.2)",
                    color: "#ff6666", fontSize: "0.8rem", fontWeight: 600, cursor: "pointer",
                  }}
                >
                  ✕ Закрыть
                </button>
              </div>
            </div>

            {chartLoading ? (
              <div style={{ height: 420, display: "flex", alignItems: "center", justifyContent: "center", color: "hsl(0 0% 45%)" }}>
                Загрузка...
              </div>
            ) : chartData.length > 0 ? (
              <ChartBlock chartData={chartData} period={period} expanded />
            ) : (
              <div style={{ height: 420, display: "flex", alignItems: "center", justifyContent: "center", color: "hsl(0 0% 45%)" }}>
                Нет данных за выбранный период
              </div>
            )}
          </div>
        </div>
      )}
    </AdminLayout>
  );
}
