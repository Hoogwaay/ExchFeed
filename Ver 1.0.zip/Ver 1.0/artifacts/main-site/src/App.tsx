import { Switch, Route, Router as WouterRouter, Redirect, useLocation } from "wouter";
import { QueryClientProvider } from "@tanstack/react-query";
import { queryClient } from "@/lib/queryClient";
import { useState, useCallback, useEffect } from "react";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { ThemeProvider } from "@/lib/theme";
import NotFound from "@/pages/not-found";
import Home from "@/pages/Home";
import Login from "@/pages/Login";
import Loader from "@/components/Loader";
import { CursorContext } from "@/lib/cursor-context";

// Admin panel (ExchFeed style)
import AdminLogin from "@/pages/admin/AdminLogin";
import AdminLayout from "@/pages/admin/AdminLayout";
import Dashboard from "@/pages/admin/Dashboard";
import Clients from "@/pages/admin/Clients";
import Accounting from "@/pages/admin/Accounting";
import Schedule from "@/pages/admin/Schedule";
import Resources from "@/pages/admin/Resources";

// Client cabinet
import ClientLayout from "@/pages/client/ClientLayout";
import Cabinet from "@/pages/client/Cabinet";

// AM (Analytics Admin Panel)
import AmLayout from "@/pages/am/Layout";
import AmOverview from "@/pages/am/Overview";
import AmCustomers from "@/pages/am/Customers";
import AmBalance from "@/pages/am/Balance";
import AmReviews from "@/pages/am/Reviews";
import AmAnalytics from "@/pages/am/Analytics";
import AmCampaign from "@/pages/am/Campaign";
import AmActivityLog from "@/pages/am/ActivityLog";
import AmEmployees from "@/pages/am/Employees";

// CRM (Worker Panel)
import CrmLayout from "@/pages/crm/Layout";
import CrmHome from "@/pages/crm/Home";
import CrmInfoClients from "@/pages/crm/InfoClients";
import CrmInfoWallets from "@/pages/crm/InfoWallets";

function AppRoutes() {
  return (
    <Switch>
      {/* Public site */}
      <Route path="/" component={Home} />
      <Route path="/login" component={Login} />

      {/* Client cabinet */}
      <Route path="/cabinet">
        <ClientLayout>
          <Cabinet />
        </ClientLayout>
      </Route>

      {/* Admin panel (ExchFeed) */}
      <Route path="/admin/login" component={AdminLogin} />
      <Route path="/admin">
        <AdminLayout>
          <Dashboard />
        </AdminLayout>
      </Route>
      <Route path="/admin/clients">
        <AdminLayout>
          <Clients />
        </AdminLayout>
      </Route>
      <Route path="/admin/accounting">
        <AdminLayout>
          <Accounting />
        </AdminLayout>
      </Route>
      <Route path="/admin/schedule">
        <AdminLayout>
          <Schedule />
        </AdminLayout>
      </Route>
      <Route path="/admin/resources">
        <AdminLayout>
          <Resources />
        </AdminLayout>
      </Route>

      {/* AM Analytics Admin Panel */}
      <Route path="/am">
        <Redirect to="/am/overview" />
      </Route>
      <Route path="/am/overview">
        <AmLayout>
          <AmOverview />
        </AmLayout>
      </Route>
      <Route path="/am/analytics">
        <AmLayout>
          <AmAnalytics />
        </AmLayout>
      </Route>
      <Route path="/am/campaign">
        <AmLayout>
          <AmCampaign />
        </AmLayout>
      </Route>
      <Route path="/am/activity">
        <AmLayout>
          <AmActivityLog />
        </AmLayout>
      </Route>
      <Route path="/am/customers">
        <AmLayout>
          <AmCustomers />
        </AmLayout>
      </Route>
      <Route path="/am/employees">
        <AmLayout>
          <AmEmployees />
        </AmLayout>
      </Route>
      <Route path="/am/reviews">
        <AmLayout>
          <AmReviews />
        </AmLayout>
      </Route>
      <Route path="/am/balance">
        <AmLayout>
          <AmBalance />
        </AmLayout>
      </Route>

      {/* CRM (Worker Panel) */}
      <Route path="/crm">
        <Redirect to="/crm/home" />
      </Route>
      <Route path="/crm/home">
        <CrmLayout>
          <CrmHome />
        </CrmLayout>
      </Route>
      <Route path="/crm/info">
        <Redirect to="/crm/info/clients" />
      </Route>
      <Route path="/crm/info/clients">
        <CrmLayout>
          <CrmInfoClients />
        </CrmLayout>
      </Route>
      <Route path="/crm/info/wallets">
        <CrmLayout>
          <CrmInfoWallets />
        </CrmLayout>
      </Route>

      <Route component={NotFound} />
    </Switch>
  );
}

function isPublicPath(path: string) {
  return path === "/" || path === "/login";
}

function App() {
  const initialPath = window.location.pathname;
  const alreadyLoaded = sessionStorage.getItem("loader_done") === "1";
  const needsLoader = isPublicPath(initialPath) && !alreadyLoaded;

  const [loaderDone, setLoaderDone] = useState(!needsLoader);
  const [contentVisible, setContentVisible] = useState(!needsLoader);
  const [cursor, setCursor] = useState({ x: -200, y: -200 });
  const [cursorBig, setCursorBig] = useState(false);

  useEffect(() => {
    const move = (e: MouseEvent) => setCursor({ x: e.clientX, y: e.clientY });
    window.addEventListener("mousemove", move);
    return () => window.removeEventListener("mousemove", move);
  }, []);

  const hoverOn = useCallback(() => setCursorBig(true), []);
  const hoverOff = useCallback(() => setCursorBig(false), []);

  const handleLoaderDone = useCallback(() => {
    sessionStorage.setItem("loader_done", "1");
    setLoaderDone(true);
    requestAnimationFrame(() => {
      requestAnimationFrame(() => setContentVisible(true));
    });
  }, []);

  return (
    <ThemeProvider>
      <QueryClientProvider client={queryClient}>
        <TooltipProvider>
          <CursorContext.Provider value={{ hoverOn, hoverOff }}>
            <div
              style={{
                position: "fixed",
                left: cursor.x,
                top: cursor.y,
                width: cursorBig ? 44 : 10,
                height: cursorBig ? 44 : 10,
                borderRadius: "50%",
                background: cursorBig ? "transparent" : "#c9ff47",
                border: cursorBig ? "1.5px solid #c9ff47" : "none",
                transform: "translate(-50%,-50%)",
                pointerEvents: "none",
                zIndex: 999999,
                transition: "width 0.22s cubic-bezier(0.16,1,0.3,1), height 0.22s cubic-bezier(0.16,1,0.3,1), background 0.22s, border 0.22s",
                mixBlendMode: "difference",
              }}
            />

            <div
              style={{
                position: "fixed", inset: 0, zIndex: 99998, pointerEvents: "none",
                backgroundImage: `url("data:image/svg+xml,%3Csvg viewBox='0 0 256 256' xmlns='http://www.w3.org/2000/svg'%3E%3Cfilter id='noise'%3E%3CfeTurbulence type='fractalNoise' baseFrequency='0.9' numOctaves='4' stitchTiles='stitch'/%3E%3C/filter%3E%3Crect width='100%25' height='100%25' filter='url(%23noise)' opacity='1'/%3E%3C/svg%3E")`,
                opacity: 0.03,
              }}
            />

            {!loaderDone && <Loader onDone={handleLoaderDone} />}

            <div style={{
              opacity: contentVisible ? 1 : 0,
              transition: "opacity 0.9s cubic-bezier(0.16,1,0.3,1)",
            }}>
              <WouterRouter base={import.meta.env.BASE_URL.replace(/\/$/, "")}>
                <AppRoutes />
              </WouterRouter>
            </div>

            <Toaster />
          </CursorContext.Provider>
        </TooltipProvider>
      </QueryClientProvider>
    </ThemeProvider>
  );
}

export default App;
