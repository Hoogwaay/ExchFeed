import { Link, useLocation } from "wouter";
import { useTheme } from "@/lib/theme";
import {
  LayoutDashboard, Users, Wallet, Star, Moon, Sun, Menu, X,
  BarChart2, Megaphone, ActivitySquare, UserSquare2, Settings, HelpCircle, LogOut
} from "lucide-react";
import { useState, useEffect } from "react";
import type { ReactNode } from "react";

const mainNavItems = [
  { path: "/am/overview", label: "Overview", icon: LayoutDashboard },
  { path: "/am/analytics", label: "Analytics / Reports", icon: BarChart2 },
  { path: "/am/campaign", label: "Campaign", icon: Megaphone },
  { path: "/am/activity", label: "Activity Log", icon: ActivitySquare },
  { path: "/am/customers", label: "Customers", icon: UserSquare2 },
  { path: "/am/employees", label: "Employees", icon: Users },
  { path: "/am/reviews", label: "Reviews", icon: Star },
  { path: "/am/balance", label: "Balance", icon: Wallet },
];

function NavLink({ path, label, icon: Icon, onClick }: {
  path: string; label: string; icon: typeof LayoutDashboard; onClick?: () => void;
}) {
  const [location] = useLocation();
  const active = location === path;
  return (
    <Link
      href={path}
      data-testid={`nav-${label.toLowerCase().replace(/[\s\/]+/g, "-")}`}
      onClick={onClick}
      className={`flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium transition-colors w-full
        ${active
          ? "bg-[--admin-accent] text-white dark:text-black"
          : "text-[--admin-muted] hover:bg-[--admin-hover] hover:text-[--admin-text]"
        }`}
    >
      <Icon size={17} className="shrink-0" />
      <span className="truncate">{label}</span>
    </Link>
  );
}

function SidebarButton({ icon: Icon, label, onClick, testId }: {
  icon: typeof Settings; label: string; onClick?: () => void; testId?: string;
}) {
  return (
    <button
      data-testid={testId}
      onClick={onClick}
      className="flex items-center gap-3 w-full px-3 py-2.5 rounded-lg text-sm font-medium text-[--admin-muted] hover:bg-[--admin-hover] hover:text-[--admin-text] transition-colors"
    >
      <Icon size={17} className="shrink-0" />
      <span className="truncate">{label}</span>
    </button>
  );
}

function Layout({ children }: { children: ReactNode }) {
  const [, navigate] = useLocation();
  const { theme, toggleTheme } = useTheme();
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const close = () => setSidebarOpen(false);

  useEffect(() => {
    const token = localStorage.getItem("admin_token");
    if (!token) navigate("/admin/login");
  }, [navigate]);

  const handleLogout = () => {
    localStorage.removeItem("admin_token");
    navigate("/admin/login");
  };

  return (
    <div className="h-screen flex overflow-hidden bg-[--admin-bg] text-[--admin-text]">
      {sidebarOpen && (
        <div
          className="fixed inset-0 z-20 bg-black/50 lg:hidden"
          onClick={close}
        />
      )}

      <aside
        className={`fixed top-0 left-0 z-30 h-full w-60 flex flex-col bg-[--admin-sidebar] border-r border-[--admin-border] transition-transform duration-200
          ${sidebarOpen ? "translate-x-0" : "-translate-x-full"} lg:translate-x-0 lg:static lg:z-auto`}
      >
        <div className="flex items-center gap-2.5 px-5 py-4 border-b border-[--admin-border] shrink-0">
          <div className="w-8 h-8 rounded-lg bg-[--admin-accent] flex items-center justify-center shrink-0">
            <span className="font-bold text-sm" style={{ color: theme === "dark" ? "#0f1117" : "white" }}>A</span>
          </div>
          <span className="font-semibold text-[--admin-text] text-[15px]">Admin Panel</span>
        </div>

        <nav className="flex-1 px-3 py-3 space-y-0.5 overflow-y-auto min-h-0">
          {mainNavItems.map(item => (
            <NavLink key={item.path} {...item} onClick={close} />
          ))}
        </nav>

        <div className="px-3 py-3 border-t border-[--admin-border] space-y-0.5 shrink-0">
          <SidebarButton icon={Settings} label="Settings" testId="btn-settings" />
          <SidebarButton icon={HelpCircle} label="Help" testId="btn-help" />
          <SidebarButton
            icon={theme === "dark" ? Sun : Moon}
            label={theme === "dark" ? "Light Mode" : "Dark Mode"}
            onClick={toggleTheme}
            testId="btn-toggle-theme"
          />
        </div>

        <div className="px-3 py-3 border-t border-[--admin-border] shrink-0">
          <button
            data-testid="btn-logout"
            onClick={handleLogout}
            className="flex items-center gap-3 w-full px-3 py-2.5 rounded-lg text-sm font-medium text-red-500 hover:bg-red-50 dark:hover:bg-red-900/20 hover:text-red-600 transition-colors"
          >
            <LogOut size={17} className="shrink-0" />
            <span>Log Out</span>
          </button>
        </div>
      </aside>

      <div className="flex-1 flex flex-col min-w-0 overflow-hidden">
        <header className="lg:hidden flex items-center gap-3 px-4 py-3 bg-[--admin-sidebar] border-b border-[--admin-border] shrink-0">
          <button
            data-testid="btn-sidebar-toggle"
            onClick={() => setSidebarOpen(o => !o)}
            className="text-[--admin-muted] hover:text-[--admin-text]"
          >
            {sidebarOpen ? <X size={22} /> : <Menu size={22} />}
          </button>
          <span className="font-semibold text-[--admin-text]">Admin Panel</span>
        </header>

        <main className="flex-1 p-6 overflow-auto">
          {children}
        </main>
      </div>
    </div>
  );
}

export default Layout;
