import { useQuery } from "@tanstack/react-query";
import { Copy, Wallet, FileText } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import type { Client } from "@/lib/types";

async function fetchJson(url: string) {
  const r = await fetch(url);
  if (!r.ok) throw new Error("Request failed");
  return r.json();
}

interface WalletEntry {
  name: string;
  address: string;
}

function parseWallets(raw: string | null | undefined): WalletEntry[] {
  if (!raw) return [];
  try {
    const parsed = JSON.parse(raw);
    if (Array.isArray(parsed)) return parsed;
    return [];
  } catch {
    return [];
  }
}

function ClientCard({ client }: { client: Client }) {
  const { toast } = useToast();
  const wallets = parseWallets(client.wallets);

  const copy = (text: string, label: string) => {
    navigator.clipboard.writeText(text).then(() => {
      toast({ title: "Скопировано", description: `${label} скопирован в буфер` });
    });
  };

  const statusColors: Record<string, string> = {
    in_work: "bg-green-100 text-green-700 dark:bg-green-900/30 dark:text-green-400",
    potential: "bg-blue-100 text-blue-700 dark:bg-blue-900/30 dark:text-blue-400",
    paused: "bg-yellow-100 text-yellow-700 dark:bg-yellow-900/30 dark:text-yellow-400",
    refused: "bg-red-100 text-red-700 dark:bg-red-900/30 dark:text-red-400",
  };

  const statusLabels: Record<string, string> = {
    in_work: "В работе",
    potential: "Потенциальный",
    paused: "Пауза",
    refused: "Отказ",
  };

  return (
    <div className="bg-[--admin-sidebar] border border-[--admin-border] rounded-xl p-4 space-y-4">
      <div className="flex items-center justify-between gap-3">
        <h3 className="font-semibold text-[--admin-text] text-base">{client.name}</h3>
        <span className={`text-xs font-medium px-2.5 py-1 rounded-full shrink-0 ${statusColors[client.status] ?? ""}`}>
          {statusLabels[client.status] ?? client.status}
        </span>
      </div>

      {client.tz && (
        <div className="space-y-1.5">
          <div className="flex items-center gap-1.5 text-xs font-semibold text-[--admin-muted] uppercase tracking-wide">
            <FileText size={12} />
            Техническое задание
          </div>
          <div className="bg-[--admin-bg] rounded-lg p-3 text-sm text-[--admin-text] leading-relaxed whitespace-pre-wrap">
            {client.tz}
          </div>
        </div>
      )}

      {wallets.length > 0 && (
        <div className="space-y-1.5">
          <div className="flex items-center gap-1.5 text-xs font-semibold text-[--admin-muted] uppercase tracking-wide">
            <Wallet size={12} />
            Кошельки
          </div>
          <div className="space-y-2">
            {wallets.map((w, i) => (
              <button
                key={i}
                onClick={() => copy(w.address, w.name)}
                className="w-full flex items-center justify-between gap-3 bg-[--admin-bg] hover:bg-[--admin-hover] rounded-lg p-2.5 transition-colors group text-left"
              >
                <div className="min-w-0">
                  <div className="text-xs font-medium text-[--admin-text]">{w.name}</div>
                  <div className="text-xs text-[--admin-muted] font-mono mt-0.5 truncate">{w.address}</div>
                </div>
                <Copy size={13} className="text-[--admin-muted] group-hover:text-[--admin-text] transition-colors shrink-0" />
              </button>
            ))}
          </div>
        </div>
      )}

      {!client.tz && wallets.length === 0 && (
        <div className="text-sm text-[--admin-muted] text-center py-2">
          Нет данных. Информация заполняется с панели администратора.
        </div>
      )}
    </div>
  );
}

export default function Info() {
  const { data: clients = [], isLoading } = useQuery<Client[]>({
    queryKey: ["/api/clients"],
    queryFn: () => fetchJson("/api/clients"),
  });

  const inWorkClients = clients.filter(c => c.status === "in_work");
  const otherClients = clients.filter(c => c.status !== "in_work");

  return (
    <div className="space-y-5">
      <div>
        <h1 className="text-xl font-bold text-[--admin-text]">Инфо</h1>
        <p className="text-sm text-[--admin-muted] mt-0.5">Информация о клиентах и кошельки</p>
      </div>

      {isLoading && (
        <div className="text-center text-[--admin-muted] py-12 text-sm">Загрузка...</div>
      )}

      {!isLoading && clients.length === 0 && (
        <div className="text-center py-16 text-[--admin-muted]">
          <Wallet size={40} className="mx-auto mb-3 opacity-30" />
          <p className="text-sm font-medium">Нет клиентов</p>
          <p className="text-xs mt-1 opacity-60">Клиенты добавляются с панели администратора</p>
        </div>
      )}

      {inWorkClients.length > 0 && (
        <div className="space-y-3">
          <h2 className="text-sm font-semibold text-[--admin-muted] uppercase tracking-wide">В работе</h2>
          {inWorkClients.map(c => <ClientCard key={c.id} client={c} />)}
        </div>
      )}

      {otherClients.length > 0 && (
        <div className="space-y-3">
          <h2 className="text-sm font-semibold text-[--admin-muted] uppercase tracking-wide">Остальные</h2>
          {otherClients.map(c => <ClientCard key={c.id} client={c} />)}
        </div>
      )}
    </div>
  );
}
