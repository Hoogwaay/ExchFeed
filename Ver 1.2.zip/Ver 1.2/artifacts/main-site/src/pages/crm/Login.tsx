import { useState } from "react";
import { useLocation } from "wouter";

const C = "#4ade80";

export default function CrmLogin() {
  const [, navigate] = useLocation();
  const [login, setLogin] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError("");
    setLoading(true);
    try {
      const res = await fetch("/api/crm/login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ login, password }),
      });
      const data = await res.json();
      if (!res.ok) {
        setError(data.error || "Неверные данные для входа");
        return;
      }
      localStorage.setItem("worker_token", data.token);
      navigate("/crm/home");
    } catch {
      setError("Ошибка соединения с сервером");
    } finally {
      setLoading(false);
    }
  };

  return (
    <div style={{
      display: "flex", alignItems: "center", justifyContent: "center",
      minHeight: "100vh", background: "#050505", fontFamily: "'Inter', sans-serif",
    }}>
      <div style={{
        width: 360, padding: "40px 32px",
        background: "#0a0a0a", border: "1px solid rgba(255,255,255,0.08)",
        borderRadius: 12,
      }}>
        <div style={{ marginBottom: 32, textAlign: "center" }}>
          <div style={{ fontFamily: "monospace", fontSize: "0.55rem", letterSpacing: 5, color: C, textTransform: "uppercase", marginBottom: 8 }}>
            Worker Panel
          </div>
          <div style={{ fontWeight: 800, fontSize: "1.3rem", color: "#fff", letterSpacing: -0.5 }}>
            Exchange Feed
          </div>
          <div style={{ color: "hsl(0 0% 55%)", fontSize: "0.825rem", marginTop: 4 }}>
            Войдите чтобы продолжить
          </div>
        </div>

        <form onSubmit={handleSubmit} style={{ display: "flex", flexDirection: "column", gap: 16 }}>
          <div>
            <label style={{
              display: "block", fontSize: "0.75rem", fontWeight: 500,
              color: "hsl(0 0% 60%)", marginBottom: 6,
            }}>
              Логин
            </label>
            <input
              type="text"
              value={login}
              onChange={(e) => setLogin(e.target.value)}
              placeholder="Введите логин"
              required
              style={{
                width: "100%", padding: "10px 14px",
                background: "rgba(255,255,255,0.05)",
                border: "1px solid rgba(255,255,255,0.1)",
                borderRadius: 8, color: "#fff", fontSize: "0.9rem",
                outline: "none", boxSizing: "border-box",
              }}
            />
          </div>

          <div>
            <label style={{
              display: "block", fontSize: "0.75rem", fontWeight: 500,
              color: "hsl(0 0% 60%)", marginBottom: 6,
            }}>
              Пароль
            </label>
            <input
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              placeholder="Введите пароль"
              required
              style={{
                width: "100%", padding: "10px 14px",
                background: "rgba(255,255,255,0.05)",
                border: "1px solid rgba(255,255,255,0.1)",
                borderRadius: 8, color: "#fff", fontSize: "0.9rem",
                outline: "none", boxSizing: "border-box",
              }}
            />
          </div>

          {error && (
            <div style={{
              padding: "10px 14px", borderRadius: 8,
              background: "rgba(239,68,68,0.1)", border: "1px solid rgba(239,68,68,0.2)",
              color: "#f87171", fontSize: "0.825rem",
            }}>
              {error}
            </div>
          )}

          <button
            type="submit"
            disabled={loading}
            style={{
              marginTop: 8, padding: "11px",
              background: C, border: "none", borderRadius: 8,
              color: "#050505", fontWeight: 700, fontSize: "0.9rem",
              cursor: loading ? "not-allowed" : "pointer",
              opacity: loading ? 0.7 : 1,
              transition: "opacity 0.2s",
            }}
          >
            {loading ? "Вход..." : "Войти"}
          </button>
        </form>
      </div>
    </div>
  );
}
