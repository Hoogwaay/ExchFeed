import { Link, useLocation } from "wouter";
import { useTheme } from "@/lib/theme";
import { Home, Info, Moon, Sun, Menu, X, LogOut, Users, BookOpen, ChevronDown } from "lucide-react";
import { useState, useEffect } from "react";
import type { ReactNode } from "react";

function LiveClock() {
  const [now, setNow] = useState(() => new Date());
  useEffect(() => {
    const id = setInterval(() => setNow(new Date()), 1000);
    return () => clearInterval(id);
  }, []);
  const hh = String(now.getHours()).padStart(2, "0");
  const mm = String(now.getMinutes()).padStart(2, "0");
  const ss = String(now.getSeconds()).padStart(2, "0");
  return (
    <div className="px-4 py-2.5 border-t border-[--admin-border] shrink-0 flex items-center justify-center">
      <span className="font-mono text-sm font-semibold tracking-widest text-[--admin-text] tabular-nums">
        {hh}:{mm}:{ss}
      </span>
    </div>
  );
}

function NavLink({ path, label, icon: Icon, onClick }: {
  path: string; label: string; icon: typeof Home; onClick?: () => void;
}) {
  const [location] = useLocation();
  const active = location === path;
  return (
    <Link
      href={path}
      onClick={onClick}
      className={`flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium transition-colors w-full
        ${active
          ? "bg-[--admin-accent] text-white dark:text-black"
          : "text-[--admin-muted] hover:bg-[--admin-hover] hover:text-[--admin-text]"
        }`}
    >
      <Icon size={17} className="shrink-0" />
      <span className="truncate">{label}</span>
    </Link>
  );
}

function ExpandableNav({ label, icon: Icon, children, prefix }: {
  label: string; icon: typeof Info; children: ReactNode; prefix: string;
}) {
  const [location] = useLocation();
  const isChildActive = location.startsWith(prefix);
  const [open, setOpen] = useState(isChildActive);

  return (
    <div>
      <button
        onClick={() => setOpen(o => !o)}
        className={`flex items-center gap-3 px-3 py-2.5 rounded-lg text-sm font-medium transition-colors w-full
          ${isChildActive
            ? "text-[--admin-text]"
            : "text-[--admin-muted] hover:bg-[--admin-hover] hover:text-[--admin-text]"
          }`}
      >
        <Icon size={17} className="shrink-0" />
        <span className="flex-1 text-left truncate">{label}</span>
        <ChevronDown
          size={14}
          className={`shrink-0 transition-transform duration-200 ${open ? "rotate-180" : ""}`}
        />
      </button>
      {open && (
        <div className="mt-0.5 ml-2 pl-3 border-l border-[--admin-border] space-y-0.5">
          {children}
        </div>
      )}
    </div>
  );
}

function SubNavLink({ path, label, icon: Icon, onClick }: {
  path: string; label: string; icon: typeof Users; onClick?: () => void;
}) {
  const [location] = useLocation();
  const active = location === path;
  return (
    <Link
      href={path}
      onClick={onClick}
      className={`flex items-center gap-2.5 px-3 py-2 rounded-lg text-sm font-medium transition-colors w-full
        ${active
          ? "bg-[--admin-accent] text-white dark:text-black"
          : "text-[--admin-muted] hover:bg-[--admin-hover] hover:text-[--admin-text]"
        }`}
    >
      <Icon size={15} className="shrink-0" />
      <span className="truncate">{label}</span>
    </Link>
  );
}

function SidebarButton({ icon: Icon, label, onClick, testId, variant }: {
  icon: typeof Moon; label: string; onClick?: () => void; testId?: string; variant?: "danger";
}) {
  return (
    <button
      data-testid={testId}
      onClick={onClick}
      className={`flex items-center gap-3 w-full px-3 py-2.5 rounded-lg text-sm font-medium transition-colors
        ${variant === "danger"
          ? "text-red-500 hover:bg-red-50 dark:hover:bg-red-900/20 hover:text-red-600"
          : "text-[--admin-muted] hover:bg-[--admin-hover] hover:text-[--admin-text]"
        }`}
    >
      <Icon size={17} className="shrink-0" />
      <span className="truncate">{label}</span>
    </button>
  );
}

export function Layout({ children }: { children: ReactNode }) {
  const { theme, toggleTheme } = useTheme();
  const [sidebarOpen, setSidebarOpen] = useState(false);
  const close = () => setSidebarOpen(false);
  const [, navigate] = useLocation();

  useEffect(() => {
    const token = localStorage.getItem("worker_token");
    if (!token) navigate("/crm/login");
  }, [navigate]);

  return (
    <div className="h-screen flex overflow-hidden bg-[--admin-bg] text-[--admin-text]">
      {sidebarOpen && (
        <div
          className="fixed inset-0 z-20 bg-black/50 lg:hidden"
          onClick={close}
        />
      )}

      <aside
        className={`fixed top-0 left-0 z-30 h-full w-56 flex flex-col bg-[--admin-sidebar] border-r border-[--admin-border] transition-transform duration-200
          ${sidebarOpen ? "translate-x-0" : "-translate-x-full"} lg:translate-x-0 lg:static lg:z-auto`}
      >
        <div className="flex items-center gap-2.5 px-5 py-4 border-b border-[--admin-border] shrink-0">
          <div className="w-8 h-8 rounded-lg bg-[--admin-accent] flex items-center justify-center shrink-0">
            <span className="font-bold text-sm" style={{ color: theme === "dark" ? "#0f1117" : "white" }}>W</span>
          </div>
          <span className="font-semibold text-[--admin-text] text-[15px]">Панель</span>
        </div>

        <nav className="flex-1 px-3 py-3 space-y-0.5 overflow-y-auto min-h-0">
          <NavLink path="/crm/home" label="Главная" icon={Home} onClick={close} />
          <ExpandableNav label="Инфо" icon={Info} prefix="/crm/info">
            <SubNavLink path="/crm/info/clients" label="Клиенты" icon={Users} onClick={close} />
            <SubNavLink path="/crm/info/wallets" label="База знаний" icon={BookOpen} onClick={close} />
          </ExpandableNav>
        </nav>

        <LiveClock />

        <div className="px-3 py-3 border-t border-[--admin-border] space-y-0.5 shrink-0">
          <SidebarButton
            icon={theme === "dark" ? Sun : Moon}
            label={theme === "dark" ? "Светлая тема" : "Тёмная тема"}
            onClick={toggleTheme}
            testId="btn-toggle-theme"
          />
          <SidebarButton
            icon={LogOut}
            label="Выйти"
            variant="danger"
            testId="btn-logout"
            onClick={() => { localStorage.removeItem("worker_token"); navigate("/crm/login"); }}
          />
        </div>
      </aside>

      <div className="flex-1 flex flex-col min-w-0 overflow-hidden">
        <header className="lg:hidden flex items-center gap-3 px-4 py-3 bg-[--admin-sidebar] border-b border-[--admin-border] shrink-0">
          <button
            onClick={() => setSidebarOpen(o => !o)}
            className="text-[--admin-muted] hover:text-[--admin-text]"
          >
            {sidebarOpen ? <X size={22} /> : <Menu size={22} />}
          </button>
          <span className="font-semibold text-[--admin-text]">Панель</span>
        </header>

        <main className="flex-1 p-5 overflow-auto">
          {children}
        </main>
      </div>
    </div>
  );
}

export default Layout;
