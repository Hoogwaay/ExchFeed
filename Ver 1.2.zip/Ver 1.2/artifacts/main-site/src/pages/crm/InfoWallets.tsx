import { useQuery } from "@tanstack/react-query";
import { Copy, BookOpen, Wallet } from "lucide-react";
import { useToast } from "@/hooks/use-toast";
import type { Client } from "@/lib/types";

async function fetchJson(url: string) {
  const r = await fetch(url);
  if (!r.ok) throw new Error("Request failed");
  return r.json();
}

interface WalletEntry {
  name: string;
  address: string;
}

function parseWallets(raw: string | null | undefined): WalletEntry[] {
  if (!raw) return [];
  try {
    const parsed = JSON.parse(raw);
    return Array.isArray(parsed) ? parsed : [];
  } catch {
    return [];
  }
}

export default function InfoWallets() {
  const { toast } = useToast();

  const { data: clients = [], isLoading } = useQuery<Client[]>({
    queryKey: ["/api/clients"],
    queryFn: () => fetchJson("/api/clients"),
  });

  const copy = (text: string, label: string) => {
    navigator.clipboard.writeText(text).then(() => {
      toast({ title: "Скопировано", description: `${label} скопирован в буфер` });
    });
  };

  const allWallets = clients.flatMap(c =>
    parseWallets(c.wallets).map(w => ({ ...w, clientName: c.name }))
  );

  return (
    <div className="space-y-5">
      <div>
        <h1 className="text-xl font-bold text-[--admin-text]">База знаний</h1>
        <p className="text-sm text-[--admin-muted] mt-0.5">Адреса криптокошельков — нажмите чтобы скопировать</p>
      </div>

      {isLoading && (
        <div className="text-center text-[--admin-muted] py-12 text-sm">Загрузка...</div>
      )}

      {!isLoading && allWallets.length === 0 && (
        <div className="text-center py-16 text-[--admin-muted]">
          <Wallet size={40} className="mx-auto mb-3 opacity-30" />
          <p className="text-sm font-medium">Нет кошельков</p>
          <p className="text-xs mt-1 opacity-60">Кошельки добавляются с панели администратора</p>
        </div>
      )}

      {allWallets.length > 0 && (
        <div className="bg-[--admin-sidebar] border border-[--admin-border] rounded-xl overflow-hidden">
          <div className="flex items-center gap-2 px-4 py-3 border-b border-[--admin-border]">
            <BookOpen size={14} className="text-[--admin-muted]" />
            <span className="text-xs font-semibold text-[--admin-muted] uppercase tracking-wide">
              Кошельки ({allWallets.length})
            </span>
          </div>
          <div className="divide-y divide-admin-border">
            {allWallets.map((w, i) => (
              <button
                key={i}
                onClick={() => copy(w.address, w.name)}
                className="w-full flex items-center justify-between gap-4 px-4 py-3 hover:bg-[--admin-hover] transition-colors group text-left"
              >
                <div className="min-w-0">
                  <div className="flex items-center gap-2">
                    <span className="text-sm font-medium text-[--admin-text]">{w.name}</span>
                    <span className="text-xs text-[--admin-muted]">· {w.clientName}</span>
                  </div>
                  <div className="text-xs text-[--admin-muted] font-mono mt-0.5 truncate">{w.address}</div>
                </div>
                <Copy size={13} className="text-[--admin-muted] group-hover:text-[--admin-text] transition-colors shrink-0" />
              </button>
            ))}
          </div>
        </div>
      )}
    </div>
  );
}
