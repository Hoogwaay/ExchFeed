import { useEffect, useState } from "react";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from "recharts";
import ClientLayout from "./ClientLayout";

const C = "#c9ff47";
const CARD_BG = "rgba(255,255,255,0.03)";
const BORDER = "rgba(255,255,255,0.08)";
const CARD_BORDER = "rgba(255,255,255,0.1)";

interface SiteData {
  id: number;
  url: string;
  reviewsPerMonth: number;
  reviewsPeriod: string;
  pricePerReview: string;
  reviewsAllTime: number;
  reviewsThisMonth: number;
  reviewsToday: number;
  dailyTarget: number;
  chartData: { date: string; count: number }[];
}

interface ProfileData {
  client: { id: number; name: string; status: string };
  sites: SiteData[];
}

interface Review {
  id: number;
  reviewDate: string;
  reviewUrl: string;
  requestId: string | null;
  email: string | null;
  name: string;
  siteUrl: string | null;
}

type Tab = "overview" | "reviews";

function StatBox({ label, value, accent }: { label: string; value: string | number; accent?: boolean }) {
  return (
    <div style={{
      background: CARD_BG,
      border: `1px solid ${accent ? "rgba(201,255,71,0.2)" : BORDER}`,
      borderRadius: 8, padding: "20px 24px",
    }}>
      <div style={{ fontSize: "0.7rem", color: "rgba(255,255,255,0.4)", textTransform: "uppercase", letterSpacing: 2, marginBottom: 10, fontFamily: "monospace" }}>
        {label}
      </div>
      <div style={{ fontSize: "1.8rem", fontWeight: 800, color: accent ? C : "#fff", lineHeight: 1 }}>
        {value}
      </div>
    </div>
  );
}

function periodLabel(period: string) {
  if (period === "day") return "в день";
  if (period === "week") return "в неделю";
  return "в месяц";
}

function formatDate(dateStr: string): string {
  const parts = dateStr.split("-");
  if (parts.length !== 3) return dateStr;
  return `${parts[2]}.${parts[1]}.${parts[0]}`;
}

function truncateUrl(url: string, max = 40): string {
  if (!url) return "—";
  try {
    const u = new URL(url);
    const path = u.pathname + u.search;
    const host = u.hostname.replace(/^www\./, "");
    const full = host + path;
    return full.length > max ? full.slice(0, max) + "…" : full;
  } catch {
    return url.length > max ? url.slice(0, max) + "…" : url;
  }
}

export default function Cabinet() {
  const [profile, setProfile] = useState<ProfileData | null>(null);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(false);

  const [tab, setTab] = useState<Tab>("overview");
  const [reviews, setReviews] = useState<Review[]>([]);
  const [reviewsLoading, setReviewsLoading] = useState(false);
  const [reviewsError, setReviewsError] = useState(false);
  const [reviewSearch, setReviewSearch] = useState("");
  const [reviewPage, setReviewPage] = useState(1);
  const PAGE_SIZE = 20;

  useEffect(() => {
    const token = localStorage.getItem("client_token");
    if (!token) return;
    fetch("/api/client/profile", {
      headers: { Authorization: `Bearer ${token}` },
    })
      .then((r) => r.json())
      .then((d) => {
        if (d.ok) setProfile(d);
        else setError(true);
      })
      .catch(() => setError(true))
      .finally(() => setLoading(false));
  }, []);

  useEffect(() => {
    if (tab !== "reviews") return;
    const token = localStorage.getItem("client_token");
    if (!token) return;
    setReviewsLoading(true);
    setReviewsError(false);
    fetch("/api/client/reviews", {
      headers: { Authorization: `Bearer ${token}` },
    })
      .then((r) => r.json())
      .then((d) => {
        if (d.ok) setReviews(d.reviews);
        else setReviewsError(true);
      })
      .catch(() => setReviewsError(true))
      .finally(() => setReviewsLoading(false));
  }, [tab]);

  const now = new Date();
  const monthName = now.toLocaleString("ru-RU", { month: "long", year: "numeric" });

  const filteredReviews = reviews.filter((r) => {
    if (!reviewSearch.trim()) return true;
    const q = reviewSearch.toLowerCase();
    return (
      r.reviewUrl?.toLowerCase().includes(q) ||
      r.name?.toLowerCase().includes(q) ||
      r.email?.toLowerCase().includes(q) ||
      r.requestId?.toLowerCase().includes(q) ||
      r.siteUrl?.toLowerCase().includes(q)
    );
  });

  const totalPages = Math.max(1, Math.ceil(filteredReviews.length / PAGE_SIZE));
  const pagedReviews = filteredReviews.slice((reviewPage - 1) * PAGE_SIZE, reviewPage * PAGE_SIZE);

  const TAB_ITEMS: { key: Tab; label: string }[] = [
    { key: "overview", label: "Обзор" },
    { key: "reviews", label: `Отзывы${reviews.length > 0 ? ` (${reviews.length})` : ""}` },
  ];

  return (
    <ClientLayout>
      <style>{`
        @media (max-width: 768px) {
          .cab-pad { padding: 24px 20px !important; }
          .cab-grid { grid-template-columns: 1fr !important; }
          .rev-table td, .rev-table th { padding: 10px 8px !important; font-size: 0.75rem !important; }
        }
        .rev-table { width: 100%; border-collapse: collapse; }
        .rev-table th { text-align: left; padding: 10px 14px; font-size: 0.65rem; letter-spacing: 2px; text-transform: uppercase; color: rgba(255,255,255,0.35); font-family: monospace; border-bottom: 1px solid rgba(255,255,255,0.08); }
        .rev-table td { padding: 12px 14px; font-size: 0.82rem; color: rgba(255,255,255,0.75); border-bottom: 1px solid rgba(255,255,255,0.04); vertical-align: top; }
        .rev-table tr:hover td { background: rgba(255,255,255,0.02); }
        .rev-link { color: #c9ff47; text-decoration: none; font-size: 0.8rem; font-family: monospace; }
        .rev-link:hover { text-decoration: underline; }
        .pag-btn { padding: 6px 12px; border-radius: 5px; border: 1px solid rgba(255,255,255,0.1); background: transparent; color: rgba(255,255,255,0.5); cursor: pointer; font-size: 0.8rem; transition: all 0.15s; }
        .pag-btn:hover:not(:disabled) { background: rgba(255,255,255,0.06); color: #fff; }
        .pag-btn.active { background: rgba(201,255,71,0.08); border-color: rgba(201,255,71,0.2); color: #c9ff47; }
        .pag-btn:disabled { opacity: 0.3; cursor: default; }
      `}</style>

      <div style={{ padding: "40px 48px", maxWidth: 1200 }} className="cab-pad">
        <div style={{ marginBottom: 28 }}>
          <div style={{ fontFamily: "monospace", fontSize: "0.65rem", letterSpacing: 4, color: C, textTransform: "uppercase", marginBottom: 8 }}>
            Мониторинг
          </div>
          <h1 style={{ fontSize: "1.75rem", fontWeight: 900, color: "#fff", letterSpacing: -1, marginBottom: 4 }}>
            {profile?.client.name ?? "Личный кабинет"}
          </h1>
          <div style={{ fontSize: "0.85rem", color: "rgba(255,255,255,0.4)", fontFamily: "monospace" }}>
            Отчёт за {monthName}
          </div>
        </div>

        {/* Tabs */}
        <div style={{ display: "flex", gap: 4, marginBottom: 28, borderBottom: "1px solid rgba(255,255,255,0.08)", paddingBottom: 0 }}>
          {TAB_ITEMS.map((t) => (
            <button
              key={t.key}
              onClick={() => { setTab(t.key); setReviewPage(1); }}
              style={{
                padding: "10px 20px",
                background: "transparent",
                border: "none",
                borderBottom: tab === t.key ? `2px solid ${C}` : "2px solid transparent",
                color: tab === t.key ? "#fff" : "rgba(255,255,255,0.45)",
                fontWeight: tab === t.key ? 700 : 400,
                fontSize: "0.875rem",
                cursor: "pointer",
                transition: "all 0.15s",
                marginBottom: -1,
              }}
            >
              {t.label}
            </button>
          ))}
        </div>

        {loading ? (
          <div style={{ color: "rgba(255,255,255,0.4)", fontFamily: "monospace", fontSize: "0.85rem" }}>Загрузка...</div>
        ) : error ? (
          <div style={{ color: "#ff6666", fontFamily: "monospace", fontSize: "0.85rem" }}>Ошибка загрузки данных</div>
        ) : tab === "overview" ? (
          profile && profile.sites.length === 0 ? (
            <div style={{ background: CARD_BG, border: `1px solid ${BORDER}`, borderRadius: 10, padding: 48, textAlign: "center", color: "rgba(255,255,255,0.3)", fontFamily: "monospace" }}>
              Нет активных площадок
            </div>
          ) : (
            <div style={{ display: "flex", flexDirection: "column", gap: 40 }}>
              {profile?.sites.map((site) => (
                <div key={site.id}>
                  <div style={{ background: CARD_BG, border: `1px solid ${CARD_BORDER}`, borderRadius: 12, overflow: "hidden" }}>
                    <div style={{
                      padding: "20px 28px",
                      borderBottom: `1px solid ${BORDER}`,
                      display: "flex", alignItems: "center", justifyContent: "space-between", flexWrap: "wrap", gap: 12,
                    }}>
                      <div>
                        <div style={{ fontFamily: "monospace", fontSize: "0.6rem", letterSpacing: 3, color: "rgba(255,255,255,0.35)", textTransform: "uppercase", marginBottom: 4 }}>
                          Площадка
                        </div>
                        <div style={{ fontWeight: 700, fontSize: "0.95rem", color: "#fff", wordBreak: "break-all" }}>
                          {site.url}
                        </div>
                      </div>
                      <div style={{ display: "flex", gap: 12, flexWrap: "wrap" }}>
                        <div style={{ background: "rgba(201,255,71,0.06)", border: "1px solid rgba(201,255,71,0.15)", borderRadius: 6, padding: "6px 14px", textAlign: "center" }}>
                          <div style={{ fontFamily: "monospace", fontSize: "0.6rem", color: "rgba(255,255,255,0.4)", marginBottom: 2 }}>ПЛАН</div>
                          <div style={{ color: C, fontWeight: 700, fontSize: "0.9rem" }}>
                            {site.reviewsPerMonth} {periodLabel(site.reviewsPeriod)}
                          </div>
                        </div>
                        <div style={{ background: "rgba(255,255,255,0.03)", border: `1px solid ${BORDER}`, borderRadius: 6, padding: "6px 14px", textAlign: "center" }}>
                          <div style={{ fontFamily: "monospace", fontSize: "0.6rem", color: "rgba(255,255,255,0.4)", marginBottom: 2 }}>В ДЕНЬ</div>
                          <div style={{ color: "#fff", fontWeight: 700, fontSize: "0.9rem" }}>{site.dailyTarget}</div>
                        </div>
                      </div>
                    </div>

                    <div className="cab-pad" style={{ padding: "24px 28px" }}>
                      <div className="cab-grid" style={{ display: "grid", gridTemplateColumns: "repeat(3, 1fr)", gap: 16, marginBottom: 28 }}>
                        <StatBox label="Всего за всё время" value={site.reviewsAllTime} accent />
                        <StatBox label={`За ${monthName}`} value={site.reviewsThisMonth} />
                        <StatBox label="Сегодня" value={site.reviewsToday} />
                      </div>

                      {site.chartData.length > 0 ? (
                        <div>
                          <div style={{ fontFamily: "monospace", fontSize: "0.65rem", letterSpacing: 2, color: "rgba(255,255,255,0.35)", textTransform: "uppercase", marginBottom: 16 }}>
                            Динамика по дням — {monthName}
                          </div>
                          <ResponsiveContainer width="100%" height={160}>
                            <BarChart data={site.chartData} margin={{ top: 4, right: 8, left: -10, bottom: 0 }}>
                              <CartesianGrid strokeDasharray="3 3" stroke="rgba(255,255,255,0.05)" vertical={false} />
                              <XAxis
                                dataKey="date"
                                tick={{ fill: "rgba(255,255,255,0.3)", fontSize: 10, fontFamily: "monospace" }}
                                tickFormatter={(v) => v.slice(8)}
                                axisLine={false} tickLine={false}
                              />
                              <YAxis tick={{ fill: "rgba(255,255,255,0.3)", fontSize: 10 }} axisLine={false} tickLine={false} />
                              <Tooltip
                                contentStyle={{ background: "#0a0a0a", border: "1px solid rgba(255,255,255,0.12)", borderRadius: 6, fontSize: 12 }}
                                labelStyle={{ color: "#fff", fontFamily: "monospace" }}
                                itemStyle={{ color: C }}
                                formatter={(v: number) => [v, "Отзывов"]}
                              />
                              <Bar dataKey="count" fill={C} radius={[3, 3, 0, 0]} name="Отзывов" />
                            </BarChart>
                          </ResponsiveContainer>
                        </div>
                      ) : (
                        <div style={{ textAlign: "center", color: "rgba(255,255,255,0.25)", fontFamily: "monospace", fontSize: "0.8rem", padding: "20px 0" }}>
                          Данных за текущий месяц ещё нет
                        </div>
                      )}
                    </div>
                  </div>
                </div>
              ))}
            </div>
          )
        ) : (
          /* Reviews tab */
          <div>
            {/* Search */}
            <div style={{ marginBottom: 16, display: "flex", gap: 12, alignItems: "center", flexWrap: "wrap" }}>
              <input
                type="text"
                placeholder="Поиск по ссылке, имени, email, заявке..."
                value={reviewSearch}
                onChange={(e) => { setReviewSearch(e.target.value); setReviewPage(1); }}
                style={{
                  flex: 1, minWidth: 200, maxWidth: 420,
                  padding: "10px 14px",
                  background: "rgba(255,255,255,0.04)",
                  border: "1px solid rgba(255,255,255,0.1)",
                  borderRadius: 6,
                  color: "#fff", fontSize: "0.875rem",
                  outline: "none",
                }}
                onFocus={(e) => (e.currentTarget.style.borderColor = C)}
                onBlur={(e) => (e.currentTarget.style.borderColor = "rgba(255,255,255,0.1)")}
              />
              {reviewSearch && (
                <div style={{ fontSize: "0.8rem", color: "rgba(255,255,255,0.4)", fontFamily: "monospace" }}>
                  {filteredReviews.length} из {reviews.length}
                </div>
              )}
            </div>

            {reviewsLoading ? (
              <div style={{ color: "rgba(255,255,255,0.4)", fontFamily: "monospace", fontSize: "0.85rem" }}>Загрузка отзывов...</div>
            ) : reviewsError ? (
              <div style={{ color: "#ff6666", fontFamily: "monospace", fontSize: "0.85rem" }}>Ошибка загрузки отзывов</div>
            ) : filteredReviews.length === 0 ? (
              <div style={{ background: CARD_BG, border: `1px solid ${BORDER}`, borderRadius: 10, padding: 48, textAlign: "center", color: "rgba(255,255,255,0.3)", fontFamily: "monospace" }}>
                {reviews.length === 0 ? "Отзывов пока нет. Запустите синхронизацию с таблицей." : "Ничего не найдено"}
              </div>
            ) : (
              <>
                <div style={{ background: CARD_BG, border: `1px solid ${CARD_BORDER}`, borderRadius: 10, overflow: "hidden", marginBottom: 16 }}>
                  <div style={{ overflowX: "auto" }}>
                    <table className="rev-table">
                      <thead>
                        <tr>
                          <th>Дата</th>
                          <th>Площадка</th>
                          <th>Ссылка на отзыв</th>
                          <th>Заявка</th>
                          <th>Имя</th>
                          <th>Email</th>
                        </tr>
                      </thead>
                      <tbody>
                        {pagedReviews.map((r) => (
                          <tr key={r.id}>
                            <td style={{ whiteSpace: "nowrap", color: "rgba(255,255,255,0.5)", fontFamily: "monospace", fontSize: "0.75rem" }}>
                              {formatDate(r.reviewDate)}
                            </td>
                            <td style={{ color: "rgba(255,255,255,0.45)", fontSize: "0.75rem", fontFamily: "monospace", maxWidth: 140, wordBreak: "break-all" }}>
                              {r.siteUrl ? r.siteUrl.replace(/^https?:\/\/(www\.)?/, "") : "—"}
                            </td>
                            <td>
                              <a
                                href={r.reviewUrl}
                                target="_blank"
                                rel="noopener noreferrer"
                                className="rev-link"
                                title={r.reviewUrl}
                              >
                                {truncateUrl(r.reviewUrl, 45)}
                              </a>
                            </td>
                            <td style={{ color: "rgba(255,255,255,0.55)", maxWidth: 160 }}>
                              {r.requestId || <span style={{ opacity: 0.3 }}>—</span>}
                            </td>
                            <td style={{ whiteSpace: "nowrap" }}>{r.name}</td>
                            <td style={{ color: "rgba(255,255,255,0.5)", fontFamily: "monospace", fontSize: "0.75rem" }}>
                              {r.email || <span style={{ opacity: 0.3 }}>—</span>}
                            </td>
                          </tr>
                        ))}
                      </tbody>
                    </table>
                  </div>
                </div>

                {/* Pagination */}
                {totalPages > 1 && (
                  <div style={{ display: "flex", alignItems: "center", gap: 6, flexWrap: "wrap" }}>
                    <button className="pag-btn" disabled={reviewPage === 1} onClick={() => setReviewPage(reviewPage - 1)}>← Назад</button>
                    {Array.from({ length: Math.min(totalPages, 7) }, (_, i) => {
                      let p: number;
                      if (totalPages <= 7) p = i + 1;
                      else if (reviewPage <= 4) p = i + 1;
                      else if (reviewPage >= totalPages - 3) p = totalPages - 6 + i;
                      else p = reviewPage - 3 + i;
                      return (
                        <button
                          key={p}
                          className={`pag-btn${reviewPage === p ? " active" : ""}`}
                          onClick={() => setReviewPage(p)}
                        >
                          {p}
                        </button>
                      );
                    })}
                    <button className="pag-btn" disabled={reviewPage === totalPages} onClick={() => setReviewPage(reviewPage + 1)}>Вперёд →</button>
                    <span style={{ fontSize: "0.75rem", color: "rgba(255,255,255,0.3)", fontFamily: "monospace", marginLeft: 8 }}>
                      {filteredReviews.length} записей
                    </span>
                  </div>
                )}
              </>
            )}
          </div>
        )}
      </div>
    </ClientLayout>
  );
}
