import { useEffect, useState } from "react";
import AdminLayout from "./AdminLayout";

interface AccountingRecord {
  id: number;
  type: string;
  amount: string;
  description: string;
  category: string | null;
  recordDate: string;
}

const C = "#c9ff47";
const CARD_BG = "hsl(240 12% 8%)";
const BORDER = "hsl(240 10% 15%)";
const INPUT_STYLE: React.CSSProperties = {
  background: "hsl(240 10% 12%)", border: `1px solid ${BORDER}`,
  borderRadius: 6, color: "#fff", padding: "9px 12px", fontSize: "0.875rem",
  outline: "none", width: "100%", fontFamily: "inherit",
};

function emptyForm() {
  return { type: "income", amount: "", description: "", category: "", recordDate: new Date().toISOString().split("T")[0] };
}

export default function Accounting() {
  const [records, setRecords] = useState<AccountingRecord[]>([]);
  const [loading, setLoading] = useState(true);
  const [showForm, setShowForm] = useState(false);
  const [editing, setEditing] = useState<AccountingRecord | null>(null);
  const [form, setForm] = useState(emptyForm());
  const [saving, setSaving] = useState(false);

  const load = () => {
    setLoading(true);
    fetch("/api/admin/accounting")
      .then((r) => r.json())
      .then((d) => { if (d.ok) setRecords(d.records); })
      .finally(() => setLoading(false));
  };

  useEffect(() => { load(); }, []);

  const totalIncome = records.filter(r => r.type === "income").reduce((s, r) => s + parseFloat(r.amount), 0);
  const totalExpense = records.filter(r => r.type === "expense").reduce((s, r) => s + parseFloat(r.amount), 0);
  const balance = totalIncome - totalExpense;

  const openAdd = () => { setForm(emptyForm()); setEditing(null); setShowForm(true); };
  const openEdit = (r: AccountingRecord) => { setEditing(r); setForm({ type: r.type, amount: r.amount, description: r.description, category: r.category || "", recordDate: r.recordDate }); setShowForm(true); };

  const save = async () => {
    setSaving(true);
    const url = editing ? `/api/admin/accounting/${editing.id}` : "/api/admin/accounting";
    const method = editing ? "PUT" : "POST";
    const res = await fetch(url, { method, headers: { "Content-Type": "application/json" }, body: JSON.stringify(form) });
    const data = await res.json();
    if (data.ok) { setShowForm(false); load(); }
    setSaving(false);
  };

  const del = async (id: number) => {
    if (!confirm("Удалить запись?")) return;
    await fetch(`/api/admin/accounting/${id}`, { method: "DELETE" });
    load();
  };

  const fmt = (v: string | number) => parseFloat(String(v)).toLocaleString("ru-RU", { minimumFractionDigits: 2 });

  return (
    <AdminLayout>
      <div style={{ padding: "40px 48px" }}>
        <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: 32 }}>
          <div>
            <div style={{ fontSize: "0.7rem", letterSpacing: 3, color: C, textTransform: "uppercase", marginBottom: 8, fontFamily: "monospace" }}>Бухгалтерия</div>
            <h1 style={{ fontSize: "1.75rem", fontWeight: 800, color: "#fff", letterSpacing: -0.5 }}>Учёт доходов и расходов</h1>
          </div>
          <button onClick={openAdd} style={{ padding: "10px 20px", background: C, border: "none", borderRadius: 6, color: "#050505", fontWeight: 700, fontSize: "0.85rem", cursor: "pointer" }}>
            + Добавить запись
          </button>
        </div>

        {/* Summary cards */}
        <div style={{ display: "grid", gridTemplateColumns: "repeat(3, 1fr)", gap: 16, marginBottom: 32 }}>
          {[
            { label: "Доходы", value: `$${fmt(totalIncome)}`, color: "hsl(142 71% 45%)" },
            { label: "Расходы", value: `$${fmt(totalExpense)}`, color: "hsl(0 84% 60%)" },
            { label: "Баланс", value: `$${fmt(balance)}`, color: balance >= 0 ? C : "hsl(0 84% 60%)" },
          ].map(({ label, value, color }) => (
            <div key={label} style={{ background: CARD_BG, border: `1px solid ${BORDER}`, borderRadius: 10, padding: "20px 24px" }}>
              <div style={{ fontSize: "0.75rem", color: "hsl(0 0% 55%)", marginBottom: 10, textTransform: "uppercase", letterSpacing: 1 }}>{label}</div>
              <div style={{ fontSize: "1.6rem", fontWeight: 800, color }}>{value}</div>
            </div>
          ))}
        </div>

        {/* Table */}
        <div style={{ background: CARD_BG, border: `1px solid ${BORDER}`, borderRadius: 10, overflow: "hidden" }}>
          <table style={{ width: "100%", borderCollapse: "collapse" }}>
            <thead>
              <tr style={{ borderBottom: `1px solid ${BORDER}` }}>
                {["Дата", "Тип", "Описание", "Категория", "Сумма", ""].map(h => (
                  <th key={h} style={{ padding: "14px 16px", textAlign: "left", fontSize: "0.72rem", color: "hsl(0 0% 50%)", fontWeight: 600, textTransform: "uppercase", letterSpacing: 1 }}>{h}</th>
                ))}
              </tr>
            </thead>
            <tbody>
              {loading ? (
                <tr><td colSpan={6} style={{ padding: "32px 16px", color: "hsl(0 0% 50%)", textAlign: "center" }}>Загрузка...</td></tr>
              ) : records.length === 0 ? (
                <tr><td colSpan={6} style={{ padding: "32px 16px", color: "hsl(0 0% 45%)", textAlign: "center" }}>Нет записей</td></tr>
              ) : records.map((r) => (
                <tr key={r.id} style={{ borderBottom: `1px solid hsl(240 10% 12%)` }}>
                  <td style={{ padding: "12px 16px", fontSize: "0.875rem", color: "hsl(0 0% 65%)" }}>{r.recordDate}</td>
                  <td style={{ padding: "12px 16px" }}>
                    <span style={{
                      padding: "3px 8px", borderRadius: 4, fontSize: "0.75rem", fontWeight: 600,
                      background: r.type === "income" ? "rgba(74,222,128,0.1)" : "rgba(255,68,68,0.1)",
                      color: r.type === "income" ? "hsl(142 71% 45%)" : "hsl(0 84% 60%)",
                    }}>
                      {r.type === "income" ? "Доход" : "Расход"}
                    </span>
                  </td>
                  <td style={{ padding: "12px 16px", fontSize: "0.875rem", color: "#fff" }}>{r.description}</td>
                  <td style={{ padding: "12px 16px", fontSize: "0.875rem", color: "hsl(0 0% 55%)" }}>{r.category || "—"}</td>
                  <td style={{ padding: "12px 16px", fontSize: "0.875rem", fontWeight: 700, color: r.type === "income" ? "hsl(142 71% 45%)" : "hsl(0 84% 60%)" }}>
                    {r.type === "income" ? "+" : "−"}${fmt(r.amount)}
                  </td>
                  <td style={{ padding: "12px 16px" }}>
                    <div style={{ display: "flex", gap: 6 }}>
                      <button onClick={() => openEdit(r)} style={{ padding: "4px 10px", background: "hsl(240 10% 14%)", border: `1px solid ${BORDER}`, borderRadius: 4, color: "#fff", cursor: "pointer", fontSize: "0.75rem" }}>Ред.</button>
                      <button onClick={() => del(r.id)} style={{ padding: "4px 10px", background: "rgba(255,68,68,0.1)", border: "1px solid rgba(255,68,68,0.3)", borderRadius: 4, color: "#ff6666", cursor: "pointer", fontSize: "0.75rem" }}>Удал.</button>
                    </div>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {showForm && (
        <div style={{ position: "fixed", inset: 0, background: "rgba(0,0,0,0.75)", display: "flex", alignItems: "center", justifyContent: "center", zIndex: 1000, padding: 24 }}>
          <div style={{ background: "hsl(240 12% 8%)", border: `1px solid ${BORDER}`, borderRadius: 12, padding: "28px", width: "100%", maxWidth: 480 }}>
            <h2 style={{ fontSize: "1.1rem", fontWeight: 700, color: "#fff", marginBottom: 20 }}>{editing ? "Редактировать запись" : "Новая запись"}</h2>
            <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 12, marginBottom: 12 }}>
              <div>
                <label style={{ fontSize: "0.75rem", color: "hsl(0 0% 55%)", display: "block", marginBottom: 6 }}>Тип</label>
                <select style={{ ...INPUT_STYLE }} value={form.type} onChange={(e) => setForm({ ...form, type: e.target.value })}>
                  <option value="income">Доход</option>
                  <option value="expense">Расход</option>
                </select>
              </div>
              <div>
                <label style={{ fontSize: "0.75rem", color: "hsl(0 0% 55%)", display: "block", marginBottom: 6 }}>Дата</label>
                <input type="date" style={INPUT_STYLE} value={form.recordDate} onChange={(e) => setForm({ ...form, recordDate: e.target.value })} />
              </div>
            </div>
            <div style={{ marginBottom: 12 }}>
              <label style={{ fontSize: "0.75rem", color: "hsl(0 0% 55%)", display: "block", marginBottom: 6 }}>Описание</label>
              <input style={INPUT_STYLE} value={form.description} onChange={(e) => setForm({ ...form, description: e.target.value })} placeholder="Описание" />
            </div>
            <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 12, marginBottom: 20 }}>
              <div>
                <label style={{ fontSize: "0.75rem", color: "hsl(0 0% 55%)", display: "block", marginBottom: 6 }}>Категория</label>
                <input style={INPUT_STYLE} value={form.category} onChange={(e) => setForm({ ...form, category: e.target.value })} placeholder="Необязательно" />
              </div>
              <div>
                <label style={{ fontSize: "0.75rem", color: "hsl(0 0% 55%)", display: "block", marginBottom: 6 }}>Сумма ($)</label>
                <input type="number" style={INPUT_STYLE} value={form.amount} onChange={(e) => setForm({ ...form, amount: e.target.value })} placeholder="0.00" min={0} step="0.01" />
              </div>
            </div>
            <div style={{ display: "flex", gap: 12 }}>
              <button onClick={save} disabled={saving} style={{ flex: 1, padding: "11px", background: C, border: "none", borderRadius: 6, color: "#050505", fontWeight: 700, cursor: "pointer", fontSize: "0.875rem" }}>
                {saving ? "Сохранение..." : "Сохранить"}
              </button>
              <button onClick={() => setShowForm(false)} style={{ padding: "11px 20px", background: "transparent", border: `1px solid ${BORDER}`, borderRadius: 6, color: "#fff", cursor: "pointer" }}>
                Отмена
              </button>
            </div>
          </div>
        </div>
      )}
    </AdminLayout>
  );
}
