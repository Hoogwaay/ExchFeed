import { useEffect, useState } from "react";
import AdminLayout from "./AdminLayout";

interface Resource {
  id: number;
  name: string;
  url: string;
  language: string;
  format: string;
}

const C = "hsl(186 100% 50%)";
const CARD_BG = "hsl(240 12% 8%)";
const BORDER = "hsl(240 10% 15%)";
const INPUT_STYLE: React.CSSProperties = {
  background: "hsl(240 10% 12%)", border: `1px solid ${BORDER}`,
  borderRadius: 6, color: "#fff", padding: "9px 12px", fontSize: "0.875rem",
  outline: "none", width: "100%", fontFamily: "inherit",
};

function emptyForm() {
  return { name: "", url: "", language: "RU", format: "monitoring" };
}

export default function Resources() {
  const [resources, setResources] = useState<Resource[]>([]);
  const [loading, setLoading] = useState(true);
  const [showForm, setShowForm] = useState(false);
  const [form, setForm] = useState(emptyForm());
  const [saving, setSaving] = useState(false);
  const [filter, setFilter] = useState<"all" | "monitoring" | "forum">("all");

  const load = () => {
    setLoading(true);
    fetch("/api/admin/resources")
      .then((r) => r.json())
      .then((d) => { if (d.ok) setResources(d.resources); })
      .finally(() => setLoading(false));
  };

  useEffect(() => { load(); }, []);

  const save = async () => {
    setSaving(true);
    const res = await fetch("/api/admin/resources", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify(form) });
    const data = await res.json();
    if (data.ok) { setShowForm(false); setForm(emptyForm()); load(); }
    setSaving(false);
  };

  const del = async (id: number) => {
    if (!confirm("Удалить ресурс?")) return;
    await fetch(`/api/admin/resources/${id}`, { method: "DELETE" });
    load();
  };

  const filtered = filter === "all" ? resources : resources.filter(r => r.format === filter);

  const formatLabel = (f: string) => f === "monitoring" ? "Мониторинг" : "Форум";
  const formatColor = (f: string) => f === "monitoring" ? "hsl(262 83% 68%)" : "hsl(45 100% 51%)";
  const formatBg = (f: string) => f === "monitoring" ? "rgba(139,92,246,0.12)" : "rgba(251,191,36,0.12)";

  return (
    <AdminLayout>
      <div style={{ padding: "40px 48px" }}>
        <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: 32 }}>
          <div>
            <div style={{ fontSize: "0.7rem", letterSpacing: 3, color: C, textTransform: "uppercase", marginBottom: 8, fontFamily: "monospace" }}>Ресурсы</div>
            <h1 style={{ fontSize: "1.75rem", fontWeight: 800, color: "#fff", letterSpacing: -0.5 }}>Мониторинги и форумы</h1>
          </div>
          <button onClick={() => setShowForm(true)} style={{ padding: "10px 20px", background: C, border: "none", borderRadius: 6, color: "#050505", fontWeight: 700, fontSize: "0.85rem", cursor: "pointer" }}>
            + Добавить ресурс
          </button>
        </div>

        {/* Filter tabs */}
        <div style={{ display: "flex", gap: 8, marginBottom: 24 }}>
          {[["all", "Все"], ["monitoring", "Мониторинги"], ["forum", "Форумы"]].map(([val, label]) => (
            <button
              key={val}
              onClick={() => setFilter(val as typeof filter)}
              style={{
                padding: "7px 16px", borderRadius: 6, cursor: "pointer", fontSize: "0.85rem",
                background: filter === val ? C : "hsl(240 10% 12%)",
                border: `1px solid ${filter === val ? C : BORDER}`,
                color: filter === val ? "#050505" : "hsl(0 0% 65%)",
                fontWeight: filter === val ? 700 : 400,
                transition: "all 0.15s",
              }}
            >
              {label}
            </button>
          ))}
          <span style={{ marginLeft: "auto", fontSize: "0.85rem", color: "hsl(0 0% 50%)", alignSelf: "center" }}>
            {filtered.length} ресурс{filtered.length === 1 ? "" : "ов"}
          </span>
        </div>

        {/* Resource grid */}
        {loading ? (
          <div style={{ color: "hsl(0 0% 50%)" }}>Загрузка...</div>
        ) : filtered.length === 0 ? (
          <div style={{ background: CARD_BG, border: `1px solid ${BORDER}`, borderRadius: 10, padding: "48px", textAlign: "center", color: "hsl(0 0% 45%)" }}>
            Нет ресурсов. Добавьте первый.
          </div>
        ) : (
          <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(320px, 1fr))", gap: 16 }}>
            {filtered.map((r) => (
              <div key={r.id} style={{ background: CARD_BG, border: `1px solid ${BORDER}`, borderRadius: 10, padding: "20px", display: "flex", flexDirection: "column", gap: 12 }}>
                <div style={{ display: "flex", alignItems: "flex-start", justifyContent: "space-between", gap: 8 }}>
                  <div style={{ fontWeight: 700, fontSize: "1rem", color: "#fff", flex: 1 }}>{r.name}</div>
                  <button onClick={() => del(r.id)} style={{ padding: "4px 10px", background: "rgba(255,68,68,0.1)", border: "1px solid rgba(255,68,68,0.3)", borderRadius: 4, color: "#ff6666", cursor: "pointer", fontSize: "0.75rem", flexShrink: 0 }}>
                    Удалить
                  </button>
                </div>
                <a
                  href={r.url} target="_blank" rel="noreferrer"
                  style={{ color: C, fontSize: "0.82rem", textDecoration: "none", wordBreak: "break-all", opacity: 0.85 }}
                  onMouseOver={(e) => (e.currentTarget.style.opacity = "1")}
                  onMouseOut={(e) => (e.currentTarget.style.opacity = "0.85")}
                >
                  {r.url}
                </a>
                <div style={{ display: "flex", gap: 8 }}>
                  <span style={{ padding: "3px 10px", borderRadius: 4, fontSize: "0.75rem", fontWeight: 600, background: formatBg(r.format), color: formatColor(r.format) }}>
                    {formatLabel(r.format)}
                  </span>
                  <span style={{ padding: "3px 10px", borderRadius: 4, fontSize: "0.75rem", fontWeight: 600, background: "hsl(240 10% 14%)", color: "hsl(0 0% 65%)" }}>
                    {r.language}
                  </span>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {showForm && (
        <div style={{ position: "fixed", inset: 0, background: "rgba(0,0,0,0.75)", display: "flex", alignItems: "center", justifyContent: "center", zIndex: 1000, padding: 24 }}>
          <div style={{ background: "hsl(240 12% 8%)", border: `1px solid ${BORDER}`, borderRadius: 12, padding: "28px", width: "100%", maxWidth: 460 }}>
            <h2 style={{ fontSize: "1.1rem", fontWeight: 700, color: "#fff", marginBottom: 20 }}>Добавить ресурс</h2>
            <div style={{ marginBottom: 12 }}>
              <label style={{ fontSize: "0.75rem", color: "hsl(0 0% 55%)", display: "block", marginBottom: 6 }}>Название</label>
              <input style={INPUT_STYLE} value={form.name} onChange={(e) => setForm({ ...form, name: e.target.value })} placeholder="Название ресурса" />
            </div>
            <div style={{ marginBottom: 12 }}>
              <label style={{ fontSize: "0.75rem", color: "hsl(0 0% 55%)", display: "block", marginBottom: 6 }}>Ссылка</label>
              <input style={INPUT_STYLE} value={form.url} onChange={(e) => setForm({ ...form, url: e.target.value })} placeholder="https://example.com" />
            </div>
            <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 12, marginBottom: 20 }}>
              <div>
                <label style={{ fontSize: "0.75rem", color: "hsl(0 0% 55%)", display: "block", marginBottom: 6 }}>Язык</label>
                <select style={{ ...INPUT_STYLE }} value={form.language} onChange={(e) => setForm({ ...form, language: e.target.value })}>
                  {["RU", "UA", "EN", "DE", "PL", "CZ", "SK", "HU", "RO", "BG"].map(l => <option key={l} value={l}>{l}</option>)}
                </select>
              </div>
              <div>
                <label style={{ fontSize: "0.75rem", color: "hsl(0 0% 55%)", display: "block", marginBottom: 6 }}>Формат</label>
                <select style={{ ...INPUT_STYLE }} value={form.format} onChange={(e) => setForm({ ...form, format: e.target.value })}>
                  <option value="monitoring">Мониторинг</option>
                  <option value="forum">Форум</option>
                </select>
              </div>
            </div>
            <div style={{ display: "flex", gap: 12 }}>
              <button onClick={save} disabled={saving} style={{ flex: 1, padding: "11px", background: C, border: "none", borderRadius: 6, color: "#050505", fontWeight: 700, cursor: "pointer", fontSize: "0.875rem" }}>
                {saving ? "Сохранение..." : "Добавить"}
              </button>
              <button onClick={() => { setShowForm(false); setForm(emptyForm()); }} style={{ padding: "11px 20px", background: "transparent", border: `1px solid ${BORDER}`, borderRadius: 6, color: "#fff", cursor: "pointer" }}>
                Отмена
              </button>
            </div>
          </div>
        </div>
      )}
    </AdminLayout>
  );
}
