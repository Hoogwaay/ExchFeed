import { useEffect, useState } from "react";
import AdminLayout from "./AdminLayout";

interface Schedule {
  id: number;
  staffName: string;
  workDate: string;
  startTime: string | null;
  endTime: string | null;
  notes: string | null;
}

const C = "hsl(186 100% 50%)";
const CARD_BG = "hsl(240 12% 8%)";
const BORDER = "hsl(240 10% 15%)";
const INPUT_STYLE: React.CSSProperties = {
  background: "hsl(240 10% 12%)", border: `1px solid ${BORDER}`,
  borderRadius: 6, color: "#fff", padding: "9px 12px", fontSize: "0.875rem",
  outline: "none", width: "100%", fontFamily: "inherit",
};

function emptyForm() {
  return { staffName: "", workDate: new Date().toISOString().split("T")[0], startTime: "", endTime: "", notes: "" };
}

export default function Schedule() {
  const [schedules, setSchedules] = useState<Schedule[]>([]);
  const [loading, setLoading] = useState(true);
  const [showForm, setShowForm] = useState(false);
  const [editing, setEditing] = useState<Schedule | null>(null);
  const [form, setForm] = useState(emptyForm());
  const [saving, setSaving] = useState(false);

  const load = () => {
    setLoading(true);
    fetch("/api/admin/schedules")
      .then((r) => r.json())
      .then((d) => { if (d.ok) setSchedules(d.schedules); })
      .finally(() => setLoading(false));
  };

  useEffect(() => { load(); }, []);

  const openAdd = () => { setForm(emptyForm()); setEditing(null); setShowForm(true); };
  const openEdit = (s: Schedule) => { setEditing(s); setForm({ staffName: s.staffName, workDate: s.workDate, startTime: s.startTime || "", endTime: s.endTime || "", notes: s.notes || "" }); setShowForm(true); };

  const save = async () => {
    setSaving(true);
    const url = editing ? `/api/admin/schedules/${editing.id}` : "/api/admin/schedules";
    const method = editing ? "PUT" : "POST";
    const res = await fetch(url, { method, headers: { "Content-Type": "application/json" }, body: JSON.stringify(form) });
    const data = await res.json();
    if (data.ok) { setShowForm(false); load(); }
    setSaving(false);
  };

  const del = async (id: number) => {
    if (!confirm("Удалить запись?")) return;
    await fetch(`/api/admin/schedules/${id}`, { method: "DELETE" });
    load();
  };

  const grouped = schedules.reduce<Record<string, Schedule[]>>((acc, s) => {
    (acc[s.workDate] = acc[s.workDate] || []).push(s);
    return acc;
  }, {});
  const sortedDates = Object.keys(grouped).sort((a, b) => b.localeCompare(a));

  return (
    <AdminLayout>
      <div style={{ padding: "40px 48px" }}>
        <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: 32 }}>
          <div>
            <div style={{ fontSize: "0.7rem", letterSpacing: 3, color: C, textTransform: "uppercase", marginBottom: 8, fontFamily: "monospace" }}>График</div>
            <h1 style={{ fontSize: "1.75rem", fontWeight: 800, color: "#fff", letterSpacing: -0.5 }}>График работы сотрудников</h1>
          </div>
          <button onClick={openAdd} style={{ padding: "10px 20px", background: C, border: "none", borderRadius: 6, color: "#050505", fontWeight: 700, fontSize: "0.85rem", cursor: "pointer" }}>
            + Добавить смену
          </button>
        </div>

        {loading ? (
          <div style={{ color: "hsl(0 0% 50%)" }}>Загрузка...</div>
        ) : schedules.length === 0 ? (
          <div style={{ background: CARD_BG, border: `1px solid ${BORDER}`, borderRadius: 10, padding: "48px", textAlign: "center", color: "hsl(0 0% 45%)" }}>
            Нет записей. Добавьте первую смену.
          </div>
        ) : (
          <div style={{ display: "flex", flexDirection: "column", gap: 24 }}>
            {sortedDates.map((date) => (
              <div key={date}>
                <div style={{ fontSize: "0.75rem", color: C, fontFamily: "monospace", letterSpacing: 2, textTransform: "uppercase", marginBottom: 10 }}>
                  {new Date(date + "T12:00:00").toLocaleDateString("ru-RU", { weekday: "long", day: "numeric", month: "long" })}
                </div>
                <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
                  {grouped[date].map((s) => (
                    <div key={s.id} style={{ background: CARD_BG, border: `1px solid ${BORDER}`, borderRadius: 8, padding: "14px 18px", display: "flex", alignItems: "center", gap: 16 }}>
                      <div style={{ flex: 1 }}>
                        <div style={{ fontWeight: 600, color: "#fff", marginBottom: 4 }}>{s.staffName}</div>
                        {(s.startTime || s.endTime) && (
                          <div style={{ fontSize: "0.82rem", color: "hsl(0 0% 55%)" }}>
                            {s.startTime && `Начало: ${s.startTime}`}
                            {s.startTime && s.endTime && " — "}
                            {s.endTime && `Конец: ${s.endTime}`}
                          </div>
                        )}
                        {s.notes && <div style={{ fontSize: "0.8rem", color: "hsl(0 0% 50%)", marginTop: 4, fontStyle: "italic" }}>{s.notes}</div>}
                      </div>
                      <div style={{ display: "flex", gap: 6 }}>
                        <button onClick={() => openEdit(s)} style={{ padding: "5px 12px", background: "hsl(240 10% 14%)", border: `1px solid ${BORDER}`, borderRadius: 4, color: "#fff", cursor: "pointer", fontSize: "0.8rem" }}>Ред.</button>
                        <button onClick={() => del(s.id)} style={{ padding: "5px 12px", background: "rgba(255,68,68,0.1)", border: "1px solid rgba(255,68,68,0.3)", borderRadius: 4, color: "#ff6666", cursor: "pointer", fontSize: "0.8rem" }}>Удал.</button>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            ))}
          </div>
        )}
      </div>

      {showForm && (
        <div style={{ position: "fixed", inset: 0, background: "rgba(0,0,0,0.75)", display: "flex", alignItems: "center", justifyContent: "center", zIndex: 1000, padding: 24 }}>
          <div style={{ background: "hsl(240 12% 8%)", border: `1px solid ${BORDER}`, borderRadius: 12, padding: "28px", width: "100%", maxWidth: 460 }}>
            <h2 style={{ fontSize: "1.1rem", fontWeight: 700, color: "#fff", marginBottom: 20 }}>{editing ? "Редактировать смену" : "Добавить смену"}</h2>
            <div style={{ marginBottom: 12 }}>
              <label style={{ fontSize: "0.75rem", color: "hsl(0 0% 55%)", display: "block", marginBottom: 6 }}>Сотрудник</label>
              <input style={INPUT_STYLE} value={form.staffName} onChange={(e) => setForm({ ...form, staffName: e.target.value })} placeholder="Имя сотрудника" />
            </div>
            <div style={{ marginBottom: 12 }}>
              <label style={{ fontSize: "0.75rem", color: "hsl(0 0% 55%)", display: "block", marginBottom: 6 }}>Дата</label>
              <input type="date" style={INPUT_STYLE} value={form.workDate} onChange={(e) => setForm({ ...form, workDate: e.target.value })} />
            </div>
            <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 12, marginBottom: 12 }}>
              <div>
                <label style={{ fontSize: "0.75rem", color: "hsl(0 0% 55%)", display: "block", marginBottom: 6 }}>Начало работы</label>
                <input type="time" style={INPUT_STYLE} value={form.startTime} onChange={(e) => setForm({ ...form, startTime: e.target.value })} />
              </div>
              <div>
                <label style={{ fontSize: "0.75rem", color: "hsl(0 0% 55%)", display: "block", marginBottom: 6 }}>Конец работы</label>
                <input type="time" style={INPUT_STYLE} value={form.endTime} onChange={(e) => setForm({ ...form, endTime: e.target.value })} />
              </div>
            </div>
            <div style={{ marginBottom: 20 }}>
              <label style={{ fontSize: "0.75rem", color: "hsl(0 0% 55%)", display: "block", marginBottom: 6 }}>Заметки</label>
              <input style={INPUT_STYLE} value={form.notes} onChange={(e) => setForm({ ...form, notes: e.target.value })} placeholder="Необязательно" />
            </div>
            <div style={{ display: "flex", gap: 12 }}>
              <button onClick={save} disabled={saving} style={{ flex: 1, padding: "11px", background: C, border: "none", borderRadius: 6, color: "#050505", fontWeight: 700, cursor: "pointer", fontSize: "0.875rem" }}>
                {saving ? "Сохранение..." : "Сохранить"}
              </button>
              <button onClick={() => setShowForm(false)} style={{ padding: "11px 20px", background: "transparent", border: `1px solid ${BORDER}`, borderRadius: 6, color: "#fff", cursor: "pointer" }}>
                Отмена
              </button>
            </div>
          </div>
        </div>
      )}
    </AdminLayout>
  );
}
