import { useEffect, useState, useRef } from "react";

interface LoaderProps {
  onDone: () => void;
}

export default function Loader({ onDone }: LoaderProps) {
  const [progress, setProgress] = useState(0);
  const [phase, setPhase] = useState<"counting" | "hold" | "exit">("counting");
  const intervalRef = useRef<ReturnType<typeof setInterval> | null>(null);
  const startRef = useRef<number>(Date.now());
  const DURATION = 2200;
  const HOLD = 220;

  useEffect(() => {
    startRef.current = Date.now();

    intervalRef.current = setInterval(() => {
      const elapsed = Date.now() - startRef.current;
      const t = Math.min(elapsed / DURATION, 1);
      const eased = t < 0.5 ? 4 * t * t * t : 1 - Math.pow(-2 * t + 2, 3) / 2;
      const val = Math.floor(eased * 100);
      setProgress(val);

      if (t >= 1) {
        if (intervalRef.current) clearInterval(intervalRef.current);
        setProgress(100);
        setPhase("hold");
        setTimeout(() => {
          setPhase("exit");
          setTimeout(() => onDone(), 900);
        }, HOLD);
      }
    }, 16);

    return () => {
      if (intervalRef.current) clearInterval(intervalRef.current);
    };
  }, [onDone]);

  const isExiting = phase === "exit";

  return (
    <div
      style={{
        position: "fixed",
        inset: 0,
        zIndex: 99999,
        display: "flex",
        overflow: "hidden",
        pointerEvents: isExiting ? "none" : "all",
      }}
    >
      {/* Left panel */}
      <div
        style={{
          position: "absolute",
          inset: 0,
          right: "50%",
          background: "#050505",
          transform: isExiting ? "translateX(-100%)" : "translateX(0)",
          transition: isExiting ? "transform 0.85s cubic-bezier(0.76,0,0.24,1)" : "none",
        }}
      />
      {/* Right panel */}
      <div
        style={{
          position: "absolute",
          inset: 0,
          left: "50%",
          background: "#050505",
          transform: isExiting ? "translateX(100%)" : "translateX(0)",
          transition: isExiting ? "transform 0.85s cubic-bezier(0.76,0,0.24,1)" : "none",
        }}
      />

      {/* Content layer */}
      <div
        style={{
          position: "absolute",
          inset: 0,
          display: "flex",
          flexDirection: "column",
          alignItems: "center",
          justifyContent: "center",
          opacity: isExiting ? 0 : 1,
          transition: isExiting ? "opacity 0.3s ease" : "none",
        }}
      >
        {/* Top-left brand */}
        <div
          style={{
            position: "absolute",
            top: 36,
            left: 48,
            fontFamily: "monospace",
            fontSize: "0.85rem",
            fontWeight: 700,
            letterSpacing: 4,
            color: "rgba(255,255,255,0.5)",
            textTransform: "uppercase",
          }}
        >
          Exchange Feed
        </div>

        {/* Top-right hint */}
        <div
          style={{
            position: "absolute",
            top: 36,
            right: 48,
            fontFamily: "monospace",
            fontSize: "0.65rem",
            letterSpacing: 3,
            color: "rgba(255,255,255,0.2)",
            textTransform: "uppercase",
          }}
        >
          Подождите
        </div>

        {/* Center: loading text */}
        <div
          style={{
            fontFamily: "monospace",
            fontSize: "clamp(0.65rem,1vw,0.8rem)",
            letterSpacing: 6,
            color: "rgba(255,255,255,0.3)",
            textTransform: "uppercase",
            marginBottom: 32,
            overflow: "hidden",
          }}
        >
          <span
            style={{
              display: "inline-block",
              transform: `translateY(${progress < 5 ? "100%" : "0"})`,
              transition: "transform 0.6s cubic-bezier(0.16,1,0.3,1)",
            }}
          >
            Загружаем возможности
          </span>
        </div>

        {/* Big percentage counter */}
        <div
          style={{
            fontFamily: "'Inter', monospace",
            fontSize: "clamp(6rem,16vw,14rem)",
            fontWeight: 900,
            lineHeight: 1,
            letterSpacing: -6,
            color: "#fff",
            position: "relative",
            userSelect: "none",
          }}
        >
          <span
            style={{
              display: "inline-block",
              minWidth: "3ch",
              textAlign: "right",
            }}
          >
            {progress}
          </span>
          <span
            style={{
              fontSize: "clamp(2rem,5vw,4.5rem)",
              color: "#c9ff47",
              letterSpacing: -2,
              marginLeft: 4,
              verticalAlign: "super",
            }}
          >
            %
          </span>
        </div>

        {/* Progress bar */}
        <div
          style={{
            width: "min(480px,60vw)",
            height: 1,
            background: "rgba(255,255,255,0.1)",
            marginTop: 48,
            position: "relative",
            overflow: "hidden",
          }}
        >
          <div
            style={{
              position: "absolute",
              inset: 0,
              right: `${100 - progress}%`,
              background: "#c9ff47",
              transition: "right 0.08s linear",
            }}
          />
        </div>

        {/* Bottom status row */}
        <div
          style={{
            position: "absolute",
            bottom: 40,
            left: 48,
            right: 48,
            display: "flex",
            justifyContent: "space-between",
            alignItems: "flex-end",
          }}
        >
          <div
            style={{
              fontFamily: "monospace",
              fontSize: "0.65rem",
              letterSpacing: 3,
              color: "#c9ff47",
              textTransform: "uppercase",
            }}
          >
            {progress < 30
              ? "Инициализация..."
              : progress < 60
              ? "Подключение..."
              : progress < 90
              ? "Почти готово..."
              : "Готово"}
          </div>
          <div
            style={{
              fontFamily: "monospace",
              fontSize: "0.65rem",
              letterSpacing: 3,
              color: "rgba(255,255,255,0.2)",
              textTransform: "uppercase",
            }}
          >
            {progress}%
          </div>
        </div>
      </div>
    </div>
  );
}
