import { Router } from "express";

const router = Router();

const STATIC_PLATFORMS = [
  { id: "1", name: "Яндекс Карты", slug: "yandex-maps", active: true, sortOrder: 1 },
  { id: "2", name: "Google Maps", slug: "google-maps", active: true, sortOrder: 2 },
  { id: "3", name: "2ГИС", slug: "2gis", active: true, sortOrder: 3 },
  { id: "4", name: "Авито", slug: "avito", active: true, sortOrder: 4 },
  { id: "5", name: "Отзовик", slug: "otzovik", active: true, sortOrder: 5 },
  { id: "6", name: "TripAdvisor", slug: "tripadvisor", active: true, sortOrder: 6 },
  { id: "7", name: "Яндекс Маркет", slug: "yandex-market", active: true, sortOrder: 7 },
  { id: "8", name: "Zoon", slug: "zoon", active: true, sortOrder: 8 },
  { id: "9", name: "Flamp", slug: "flamp", active: true, sortOrder: 9 },
];

router.get("/platforms", (_req, res) => {
  res.json({ ok: true, platforms: STATIC_PLATFORMS });
});

export default router;
