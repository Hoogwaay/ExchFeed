import { Router } from "express";
import { db } from "@workspace/db";
import { clients, insertClientSchema } from "@workspace/db";
import { eq, desc } from "drizzle-orm";

const router = Router();

router.get("/clients", async (_req, res) => {
  try {
    const all = await db.select().from(clients).orderBy(desc(clients.createdAt));
    res.json(all);
  } catch (e) {
    res.status(500).json({ error: String(e) });
  }
});

router.post("/clients", async (req, res) => {
  try {
    const parsed = insertClientSchema.safeParse(req.body);
    if (!parsed.success) return res.status(400).json({ error: parsed.error });
    const [created] = await db.insert(clients).values(parsed.data).returning();
    res.status(201).json(created);
  } catch (e) {
    res.status(500).json({ error: String(e) });
  }
});

router.put("/clients/:id", async (req, res) => {
  try {
    const parsed = insertClientSchema.partial().safeParse(req.body);
    if (!parsed.success) return res.status(400).json({ error: parsed.error });
    const [updated] = await db.update(clients).set(parsed.data).where(eq(clients.id, req.params.id)).returning();
    if (!updated) return res.status(404).json({ error: "Not found" });
    res.json(updated);
  } catch (e) {
    res.status(500).json({ error: String(e) });
  }
});

router.delete("/clients/:id", async (req, res) => {
  try {
    const [deleted] = await db.delete(clients).where(eq(clients.id, req.params.id)).returning();
    if (!deleted) return res.status(404).json({ error: "Not found" });
    res.json({ ok: true });
  } catch (e) {
    res.status(500).json({ error: String(e) });
  }
});

export default router;
