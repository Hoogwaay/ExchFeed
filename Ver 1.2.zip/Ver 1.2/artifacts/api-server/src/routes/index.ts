import { Router, type IRouter } from "express";
import healthRouter from "./health";
import clientsRouter from "./clients";
import reviewsRouter from "./reviews";
import transactionsRouter from "./transactions";
import tasksRouter from "./tasks";
import platformsRouter from "./platforms";
import contactRouter from "./contact";
import adminRouter from "./admin";

const router: IRouter = Router();

router.use(healthRouter);
router.use(clientsRouter);
router.use(reviewsRouter);
router.use(transactionsRouter);
router.use(tasksRouter);
router.use(platformsRouter);
router.use(contactRouter);
router.use(adminRouter);

export default router;
