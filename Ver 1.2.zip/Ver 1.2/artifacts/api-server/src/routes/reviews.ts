import { Router } from "express";
import { db } from "@workspace/db";
import { reviews, clients, insertReviewSchema } from "@workspace/db";
import { eq, desc } from "drizzle-orm";

const router = Router();

function groupBy(arr: { date: string; count: number }[], keyFn: (d: Date) => string) {
  const map: Record<string, number> = {};
  for (const item of arr) {
    const key = keyFn(new Date(item.date));
    map[key] = (map[key] || 0) + item.count;
  }
  return Object.entries(map)
    .sort((a, b) => a[0].localeCompare(b[0]))
    .map(([date, count]) => ({ date, count }));
}

router.get("/reviews/stats", async (_req, res) => {
  try {
    const allReviews = await db.select().from(reviews);
    const totalCount = allReviews.reduce((acc, r) => acc + r.count, 0);
    const totalEarned = allReviews.reduce((acc, r) => acc + Number(r.earnedAmount), 0);

    const now = new Date();
    const startOfMonth = new Date(now.getFullYear(), now.getMonth(), 1);
    const monthReviews = allReviews.filter(r => new Date(r.date) >= startOfMonth);
    const monthCount = monthReviews.reduce((acc, r) => acc + r.count, 0);

    const reviewItems = allReviews.map(r => ({ date: r.date, count: r.count }));

    const byDay = groupBy(reviewItems, d => d.toISOString().split("T")[0]);

    const byWeek = groupBy(reviewItems, d => {
      const monday = new Date(d);
      monday.setDate(d.getDate() - ((d.getDay() + 6) % 7));
      return monday.toISOString().split("T")[0];
    });

    const byMonth = groupBy(reviewItems, d =>
      `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}`
    );

    const allClients = await db.select().from(clients);
    res.json({
      totalAllTime: totalCount,
      totalThisMonth: monthCount,
      totalEarned: totalEarned.toFixed(2),
      clientCount: allClients.length,
      byDay,
      byWeek,
      byMonth,
    });
  } catch (e) {
    res.status(500).json({ error: String(e) });
  }
});

router.get("/reviews", async (_req, res) => {
  try {
    const all = await db.select().from(reviews).orderBy(desc(reviews.date));
    res.json(all);
  } catch (e) {
    res.status(500).json({ error: String(e) });
  }
});

router.post("/reviews", async (req, res) => {
  try {
    const parsed = insertReviewSchema.safeParse(req.body);
    if (!parsed.success) return res.status(400).json({ error: parsed.error });
    const [created] = await db.insert(reviews).values(parsed.data).returning();
    res.status(201).json(created);
  } catch (e) {
    res.status(500).json({ error: String(e) });
  }
});

router.put("/reviews/:id", async (req, res) => {
  try {
    const parsed = insertReviewSchema.partial().safeParse(req.body);
    if (!parsed.success) return res.status(400).json({ error: parsed.error });
    const [updated] = await db.update(reviews).set(parsed.data).where(eq(reviews.id, req.params.id)).returning();
    if (!updated) return res.status(404).json({ error: "Not found" });
    res.json(updated);
  } catch (e) {
    res.status(500).json({ error: String(e) });
  }
});

router.delete("/reviews/:id", async (req, res) => {
  try {
    const [deleted] = await db.delete(reviews).where(eq(reviews.id, req.params.id)).returning();
    if (!deleted) return res.status(404).json({ error: "Not found" });
    res.json({ ok: true });
  } catch (e) {
    res.status(500).json({ error: String(e) });
  }
});

export default router;
