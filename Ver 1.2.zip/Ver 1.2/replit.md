# Exchange Feed - Full Stack Trading Platform

## Project Overview

Exchange Feed is a multi-role trading/CRM platform with a React frontend and Node.js Express backend. The app is in Russian and includes multiple panels:

- **Public site** - Landing page with loader animation
- **Admin panel** (ExchFeed style) - Dashboard, Clients, Accounting, Schedule, Resources
- **Client cabinet** - Individual client view
- **AM panel** (Analytics Admin) - Overview, Customers, Balance, Reviews, Analytics, Campaign, Activity Log, Employees
- **CRM panel** (Worker panel) - Home, Client Info, Wallet Info

## Tech Stack

- **Frontend**: React + Vite + Tailwind CSS + Shadcn/UI + Radix UI, Wouter routing, TanStack Query
- **Backend**: Node.js + Express 5 + Pino logging
- **Database**: PostgreSQL with Drizzle ORM
- **Package Manager**: pnpm workspaces (monorepo)
- **Language**: TypeScript throughout
- **API**: OpenAPI spec in `lib/api-spec/openapi.yaml`, Zod validation

## Project Structure

```
artifacts/
  api-server/     # Node.js Express API (port 8080 in dev)
  main-site/      # React + Vite frontend (port 5000 in dev)
  mockup-sandbox/ # UI prototyping environment
lib/
  api-client-react/  # Generated React hooks for API
  api-spec/          # OpenAPI definitions
  api-zod/           # Zod schemas from OpenAPI
  db/                # Drizzle ORM schema and config
scripts/            # Utility scripts
```

## Development Workflows

- **Frontend**: `PORT=5000 BASE_PATH=/ pnpm --filter @workspace/main-site run dev` → port 5000
- **API Server**: `PORT=8080 pnpm --filter @workspace/api-server run dev` → port 8080

## Environment Variables

- `DATABASE_URL` - PostgreSQL connection string (Replit managed)
- `PORT` - Server port (required for both frontend and backend)
- `BASE_PATH` - Frontend base path (required, set to `/` for dev)
- `NODE_ENV` - Environment mode

## Database

PostgreSQL via Replit's built-in database. Schema managed with Drizzle ORM.
Push schema changes: `pnpm --filter @workspace/db run push`

## Key Notes

- The vite.config.ts requires both `PORT` and `BASE_PATH` environment variables
- Frontend host is always `0.0.0.0` with `allowedHosts: true` for Replit proxy
- API server uses `localhost` as host
- pnpm workspace with catalog for shared dependency versions
- The `.npmrc` enforces minimum package release age of 1440 minutes (security)
