import { Router } from "express";
import { db } from "../../database/index.js";
import { transactions } from "../../database/index.js";
import { eq, desc } from "drizzle-orm";
import { z } from "zod/v4";

const router = Router();

const transactionBodySchema = z.object({
  type: z.enum(["income", "expense"]),
  amount: z.union([z.string(), z.number()]).transform(v => String(v)),
  description: z.string().optional().nullable(),
  category: z.string().optional().nullable(),
  date: z.union([z.string(), z.date()]).transform(v =>
    typeof v === "string" ? new Date(v) : v
  ),
});

router.get("/transactions", async (_req, res) => {
  try {
    const all = await db.select().from(transactions).orderBy(desc(transactions.date));
    res.json(all);
  } catch (e) {
    res.status(500).json({ error: String(e) });
  }
});

router.post("/transactions", async (req, res) => {
  try {
    const parsed = transactionBodySchema.safeParse(req.body);
    if (!parsed.success) return res.status(400).json({ error: parsed.error });
    const [created] = await db.insert(transactions).values(parsed.data).returning();
    res.status(201).json(created);
  } catch (e) {
    res.status(500).json({ error: String(e) });
  }
});

// Support both PUT and PATCH
const updateHandler = async (req: any, res: any) => {
  try {
    const parsed = transactionBodySchema.partial().safeParse(req.body);
    if (!parsed.success) return res.status(400).json({ error: parsed.error });
    const [updated] = await db
      .update(transactions)
      .set(parsed.data)
      .where(eq(transactions.id, req.params.id))
      .returning();
    if (!updated) return res.status(404).json({ error: "Not found" });
    res.json(updated);
  } catch (e) {
    res.status(500).json({ error: String(e) });
  }
};

router.put("/transactions/:id", updateHandler);
router.patch("/transactions/:id", updateHandler);

router.delete("/transactions/:id", async (req, res) => {
  try {
    const [deleted] = await db.delete(transactions).where(eq(transactions.id, req.params.id)).returning();
    if (!deleted) return res.status(404).json({ error: "Not found" });
    res.json({ ok: true });
  } catch (e) {
    res.status(500).json({ error: String(e) });
  }
});

export default router;
