# Exchange Feed - Trading/CRM Platform

## Project Overview

Exchange Feed is a multi-role trading/CRM platform. The app is in Russian and includes:

- **Public site** — Landing page with loader animation
- **Admin panel** — Dashboard, Clients, Accounting, Schedule, Resources
- **AM panel** (Analytics Manager) — Overview, Customers, Balance, Reviews, Analytics, Campaign, Activity Log, Employees
- **CRM panel** (Worker) — Home, Client Info, Wallet Info
- **Client cabinet** — Individual client view

## Tech Stack

- **Frontend**: React + Vite + Tailwind CSS + Shadcn/UI, Wouter routing, TanStack Query
- **Backend**: Node.js + Express 5 + Pino logging
- **Database**: PostgreSQL with Drizzle ORM
- **Package Manager**: pnpm (single package, no workspaces)
- **Language**: TypeScript throughout

## Project Structure

```
client/        # React + Vite frontend (port 5000)
  src/
    pages/     # All pages: admin/, am/, crm/, client/, Home.tsx, Login.tsx
    components/# UI components (shadcn/ui + custom)
    api/       # API client (fetch wrapper)
    hooks/     # React hooks
    lib/       # Utilities, types, theme
  index.html
  vite.config.ts

server/        # Express API (port 8080)
  routes/      # API route files
  lib/         # Logger
  app.ts       # Express app setup
  index.ts     # Server entry point

database/      # Drizzle ORM
  schema.ts    # All DB table definitions
  index.ts     # DB connection + re-exports
  drizzle.config.ts

scripts/       # Utility scripts
  migrate-reviews.ts
  post-merge.sh

build-server.mjs  # esbuild bundler for server
package.json      # All dependencies (single package)
tsconfig.json
```

## Development

- **Start all**: `pnpm dev` (starts both server and client)
- **Client only**: `pnpm dev:client` → port 5000
- **Server only**: `pnpm dev:server` → port 8080
- **DB push**: `pnpm db:push`

## Environment Variables

- `DATABASE_URL` — PostgreSQL connection string (Replit managed)
- `PORT` — Server port
- `BASE_PATH` — Frontend base path (set to `/` for dev)
- `NODE_ENV` — Environment mode

## Key Notes

- Frontend: `host: "0.0.0.0"`, `allowedHosts: true` for Replit proxy
- Backend: runs on `localhost:8080`, proxied via Vite `/api`
- Single `package.json` — no pnpm workspaces
