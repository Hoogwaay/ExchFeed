import { execSync } from "child_process";
import pg from "pg";
import path from "path";
import { fileURLToPath } from "url";

const { Pool } = pg;

if (!process.env.DATABASE_URL) {
  throw new Error("DATABASE_URL is required");
}

const pool = new Pool({ connectionString: process.env.DATABASE_URL });

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const WORKSPACE_ROOT = path.resolve(__dirname, "../../");
const SQLITE_PATH = process.argv[2] || path.join(WORKSPACE_ROOT, "attached_assets/Reviews_1775380279279.db");

const CLIENT_TABLES = [
  "1WM",
  "Bitok777",
  "Exchange.Express",
  "EXWM",
  "Fastex",
  "Multival",
  "ObmenMoney",
  "Obmenoff",
  "VObmenka",
  "W-box",
  "WM.Money",
  "WX.Money",
];

function readSqliteTable(table: string): { date: string; link: string; email: string; application: string; name: string }[] {
  const output = execSync(
    `sqlite3 -separator "|||" "${SQLITE_PATH}" "SELECT date, link, email, заявка, name FROM \\"${table}\\""`,
    { encoding: "utf8", maxBuffer: 50 * 1024 * 1024 }
  );
  return output
    .split("\n")
    .filter(line => line.trim())
    .map(line => {
      const parts = line.split("|||");
      return {
        date: parts[0]?.trim() || "",
        link: parts[1]?.trim() || "",
        email: parts[2]?.trim() || "",
        application: parts[3]?.trim() || "",
        name: parts[4]?.trim() || "",
      };
    });
}

async function main() {
  const client = await pool.connect();
  try {
    for (const tableName of CLIENT_TABLES) {
      console.log(`\nProcessing client: ${tableName}`);

      const existing = await client.query(
        "SELECT id FROM clients WHERE name = $1",
        [tableName]
      );

      let clientId: string;
      if (existing.rows.length > 0) {
        clientId = existing.rows[0].id;
        console.log(`  Client already exists: ${clientId}`);
      } else {
        const res = await client.query(
          "INSERT INTO clients (name, status) VALUES ($1, 'in_work') RETURNING id",
          [tableName]
        );
        clientId = res.rows[0].id;
        console.log(`  Created client: ${clientId}`);
      }

      const existingReviews = await client.query(
        "SELECT COUNT(*) FROM client_reviews WHERE client_id = $1",
        [clientId]
      );
      if (parseInt(existingReviews.rows[0].count) > 0) {
        console.log(`  Already has ${existingReviews.rows[0].count} reviews, skipping import`);
        continue;
      }

      const rows = readSqliteTable(tableName);
      console.log(`  Importing ${rows.length} reviews...`);

      const BATCH = 500;
      for (let i = 0; i < rows.length; i += BATCH) {
        const batch = rows.slice(i, i + BATCH);
        const values: unknown[] = [];
        const placeholders = batch.map((row, j) => {
          const base = j * 5;
          values.push(clientId, row.date, row.link, row.email, row.application, row.name);
          return `($${base + 1}, $${base + 2}, $${base + 3}, $${base + 4}, $${base + 5}, $${base + 6})`;
        });

        const valuesWithCorrectIndex: unknown[] = [];
        const fixedPlaceholders = batch.map((row, j) => {
          const base = j * 6;
          valuesWithCorrectIndex.push(clientId, row.date, row.link, row.email, row.application, row.name);
          return `($${base + 1}, $${base + 2}, $${base + 3}, $${base + 4}, $${base + 5}, $${base + 6})`;
        });

        await client.query(
          `INSERT INTO client_reviews (client_id, review_date, link, email, application, reviewer_name) VALUES ${fixedPlaceholders.join(",")}`,
          valuesWithCorrectIndex
        );
        console.log(`  Batch ${Math.floor(i / BATCH) + 1}: inserted ${batch.length} rows`);
      }
    }

    console.log("\nMigration complete!");
  } finally {
    client.release();
    await pool.end();
  }
}

main().catch(err => {
  console.error("Migration failed:", err);
  process.exit(1);
});
