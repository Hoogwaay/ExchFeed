import { useRef, useEffect, useState, useCallback } from "react";
import { useLocation } from "wouter";
import { useCursor } from "@/lib/cursor-context";
import SplitReveal from "@/components/SplitReveal";

function scrollToId(id: string) {
  document.getElementById(id)?.scrollIntoView({ behavior: "smooth" });
}

function scrollToContact() {
  scrollToId("contact");
}

// ── Simple reveal hook ────────────────────────────────────────────────────────
type RevealState = "hidden-below" | "visible" | "hidden-above";

function useReveal() {
  const ref = useRef<HTMLDivElement>(null);
  const [state, setState] = useState<RevealState>("hidden-below");
  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    const obs = new IntersectionObserver(
      ([entry]) => {
        if (entry.isIntersecting) {
          setState("visible");
        } else {
          const rect = entry.boundingClientRect;
          setState(rect.top < 0 ? "hidden-above" : "hidden-below");
        }
      },
      { threshold: 0.12 }
    );
    obs.observe(el);
    return () => obs.disconnect();
  }, []);
  return { ref, state };
}

function RevealBlock({ children, delay = 0, style = {} }: {
  children: React.ReactNode; delay?: number; style?: React.CSSProperties;
}) {
  const { ref, state } = useReveal();
  return (
    <div ref={ref} style={{
      opacity: state === "visible" ? 1 : 0,
      transform: state === "visible"
        ? "translateY(0)"
        : state === "hidden-above"
          ? "translateY(-40px)"
          : "translateY(52px)",
      transition: `opacity 0.85s cubic-bezier(0.16,1,0.3,1) ${delay}ms, transform 0.85s cubic-bezier(0.16,1,0.3,1) ${delay}ms`,
      ...style,
    }}>
      {children}
    </div>
  );
}

// ── Count-up animation ────────────────────────────────────────────────────────
function CountUp({ target, suffix = "", duration = 1800, delay = 0 }: {
  target: number; suffix?: string; duration?: number; delay?: number;
}) {
  const ref = useRef<HTMLSpanElement>(null);
  const [count, setCount] = useState(0);
  const [started, setStarted] = useState(false);

  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    const obs = new IntersectionObserver(([entry]) => {
      if (entry.isIntersecting) { setStarted(true); obs.disconnect(); }
    }, { threshold: 0.5 });
    obs.observe(el);
    return () => obs.disconnect();
  }, []);

  useEffect(() => {
    if (!started) return;
    const start = Date.now() + delay;
    let raf: number;
    function tick() {
      const now = Date.now();
      if (now < start) { raf = requestAnimationFrame(tick); return; }
      const elapsed = now - start;
      const t = Math.min(elapsed / duration, 1);
      const eased = 1 - Math.pow(1 - t, 3);
      setCount(Math.floor(eased * target));
      if (t < 1) raf = requestAnimationFrame(tick);
      else setCount(target);
    }
    raf = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(raf);
  }, [started, target, duration, delay]);

  return <span ref={ref}>{count}{suffix}</span>;
}

// ── Line reveal ───────────────────────────────────────────────────────────────
function LineReveal({ delay = 0, color = "rgba(255,255,255,0.1)", style = {} }: {
  delay?: number; color?: string; style?: React.CSSProperties;
}) {
  const ref = useRef<HTMLDivElement>(null);
  const [vis, setVis] = useState(false);
  useEffect(() => {
    const el = ref.current;
    if (!el) return;
    const obs = new IntersectionObserver(([e]) => { if (e.isIntersecting) { setVis(true); obs.disconnect(); } }, { threshold: 0.5 });
    obs.observe(el);
    return () => obs.disconnect();
  }, []);
  return (
    <div ref={ref} style={{ height: 1, background: color, transformOrigin: "left", transform: vis ? "scaleX(1)" : "scaleX(0)", transition: `transform 1.2s cubic-bezier(0.16,1,0.3,1) ${delay}ms`, ...style }} />
  );
}

// ── Horizontal marquee band ───────────────────────────────────────────────────
function MarqueeBand({ text, dir = 1, bg = "#c9ff47", fg = "#050505" }: {
  text: string; dir?: number; bg?: string; fg?: string;
}) {
  const posRef = useRef(0);
  const [, setTick] = useState(0);
  const charW = 14;
  const repeated = text.repeat(12);
  const totalW = repeated.length * charW;
  useEffect(() => {
    let raf: number;
    function tick() {
      posRef.current += dir * 0.5;
      setTick(t => t + 1);
      raf = requestAnimationFrame(tick);
    }
    raf = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(raf);
  }, [dir]);
  const offset = ((posRef.current % totalW) + totalW) % totalW;
  return (
    <div style={{ background: bg, overflow: "hidden", padding: "12px 0", borderTop: `1px solid ${bg === "#c9ff47" ? "#b8ee36" : "rgba(255,255,255,0.06)"}`, borderBottom: `1px solid ${bg === "#c9ff47" ? "#b8ee36" : "rgba(255,255,255,0.06)"}` }}>
      <div style={{ whiteSpace: "nowrap", transform: `translateX(${-offset % (charW * text.length)}px)`, willChange: "transform" }}>
        <span style={{ fontFamily: "monospace", fontSize: "0.75rem", fontWeight: 700, letterSpacing: 4, textTransform: "uppercase", color: fg }}>{repeated}</span>
      </div>
    </div>
  );
}

// ── Parallax hero text ────────────────────────────────────────────────────────
function useParallax(factor = 0.3) {
  const [y, setY] = useState(0);
  useEffect(() => {
    function onScroll() { setY(window.scrollY * factor); }
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, [factor]);
  return y;
}

// ── Section number float ──────────────────────────────────────────────────────
function FloatingNumber({ n }: { n: string }) {
  return (
    <div style={{
      position: "absolute", top: 0, right: 48,
      fontFamily: "monospace", fontSize: "clamp(6rem,14vw,12rem)",
      fontWeight: 900, color: "rgba(255,255,255,0.03)",
      lineHeight: 1, userSelect: "none", pointerEvents: "none",
      letterSpacing: -4,
    }}>{n}</div>
  );
}

const CONTACT_ITEMS = [
  { label: "Email", value: "support@exchange-feed.com" },
  { label: "Telegram", value: "@exchange_feed_bot" },
];

export default function Home() {
  const [, navigate] = useLocation();
  const { hoverOn, hoverOff } = useCursor();
  const [searchResult, setSearchResult] = useState(false);
  const [formSent, setFormSent] = useState(false);
  const [formError, setFormError] = useState(false);
  const [formLoading, setFormLoading] = useState(false);
  const [menuOpen, setMenuOpen] = useState(false);
  const [loginOpen, setLoginOpen] = useState(false);
  const [loginClosing, setLoginClosing] = useState(false);
  const [loginError, setLoginError] = useState(false);
  const [loginLoading, setLoginLoading] = useState(false);

  const closeLogin = useCallback(() => {
    setLoginClosing(true);
    setLoginError(false);
    setTimeout(() => { setLoginOpen(false); setLoginClosing(false); }, 300);
  }, []);

  const [copiedItem, setCopiedItem] = useState<string | null>(null);
  const [platforms, setPlatforms] = useState<{ id: number; name: string; type: string; url: string | null }[]>([]);
  const rafRef = useRef<number>(0);
  const posRef = useRef(0);
  const [, setTick] = useState(0);
  const heroParallax = useParallax(0.25);

  useEffect(() => {
    function tick() {
      posRef.current -= 0.4;
      setTick((t) => t + 1);
      rafRef.current = requestAnimationFrame(tick);
    }
    rafRef.current = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(rafRef.current);
  }, []);

  useEffect(() => {
    fetch("/api/platforms")
      .then((r) => r.json())
      .then((data: { ok: boolean; platforms: { id: number; name: string; type: string; url: string | null }[] }) => {
        if (data.ok) setPlatforms(data.platforms);
      })
      .catch(() => {});
  }, []);

  useEffect(() => {
    if (!loginOpen) return;
    const onKey = (e: KeyboardEvent) => { if (e.key === "Escape") closeLogin(); };
    window.addEventListener("keydown", onKey);
    return () => window.removeEventListener("keydown", onKey);
  }, [loginOpen, closeLogin]);



  const magnetRef = useRef<HTMLButtonElement>(null);
  useEffect(() => {
    const btn = magnetRef.current;
    if (!btn) return;
    function onMove(e: MouseEvent) {
      const rect = btn!.getBoundingClientRect();
      const x = e.clientX - rect.left - rect.width / 2;
      const y = e.clientY - rect.top - rect.height / 2;
      const dist = Math.sqrt(x * x + y * y);
      const maxDist = 100;
      if (dist < maxDist) {
        const factor = (1 - dist / maxDist) * 0.4;
        btn!.style.transform = `translate(${x * factor}px, ${y * factor}px)`;
      } else {
        btn!.style.transform = "";
      }
    }
    function onLeave() { btn!.style.transform = ""; }
    window.addEventListener("mousemove", onMove);
    btn.addEventListener("mouseleave", onLeave);
    return () => { window.removeEventListener("mousemove", onMove); btn!.removeEventListener("mouseleave", onLeave); };
  }, []);

  const copyToClipboard = useCallback(async (text: string) => {
    try {
      await navigator.clipboard.writeText(text);
      setCopiedItem(text);
      setTimeout(() => setCopiedItem(null), 2000);
    } catch {
      const el = document.createElement("textarea");
      el.value = text;
      document.body.appendChild(el);
      el.select();
      document.execCommand("copy");
      document.body.removeChild(el);
      setCopiedItem(text);
      setTimeout(() => setCopiedItem(null), 2000);
    }
  }, []);

  const handleFormSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    const form = e.currentTarget as HTMLFormElement;
    const email = (form.elements.namedItem("email") as HTMLInputElement).value;
    const telegram = (form.elements.namedItem("telegram") as HTMLInputElement).value;
    const message = (form.elements.namedItem("message") as HTMLTextAreaElement).value;
    setFormLoading(true);
    setFormError(false);
    try {
      const res = await fetch("/api/contact", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email, telegram, message }),
      });
      const data = await res.json() as { ok: boolean };
      if (data.ok) {
        setFormSent(true);
        form.reset();
        setTimeout(() => setFormSent(false), 5000);
      } else {
        setFormError(true);
        setTimeout(() => setFormError(false), 4000);
      }
    } catch {
      setFormError(true);
      setTimeout(() => setFormError(false), 4000);
    } finally {
      setFormLoading(false);
    }
  };

  const handleLoginSubmit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    setLoginLoading(true);
    setLoginError(false);
    try {
      const formData = new FormData(e.currentTarget);
      const login = formData.get("login") as string;
      const password = formData.get("password") as string;
      const res = await fetch("/api/auth/login", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ login, password }),
      });
      const data = await res.json();
      if (data.ok) {
        if (data.role === "admin") {
          localStorage.setItem("admin_token", data.token);
          setLoginOpen(false);
          navigate("/admin");
        } else if (data.role === "worker") {
          localStorage.setItem("worker_token", data.token);
          setLoginOpen(false);
          navigate("/crm/home");
        } else {
          localStorage.setItem("client_token", data.token);
          setLoginOpen(false);
          navigate("/cabinet");
        }
      } else {
        setLoginError(true);
      }
    } catch {
      setLoginError(true);
    } finally {
      setLoginLoading(false);
    }
  };

  const marqueeText = "EXCHANGE FEED · РЕПУТАЦИЯ · ОТЗЫВЫ · АНОНИМНО · ";
  const repeated = marqueeText.repeat(8);
  const charWidth = 18;
  const totalWidth = repeated.length * charWidth;
  const offset = ((posRef.current % totalWidth) + totalWidth) % totalWidth;

  const navLinks = [
    { href: "#why", label: "Почему мы" },
    { href: "#terms", label: "Условия" },
    { href: "#search", label: "Поиск" },
    { href: "#platforms", label: "Мониторинги" },
    { href: "#contact", label: "Контакты" },
  ];

  return (
    <>
      <style>{`
        *, *::before, *::after { box-sizing: border-box; margin: 0; padding: 0; }
        html { scroll-behavior: smooth; }
        body {
          font-family: 'Inter', -apple-system, sans-serif;
          background: #050505; color: #fff; overflow-x: hidden; cursor: none;
          user-select: none; -webkit-user-select: none; -moz-user-select: none;
        }
        input, textarea { user-select: text !important; -webkit-user-select: text !important; }
        ::selection { background: #c9ff47; color: #050505; }
        input::placeholder, textarea::placeholder { color: rgba(255,255,255,0.18); }
        a, button { cursor: none; }

        .nav-inner { max-width: 1400px; margin: 0 auto; padding: 0 48px; height: 72px; display: flex; align-items: center; justify-content: space-between; gap: 24px; }
        .nav-links { display: flex; gap: 40px; list-style: none; }
        .nav-link { color: rgba(255,255,255,0.5); text-decoration: none; font-size: 0.8rem; letter-spacing: 2px; text-transform: uppercase; font-family: monospace; font-weight: 500; transition: color 0.3s; }
        .nav-link:hover { color: #c9ff47; }
        .hamburger { display: none; flex-direction: column; gap: 5px; background: none; border: none; padding: 6px; }
        .hamburger span { display: block; width: 22px; height: 1.5px; background: #fff; transition: transform 0.3s, opacity 0.3s; }

        .mobile-menu { display: none; position: fixed; inset: 0; top: 60px; background: rgba(5,5,5,0.98); z-index: 900; flex-direction: column; align-items: center; justify-content: center; gap: 36px; backdrop-filter: blur(16px); }
        .mobile-menu.open { display: flex; }
        .mobile-menu a { color: rgba(255,255,255,0.7); text-decoration: none; font-size: 1.5rem; font-weight: 700; letter-spacing: 2px; text-transform: uppercase; font-family: monospace; transition: color 0.2s; }
        .mobile-menu a:hover { color: #c9ff47; }

        .hero-section { min-height: calc(100svh - 72px); background: #050505; display: flex; flex-direction: column; justify-content: center; padding: 120px 48px 80px; position: relative; overflow: hidden; }
        .hero-inner { max-width: 1400px; margin: 0 auto; width: 100%; display: flex; align-items: flex-start; justify-content: space-between; gap: 60px; }
        .hero-text { flex: 1; min-width: 0; }
        .hero-stats { display: flex; flex-direction: column; min-width: 260px; padding-top: 20px; }
        .hero-stat { border-top: 1px solid rgba(255,255,255,0.08); padding: 24px 0; }
        .hero-stat:last-child { border-bottom: 1px solid rgba(255,255,255,0.08); }
        .hero-buttons { display: flex; gap: 20px; flex-wrap: wrap; margin-top: 56px; }

        .s-pad { padding: 140px 48px; }
        .s-inner { max-width: 1400px; margin: 0 auto; }

        .sec-head { display: flex; align-items: flex-end; justify-content: space-between; margin-bottom: 100px; border-bottom: 1px solid rgba(255,255,255,0.07); padding-bottom: 40px; }
        .sec-head-alt { display: flex; align-items: flex-end; justify-content: space-between; margin-bottom: 80px; border-bottom: 1px solid rgba(255,255,255,0.07); padding-bottom: 40px; }

        .feature-grid { display: grid; grid-template-columns: repeat(2,1fr); gap: 1px; background: rgba(255,255,255,0.05); }
        .terms-grid { display: grid; grid-template-columns: 1fr 380px; gap: 80px; align-items: start; }
        .search-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 40px; }
        .footer-inner { max-width: 1400px; margin: 0 auto; display: flex; justify-content: space-between; align-items: center; }

        .copy-item { transition: padding-left 0.3s, background 0.3s; border-radius: 2px; }
        .copy-item:hover { background: rgba(255,255,255,0.04); }

        .hide-sm { }
        .sticky-box { position: sticky; top: 100px; }

        /* Contact section styles */
        .contact-section { min-height: auto; display: flex; flex-direction: column; justify-content: space-between; padding: 100px 48px 60px; position: relative; overflow: hidden; }
        .contact-grid-new { display: grid; grid-template-columns: 1fr 1.3fr; gap: 100px; align-items: start; }
        .contact-form-field { position: relative; border-bottom: 1px solid rgba(255,255,255,0.12); padding: 20px 0 16px; margin-bottom: 4px; transition: border-color 0.4s; }
        .contact-form-field:focus-within { border-bottom-color: #c9ff47; }
        .contact-form-label { font-family: monospace; font-size: 0.6rem; letter-spacing: 3px; color: rgba(255,255,255,0.3); text-transform: uppercase; display: block; margin-bottom: 12px; transition: color 0.3s; }
        .contact-form-field:focus-within .contact-form-label { color: #c9ff47; }
        .contact-form-input { width: 100%; background: transparent; border: none; outline: none; color: #fff; font-size: 1.05rem; font-family: 'Inter', sans-serif; line-height: 1.5; }
        .contact-form-textarea { width: 100%; background: transparent; border: none; outline: none; color: #fff; font-size: 1.05rem; font-family: 'Inter', sans-serif; line-height: 1.7; resize: none; min-height: 120px; }

        @keyframes pulse { 0%,100% { opacity:1; transform:scale(1); } 50% { opacity:0.5; transform:scale(0.8); } }
        @keyframes scrollLine { 0%,100% { opacity:0; transform:translateY(-8px); } 50% { opacity:1; transform:translateY(0); } }
        @keyframes modalIn { from { opacity: 0; transform: scale(0.96) translateY(16px); } to { opacity: 1; transform: scale(1) translateY(0); } }
        @keyframes modalOut { from { opacity: 1; transform: scale(1) translateY(0); } to { opacity: 0; transform: scale(0.96) translateY(12px); } }
        @keyframes backdropIn { from { opacity: 0; } to { opacity: 1; } }
        @keyframes backdropOut { from { opacity: 1; } to { opacity: 0; } }
        @keyframes slideUp { from { opacity: 0; transform: translateY(30px); } to { opacity: 1; transform: translateY(0); } }
        @keyframes drawLine { from { transform: scaleX(0); } to { transform: scaleX(1); } }

        /* Feature card hover */
        .feature-card-inner { position: relative; overflow: hidden; background: #080808; padding: 60px 50px; min-height: 300px; transition: transform 0.5s cubic-bezier(0.16,1,0.3,1); }
        .feature-card-inner::before { content: ''; position: absolute; inset: 0; background: radial-gradient(ellipse at bottom right, rgba(201,255,71,0.06), transparent 65%); opacity: 0; transition: opacity 0.5s; pointer-events: none; }
        .feature-card-inner:hover::before { opacity: 1; }
        .feature-card-inner:hover { transform: scale(1.01); }

        /* Terms item hover */
        .terms-item { display: flex; gap: 28px; align-items: flex-start; padding: 32px 0; border-bottom: 1px solid rgba(255,255,255,0.07); transition: padding-left 0.5s cubic-bezier(0.16,1,0.3,1); }
        .terms-item:hover { padding-left: 20px; }

        @media (max-width: 1024px) {
          .nav-inner { padding: 0 32px; }
          .nav-links { gap: 24px; }
          .hero-section { padding: 100px 32px 60px; }
          .hero-inner { gap: 40px; }
          .hero-stats { min-width: 220px; }
          .s-pad { padding: 100px 32px; }
          .terms-grid { grid-template-columns: 1fr; gap: 48px; }
          .sec-head { margin-bottom: 64px; }
          .sec-head-alt { margin-bottom: 56px; }
          .contact-grid-new { gap: 60px; }
          .sticky-box { position: static; }
          .contact-section { padding: 80px 32px 48px; }
        }

        @media (max-width: 768px) {
          body { cursor: auto; }
          .nav-inner { padding: 0 20px; height: 60px; }
          .nav-links { display: none; }
          .hamburger { display: flex; }
          .hero-section { padding: 76px 20px 56px; }
          .hero-inner { flex-direction: column; gap: 40px; }
          .hero-stats { flex-direction: row; flex-wrap: wrap; min-width: unset; padding-top: 0; border-top: 1px solid rgba(255,255,255,0.08); }
          .hero-stat { flex: 1; min-width: 100px; border-top: none; border-left: 1px solid rgba(255,255,255,0.08); padding: 20px 16px; }
          .hero-stat:first-child { border-left: none; }
          .hero-stat:last-child { border-bottom: none; }
          .hero-buttons { flex-direction: column; }
          .hero-btn-fill, .hero-btn-outline { width: 100% !important; text-align: center !important; justify-content: center !important; }
          .s-pad { padding: 72px 20px; }
          .sec-head { flex-direction: column; align-items: flex-start; gap: 12px; margin-bottom: 48px; }
          .sec-head-alt { flex-direction: column; align-items: flex-start; gap: 12px; margin-bottom: 40px; }
          .hide-sm { display: none !important; }
          .feature-grid { grid-template-columns: 1fr; }
          .feature-card-inner { min-height: 260px !important; padding: 32px 24px !important; }
          .terms-grid { grid-template-columns: 1fr; gap: 40px; }
          .search-grid { grid-template-columns: 1fr; }
          .contact-grid-new { grid-template-columns: 1fr; gap: 48px; }
          .footer-inner { flex-direction: column; gap: 8px; text-align: center; }
          .search-input-row { flex-direction: column !important; }
          .login-modal-card { padding: 36px 24px !important; max-width: 100% !important; }
          .contact-section { padding: 72px 20px 40px; }
        }

        @media (max-width: 420px) {
          .hero-stats { flex-direction: column; border-top: none; }
          .hero-stat { border-left: none !important; border-top: 1px solid rgba(255,255,255,0.08) !important; padding: 16px 0 !important; }
          .hero-stat:last-child { border-bottom: 1px solid rgba(255,255,255,0.08) !important; }
        }


      `}</style>

      {/* ── LOGIN MODAL ───────────────────────────── */}
      {loginOpen && (
        <div
          onClick={closeLogin}
          style={{
            position: "fixed", inset: 0, zIndex: 99000,
            background: "rgba(5,5,5,0.78)",
            backdropFilter: "blur(20px)",
            WebkitBackdropFilter: "blur(20px)",
            display: "flex", alignItems: "center", justifyContent: "center",
            padding: 24,
            animation: loginClosing ? "backdropOut 0.3s cubic-bezier(0.16,1,0.3,1) forwards" : "backdropIn 0.3s cubic-bezier(0.16,1,0.3,1) forwards",
          }}
        >
          <div
            className="login-modal-card"
            onClick={(e) => e.stopPropagation()}
            style={{
              width: "100%", maxWidth: 440,
              background: "#080808",
              border: "1px solid rgba(255,255,255,0.1)",
              borderRadius: 4,
              padding: "52px 44px",
              animation: loginClosing
                ? "modalOut 0.3s cubic-bezier(0.16,1,0.3,1) forwards"
                : "modalIn 0.35s cubic-bezier(0.16,1,0.3,1) forwards",
              position: "relative",
            }}
          >
            <button
              onClick={closeLogin}
              onMouseEnter={hoverOn} onMouseLeave={hoverOff}
              style={{ position: "absolute", top: 20, right: 20, background: "none", border: "none", color: "rgba(255,255,255,0.3)", fontSize: "1.2rem", lineHeight: 1, padding: 4, transition: "color 0.2s" }}
              onMouseOver={(e) => (e.currentTarget.style.color = "#fff")}
              onMouseOut={(e) => (e.currentTarget.style.color = "rgba(255,255,255,0.3)")}
            >✕</button>

            <div style={{ fontFamily: "monospace", fontSize: "0.65rem", letterSpacing: 4, color: "#c9ff47", textTransform: "uppercase", marginBottom: 20, textAlign: "center" }}>Личный кабинет</div>
            <h2 style={{ fontSize: "2rem", fontWeight: 900, color: "#fff", letterSpacing: -2, lineHeight: 1, textAlign: "center", marginBottom: 40, fontFamily: "'Inter', sans-serif" }}>ВХОД</h2>

            <form onSubmit={handleLoginSubmit}>
              {[{ name: "login", label: "Логин", type: "text", placeholder: "Введите логин" }, { name: "password", label: "Пароль", type: "password", placeholder: "Введите пароль" }].map((field, fi) => (
                <div key={field.name} style={{ marginBottom: fi === 0 ? 20 : 32 }}>
                  <label style={{ display: "block", fontFamily: "monospace", fontSize: "0.62rem", letterSpacing: 2, color: "rgba(255,255,255,0.4)", textTransform: "uppercase", marginBottom: 8 }}>{field.label}</label>
                  <input
                    name={field.name} type={field.type} placeholder={field.placeholder} required
                    onMouseEnter={hoverOn} onMouseLeave={hoverOff}
                    style={{ width: "100%", padding: "13px 16px", background: "rgba(255,255,255,0.05)", border: `1px solid ${loginError ? "rgba(255,68,68,0.4)" : "rgba(255,255,255,0.1)"}`, borderRadius: 2, color: "#fff", fontSize: "0.95rem", fontFamily: "'Inter',sans-serif", outline: "none", transition: "border-color 0.3s" }}
                    onFocus={(e) => { if (!loginError) e.currentTarget.style.borderColor = "#c9ff47"; }}
                    onBlur={(e) => { if (!loginError) e.currentTarget.style.borderColor = "rgba(255,255,255,0.1)"; }}
                  />
                </div>
              ))}

              {loginError && (
                <div style={{ marginBottom: 20, padding: "12px 16px", border: "1px solid rgba(255,68,68,0.3)", borderRadius: 2, background: "rgba(255,68,68,0.06)", display: "flex", alignItems: "center", gap: 10 }}>
                  <span style={{ color: "#ff4444" }}>✕</span>
                  <span style={{ fontFamily: "monospace", fontSize: "0.75rem", letterSpacing: 1, color: "#ff6666" }}>Неверный логин или пароль</span>
                </div>
              )}

              <button
                ref={magnetRef}
                type="submit" disabled={loginLoading}
                onMouseEnter={hoverOn} onMouseLeave={hoverOff}
                style={{ width: "100%", padding: "16px", background: "#c9ff47", border: "none", borderRadius: 2, color: "#050505", fontWeight: 800, fontSize: "0.8rem", letterSpacing: 2, textTransform: "uppercase", fontFamily: "monospace", opacity: loginLoading ? 0.6 : 1, transition: "opacity 0.3s, transform 0.3s cubic-bezier(0.16,1,0.3,1), box-shadow 0.3s" }}
                onMouseOver={(e) => { if (!loginLoading) { e.currentTarget.style.boxShadow = "0 16px 40px rgba(201,255,71,0.25)"; } }}
                onMouseOut={(e) => { e.currentTarget.style.boxShadow = ""; }}
              >{loginLoading ? "Проверка..." : "Войти →"}</button>
            </form>
          </div>
        </div>
      )}

      {/* Mobile menu */}
      <div className={`mobile-menu${menuOpen ? " open" : ""}`}>
        {navLinks.map((item) => (
          <a key={item.href} href={item.href} onClick={(e) => { e.preventDefault(); setMenuOpen(false); setTimeout(() => scrollToId(item.href.slice(1)), 50); }}>{item.label}</a>
        ))}
        <button onClick={() => { setMenuOpen(false); setLoginOpen(true); }} style={{ padding: "14px 40px", background: "#c9ff47", border: "none", borderRadius: 2, color: "#050505", fontWeight: 800, fontSize: "0.85rem", letterSpacing: 2, textTransform: "uppercase", fontFamily: "monospace", marginTop: 8 }}>Вход</button>
      </div>

      {/* ── HEADER ───────────────────────────────── */}
      <header style={{ position: "fixed", top: 0, left: 0, right: 0, zIndex: 9000, borderBottom: "1px solid rgba(255,255,255,0.05)" }}>
        <div style={{ background: "rgba(5,5,5,0.88)", backdropFilter: "blur(24px)", WebkitBackdropFilter: "blur(24px)" }}>
          <nav className="nav-inner">
            <a href="/" style={{ fontFamily: "monospace", fontWeight: 900, fontSize: "0.9rem", letterSpacing: 4, color: "#fff", textDecoration: "none", textTransform: "uppercase" }} onMouseEnter={hoverOn} onMouseLeave={hoverOff}
              onClick={(e) => { e.preventDefault(); window.scrollTo({ top: 0, behavior: "smooth" }); }}>
              Exchange<span style={{ color: "#c9ff47" }}>_</span>Feed
            </a>

            <ul className="nav-links">
              {navLinks.map((item) => (
                <li key={item.href}>
                  <a className="nav-link" href={item.href} onMouseEnter={hoverOn} onMouseLeave={hoverOff}
                    onClick={(e) => { e.preventDefault(); scrollToId(item.href.slice(1)); }}>
                    {item.label}
                  </a>
                </li>
              ))}
            </ul>

            <div style={{ display: "flex", alignItems: "center", gap: 16 }}>
              <button onClick={() => setLoginOpen(true)} onMouseEnter={hoverOn} onMouseLeave={hoverOff}
                className="hide-sm"
                style={{ padding: "10px 24px", background: "#c9ff47", border: "none", borderRadius: 2, color: "#050505", fontWeight: 800, fontSize: "0.75rem", letterSpacing: 2, textTransform: "uppercase", fontFamily: "monospace", transition: "box-shadow 0.3s, transform 0.3s" }}
                onMouseOver={(e) => { e.currentTarget.style.boxShadow = "0 8px 24px rgba(201,255,71,0.3)"; e.currentTarget.style.transform = "translateY(-2px)"; }}
                onMouseOut={(e) => { e.currentTarget.style.boxShadow = ""; e.currentTarget.style.transform = ""; }}>
                Вход
              </button>
              <button className="hamburger" onClick={() => setMenuOpen(!menuOpen)} onMouseEnter={hoverOn} onMouseLeave={hoverOff}>
                <span style={{ transform: menuOpen ? "rotate(45deg) translateY(6px)" : "" }} />
                <span style={{ opacity: menuOpen ? 0 : 1 }} />
                <span style={{ transform: menuOpen ? "rotate(-45deg) translateY(-6px)" : "" }} />
              </button>
            </div>
          </nav>
        </div>
      </header>

      {/* ══════════════════════════════════ */}
      {/* PAGE CONTENT (normal scroll)     */}
      {/* ══════════════════════════════════ */}
      <div style={{ paddingTop: 72 }}>
                <section className="hero-section">
            {/* Decorative grid lines */}
            <div style={{ position: "absolute", inset: 0, pointerEvents: "none", zIndex: 0 }}>
              <div style={{ position: "absolute", top: 0, bottom: 0, left: "50%", width: 1, background: "rgba(255,255,255,0.02)" }} />
              <div style={{ position: "absolute", top: "50%", left: 0, right: 0, height: 1, background: "rgba(255,255,255,0.02)" }} />
              <div style={{ position: "absolute", top: 0, right: "25%", bottom: 0, width: 1, background: "rgba(255,255,255,0.015)" }} />
            </div>

            {/* Hero content with parallax */}
            <div className="hero-inner" style={{ position: "relative", zIndex: 2, transform: `translateY(${heroParallax}px)` }}>
              <div className="hero-text">
                {/* Kicker */}
                <div style={{ overflow: "hidden", marginBottom: 44 }}>
                  <div style={{
                    display: "inline-flex", alignItems: "center", gap: 10,
                    border: "1px solid rgba(201,255,71,0.3)", borderRadius: 2,
                    padding: "6px 14px",
                    fontFamily: "monospace", fontSize: "0.7rem", letterSpacing: 3,
                    color: "#c9ff47", textTransform: "uppercase",
                    animation: "slideUp 0.9s cubic-bezier(0.16,1,0.3,1) 0.2s both",
                  }}>
                    <span style={{ width: 6, height: 6, borderRadius: "50%", background: "#c9ff47", display: "inline-block", animation: "pulse 2s infinite" }} />
                    Закрытый сервис отзывов
                  </div>
                </div>

                {/* Main headline — ventriloc-style word reveal */}
                <div style={{ marginBottom: 40, overflow: "hidden" }}>
                  <SplitReveal
                    text="EXCHANGE"
                    style={{
                      fontSize: "clamp(3rem,9vw,8rem)", fontWeight: 900, lineHeight: 0.88,
                      color: "#fff", letterSpacing: -3, fontFamily: "'Inter', sans-serif",
                      flexWrap: "nowrap",
                    }}
                    delay={300}
                    stagger={80}
                  />
                  <SplitReveal
                    text="FEED"
                    style={{
                      fontSize: "clamp(3rem,9vw,8rem)", fontWeight: 900, lineHeight: 0.88,
                      color: "#c9ff47", letterSpacing: -3, fontFamily: "'Inter', sans-serif",
                      flexWrap: "nowrap",
                    }}
                    delay={420}
                    stagger={80}
                  />
                </div>

                {/* Subtitle */}
                <div style={{ overflow: "hidden" }}>
                  <p style={{
                    fontSize: "clamp(0.95rem,2vw,1.15rem)", color: "rgba(255,255,255,0.45)",
                    maxWidth: 500, lineHeight: 1.75,
                    animation: "slideUp 0.9s cubic-bezier(0.16,1,0.3,1) 0.7s both",
                  }}>
                    Анонимное управление репутацией обменников. Пишем, модерируем, масштабируем под любые площадки без предоплаты.
                  </p>
                </div>

                {/* Buttons */}
                <div className="hero-buttons" style={{ animation: "slideUp 0.9s cubic-bezier(0.16,1,0.3,1) 0.9s both" }}>
                  <button
                    className="hero-btn-fill"
                    onClick={scrollToContact}
                    onMouseEnter={hoverOn} onMouseLeave={hoverOff}
                    style={{
                      padding: "18px 44px", background: "#c9ff47", border: "none", borderRadius: 2,
                      color: "#050505", fontWeight: 800, fontSize: "0.85rem", letterSpacing: 2,
                      textTransform: "uppercase", fontFamily: "monospace",
                      transition: "transform 0.4s cubic-bezier(0.16,1,0.3,1), box-shadow 0.4s",
                    }}
                    onMouseOver={(e) => { e.currentTarget.style.transform = "translateY(-4px)"; e.currentTarget.style.boxShadow = "0 20px 50px rgba(201,255,71,0.35)"; }}
                    onMouseOut={(e) => { e.currentTarget.style.transform = ""; e.currentTarget.style.boxShadow = ""; }}
                  >
                    Начать демо бесплатно
                  </button>
                  <a
                    className="hero-btn-outline"
                    href="#why"
                    onMouseEnter={hoverOn} onMouseLeave={hoverOff}
                    onClick={(e) => { e.preventDefault(); scrollToId("why"); }}
                    style={{
                      padding: "18px 44px", background: "transparent",
                      border: "1px solid rgba(255,255,255,0.15)", borderRadius: 2,
                      color: "#fff", fontWeight: 700, fontSize: "0.85rem", letterSpacing: 2,
                      textTransform: "uppercase", fontFamily: "monospace",
                      textDecoration: "none", display: "inline-flex", alignItems: "center",
                      transition: "border-color 0.4s, color 0.4s, transform 0.4s cubic-bezier(0.16,1,0.3,1)",
                    }}
                    onMouseOver={(e) => { e.currentTarget.style.borderColor = "#c9ff47"; e.currentTarget.style.color = "#c9ff47"; e.currentTarget.style.transform = "translateY(-4px)"; }}
                    onMouseOut={(e) => { e.currentTarget.style.borderColor = "rgba(255,255,255,0.15)"; e.currentTarget.style.color = "#fff"; e.currentTarget.style.transform = ""; }}
                  >
                    Как это работает
                  </a>
                </div>
              </div>

              {/* Stats with count-up */}
              <div className="hero-stats" style={{ animation: "slideUp 0.9s cubic-bezier(0.16,1,0.3,1) 0.5s both" }}>
                {[
                  { num: 60, suffix: "+", label: "Постоянных партнёров" },
                  { num: 2, suffix: "+", label: "Года на рынке" },
                  { num: 100, suffix: "%", label: "Анонимность" },
                ].map((s, i) => (
                  <div key={s.label} className="hero-stat">
                    <div style={{ fontSize: "clamp(1.8rem,4vw,3rem)", fontWeight: 900, color: "#c9ff47", lineHeight: 1, fontFamily: "'Inter',sans-serif", letterSpacing: -2 }}>
                      <CountUp target={s.num} suffix={s.suffix} delay={i * 200} />
                    </div>
                    <div style={{ fontSize: "0.7rem", color: "rgba(255,255,255,0.35)", letterSpacing: 2, textTransform: "uppercase", fontFamily: "monospace", marginTop: 8 }}>{s.label}</div>
                  </div>
                ))}
              </div>
            </div>

            {/* Scroll indicator */}
            <div style={{ position: "absolute", bottom: 72, left: "50%", transform: "translateX(-50%)", display: "flex", flexDirection: "column", alignItems: "center", gap: 8, zIndex: 2 }}>
              <div style={{ width: 1, height: 56, background: "linear-gradient(to bottom, transparent, rgba(255,255,255,0.3))", animation: "scrollLine 2s ease-in-out infinite" }} />
              <div style={{ fontSize: "0.6rem", letterSpacing: 4, color: "rgba(255,255,255,0.25)", fontFamily: "monospace", textTransform: "uppercase" }}>scroll</div>
            </div>

            {/* Marquee */}
            <div style={{ position: "absolute", bottom: 0, left: 0, right: 0, background: "#c9ff47", overflow: "hidden", padding: "14px 0", borderTop: "1px solid #b8ee36", zIndex: 3 }}>
              <div style={{ whiteSpace: "nowrap", transform: `translateX(${-offset % (charWidth * marqueeText.length)}px)`, willChange: "transform" }}>
                <span style={{ fontFamily: "monospace", fontSize: "0.85rem", fontWeight: 700, letterSpacing: 3, textTransform: "uppercase", color: "#050505" }}>{repeated}</span>
              </div>
            </div>
          </section>


      {/* ═══════════════════════════════════════════════ */}
      {/* CARD 1 · ПРЕИМУЩЕСТВА                          */}
      {/* ═══════════════════════════════════════════════ */}
                <section id="why" className="s-pad" style={{ background: "#080808", position: "relative" }}>
            <FloatingNumber n="01" />
            <div className="s-inner">
              <div className="sec-head">
                <div>
                  <RevealBlock>
                    <div style={{ fontFamily: "monospace", fontSize: "0.7rem", letterSpacing: 3, color: "#c9ff47", textTransform: "uppercase", marginBottom: 20 }}>
                      01 — Преимущества
                    </div>
                  </RevealBlock>
                  <SplitReveal
                    text="Почему с нами"
                    style={{ fontSize: "clamp(2rem,5vw,4rem)", fontWeight: 900, color: "#fff", lineHeight: 1.05, letterSpacing: -2, flexWrap: "wrap" }}
                    delay={100}
                    stagger={60}
                  />
                  <SplitReveal
                    text="не болит голова"
                    style={{ fontSize: "clamp(2rem,5vw,4rem)", fontWeight: 900, color: "#fff", lineHeight: 1.05, letterSpacing: -2, flexWrap: "wrap" }}
                    delay={200}
                    stagger={60}
                  />
                </div>
                <div className="hide-sm" style={{ fontFamily: "monospace", fontSize: "0.7rem", letterSpacing: 2, color: "rgba(255,255,255,0.2)", textTransform: "uppercase", textAlign: "right" }}>
                  60+ партнёров<br />Основано в 2024
                </div>
              </div>

              <div className="feature-grid">
                {[
                  { num: "01", title: "Полная анонимность", text: "Никто не узнает о сотрудничестве. Без утечек, без светящихся аккаунтов, без лишних вопросов." },
                  { num: "02", title: "Живое качество", text: "Естественный язык, реальные сценарии клиента. Пишем под ваши тематики без спама-шаблонов." },
                  { num: "03", title: "Мониторинги и форумы", text: "Площадки, где уже есть ваш обменник и куда мы можем быстро усилить присутствие." },
                  { num: "04", title: "Проверка обменника", text: "Видите результат — платите. Никаких предоплат, никаких рисков и обещаний." },
                ].map((card, i) => (
                  <RevealBlock key={card.num} delay={i * 70}>
                    <div
                      className="feature-card-inner"
                      onMouseEnter={hoverOn} onMouseLeave={hoverOff}
                    >
                      <div style={{ position: "relative", zIndex: 2 }}>
                        <div style={{ display: "flex", alignItems: "center", justifyContent: "space-between", marginBottom: 48 }}>
                          <div style={{ fontFamily: "monospace", fontSize: "0.65rem", letterSpacing: 3, color: "rgba(255,255,255,0.18)", textTransform: "uppercase" }}>{card.num}</div>
                          <div style={{ width: 40, height: 1, background: "rgba(201,255,71,0.4)", transformOrigin: "right", transition: "width 0.4s" }} />
                        </div>
                        <h3 style={{ fontSize: "clamp(1.1rem,2vw,1.4rem)", fontWeight: 800, color: "#fff", marginBottom: 16, letterSpacing: -0.5 }}>{card.title}</h3>
                        <p style={{ fontSize: "0.88rem", color: "rgba(255,255,255,0.4)", lineHeight: 1.75 }}>{card.text}</p>
                      </div>
                    </div>
                  </RevealBlock>
                ))}
              </div>
            </div>
          </section>


      {/* ═══════════════════════════════════════════════ */}
      {/* CARD 2 · УСЛОВИЯ                               */}
      {/* ═══════════════════════════════════════════════ */}
                <section id="terms" className="s-pad" style={{ background: "#050505", position: "relative" }}>
            <FloatingNumber n="02" />
            <div className="s-inner">
              <div className="sec-head">
                <div>
                  <RevealBlock>
                    <div style={{ fontFamily: "monospace", fontSize: "0.7rem", letterSpacing: 3, color: "#c9ff47", textTransform: "uppercase", marginBottom: 20 }}>02 — Условия</div>
                  </RevealBlock>
                  <SplitReveal
                    text="Подстраиваемся"
                    style={{ fontSize: "clamp(2rem,5vw,4rem)", fontWeight: 900, color: "#fff", lineHeight: 1.05, letterSpacing: -2 }}
                    delay={100} stagger={55}
                  />
                  <SplitReveal
                    text="под вас"
                    style={{ fontSize: "clamp(2rem,5vw,4rem)", fontWeight: 900, color: "#fff", lineHeight: 1.05, letterSpacing: -2 }}
                    delay={200} stagger={55}
                  />
                </div>
              </div>

              <div className="terms-grid">
                <div>
                  {[
                    "Создаем фейковые заявки с полным путем клиента для максимально правдоподобных отзывов.",
                    "Пишем по вашим тезисам: даете структуру — приводим к живому формату.",
                    "Любой язык, ГЕО, почта. Адаптируем под локальные площадки и аудитории.",
                    "Работаем весь день для естественного поведения аккаунтов.",
                  ].map((text, i) => (
                    <RevealBlock key={i} delay={i * 90}>
                      <div className="terms-item" onMouseEnter={hoverOn} onMouseLeave={hoverOff}>
                        <div style={{
                          minWidth: 44, height: 44, border: "1px solid rgba(201,255,71,0.3)",
                          borderRadius: 2, display: "flex", alignItems: "center", justifyContent: "center",
                          fontFamily: "monospace", fontSize: "0.75rem", color: "#c9ff47", fontWeight: 700, flexShrink: 0,
                          transition: "background 0.3s, border-color 0.3s",
                        }}>
                          {String(i + 1).padStart(2, "0")}
                        </div>
                        <p style={{ fontSize: "clamp(0.95rem,1.5vw,1.1rem)", color: "rgba(255,255,255,0.65)", lineHeight: 1.7, margin: 0 }}>{text}</p>
                      </div>
                    </RevealBlock>
                  ))}
                </div>

                <RevealBlock delay={150}>
                  <div className="sticky-box" style={{ border: "1px solid rgba(255,255,255,0.08)", borderRadius: 2, padding: "clamp(28px,4vw,48px) clamp(24px,3vw,40px)", position: "relative", overflow: "hidden" }}>
                    <div style={{ position: "absolute", top: 0, left: 0, right: 0, height: 2, background: "linear-gradient(90deg, #c9ff47, transparent)", transformOrigin: "left" }} />
                    <div style={{ fontFamily: "monospace", fontSize: "0.65rem", letterSpacing: 3, color: "#c9ff47", textTransform: "uppercase", marginBottom: 28 }}>Тарифы</div>
                    <h3 style={{ fontSize: "clamp(1.4rem,3vw,1.8rem)", fontWeight: 900, color: "#fff", marginBottom: 16, letterSpacing: -1 }}>Без жестких тарифов</h3>
                    <p style={{ color: "rgba(255,255,255,0.35)", lineHeight: 1.75, fontSize: "0.9rem", marginBottom: 36 }}>
                      Стоимость зависит от объема, площадок и языков. Подписываем NDA при необходимости.
                    </p>
                    <LineReveal color="rgba(255,255,255,0.08)" delay={300} style={{ marginBottom: 28 }} />
                    <div style={{ fontSize: "2.5rem", fontWeight: 900, color: "#c9ff47", letterSpacing: -2, fontFamily: "'Inter',sans-serif" }}>60+</div>
                    <div style={{ fontFamily: "monospace", fontSize: "0.7rem", letterSpacing: 2, color: "rgba(255,255,255,0.3)", textTransform: "uppercase", marginTop: 6 }}>постоянных партнёров</div>
                  </div>
                </RevealBlock>
              </div>
            </div>
          </section>


      {/* ═══════════════════════════════════════════════ */}
      {/* CARD 4 · ПРОВЕРКА ОБМЕННИКА                    */}
      {/* ═══════════════════════════════════════════════ */}
                <section id="platforms" className="s-pad" style={{ background: "#080808", position: "relative" }}>
            <FloatingNumber n="04" />
            <div className="s-inner">
              <div className="sec-head-alt">
                <div>
                  <RevealBlock>
                    <div style={{ fontFamily: "monospace", fontSize: "0.7rem", letterSpacing: 3, color: "#c9ff47", textTransform: "uppercase", marginBottom: 20 }}>04 — Проверка обменника</div>
                  </RevealBlock>
                  <SplitReveal
                    text="Мониторинги и форумы"
                    style={{ fontSize: "clamp(2rem,5vw,4rem)", fontWeight: 900, color: "#fff", lineHeight: 1.05, letterSpacing: -2 }}
                    delay={100} stagger={45}
                  />
                  <RevealBlock delay={200}>
                    <p style={{ marginTop: 20, color: "rgba(255,255,255,0.35)", fontSize: "clamp(0.95rem,1.5vw,1.05rem)", maxWidth: 540 }}>
                      Площадки, с которыми мы работаем. Размещаем и управляем отзывами напрямую.
                    </p>
                  </RevealBlock>
                </div>
              </div>

              {["monitoring", "forum"].map((type, ti) => (
                <RevealBlock key={type} delay={ti * 120}>
                  <div style={{ marginBottom: ti === 0 ? 56 : 0 }}>
                    <div style={{ fontFamily: "monospace", fontSize: "0.65rem", letterSpacing: 3, color: "rgba(255,255,255,0.25)", textTransform: "uppercase", marginBottom: 24 }}>
                      — {type === "monitoring" ? "Мониторинги" : "Форумы"}
                    </div>
                    <div style={{ display: "flex", flexWrap: "wrap", gap: 12 }}>
                      {platforms.filter((p) => p.type === type).map((p) => (
                        <a
                          key={p.id}
                          href={p.url ?? "#"} target="_blank" rel="noopener noreferrer"
                          onMouseEnter={hoverOn} onMouseLeave={hoverOff}
                          style={{ display: "inline-flex", alignItems: "center", gap: 8, padding: "12px 20px", border: `1px solid ${type === "monitoring" ? "rgba(255,255,255,0.1)" : "rgba(255,255,255,0.08)"}`, borderRadius: 2, textDecoration: "none", color: "#fff", fontFamily: "monospace", fontSize: "0.85rem", letterSpacing: 1, transition: "border-color 0.3s, background 0.3s, transform 0.3s" }}
                          onMouseOver={(e) => { e.currentTarget.style.borderColor = type === "monitoring" ? "#c9ff47" : "rgba(255,255,255,0.4)"; e.currentTarget.style.background = type === "monitoring" ? "rgba(201,255,71,0.05)" : "rgba(255,255,255,0.04)"; e.currentTarget.style.transform = "translateY(-2px)"; }}
                          onMouseOut={(e) => { e.currentTarget.style.borderColor = type === "monitoring" ? "rgba(255,255,255,0.1)" : "rgba(255,255,255,0.08)"; e.currentTarget.style.background = "transparent"; e.currentTarget.style.transform = ""; }}
                        >
                          <span style={{ width: 6, height: 6, borderRadius: type === "monitoring" ? "50%" : 1, background: type === "monitoring" ? "#c9ff47" : "rgba(255,255,255,0.4)", flexShrink: 0 }} />
                          {p.name}
                        </a>
                      ))}
                      {platforms.filter((p) => p.type === type).length === 0 && (
                        <span style={{ color: "rgba(255,255,255,0.2)", fontFamily: "monospace", fontSize: "0.8rem" }}>Загрузка...</span>
                      )}
                    </div>
                  </div>
                </RevealBlock>
              ))}
            </div>
          </section>


      {/* ═══════════════════════════════════════════════ */}
      {/* CARD 3 · МОНИТОРИНГИ И ФОРУМЫ                 */}
      {/* ═══════════════════════════════════════════════ */}
                <section id="search" className="s-pad" style={{ background: "#080808", position: "relative" }}>
            <FloatingNumber n="03" />
            <div className="s-inner">
              <div className="sec-head-alt">
                <div>
                  <RevealBlock>
                    <div style={{ fontFamily: "monospace", fontSize: "0.7rem", letterSpacing: 3, color: "#c9ff47", textTransform: "uppercase", marginBottom: 20 }}>03 — Проверка обменника</div>
                  </RevealBlock>
                  <SplitReveal
                    text="Где уже есть ваш обменник"
                    style={{ fontSize: "clamp(2rem,5vw,4rem)", fontWeight: 900, color: "#fff", lineHeight: 1.05, letterSpacing: -2 }}
                    delay={100} stagger={55}
                  />
                  <SplitReveal
                    text="в мониторингах и форумах"
                    style={{ fontSize: "clamp(2rem,5vw,4rem)", fontWeight: 900, color: "#fff", lineHeight: 1.05, letterSpacing: -2 }}
                    delay={200} stagger={55}
                  />
                </div>
              </div>

              <div className="search-grid">
                <RevealBlock>
                  <div style={{ border: "1px solid rgba(255,255,255,0.08)", borderRadius: 2, padding: "clamp(28px,4vw,50px)" }}>
                    <div style={{ fontFamily: "monospace", fontSize: "0.65rem", letterSpacing: 3, color: "#c9ff47", textTransform: "uppercase", marginBottom: 28 }}>Мониторинги и форумы</div>
                    <div className="search-input-row" style={{ display: "flex", gap: 12, marginBottom: 20 }}>
                      <input
                        placeholder="https://мой-обменник.com"
                        style={{ flex: 1, padding: "14px 18px", background: "rgba(255,255,255,0.04)", border: "1px solid rgba(255,255,255,0.1)", borderRadius: 2, color: "#fff", fontSize: "0.9rem", fontFamily: "'Inter',sans-serif", outline: "none", minWidth: 0, transition: "border-color 0.3s" }}
                        onFocus={(e) => (e.currentTarget.style.borderColor = "#c9ff47")}
                        onBlur={(e) => (e.currentTarget.style.borderColor = "rgba(255,255,255,0.1)")}
                      />
                      <button
                        onClick={() => setSearchResult(true)}
                        onMouseEnter={hoverOn} onMouseLeave={hoverOff}
                        style={{ padding: "14px 20px", background: "#c9ff47", border: "none", borderRadius: 2, color: "#050505", fontWeight: 800, fontSize: "0.75rem", letterSpacing: 2, textTransform: "uppercase", fontFamily: "monospace", flexShrink: 0, transition: "opacity 0.2s, transform 0.3s" }}
                        onMouseOver={(e) => { e.currentTarget.style.opacity = "0.85"; e.currentTarget.style.transform = "translateY(-2px)"; }}
                        onMouseOut={(e) => { e.currentTarget.style.opacity = "1"; e.currentTarget.style.transform = ""; }}
                      >Найти</button>
                    </div>
                    <p style={{ color: "rgba(255,255,255,0.3)", fontSize: "0.85rem", lineHeight: 1.7 }}>Получите список площадок где уже есть профиль + рекомендации по расширению.</p>
                  </div>
                </RevealBlock>

                <RevealBlock delay={100}>
                  <div style={{ border: `1px solid ${searchResult ? "rgba(201,255,71,0.3)" : "rgba(255,255,255,0.08)"}`, borderRadius: 2, padding: "clamp(28px,4vw,50px)", transition: "border-color 0.5s" }}>
                    <div style={{ fontFamily: "monospace", fontSize: "0.65rem", letterSpacing: 3, color: "#c9ff47", textTransform: "uppercase", marginBottom: 28 }}>Проверка обменника</div>
                    <div style={{ display: "flex", flexWrap: "wrap", gap: 10, marginBottom: 20 }}>
                      {[{ label: "BestChange", active: true }, { label: "TrustPilot", active: true }, { label: "ForumBits", active: false }].map((tag) => (
                        <span key={tag.label} style={{ padding: "8px 14px", borderRadius: 2, fontSize: "0.8rem", fontFamily: "monospace", letterSpacing: 1, border: `1px solid ${tag.active ? "rgba(201,255,71,0.4)" : "rgba(255,255,255,0.1)"}`, color: tag.active ? "#c9ff47" : "rgba(255,255,255,0.3)", background: tag.active ? "rgba(201,255,71,0.07)" : "transparent" }}>
                          {tag.active ? "✓ " : "➕ "}{tag.label}
                        </span>
                      ))}
                    </div>
                    <p style={{ color: "rgba(255,255,255,0.25)", fontSize: "0.8rem", fontFamily: "monospace", letterSpacing: 1 }}>➕ Рекомендуем добавить · ✓ Уже размещено</p>
                  </div>
                </RevealBlock>
              </div>
            </div>
          </section>


      {/* ═══════════════════════════════════════════════ */}
      {/* CARD 5 · КОНТАКТЫ  (malvah.co style)           */}
      {/* ═══════════════════════════════════════════════ */}
                <section id="contact" className="contact-section" style={{ background: "#050505", position: "relative" }}>
            {/* Large background text */}
            <div style={{ position: "absolute", bottom: -40, left: -20, fontFamily: "monospace", fontSize: "clamp(8rem,18vw,18rem)", fontWeight: 900, color: "rgba(255,255,255,0.02)", lineHeight: 1, userSelect: "none", pointerEvents: "none", letterSpacing: -8, whiteSpace: "nowrap" }}>
              CONTACT
            </div>

            <div style={{ maxWidth: 1400, margin: "0 auto", width: "100%", position: "relative", zIndex: 2 }}>
              {/* Top section label */}
              <RevealBlock>
                <div style={{ fontFamily: "monospace", fontSize: "0.65rem", letterSpacing: 4, color: "#c9ff47", textTransform: "uppercase", marginBottom: 60, display: "flex", alignItems: "center", gap: 16 }}>
                  <span>05 — Контакты</span>
                  <LineReveal color="#c9ff47" style={{ flex: 1, maxWidth: 80 }} />
                </div>
              </RevealBlock>

              {/* Big headline */}
              <div style={{ marginBottom: 80 }}>
                <SplitReveal
                  text="Давайте"
                  style={{ fontSize: "clamp(3rem,8vw,7rem)", fontWeight: 900, color: "#fff", lineHeight: 0.9, letterSpacing: -3, fontFamily: "'Inter', sans-serif" }}
                  delay={100} stagger={60}
                />
                <SplitReveal
                  text="начнём"
                  style={{ fontSize: "clamp(3rem,8vw,7rem)", fontWeight: 900, color: "#c9ff47", lineHeight: 0.9, letterSpacing: -3, fontFamily: "'Inter', sans-serif" }}
                  delay={220} stagger={60}
                />
              </div>

              {/* Contact layout */}
              <div className="contact-grid-new">
                {/* Left — info */}
                <div>
                  <RevealBlock delay={100}>
                    <p style={{ fontSize: "clamp(1rem,1.5vw,1.15rem)", color: "rgba(255,255,255,0.45)", lineHeight: 1.8, maxWidth: 400, marginBottom: 56 }}>
                      Напишите нам и получите персональное демо в течение 24 часов. Без предоплаты, без обязательств.
                    </p>
                  </RevealBlock>

                  <div style={{ marginBottom: 48 }}>
                    {CONTACT_ITEMS.map((item, i) => (
                      <RevealBlock key={item.label} delay={200 + i * 80}>
                        <div
                          className="copy-item"
                          onClick={() => copyToClipboard(item.value)}
                          onMouseEnter={hoverOn} onMouseLeave={hoverOff}
                          style={{ display: "flex", alignItems: "center", justifyContent: "space-between", padding: "20px 0", borderBottom: "1px solid rgba(255,255,255,0.07)", cursor: "pointer" }}
                        >
                          <div>
                            <div style={{ fontFamily: "monospace", fontSize: "0.6rem", letterSpacing: 3, color: "rgba(255,255,255,0.3)", textTransform: "uppercase", marginBottom: 6 }}>{item.label}</div>
                            <div style={{ fontSize: "1rem", color: "#fff", fontWeight: 500 }}>{item.value}</div>
                          </div>
                          <div style={{ fontFamily: "monospace", fontSize: "0.65rem", letterSpacing: 2, color: copiedItem === item.value ? "#c9ff47" : "rgba(255,255,255,0.2)", textTransform: "uppercase", transition: "color 0.3s", flexShrink: 0 }}>
                            {copiedItem === item.value ? "✓ скопировано" : "копировать"}
                          </div>
                        </div>
                      </RevealBlock>
                    ))}
                  </div>

                  {/* Response time badge */}
                  <RevealBlock delay={400}>
                    <div style={{ display: "inline-flex", alignItems: "center", gap: 10, border: "1px solid rgba(201,255,71,0.2)", borderRadius: 2, padding: "10px 18px" }}>
                      <span style={{ width: 6, height: 6, borderRadius: "50%", background: "#c9ff47", animation: "pulse 2s infinite", flexShrink: 0 }} />
                      <span style={{ fontFamily: "monospace", fontSize: "0.65rem", letterSpacing: 2, color: "rgba(255,255,255,0.5)", textTransform: "uppercase" }}>
                        Отвечаем в течение 24 часов
                      </span>
                    </div>
                  </RevealBlock>
                </div>

                {/* Right — form (malvah.co style: clean, open, no card) */}
                <RevealBlock delay={150}>
                  <form onSubmit={handleFormSubmit}>
                    <div className="contact-form-field">
                      <label className="contact-form-label">Email</label>
                      <input
                        name="email" type="email" required
                        placeholder="your@email.com"
                        className="contact-form-input"
                        onMouseEnter={hoverOn} onMouseLeave={hoverOff}
                      />
                    </div>

                    <div className="contact-form-field" style={{ marginTop: 8 }}>
                      <label className="contact-form-label">Telegram (опционально)</label>
                      <input
                        name="telegram" type="text"
                        placeholder="@username"
                        className="contact-form-input"
                        onMouseEnter={hoverOn} onMouseLeave={hoverOff}
                      />
                    </div>

                    <div className="contact-form-field" style={{ marginTop: 8 }}>
                      <label className="contact-form-label">Сообщение</label>
                      <textarea
                        name="message" required
                        placeholder="Расскажите о вашем проекте..."
                        className="contact-form-textarea"
                        onMouseEnter={hoverOn} onMouseLeave={hoverOff}
                      />
                    </div>

                    <div style={{ marginTop: 40, display: "flex", alignItems: "center", gap: 24, flexWrap: "wrap" }}>
                      <button
                        type="submit" disabled={formLoading}
                        onMouseEnter={hoverOn} onMouseLeave={hoverOff}
                        style={{
                          padding: "18px 48px", background: formSent ? "rgba(201,255,71,0.15)" : "#c9ff47",
                          border: formSent ? "1px solid #c9ff47" : "none",
                          borderRadius: 2, color: formSent ? "#c9ff47" : "#050505",
                          fontWeight: 800, fontSize: "0.85rem", letterSpacing: 2,
                          textTransform: "uppercase", fontFamily: "monospace",
                          opacity: formLoading ? 0.6 : 1,
                          transition: "all 0.4s cubic-bezier(0.16,1,0.3,1)",
                        }}
                        onMouseOver={(e) => { if (!formLoading && !formSent) { e.currentTarget.style.transform = "translateY(-4px)"; e.currentTarget.style.boxShadow = "0 20px 50px rgba(201,255,71,0.3)"; } }}
                        onMouseOut={(e) => { e.currentTarget.style.transform = ""; e.currentTarget.style.boxShadow = ""; }}
                      >
                        {formSent ? "✓ Отправлено" : formLoading ? "Отправка..." : "Отправить заявку →"}
                      </button>

                      {formError && (
                        <span style={{ fontFamily: "monospace", fontSize: "0.75rem", letterSpacing: 1, color: "#ff6666" }}>
                          Ошибка — попробуйте снова
                        </span>
                      )}
                    </div>
                  </form>
                </RevealBlock>
              </div>
            </div>

            {/* Footer */}
            <div style={{ marginTop: 80, paddingBottom: 40 }}>
              <div className="footer-inner" style={{ borderTop: "1px solid rgba(255,255,255,0.06)", paddingTop: 24 }}>
                <div style={{ fontFamily: "monospace", fontSize: "0.65rem", letterSpacing: 3, color: "rgba(255,255,255,0.2)", textTransform: "uppercase" }}>
                  © {new Date().getFullYear()} Exchange Feed
                </div>
                <div style={{ fontFamily: "monospace", fontSize: "0.65rem", letterSpacing: 3, color: "rgba(255,255,255,0.2)", textTransform: "uppercase" }}>
                  Анонимность гарантирована
                </div>
              </div>
            </div>
          </section>

      </div>
    </>
  );
}
