import { useQuery, useMutation } from "@tanstack/react-query";
import { useState } from "react";
import { queryClient, apiRequest } from "@/lib/queryClient";
import { useToast } from "@/hooks/use-toast";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { insertClientSchema, type Client, type InsertClient } from "@shared/schema";
import { z } from "zod";
import { Plus, Pencil, Trash2, Search, BarChart2 } from "lucide-react";
import { useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogFooter } from "@/components/ui/dialog";
import { Form, FormField, FormItem, FormLabel, FormControl, FormMessage } from "@/components/ui/form";
import { Badge } from "@/components/ui/badge";

const formSchema = insertClientSchema.extend({
  name: z.string().min(1, "Name is required"),
});

const STATUS_LABELS: Record<string, { label: string; color: string }> = {
  in_work: { label: "In Work", color: "bg-green-100 text-green-700 dark:bg-green-900/40 dark:text-green-400" },
  potential: { label: "Potential", color: "bg-blue-100 text-blue-700 dark:bg-blue-900/40 dark:text-blue-400" },
  paused: { label: "Paused", color: "bg-yellow-100 text-yellow-700 dark:bg-yellow-900/40 dark:text-yellow-400" },
  refused: { label: "Refused", color: "bg-red-100 text-red-700 dark:bg-red-900/40 dark:text-red-400" },
};

interface Monitor {
  url: string;
  price: number;
  period: "day" | "week" | "month";
  quantity: number;
}

const getCalculatedQuantities = (period: "day" | "week" | "month", quantity: number) => {
  if (period === "day") {
    return { daily: quantity, weekly: quantity * 7, monthly: quantity * 30 };
  } else if (period === "week") {
    return { daily: Math.round(quantity / 7), weekly: quantity, monthly: Math.round(quantity * 4.3) };
  } else {
    return { daily: Math.round(quantity / 30), weekly: Math.round(quantity / 4.3), monthly: quantity };
  }
};

function ClientForm({
  defaultValues,
  onSubmit,
  isPending,
}: {
  defaultValues: Partial<InsertClient>;
  onSubmit: (data: InsertClient) => void;
  isPending: boolean;
}) {
  const [monitors, setMonitors] = useState<Monitor[]>([{ url: "", price: 0, period: "day", quantity: 0 }]);
  
  const form = useForm<InsertClient>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      name: "",
      email: "",
      phone: "",
      status: "potential",
      notes: "",
      wallets: "",
      ...defaultValues,
    },
  });

  const handleAddMonitor = () => {
    setMonitors([...monitors, { url: "", price: 0, period: "day" }]);
  };

  const handleMonitorChange = (index: number, field: keyof Monitor, value: any) => {
    const updated = [...monitors];
    updated[index] = { ...updated[index], [field]: value };
    setMonitors(updated);
  };

  const handleRemoveMonitor = (index: number) => {
    setMonitors(monitors.filter((_, i) => i !== index));
  };

  const handleSubmit = (data: InsertClient) => {
    onSubmit({
      ...data,
      wallets: JSON.stringify(monitors),
    });
  };

  return (
    <Form {...form}>
      <form onSubmit={form.handleSubmit(handleSubmit)} className="space-y-4">
        <FormField control={form.control} name="name" render={({ field }) => (
          <FormItem>
            <FormLabel>Client Name *</FormLabel>
            <FormControl><Input data-testid="input-client-name" placeholder="Client name" {...field} className="admin-input" /></FormControl>
            <FormMessage />
          </FormItem>
        )} />

        <FormField control={form.control} name="phone" render={({ field }) => (
          <FormItem>
            <FormLabel>Telegram</FormLabel>
            <FormControl><Input data-testid="input-client-telegram" placeholder="@username or phone" {...field} value={field.value ?? ""} className="admin-input" /></FormControl>
            <FormMessage />
          </FormItem>
        )} />

        <div className="grid grid-cols-2 gap-3">
          <FormField control={form.control} name="status" render={({ field }) => (
            <FormItem>
              <FormLabel>Status</FormLabel>
              <Select onValueChange={field.onChange} defaultValue={field.value}>
                <FormControl>
                  <SelectTrigger data-testid="select-client-status" className="admin-select">
                    <SelectValue placeholder="Select status" />
                  </SelectTrigger>
                </FormControl>
                <SelectContent>
                  <SelectItem value="in_work">In Work</SelectItem>
                  <SelectItem value="potential">Potential</SelectItem>
                  <SelectItem value="paused">Paused</SelectItem>
                  <SelectItem value="refused">Refused</SelectItem>
                </SelectContent>
              </Select>
              <FormMessage />
            </FormItem>
          )} />
          <FormField control={form.control} name="tz" render={({ field }) => (
            <FormItem>
              <FormLabel>Resource URL</FormLabel>
              <FormControl><Input data-testid="input-client-resource" placeholder="https://..." {...field} value={field.value ?? ""} className="admin-input" /></FormControl>
              <FormMessage />
            </FormItem>
          )} />
        </div>

        <FormField control={form.control} name="notes" render={({ field }) => (
          <FormItem>
            <FormLabel>Notes & Additional Info</FormLabel>
            <FormControl>
              <textarea
                data-testid="input-client-notes"
                placeholder="Additional information..."
                {...field}
                value={field.value ?? ""}
                className="admin-input w-full min-h-[60px] resize-none rounded-md border border-admin-border bg-admin-input px-3 py-2 text-sm text-admin-text placeholder:text-admin-muted focus:outline-none focus:ring-2 focus:ring-admin-accent"
              />
            </FormControl>
            <FormMessage />
          </FormItem>
        )} />

        <div className="space-y-4 border-t border-admin-border pt-4">
          <h3 className="text-sm font-semibold text-admin-text">Monitors</h3>
          {monitors.map((monitor, idx) => {
            const calc = getCalculatedQuantities(monitor.period, monitor.quantity);
            return (
              <div key={idx} className="space-y-2 p-3 bg-admin-card rounded-lg border border-admin-border">
                {/* Line 1: URL */}
                <div>
                  <label className="block text-xs text-admin-muted mb-1">Monitor URL</label>
                  <Input
                    placeholder="https://..."
                    value={monitor.url}
                    onChange={(e) => handleMonitorChange(idx, "url", e.target.value)}
                    className="admin-input"
                  />
                </div>

                {/* Line 2: Price | Period | Quantity with calculations */}
                <div className="grid grid-cols-3 gap-2">
                  <div>
                    <label className="block text-xs text-admin-muted mb-1">Price (USD)</label>
                    <Input
                      type="number"
                      step="0.01"
                      placeholder="0.00"
                      value={monitor.price || ""}
                      onChange={(e) => handleMonitorChange(idx, "price", parseFloat(e.target.value) || 0)}
                      className="admin-input"
                    />
                  </div>
                  <div>
                    <label className="block text-xs text-admin-muted mb-1">Period</label>
                    <Select value={monitor.period} onValueChange={(v) => handleMonitorChange(idx, "period", v as "day" | "week" | "month")}>
                      <SelectTrigger className="admin-select">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="day">Day</SelectItem>
                        <SelectItem value="week">Week</SelectItem>
                        <SelectItem value="month">Month</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                  <div>
                    <label className="block text-xs text-admin-muted mb-1">Quantity</label>
                    <Input
                      type="number"
                      placeholder="0"
                      value={monitor.quantity || ""}
                      onChange={(e) => handleMonitorChange(idx, "quantity", parseInt(e.target.value) || 0)}
                      className="admin-input"
                    />
                  </div>
                </div>

                {/* Calculated values */}
                {monitor.quantity > 0 && (
                  <div className="text-xs text-admin-muted space-y-1 pt-2 border-t border-admin-border">
                    <div>📅 Per day: <span className="text-admin-text font-semibold">{calc.daily}</span> reviews</div>
                    <div>📊 Per week: <span className="text-admin-text font-semibold">{calc.weekly}</span> reviews</div>
                    <div>📈 Per month: <span className="text-admin-text font-semibold">{calc.monthly}</span> reviews</div>
                  </div>
                )}

                {monitors.length > 1 && (
                  <Button
                    type="button"
                    variant="outline"
                    size="sm"
                    onClick={() => handleRemoveMonitor(idx)}
                    className="admin-btn-outline w-full h-8 mt-2"
                  >
                    Remove Monitor
                  </Button>
                )}
              </div>
            );
          })}
        </div>

        <div className="flex items-center justify-between pt-2">
          <Button
            type="button"
            variant="outline"
            size="sm"
            onClick={handleAddMonitor}
            className="admin-btn-outline"
          >
            + Add Monitor
          </Button>
          <Button data-testid="btn-submit-client" type="submit" disabled={isPending} className="admin-btn-primary">
            {isPending ? "Saving…" : "Save"}
          </Button>
        </div>
      </form>
    </Form>
  );
}

export default function Customers() {
  const { toast } = useToast();
  const [, navigate] = useLocation();
  const [search, setSearch] = useState("");
  const [statusFilter, setStatusFilter] = useState<string>("all");
  const [dialogOpen, setDialogOpen] = useState(false);
  const [editingClient, setEditingClient] = useState<Client | null>(null);
  const [deleteTarget, setDeleteTarget] = useState<Client | null>(null);
  const [viewingClient, setViewingClient] = useState<Client | null>(null);

  const { data: clients = [], isLoading } = useQuery<Client[]>({ queryKey: ["/api/clients"] });

  const createMutation = useMutation({
    mutationFn: (data: InsertClient) => apiRequest("POST", "/api/clients", data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/clients"] });
      toast({ title: "Client created" });
      setDialogOpen(false);
    },
    onError: () => toast({ title: "Failed to create client", variant: "destructive" }),
  });

  const updateMutation = useMutation({
    mutationFn: ({ id, data }: { id: string; data: Partial<InsertClient> }) =>
      apiRequest("PATCH", `/api/clients/${id}`, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/clients"] });
      toast({ title: "Client updated" });
      setDialogOpen(false);
      setEditingClient(null);
    },
    onError: () => toast({ title: "Failed to update client", variant: "destructive" }),
  });

  const deleteMutation = useMutation({
    mutationFn: (id: string) => apiRequest("DELETE", `/api/clients/${id}`),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["/api/clients"] });
      toast({ title: "Client deleted" });
      setDeleteTarget(null);
    },
    onError: () => toast({ title: "Failed to delete client", variant: "destructive" }),
  });

  const filtered = clients.filter(c => {
    const matchSearch = c.name.toLowerCase().includes(search.toLowerCase()) ||
      (c.email?.toLowerCase().includes(search.toLowerCase()) ?? false);
    const matchStatus = statusFilter === "all" || c.status === statusFilter;
    return matchSearch && matchStatus;
  });

  const openAdd = () => { setEditingClient(null); setDialogOpen(true); };
  const openEdit = (c: Client) => { setEditingClient(c); setDialogOpen(true); };

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-admin-text">Customers</h1>
          <p className="text-admin-muted text-sm mt-1">Manage your client base</p>
        </div>
        <Button data-testid="btn-add-client" onClick={openAdd} className="admin-btn-primary">
          <Plus size={16} className="mr-1.5" /> Add Client
        </Button>
      </div>

      <div className="flex flex-col sm:flex-row gap-3">
        <div className="relative flex-1">
          <Search size={15} className="absolute left-3 top-1/2 -translate-y-1/2 text-admin-muted" />
          <Input
            data-testid="input-search-clients"
            placeholder="Search by name..."
            value={search}
            onChange={e => setSearch(e.target.value)}
            className="pl-9 admin-input"
          />
        </div>
        <Select value={statusFilter} onValueChange={setStatusFilter}>
          <SelectTrigger data-testid="select-filter-status" className="w-40 admin-select">
            <SelectValue placeholder="All statuses" />
          </SelectTrigger>
          <SelectContent>
            <SelectItem value="all">All Statuses</SelectItem>
            <SelectItem value="in_work">In Work</SelectItem>
            <SelectItem value="potential">Potential</SelectItem>
            <SelectItem value="paused">Paused</SelectItem>
            <SelectItem value="refused">Refused</SelectItem>
          </SelectContent>
        </Select>
      </div>

      <div className="admin-card overflow-hidden">
        {isLoading ? (
          <div className="p-8 text-center text-admin-muted text-sm">Loading…</div>
        ) : filtered.length === 0 ? (
          <div className="p-8 text-center text-admin-muted text-sm">No clients found</div>
        ) : (
          <table className="w-full text-sm">
            <thead>
              <tr className="border-b border-admin-border">
                <th className="text-left px-4 py-3 text-admin-muted font-medium">Name</th>
                <th className="text-left px-4 py-3 text-admin-muted font-medium">Telegram</th>
                <th className="text-left px-4 py-3 text-admin-muted font-medium">Status</th>
                <th className="text-left px-4 py-3 text-admin-muted font-medium">Notes</th>
                <th className="text-right px-4 py-3 text-admin-muted font-medium">Actions</th>
              </tr>
            </thead>
            <tbody>
              {filtered.map((c, i) => {
                const st = STATUS_LABELS[c.status];
                return (
                  <tr key={c.id} data-testid={`row-client-${c.id}`}
                    onClick={() => setViewingClient(c)}
                    className={`border-b border-admin-border last:border-0 hover:bg-admin-hover transition-colors cursor-pointer ${i % 2 === 0 ? "" : ""}`}>
                    <td className="px-4 py-3 font-medium text-admin-text">{c.name}</td>
                    <td className="px-4 py-3 text-admin-muted">{c.phone || "—"}</td>
                    <td className="px-4 py-3">
                      <span className={`inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium ${st.color}`}>
                        {st.label}
                      </span>
                    </td>
                    <td className="px-4 py-3 text-admin-muted max-w-[200px] truncate">{c.notes || "—"}</td>
                    <td className="px-4 py-3">
                      <div className="flex items-center justify-end gap-1" onClick={e => e.stopPropagation()}>
                        <button
                          title="View Stats"
                          onClick={() => navigate(`/admin/customers/${c.id}/stats`)}
                          className="p-1.5 rounded-md text-admin-muted hover:text-admin-accent hover:bg-admin-accent/10 transition-colors"
                        >
                          <BarChart2 size={14} />
                        </button>
                        <button
                          data-testid={`btn-edit-client-${c.id}`}
                          onClick={() => openEdit(c)}
                          className="p-1.5 rounded-md text-admin-muted hover:text-admin-text hover:bg-admin-hover transition-colors"
                        >
                          <Pencil size={14} />
                        </button>
                        <button
                          data-testid={`btn-delete-client-${c.id}`}
                          onClick={() => setDeleteTarget(c)}
                          className="p-1.5 rounded-md text-admin-muted hover:text-red-500 hover:bg-red-50 dark:hover:bg-red-900/20 transition-colors"
                        >
                          <Trash2 size={14} />
                        </button>
                      </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        )}
      </div>

      <Dialog open={!!viewingClient} onOpenChange={o => { if (!o) setViewingClient(null); }}>
        <DialogContent className="admin-dialog">
          <DialogHeader>
            <DialogTitle className="text-admin-text">Client Information</DialogTitle>
          </DialogHeader>
          {viewingClient && (
            <div className="space-y-4">
              <div>
                <label className="text-xs text-admin-muted uppercase tracking-wide">Name</label>
                <p className="text-admin-text font-semibold mt-1">{viewingClient.name}</p>
              </div>
              <div>
                <label className="text-xs text-admin-muted uppercase tracking-wide">Telegram</label>
                <p className="text-admin-text mt-1">{viewingClient.phone || "—"}</p>
              </div>
              <div>
                <label className="text-xs text-admin-muted uppercase tracking-wide">Status</label>
                <div className="mt-1">
                  <span className={`inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium ${STATUS_LABELS[viewingClient.status].color}`}>
                    {STATUS_LABELS[viewingClient.status].label}
                  </span>
                </div>
              </div>
              <div>
                <label className="text-xs text-admin-muted uppercase tracking-wide">Resource URL</label>
                <p className="text-admin-text mt-1 break-all">{viewingClient.tz || "—"}</p>
              </div>
              <div>
                <label className="text-xs text-admin-muted uppercase tracking-wide">Notes</label>
                <p className="text-admin-text mt-1 whitespace-pre-wrap">{viewingClient.notes || "—"}</p>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>

      <Dialog open={dialogOpen} onOpenChange={o => { setDialogOpen(o); if (!o) setEditingClient(null); }}>
        <DialogContent className="admin-dialog">
          <DialogHeader>
            <DialogTitle className="text-admin-text">{editingClient ? "Edit Client" : "Add Client"}</DialogTitle>
          </DialogHeader>
          <ClientForm
            defaultValues={editingClient ?? {}}
            onSubmit={data => {
              if (editingClient) {
                updateMutation.mutate({ id: editingClient.id, data });
              } else {
                createMutation.mutate(data);
              }
            }}
            isPending={createMutation.isPending || updateMutation.isPending}
          />
        </DialogContent>
      </Dialog>

      <Dialog open={!!deleteTarget} onOpenChange={o => { if (!o) setDeleteTarget(null); }}>
        <DialogContent className="admin-dialog">
          <DialogHeader>
            <DialogTitle className="text-admin-text">Delete Client</DialogTitle>
          </DialogHeader>
          <p className="text-admin-muted text-sm">
            Are you sure you want to delete <strong className="text-admin-text">{deleteTarget?.name}</strong>? This action cannot be undone.
          </p>
          <DialogFooter className="gap-2">
            <Button variant="outline" onClick={() => setDeleteTarget(null)} className="admin-btn-outline">Cancel</Button>
            <Button
              data-testid="btn-confirm-delete-client"
              onClick={() => deleteTarget && deleteMutation.mutate(deleteTarget.id)}
              disabled={deleteMutation.isPending}
              className="bg-red-600 hover:bg-red-700 text-white"
            >
              {deleteMutation.isPending ? "Deleting…" : "Delete"}
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  );
}
